# Skill 3.2.2 验证报告

验证日期：2026-10-04。输入为桌面 ToMyFramework 中的 myframework-migration-3.2.1.zip；原包保留，未替换已安装技能，未修改游戏工程或提交 Git。

| 检查 | 实际结果 | 边界 |
|---|---|---|
| 原 3.2.1 完整性 | ZIP CRC 与 PACKAGE_FILES.sha256 全部匹配 | 不是迁移语义证明 |
| Python unittest | 109/109 通过 | 原有79项 + 本次30项；临时 fixtures，不执行 Unity |
| 脚本语法与 --help | 11 个全部通过 | Python 标准库 CLI 可启动 |
| skill-creator quick_validate | 通过 | 使用已有独立 validation-deps/PyYAML，未安装系统依赖 |
| frontmatter / agents YAML / JSON | 可解析，版本与 UI 元数据检查通过 | 项目模板仍需填真实事实 |
| Markdown 本地链接 | 全部目标存在，数量见 release_manifest.json | 不验证外部网站或 Markdown 锚点 |
| 真实 RPK 字节测量 | 默认文件口径 FAIL，显式分包口径 PASS | 只是同一产物两种口径，不认证后台受理 |
| 新 ZIP 完整性 | CRC 与解压后全部文件摘要匹配 | 打包完成后独立核验 |

测试日志：[audit_tools_unittest.txt](validation/audit_tools_unittest.txt)。真实字节记录：[quickgame_accounting_real_package.json](validation/quickgame_accounting_real_package.json)。

新增 tests 覆盖物理/分包/兼容包计量、压缩后 entry 与原字节数区别、边界值、改名保守计量、重复/危险路径、无 main 的未评估、只读与 CLI 返回码；UI 覆盖 Padding 旋转/缩放、嵌套变换/停靠 override、混合未解析 prefab、GUID身份冲突与无效枚举配置。

本次直接阅读目标框架 PaddingAnchor/ScaleAnchor/applyAnchor 源码确认计算前提。框架运行时禁用 MonoBehaviour 并不阻止 applyAnchor 显式更新，未添加 enabled=false 的错误拒绝规则。

入口缩短并将原详细阶段保留在 references/34；模块约束按任务范围适用，不要求修一个平台问题就全项目重构或自动修改 Skill。9个旧审计脚本未修改，仅 UI 适配脚本修复漏检，另新增 RPK 测量工具。

本次没有执行 Unity 编译、PlayMode、官方 UI/Excel Generator、真机、登录或上传，也没有验证新游戏版本。历史 R33/R34 和 template_coverage 记录只是原包保留的历史证据，不能当本次运行结果。实际包测量使用既有 0.6.1 产物，不把其过去运行测试追认为 Skill 自测。

重跑：`python -m unittest discover -s tests -v`。PACKAGE_FILES.sha256 是文件完整性摘要，不能证明工具语义或工程运行正确。
