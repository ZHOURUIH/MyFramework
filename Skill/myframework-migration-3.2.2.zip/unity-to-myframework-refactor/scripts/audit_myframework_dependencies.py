#!/usr/bin/env python3
"""Dependency / Assembly / Direct-Run integrity audit for MyFramework migrations.

Static checks:
- duplicate asmdef assembly names across Assets and compiled embedded/local Packages (non-imported package template folders such as ProjectTemplate~ are excluded);
- suspicious fake compatibility/stub paths under Assets;
- embedded Packages that are also listed in manifest.json (informational provenance overlap);
- project-configured direct-run runtime-critical artifacts exist in final staged root.

This does not replace Unity Package Manager resolution or Unity compilation.
"""
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path


DEFAULT_FORBIDDEN_PATH_FRAGMENTS = [
    "MyFrameworkCompatibility",
    "CompatibilityRuntime",
    "FakeCompatibility",
    "FakeRuntime",
    "FakeEditor",
    "PlaceholderRuntime",
    "PlaceholderEditor",
]


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize(path: str) -> str:
    return path.replace("\\", "/").lstrip("./")


def load_config(path: Path | None) -> dict:
    if path is None:
        return {}
    return read_json(path)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("root", type=Path)
    p.add_argument("--config", type=Path, help="MIGRATION_AUDIT_CONFIG.json")
    p.add_argument("--json", action="store_true")
    p.add_argument(
        "--fail-on",
        default="duplicate-asmdef,invalid-asmdef,fake-compat,missing-direct-run-artifact",
        help=(
            "comma-separated: duplicate-asmdef,invalid-asmdef,fake-compat,"
            "embedded-manifest-overlap,missing-direct-run-artifact"
        ),
    )
    return p.parse_args()


def main():
    args = parse_args()
    root = args.root.resolve()
    cfg = load_config(args.config)

    duplicate_allow = set(cfg.get("asmdef_duplicate_allowlist", []))
    forbidden_fragments = cfg.get(
        "forbidden_compatibility_path_fragments",
        DEFAULT_FORBIDDEN_PATH_FRAGMENTS,
    )
    direct_run_required = cfg.get("direct_run_required_artifacts", [])
    asmdef_scan_exclude_fragments = [
        str(x).strip() for x in cfg.get(
            "asmdef_scan_exclude_path_fragments",
            ["ProjectTemplate~", "Samples~", "Documentation~", "Tests~"],
        ) if str(x).strip()
    ]

    # 1) asmdef assembly names.
    asmdef_by_name: dict[str, list[str]] = defaultdict(list)
    invalid_asmdef = []
    scan_roots = [root / "Assets", root / "Packages"]
    for scan_root in scan_roots:
        if not scan_root.exists():
            continue
        for p in sorted(scan_root.rglob("*.asmdef")):
            posix = p.as_posix()
            if "/Library/" in posix or "/Temp/" in posix or "/obj/" in posix:
                continue
            rel = normalize(str(p.relative_to(root)))
            rel_parts = Path(rel).parts
            # Unity package template/sample/documentation folders conventionally end
            # with '~' and are not compiled as project assemblies. Counting their
            # asmdefs creates false duplicate Assembly-name failures in FullInstall.
            if any(part.endswith("~") for part in rel_parts):
                continue
            if any(frag.lower() in rel.lower() for frag in asmdef_scan_exclude_fragments):
                continue
            try:
                data = read_json(p)
            except Exception as e:
                invalid_asmdef.append({"file": rel, "error": str(e)})
                continue
            name = str(data.get("name", "")).strip()
            if name:
                asmdef_by_name[name].append(rel)

    duplicate_asmdef = [
        {"name": name, "files": files}
        for name, files in sorted(asmdef_by_name.items())
        if len(files) > 1 and name not in duplicate_allow
    ]

    # 2) fake compatibility/stub paths under Assets.
    fake_compat_paths = []
    assets = root / "Assets"
    if assets.exists():
        seen = set()
        for p in assets.rglob("*"):
            rel = normalize(str(p.relative_to(root)))
            parts = Path(rel).parts
            hit = next(
                (frag for frag in forbidden_fragments if any(frag.lower() in part.lower() for part in parts)),
                None,
            )
            if not hit:
                continue
            idx = next(
                i for i, part in enumerate(parts)
                if hit.lower() in part.lower()
            )
            prefix = normalize(str(Path(*parts[: idx + 1])))
            key = (prefix, hit)
            if key not in seen:
                seen.add(key)
                fake_compat_paths.append({"path": prefix, "fragment": hit})

    # 3) embedded package vs manifest declaration.
    embedded_packages = {}
    packages_root = root / "Packages"
    if packages_root.exists():
        for child in sorted(packages_root.iterdir()):
            if not child.is_dir():
                continue
            package_json = child / "package.json"
            if not package_json.exists():
                continue
            try:
                data = read_json(package_json)
            except Exception:
                continue
            name = str(data.get("name", "")).strip()
            if name:
                embedded_packages[name] = normalize(str(child.relative_to(root)))

    manifest_deps = {}
    manifest_path = packages_root / "manifest.json"
    if manifest_path.exists():
        try:
            manifest = read_json(manifest_path)
            manifest_deps = dict(manifest.get("dependencies", {}))
        except Exception:
            manifest_deps = {}

    embedded_manifest_overlaps = []
    for package_name, embedded_path in sorted(embedded_packages.items()):
        if package_name not in manifest_deps:
            continue
        source = str(manifest_deps[package_name])
        # Unity permits an embedded package to remain listed in manifest.json;
        # the embedded copy on disk takes precedence. Report this as provenance
        # information rather than a default failure.
        embedded_manifest_overlaps.append(
            {
                "package": package_name,
                "embedded_path": embedded_path,
                "manifest_source": source,
            }
        )

    # 4) runtime-critical final artifacts.
    missing_direct_run = []
    present_direct_run = []
    for raw in direct_run_required:
        if isinstance(raw, dict):
            path = str(raw.get("path", "")).strip()
            reason = str(raw.get("reason", "")).strip()
        else:
            path = str(raw).strip()
            reason = ""
        if not path:
            continue
        exists = (root / path).exists()
        entry = {"path": normalize(path), "reason": reason, "exists": exists}
        (present_direct_run if exists else missing_direct_run).append(entry)

    report = {
        "root": str(root),
        "config": str(args.config) if args.config else None,
        "summary": {
            "asmdef_names": len(asmdef_by_name),
            "duplicate_asmdef_names": len(duplicate_asmdef),
            "invalid_asmdef_files": len(invalid_asmdef),
            "fake_compatibility_paths": len(fake_compat_paths),
            "embedded_packages": len(embedded_packages),
            "embedded_manifest_overlaps": len(embedded_manifest_overlaps),
            "direct_run_required_artifacts": len(present_direct_run) + len(missing_direct_run),
            "missing_direct_run_artifacts": len(missing_direct_run),
        },
        "duplicate_asmdef": duplicate_asmdef,
        "invalid_asmdef": invalid_asmdef,
        "fake_compatibility_paths": fake_compat_paths,
        "embedded_manifest_overlaps": embedded_manifest_overlaps,
        "direct_run_present": present_direct_run,
        "direct_run_missing": missing_direct_run,
    }

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("MyFramework dependency/direct-run audit")
        print("root:", root)
        if args.config:
            print("config:", args.config)
        for k, v in report["summary"].items():
            print(f"{k:40} {v}")
        if duplicate_asmdef:
            print("\nDuplicate asmdef assembly names:")
            for x in duplicate_asmdef:
                print(" -", x["name"], "=>", ", ".join(x["files"]))
        if fake_compat_paths:
            print("\nForbidden fake compatibility/stub paths:")
            for x in fake_compat_paths:
                print(" -", x["path"], f"({x['fragment']})")
        if embedded_manifest_overlaps:
            print("\nEmbedded package + manifest source overlaps (informational; embedded copy takes precedence):")
            for x in embedded_manifest_overlaps:
                print(" -", x["package"], "embedded=", x["embedded_path"], "manifest=", x["manifest_source"])
        if missing_direct_run:
            print("\nMissing direct-run artifacts:")
            for x in missing_direct_run:
                print(" -", x["path"], ("-- " + x["reason"]) if x["reason"] else "")
        print("\nNotes:")
        print("- Do not satisfy real package dependencies with same-name fake asmdefs or placeholder classes.")
        print("- Duplicate Assembly names are Unity compile failures even when filenames differ; non-imported package template folders ending '~' are excluded.")
        print("- direct_run_required_artifacts is project-specific; list runtime-critical Scene/Prefab/UI/Material/bytes there.")
        print("- This static gate does not prove Package Manager resolve, Unity import, compile, or Play.")

    fail = {x.strip() for x in args.fail_on.split(",") if x.strip()}
    bad = False
    if "duplicate-asmdef" in fail and duplicate_asmdef:
        bad = True
    if "invalid-asmdef" in fail and invalid_asmdef:
        bad = True
    if "fake-compat" in fail and fake_compat_paths:
        bad = True
    if "embedded-manifest-overlap" in fail and embedded_manifest_overlaps:
        bad = True
    if "missing-direct-run-artifact" in fail and missing_direct_run:
        bad = True
    raise SystemExit(1 if bad else 0)


if __name__ == "__main__":
    main()
