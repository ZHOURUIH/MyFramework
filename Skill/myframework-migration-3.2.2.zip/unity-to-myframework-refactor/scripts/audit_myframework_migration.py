﻿#!/usr/bin/env python3
"""Heuristic static audit for MyFramework migration.

The audit intentionally reports *candidates*. It does not replace Roslyn, Unity
compilation, generator execution, runtime testing, or baseline parity testing.

v2.6.0 keeps the v2.5.0 MyFramework hard-contract checks (BASE001-style base calls, code style, enum rename damage, and utility overload shadowing) in addition to project-specific migration debt tracking:
{
  "legacy_symbols": ["PortedScreen", "SaveService"],
  "legacy_prefab_guids": ["0123..."],
  "mono_behaviour_allowlist": ["BoardInputBridge"],
  "ui_path_apis": ["Node", "Text", "Active", "Component"],
  "hotfix_ui_path": "Assets/Scripts/HotFix/UI",
  "static_api_visibility_rules": [
    {"symbol": "mLayoutManager", "owners": ["FrameBase", "FrameBaseHotFix"], "kind": "member"}
  ]
}
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path

REFLECTION_PATTERNS = {
    "System.Reflection": r"\bSystem\.Reflection\b",
    "BindingFlags": r"\bBindingFlags\b",
    "Activator": r"\bActivator\s*\.",
    "GetField": r"\.GetFields?\s*\(",
    "GetProperty": r"\.GetProperties?\s*\(",
    "GetMethod": r"\.GetMethods?\s*\(",
    "GetMember": r"\.GetMembers?\s*\(",
    "Assembly.Load": r"\bAssembly\s*\.\s*(Load|LoadFrom|LoadFile)\s*\(",
    "Assembly.GetTypes": r"\.GetTypes\s*\(",
}
NATIVE_RESOURCE_PATTERNS = {
    "Resources.Load": r"\bResources\s*\.\s*Load",
    "Instantiate": r"(?<![A-Za-z0-9_])(?:Object\s*\.\s*)?Instantiate\s*\(",
    "Destroy": r"(?<![A-Za-z0-9_])(?:Object\s*\.\s*)?Destroy(?:Immediate)?\s*\(",
}
RUNTIME_LOOKUP_PATTERNS = {
    "Transform.Find": r"\.Find\s*\(",
    "GameObject.Find": r"\bGameObject\s*\.\s*Find\s*\(",
    "GetComponent": r"\.GetComponent(?:InChildren|InParent)?\s*<",
    "TryGetComponent": r"\.TryGetComponent\s*<",
    "AddComponent": r"\.AddComponent\s*<",
}
CLASS_RE = re.compile(r"\bclass\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)(?:\s*:\s*(?P<bases>[^\{\n]+))?")
NAMESPACE_RE = re.compile(r"^\s*namespace\s+", re.M)
SEALED_RE = re.compile(r"\bsealed\s+class\b")
DIRECT_MONO_RE = re.compile(r"\bclass\s+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*[^\n\{]*\bMonoBehaviour\b")
EXPR_METHOD_RE = re.compile(r"^[ \t]*(?:public|protected|private|internal)[^=\n;{}]*\([^;{}\n]*\)\s*=>", re.M)
AUTO_PROPERTY_RE = re.compile(r"\b(?:public|protected|private|internal)\s+(?:static\s+)?[A-Za-z_][A-Za-z0-9_<>,.\[\]? ]*\s+[A-Za-z_][A-Za-z0-9_]*\s*\{\s*(?:get\s*;|set\s*;)", re.S)
EXPR_PROPERTY_RE = re.compile(r"^[ \t]*(?:public|protected|private|internal)\s+(?:static\s+)?[A-Za-z_][A-Za-z0-9_<>,.\[\]? ]*\s+[A-Za-z_][A-Za-z0-9_]*\s*=>", re.M)
UNDERSCORE_FIELD_RE = re.compile(r"^[ \t]*(?:public|protected|private|internal)\s+(?:static\s+|readonly\s+|const\s+)*[A-Za-z_][A-Za-z0-9_<>,.\[\]? ]*\s+(_[A-Za-z][A-Za-z0-9_]*)\s*(?:[;=])", re.M)
ENUM_RE = re.compile(r"\benum\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{")
OVERRIDE_RE = re.compile(r"\boverride\s+[A-Za-z_][A-Za-z0-9_<>,.\[\]? ]*\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*\{")
LIFECYCLE_BASE_METHODS = {
    "init", "lateInit", "update", "fixedUpdate", "lateUpdate", "willDestroy", "destroy",
    "resetProperty", "onCreate", "onGameState", "onHide",
    "exit", "enter", "onPreInit", "onPostInit", "Awake",
}
AMBIGUOUS_GET_OR_ADD_RE = re.compile(r"(?<![A-Za-z0-9_\.])getOrAddComponent\s*<[^>]+>\s*\(\s*(?!out\b)([^)]+)\)")

DEFAULT_STATIC_API_RULES = [
    {"symbol": "changeProcedure", "owner": "FrameUtility", "kind": "call"},
    {"symbol": "changeProcedureDelay", "owner": "FrameUtility", "kind": "call"},
    {"symbol": "isEditor", "owner": "FrameBaseUtility", "kind": "call"},
    {"symbol": "mGameFrameworkHotFix", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mCommandSystem", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mAudioManager", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mGameSceneManager", "owners": ["FrameBase", "FrameBaseHotFix"], "kind": "member"},
    {"symbol": "mLayoutManager", "owners": ["FrameBase", "FrameBaseHotFix"], "kind": "member"},
    {"symbol": "mKeyFrameManager", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mGlobalTouchSystem", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mShaderManager", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mCameraManager", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mResourceManager", "owners": ["FrameBase", "FrameBaseHotFix"], "kind": "member"},
    {"symbol": "mPrefabPoolManager", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mInputSystem", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mSceneSystem", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mEventSystem", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mTweenerManager", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mExcelManager", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mLocalizationManager", "owner": "FrameBaseHotFix", "kind": "member"},
    {"symbol": "mWaitingManager", "owner": "FrameBaseHotFix", "kind": "member"},
]
FRAME_SYSTEM_REGISTER_RE = re.compile(
    r"registeFrameSystem\s*<[^>]+>\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*=>\s*\{"
)
DESTROY_OVERRIDE_RE = re.compile(
    r"\boverride\s+void\s+destroy\s*\([^)]*\)\s*\{"
)
GLOBAL_SYSTEM_FIELD_RE = re.compile(
    r"\b(m[A-Z][A-Za-z0-9_]*(?:System|Manager)|mGameFrameworkHotFix)\s*\."
)


def read_text(path: Path) -> str:
    return path.read_bytes().decode("utf-8-sig", errors="replace")


def mask_comments_and_strings(src: str) -> str:
    """Replace comment/string content with spaces while preserving newlines/offsets."""
    out = list(src)
    i = 0
    n = len(src)
    state = "code"
    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ""
        if state == "code":
            if c == '/' and nxt == '/':
                out[i] = out[i + 1] = ' '
                i += 2
                state = "line"
                continue
            if c == '/' and nxt == '*':
                out[i] = out[i + 1] = ' '
                i += 2
                state = "block"
                continue
            if c == '"':
                out[i] = ' '
                i += 1
                state = "string"
                continue
            if c == "'":
                out[i] = ' '
                i += 1
                state = "char"
                continue
        elif state == "line":
            if c == '\n':
                state = "code"
            else:
                out[i] = ' '
            i += 1
            continue
        elif state == "block":
            if c == '*' and nxt == '/':
                out[i] = out[i + 1] = ' '
                i += 2
                state = "code"
                continue
            if c != '\n':
                out[i] = ' '
            i += 1
            continue
        elif state in ("string", "char"):
            quote = '"' if state == "string" else "'"
            if c == '\\':
                out[i] = ' '
                if i + 1 < n:
                    if src[i + 1] != '\n':
                        out[i + 1] = ' '
                    i += 2
                    continue
            if c == quote:
                out[i] = ' '
                i += 1
                state = "code"
                continue
            if c != '\n':
                out[i] = ' '
            i += 1
            continue
        i += 1
    return ''.join(out)


def line_hits(text: str, pattern: str):
    rx = re.compile(pattern)
    return [i for i, line in enumerate(text.splitlines(), 1) if rx.search(line)]


def literal_line_hits(text: str, literal: str):
    return [i for i, line in enumerate(text.splitlines(), 1) if literal in line]


def find_matching_brace(text: str, open_index: int) -> int:
    depth = 0
    for i in range(open_index, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    return -1


def lifecycle_override_missing_base(text: str):
    hits = []
    for m in OVERRIDE_RE.finditer(text):
        name = m.group("name")
        if name not in LIFECYCLE_BASE_METHODS:
            continue
        open_index = text.find("{", m.start())
        end = find_matching_brace(text, open_index)
        if end < 0:
            continue
        body = text[open_index + 1:end]
        if not re.search(r"\bbase\s*\.\s*" + re.escape(name) + r"\s*\(", body):
            line = text.count("\n", 0, m.start()) + 1
            hits.append((line, name))
    return hits


def extract_braced_body(text: str, open_index: int) -> tuple[str, int]:
    end = find_matching_brace(text, open_index)
    if end < 0:
        return "", -1
    return text[open_index + 1:end], end


def has_null_guard(body: str, var: str) -> bool:
    v = re.escape(var)
    if re.search(r"\b" + v + r"\s*\?\.", body):
        return True
    if re.search(r"if\s*\(\s*" + v + r"\s*!=\s*null\s*\)", body):
        return True
    if re.search(r"if\s*\(\s*" + v + r"\s+is\s+not\s+null\s*\)", body):
        return True
    if re.search(r"if\s*\(\s*" + v + r"\s*==\s*null\s*\)\s*(?:\{[^{}]*\}\s*)?return\s*;", body, re.S):
        return True
    return False


def static_api_owners(rule: dict) -> list[str]:
    raw = rule.get("owners")
    if raw is None:
        raw = [rule.get("owner", "")]
    if isinstance(raw, str):
        raw = [raw]
    return [str(x).strip() for x in raw if str(x).strip()]


def static_api_unqualified_hits(text: str, rule: dict) -> list[int]:
    symbol = str(rule.get("symbol", "")).strip()
    owners = static_api_owners(rule)
    kind = str(rule.get("kind", "call")).strip()
    if not symbol or not owners:
        return []
    # Some globals intentionally exist in both the AOT FrameBase and HotFix
    # FrameBaseHotFix layers. Any source-confirmed owner import is sufficient.
    if any(re.search(r"using\s+static\s+" + re.escape(owner) + r"\s*;", text) for owner in owners):
        return []
    if kind == "call":
        rx = re.compile(r"(?<![A-Za-z0-9_\.])" + re.escape(symbol) + r"\s*(?:<[^;{}()]+>)?\s*\(")
    else:
        # Avoid obvious local/member declarations with the same name.
        if re.search(r"(?:public|protected|private|internal)\s+[^;{}\n=]+\s+" + re.escape(symbol) + r"\s*(?:[;=])", text):
            return []
        rx = re.compile(r"(?<![A-Za-z0-9_\.])" + re.escape(symbol) + r"\b")
    return [text.count("\n", 0, m.start()) + 1 for m in rx.finditer(text)]


def unsafe_destroy_dependencies(text: str, allow: set[str], rel: str) -> list[dict]:
    hits = []
    for m in DESTROY_OVERRIDE_RE.finditer(text):
        open_index = text.find("{", m.start())
        body, end = extract_braced_body(text, open_index)
        if end < 0:
            continue
        for fm in GLOBAL_SYSTEM_FIELD_RE.finditer(body):
            field = fm.group(1)
            key = f"{rel}:{field}"
            if field in allow or key in allow:
                continue
            # Null conditional is safe. A simple explicit non-null guard is accepted as a heuristic.
            if body[fm.start():].startswith(field + "?."):
                continue
            if re.search(r"if\s*\([^)]*\b" + re.escape(field) + r"\s*!=\s*null", body):
                continue
            line = text.count("\n", 0, open_index + 1 + fm.start()) + 1
            hits.append({"file": rel, "line": line, "field": field})
    # one report per file/field/line is enough
    uniq = []
    seen = set()
    for h in hits:
        k = (h["file"], h["line"], h["field"])
        if k not in seen:
            seen.add(k); uniq.append(h)
    return uniq


def load_config(path: Path | None) -> dict:
    if path is None:
        return {}
    return json.loads(path.read_text(encoding="utf-8-sig"))


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("root", type=Path)
    p.add_argument("--hotfix", default="Assets/Scripts/HotFix", help="relative path used for HotFix-specific counts")
    p.add_argument("--config", type=Path, help="optional MIGRATION_AUDIT_CONFIG.json")
    p.add_argument("--legacy-symbol", action="append", default=[], help="project legacy symbol to count; repeatable")
    p.add_argument("--legacy-guid", action="append", default=[], help="legacy MonoBehaviour/resource guid to scan in prefab/scene/asset YAML")
    p.add_argument("--mono-allow", action="append", default=[], help="allowed direct MonoBehaviour class; repeatable")
    p.add_argument("--json", action="store_true")
    p.add_argument("--fail-on", default="reflection,bom,base-call,auto-property,namespace,sealed,static-api,frame-callback-null,destroy-dependency", help="comma-separated: reflection,bom,base-call,auto-property,underscore-field,enum-getter,ambiguous-getoradd,namespace,sealed,direct-new,legacy-symbol,legacy-guid,static-api,frame-callback-null,destroy-dependency")
    return p.parse_args()


def main():
    args = parse_args()
    root = args.root.resolve()
    cfg = load_config(args.config)
    legacy_symbols = list(dict.fromkeys([*cfg.get("legacy_symbols", []), *args.legacy_symbol]))
    legacy_guids = list(dict.fromkeys([*cfg.get("legacy_prefab_guids", []), *args.legacy_guid]))
    mono_allow = set([*cfg.get("mono_behaviour_allowlist", []), *args.mono_allow])
    ui_path_apis = cfg.get("ui_path_apis", ["Node", "Text", "Active", "Component"])
    hotfix_ui_rel = cfg.get("hotfix_ui_path", "Assets/Scripts/HotFix/UI")
    project_code_root_names = cfg.get("project_code_roots", ["Assets/Scripts/Game", "Assets/Scripts/HotFix"])
    project_code_roots = [root / x for x in project_code_root_names]
    audit_code_root_names = cfg.get("audit_code_roots", project_code_root_names)
    audit_code_roots = [root / x for x in audit_code_root_names]
    style_exclude_fragments = cfg.get("style_exclude_path_fragments", ["/AutoGenerated/", "/Generated/", "/DataBase/Excel/Data/ED"])
    static_api_rules = cfg.get("static_api_visibility_rules", DEFAULT_STATIC_API_RULES)
    destroy_dependency_allow = set(cfg.get("destroy_dependency_allowlist", []))

    cs_seen = set()
    cs_files = []
    for code_root in audit_code_roots:
        if not code_root.exists():
            continue
        for candidate in code_root.rglob("*.cs"):
            if candidate not in cs_seen:
                cs_seen.add(candidate)
                cs_files.append(candidate)
    cs_files.sort()
    hotfix_root = (root / args.hotfix).resolve()
    hotfix_ui_root = (root / hotfix_ui_rel).resolve()

    texts = {p: read_text(p) for p in cs_files}
    masked = {p: mask_comments_and_strings(t) for p, t in texts.items()}
    project_enum_names = sorted(set(name for text in masked.values() for name in ENUM_RE.findall(text)))
    report = {
        "root": str(root),
        "config": str(args.config) if args.config else None,
        "cs_files": len(cs_files),
        "missing_utf8_bom": [],
        "reflection": [],
        "gettype": [],
        "namespace": [],
        "sealed_class": [],
        "auto_property": [],
        "expression_property": [],
        "underscore_field": [],
        "missing_base_lifecycle": [],
        "enum_getter_call_candidates": [],
        "ambiguous_get_or_add_component_candidates": [],
        "static_api_visibility_candidates": [],
        "frame_system_callback_null_unsafe_candidates": [],
        "cross_system_destroy_dependency_candidates": [],
        "expression_body_method_candidates": [],
        "multi_class_files": [],
        "direct_monobehaviour": [],
        "allowed_direct_monobehaviour": [],
        "classobject_descendants": [],
        "direct_new_classobject_candidates": [],
        "native_resource_api_candidates": [],
        "runtime_component_lookup_candidates": [],
        "ui_runtime_path_candidates": [],
        "un_class_list_candidates": [],
        "legacy_symbol_hits": [],
        "legacy_guid_hits": [],
    }

    bases = {}
    for p, text in masked.items():
        decls = list(CLASS_RE.finditer(text))
        if len(decls) > 1:
            report["multi_class_files"].append({"file": str(p.relative_to(root)), "count": len(decls)})
        for m in decls:
            name = m.group("name")
            raw = m.group("bases") or ""
            base_names = []
            for b in raw.split(","):
                b = b.strip().split("<", 1)[0].strip().split(".")[-1]
                if b:
                    base_names.append(b)
            bases[name] = base_names

    classobject = {"ClassObject"}
    changed = True
    while changed:
        changed = False
        for name, bs in bases.items():
            if name not in classobject and any(b in classobject for b in bs):
                classobject.add(name)
                changed = True
    project_classobjects = sorted(x for x in classobject if x != "ClassObject")
    report["classobject_descendants"] = project_classobjects

    def under(path: Path, parent: Path) -> bool:
        return path == parent or parent in path.parents

    def is_project_code(path: Path) -> bool:
        return any(under(path, r.resolve()) for r in project_code_roots)

    def style_excluded(rel: str) -> bool:
        probe = "/" + rel.replace("\\", "/")
        return any(fragment in probe for fragment in style_exclude_fragments)

    for p, text in masked.items():
        rel = str(p.relative_to(root))
        is_hotfix = under(p, hotfix_root)
        is_hotfix_ui = under(p, hotfix_ui_root)
        if not p.read_bytes().startswith(b"\xef\xbb\xbf"):
            report["missing_utf8_bom"].append({"file": rel, "hotfix": is_hotfix})

        for label, pat in REFLECTION_PATTERNS.items():
            for line in line_hits(text, pat):
                report["reflection"].append({"file": rel, "line": line, "api": label, "hotfix": is_hotfix})
        for line in line_hits(text, r"\.GetType\s*\("):
            report["gettype"].append({"file": rel, "line": line, "hotfix": is_hotfix})
        if NAMESPACE_RE.search(text):
            report["namespace"].append({"file": rel, "hotfix": is_hotfix})
        if SEALED_RE.search(text):
            report["sealed_class"].append({"file": rel, "hotfix": is_hotfix})
        project_code = is_project_code(p)
        excluded_style = style_excluded(rel)
        if project_code and not excluded_style:
            for m in AUTO_PROPERTY_RE.finditer(text):
                report["auto_property"].append({"file": rel, "line": text.count("\n", 0, m.start()) + 1, "hotfix": is_hotfix})
            for m in EXPR_PROPERTY_RE.finditer(text):
                report["expression_property"].append({"file": rel, "line": text.count("\n", 0, m.start()) + 1, "hotfix": is_hotfix})
            for m in UNDERSCORE_FIELD_RE.finditer(text):
                report["underscore_field"].append({"file": rel, "line": text.count("\n", 0, m.start()) + 1, "field": m.group(1), "hotfix": is_hotfix})
            for line, method in lifecycle_override_missing_base(text):
                report["missing_base_lifecycle"].append({"file": rel, "line": line, "method": method, "hotfix": is_hotfix})
            for m in AMBIGUOUS_GET_OR_ADD_RE.finditer(text):
                report["ambiguous_get_or_add_component_candidates"].append({"file": rel, "line": text.count("\n", 0, m.start()) + 1, "hotfix": is_hotfix})
            for rule in static_api_rules:
                for line in static_api_unqualified_hits(text, rule):
                    report["static_api_visibility_candidates"].append({
                        "file": rel, "line": line, "symbol": rule.get("symbol"),
                        "owner": rule.get("owner") or "|".join(static_api_owners(rule)),
                        "owners": static_api_owners(rule), "hotfix": is_hotfix,
                    })
            for rm in FRAME_SYSTEM_REGISTER_RE.finditer(text):
                var = rm.group(1)
                open_index = text.find("{", rm.start())
                body, end = extract_braced_body(text, open_index)
                if end < 0:
                    continue
                if re.search(r"\b" + re.escape(var) + r"\s*\.", body) and not has_null_guard(body, var):
                    report["frame_system_callback_null_unsafe_candidates"].append({
                        "file": rel, "line": text.count("\n", 0, rm.start()) + 1,
                        "parameter": var, "hotfix": is_hotfix,
                    })
            for item in unsafe_destroy_dependencies(text, destroy_dependency_allow, rel):
                item["hotfix"] = is_hotfix
                report["cross_system_destroy_dependency_candidates"].append(item)
            for enum_name in project_enum_names:
                pat = r"\b" + re.escape(enum_name) + r"\s*\.\s*get[A-Z][A-Za-z0-9_]*\s*\("
                for line in line_hits(text, pat):
                    report["enum_getter_call_candidates"].append({"file": rel, "line": line, "enum": enum_name, "hotfix": is_hotfix})
        if EXPR_METHOD_RE.search(text):
            report["expression_body_method_candidates"].append({"file": rel, "hotfix": is_hotfix})

        for m in DIRECT_MONO_RE.finditer(text):
            line = text.count("\n", 0, m.start()) + 1
            entry = {"file": rel, "line": line, "class": m.group(1), "hotfix": is_hotfix}
            if m.group(1) in mono_allow:
                report["allowed_direct_monobehaviour"].append(entry)
            else:
                report["direct_monobehaviour"].append(entry)

        for label, pat in NATIVE_RESOURCE_PATTERNS.items():
            for line in line_hits(text, pat):
                report["native_resource_api_candidates"].append({"file": rel, "line": line, "api": label, "hotfix": is_hotfix})
        for label, pat in RUNTIME_LOOKUP_PATTERNS.items():
            for line in line_hits(text, pat):
                report["runtime_component_lookup_candidates"].append({"file": rel, "line": line, "api": label, "hotfix": is_hotfix, "hotfix_ui": is_hotfix_ui})
        if is_hotfix_ui:
            for api in ui_path_apis:
                pat = r"\." + re.escape(api) + r"\s*\("
                for line in line_hits(text, pat):
                    report["ui_runtime_path_candidates"].append({"file": rel, "line": line, "api": api})

        for line in line_hits(text, r"\bUN_CLASS_LIST\s*\("):
            report["un_class_list_candidates"].append({"file": rel, "line": line, "hotfix": is_hotfix})

        for typ in project_classobjects:
            pat = re.compile(r"\bnew\s+" + re.escape(typ) + r"\s*\(")
            for m in pat.finditer(text):
                line = text.count("\n", 0, m.start()) + 1
                report["direct_new_classobject_candidates"].append({"file": rel, "line": line, "type": typ, "hotfix": is_hotfix})

        for symbol in legacy_symbols:
            for line in literal_line_hits(text, symbol):
                report["legacy_symbol_hits"].append({"file": rel, "line": line, "symbol": symbol, "hotfix": is_hotfix})

    if legacy_guids:
        yaml_files = []
        for suffix in ("*.prefab", "*.unity", "*.asset"):
            yaml_files.extend(root.rglob(suffix))
        for p in sorted(set(yaml_files)):
            if "/Library/" in p.as_posix() or "/Temp/" in p.as_posix():
                continue
            try:
                text = read_text(p)
            except OSError:
                continue
            rel = str(p.relative_to(root))
            for guid in legacy_guids:
                for line in literal_line_hits(text, guid):
                    report["legacy_guid_hits"].append({"file": rel, "line": line, "guid": guid})

    def cnt(key, only_hotfix=False):
        seq = report[key]
        if not only_hotfix:
            return len(seq)
        return sum(1 for x in seq if isinstance(x, dict) and x.get("hotfix"))

    summary = {
        "reflection": cnt("reflection"),
        "hotfix_reflection": cnt("reflection", True),
        "gettype": cnt("gettype"),
        "hotfix_gettype": cnt("gettype", True),
        "missing_utf8_bom": len(report["missing_utf8_bom"]),
        "hotfix_missing_utf8_bom": sum(1 for x in report["missing_utf8_bom"] if x["hotfix"]),
        "namespace_files": cnt("namespace"),
        "hotfix_namespace_files": cnt("namespace", True),
        "sealed_files": cnt("sealed_class"),
        "hotfix_sealed_files": cnt("sealed_class", True),
        "auto_property": cnt("auto_property"),
        "hotfix_auto_property": cnt("auto_property", True),
        "expression_property": cnt("expression_property"),
        "underscore_field": cnt("underscore_field"),
        "missing_base_lifecycle": cnt("missing_base_lifecycle"),
        "hotfix_missing_base_lifecycle": cnt("missing_base_lifecycle", True),
        "enum_getter_call_candidates": cnt("enum_getter_call_candidates"),
        "ambiguous_get_or_add_component_candidates": cnt("ambiguous_get_or_add_component_candidates"),
        "static_api_visibility_candidates": cnt("static_api_visibility_candidates"),
        "frame_system_callback_null_unsafe_candidates": cnt("frame_system_callback_null_unsafe_candidates"),
        "cross_system_destroy_dependency_candidates": cnt("cross_system_destroy_dependency_candidates"),
        "direct_monobehaviour": cnt("direct_monobehaviour"),
        "hotfix_direct_monobehaviour": cnt("direct_monobehaviour", True),
        "allowed_direct_monobehaviour": cnt("allowed_direct_monobehaviour"),
        "classobject_descendants": len(project_classobjects),
        "direct_new_classobject_candidates": cnt("direct_new_classobject_candidates"),
        "hotfix_direct_new_classobject_candidates": cnt("direct_new_classobject_candidates", True),
        "native_resource_api_candidates": cnt("native_resource_api_candidates"),
        "hotfix_native_resource_api_candidates": cnt("native_resource_api_candidates", True),
        "runtime_component_lookup_candidates": cnt("runtime_component_lookup_candidates"),
        "hotfix_runtime_component_lookup_candidates": cnt("runtime_component_lookup_candidates", True),
        "ui_runtime_path_candidates": cnt("ui_runtime_path_candidates"),
        "un_class_list_candidates": cnt("un_class_list_candidates"),
        "hotfix_un_class_list_candidates": cnt("un_class_list_candidates", True),
        "legacy_symbol_hits": cnt("legacy_symbol_hits"),
        "hotfix_legacy_symbol_hits": cnt("legacy_symbol_hits", True),
        "legacy_guid_hits": cnt("legacy_guid_hits"),
    }
    report["summary"] = summary

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("MyFramework migration audit")
        print("root:", root)
        if args.config:
            print("config:", args.config)
        for k, v in summary.items():
            print(f"{k:47} {v}")
        if legacy_symbols:
            print("legacy_symbols:", ", ".join(legacy_symbols))
        if legacy_guids:
            print("legacy_guids:", ", ".join(legacy_guids))
        print("\nNotes:")
        print("- Results are heuristic candidates, not compiler proof.")
        print("- MonoBehaviour bridges and component lookups may be legitimate; whitelist/review them explicitly.")
        print("- UI path candidates are migration debt indicators, not automatic errors.")
        print("- Direct new detection covers project-declared ClassObject inheritance visible to this scan.")
        print("- v2.6.0 keeps static API visibility, null-unsafe registeFrameSystem callbacks, and cross-System destroy checks. Display/UI-generator ownership/Excel toolchain are audited by their dedicated scripts; abstract UI binding contracts remain excluded from fake base-call requirements.")
        print("- Run audit_myframework_ui.py, audit_myframework_display.py, audit_myframework_excel.py, audit_myframework_resources.py, and audit_myframework_dependencies.py separately for their dedicated contracts.")

    fail = {x.strip() for x in args.fail_on.split(",") if x.strip()}
    bad = False
    if "reflection" in fail and summary["hotfix_reflection"]:
        bad = True
    if "bom" in fail and summary["hotfix_missing_utf8_bom"]:
        bad = True
    if "namespace" in fail and summary["hotfix_namespace_files"]:
        bad = True
    if "sealed" in fail and summary["hotfix_sealed_files"]:
        bad = True
    if "direct-new" in fail and summary["hotfix_direct_new_classobject_candidates"]:
        bad = True
    if "legacy-symbol" in fail and summary["legacy_symbol_hits"]:
        bad = True
    if "legacy-guid" in fail and summary["legacy_guid_hits"]:
        bad = True
    if "base-call" in fail and summary["missing_base_lifecycle"]:
        bad = True
    if "auto-property" in fail and summary["auto_property"]:
        bad = True
    if "underscore-field" in fail and summary["underscore_field"]:
        bad = True
    if "enum-getter" in fail and summary["enum_getter_call_candidates"]:
        bad = True
    if "ambiguous-getoradd" in fail and summary["ambiguous_get_or_add_component_candidates"]:
        bad = True
    if "static-api" in fail and summary["static_api_visibility_candidates"]:
        bad = True
    if "frame-callback-null" in fail and summary["frame_system_callback_null_unsafe_candidates"]:
        bad = True
    if "destroy-dependency" in fail and summary["cross_system_destroy_dependency_candidates"]:
        bad = True
    raise SystemExit(1 if bad else 0)


if __name__ == "__main__":
    main()
