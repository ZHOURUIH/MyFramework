﻿#!/usr/bin/env python3
"""Static UI contract audit for MyFramework migration.

This script validates *structure* around the official UGUIGenerator pipeline. It
cannot prove that the Unity Editor generator was actually executed. Generator
execution remains a separate Unity evidence gate.

v3.1.0 checks:
- root UGUIGenerator Prefab discovery under the real runtime UI path
- root Generator is attached to a Canvas GameObject
- matching LayoutScript and generator marker regions exist
- LayoutRegisterHotFix and GBR LayoutScript sets match generator Prefabs
- manual/fallback layout registration outside LayoutRegisterHotFix
- likely project-level UI God FrameSystem candidates
- known-invalid Unity builtin Arial references seen in migration artifacts
- UGUIGenerator root/sub parent type contracts
- generator-owned binding code leaking outside auto-generate regions
- LayoutScript/UI page resetProperty() candidates (disallowed by project convention unless allowlisted)
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import re
from pathlib import Path

DEFAULT_UGUI_GENERATOR_GUIDS = ["1324c7b97d0cd4d4286eaa7aef336d1d"]
DEFAULT_UGUI_SUB_GENERATOR_GUIDS = ["4be6038f6da4c82439e4ab4cb00df702"]
KNOWN_BAD_BUILTIN_FONT_PATTERNS = [
    # Common migration error: this is unity_builtin_extra, not default Arial.
    r"m_Font:\s*\{fileID:\s*12800000,\s*guid:\s*0000000000000000f000000000000000,\s*type:\s*0\}",
]


def read_text(path: Path) -> str:
    return path.read_bytes().decode("utf-8-sig", errors="replace")


def load_config(path: Path | None) -> dict:
    if path is None:
        return {}
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize(path: str) -> str:
    return path.replace("\\", "/").lstrip("./")


def split_yaml_blocks(raw: str) -> list[str]:
    return [x for x in re.split(r"(?=^--- !u!\d+ &-?\d+\s*$)", raw, flags=re.M) if x.strip()]


def parse_header(block: str):
    m = re.match(r"--- !u!(\d+) &(-?\d+)", block)
    if not m:
        return None, None
    return int(m.group(1)), int(m.group(2))


def parse_prefab(path: Path, gen_guids: set[str], sub_guids: set[str]) -> dict:
    raw = read_text(path)
    blocks = split_yaml_blocks(raw)
    go_components: dict[int, list[int]] = {}
    comp_to_go: dict[int, int] = {}
    comp_script_guid: dict[int, str] = {}
    canvas_components: set[int] = set()

    for b in blocks:
        typ, fid = parse_header(b)
        if typ is None:
            continue
        if typ == 1:  # GameObject
            comps = [int(x) for x in re.findall(r"component:\s*\{fileID:\s*(-?\d+)\}", b)]
            go_components[fid] = comps
        else:
            gm = re.search(r"m_GameObject:\s*\{fileID:\s*(-?\d+)\}", b)
            if gm:
                comp_to_go[fid] = int(gm.group(1))
            if typ == 223:  # Canvas
                canvas_components.add(fid)
            if typ == 114:  # MonoBehaviour
                sm = re.search(r"m_Script:\s*\{fileID:\s*\d+,\s*guid:\s*([0-9a-fA-F]{32}),", b)
                if sm:
                    comp_script_guid[fid] = sm.group(1).lower()

    roots = []
    subs = []
    for comp, guid in comp_script_guid.items():
        go = comp_to_go.get(comp, 0)
        entry = {"component": comp, "game_object": go, "guid": guid}
        pm = re.search(r"(?m)^\s*mParentType:\s*(.*)$", next((b for b in blocks if parse_header(b)[1] == comp), ""))
        entry["parent_type"] = pm.group(1).strip() if pm else ""
        if guid in gen_guids:
            entry["on_canvas"] = any(c in canvas_components for c in go_components.get(go, []))
            roots.append(entry)
        elif guid in sub_guids:
            subs.append(entry)

    return {"raw": raw, "root_generators": roots, "sub_generators": subs}


def region(text: str, start_marker: str, end_marker: str) -> str | None:
    lines = text.replace("\r\n", "\n").split("\n")
    si = next((i for i, l in enumerate(lines) if start_marker in l), -1)
    ei = next((i for i, l in enumerate(lines) if i > si and end_marker in l), -1)
    if si < 0 or ei < 0:
        return None
    return "\n".join(lines[si + 1:ei])


def region_bounds(text: str, start_marker: str, end_marker: str):
    lines = text.replace("\r\n", "\n").split("\n")
    si = next((i for i, l in enumerate(lines) if start_marker in l), -1)
    ei = next((i for i, l in enumerate(lines) if i > si and end_marker in l), -1)
    if si < 0 or ei < 0:
        return None
    return si + 1, ei - 1


def in_bounds(line_index: int, bounds) -> bool:
    return bool(bounds and bounds[0] <= line_index <= bounds[1])


def resolve_layout_script(root: Path, roots: list[str], class_name: str) -> Path | None:
    for rel in roots:
        base = root / rel
        p = base / f"{class_name}.cs"
        if p.exists():
            return p
    # Last resort: deterministic unique search only inside configured roots.
    hits = []
    for rel in roots:
        base = root / rel
        if base.exists():
            hits.extend(base.rglob(f"{class_name}.cs"))
    hits = sorted(set(hits))
    return hits[0] if len(hits) == 1 else None


def iter_project_cs(root: Path, code_roots: list[str]):
    seen = set()
    for rel in code_roots:
        base = root / rel
        if not base.exists():
            continue
        for p in base.rglob("*.cs"):
            if p not in seen:
                seen.add(p)
                yield p


def match_allow(value: str, patterns: list[str]) -> bool:
    value = normalize(value)
    return any(fnmatch.fnmatchcase(value, normalize(p)) for p in patterns)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", type=Path)
    ap.add_argument("--config", type=Path)
    ap.add_argument("--json", action="store_true")
    ap.add_argument(
        "--fail-on",
        default="generator-root,canvas,parent-type,layout-script,markers,binding-owner,layout-reset-property,register-set,gbr-set,manual-register,ui-god-system,bad-font",
        help=(
            "comma-separated: generator-root,canvas,parent-type,layout-script,markers,binding-owner,layout-reset-property,register-set,gbr-set,"
            "manual-register,ui-god-system,bad-font"
        ),
    )
    args = ap.parse_args()
    root = args.root.resolve()
    cfg = load_config(args.config)

    prefab_roots = cfg.get("ui_prefab_roots", ["Assets/GameResources/UI/UIPrefab"])
    layout_roots = cfg.get("ui_layout_roots", ["Assets/Scripts/HotFix/UI", "Assets/Scripts/HotFix/UI/Layouts"])
    gen_guids = set(x.lower() for x in cfg.get("ugui_generator_script_guids", DEFAULT_UGUI_GENERATOR_GUIDS))
    sub_guids = set(x.lower() for x in cfg.get("ugui_sub_generator_script_guids", DEFAULT_UGUI_SUB_GENERATOR_GUIDS))
    layout_register_rel = cfg.get("layout_register_path", "Assets/Scripts/HotFix/UI/LayoutRegisterHotFix.cs")
    gbr_rel = cfg.get("gbr_path", "Assets/Scripts/HotFix/Common/GameBaseHotFix.cs")
    project_code_roots = cfg.get("project_code_roots", ["Assets/Scripts/Game", "Assets/Scripts/HotFix"])
    ui_frame_system_allowlist = cfg.get("ui_frame_system_allowlist", [])
    manual_register_allowlist = cfg.get("manual_layout_registration_allowlist", [])
    manual_binding_allowlist = cfg.get("manual_generator_binding_allowlist", [])
    layout_reset_property_allowlist = cfg.get("layout_reset_property_allowlist", [])
    bad_font_patterns = cfg.get("known_invalid_builtin_font_patterns", KNOWN_BAD_BUILTIN_FONT_PATTERNS)
    root_parent_type = cfg.get("ugui_root_expected_parent_type", "LayoutScript")
    require_sub_parent_type = bool(cfg.get("require_ugui_sub_parent_type", True))

    generator_prefabs = []
    prefab_reports = []
    bad_font_refs = []
    for rel_root in prefab_roots:
        base = root / rel_root
        if not base.exists():
            continue
        for p in sorted(base.rglob("*.prefab")):
            parsed = parse_prefab(p, gen_guids, sub_guids)
            rel = normalize(str(p.relative_to(root)))
            raw = parsed["raw"]
            for pat in bad_font_patterns:
                for m in re.finditer(pat, raw, flags=re.I):
                    bad_font_refs.append({"file": rel, "line": raw.count("\n", 0, m.start()) + 1})
            if not parsed["root_generators"]:
                continue
            generator_prefabs.append((p, parsed))

    expected_layouts = []
    missing_layout_scripts = []
    marker_failures = []
    generator_root_failures = []
    generator_canvas_failures = []
    generator_parent_type_failures = []
    sub_generator_parent_type_failures = []
    manual_generator_binding_candidates = []
    layout_reset_property_candidates = []

    for p, parsed in generator_prefabs:
        rel = normalize(str(p.relative_to(root)))
        class_name = p.stem[:-7] if p.stem.endswith("_Mobile") else p.stem
        expected_layouts.append(class_name)
        roots = parsed["root_generators"]
        root_ok = len(roots) == 1
        canvas_ok = root_ok and bool(roots[0].get("on_canvas"))
        if not root_ok:
            generator_root_failures.append({"prefab": rel, "count": len(roots)})
        if root_ok and not canvas_ok:
            generator_canvas_failures.append({"prefab": rel, "game_object": roots[0].get("game_object")})
        if root_ok and root_parent_type and roots[0].get("parent_type") != root_parent_type:
            generator_parent_type_failures.append({
                "prefab": rel,
                "actual": roots[0].get("parent_type"),
                "expected": root_parent_type,
            })
        if require_sub_parent_type:
            for sub in parsed["sub_generators"]:
                if not sub.get("parent_type"):
                    sub_generator_parent_type_failures.append({
                        "prefab": rel,
                        "component": sub.get("component"),
                        "game_object": sub.get("game_object"),
                    })

        script = resolve_layout_script(root, layout_roots, class_name)
        script_ok = script is not None
        markers_ok = False
        source_ok = False
        script_rel = None
        if script is None:
            missing_layout_scripts.append({"prefab": rel, "class": class_name})
        else:
            script_rel = normalize(str(script.relative_to(root)))
            t = read_text(script)
            markers = [
                ("// auto generate member start", "// auto generate member end"),
                ("// auto generate constructor start", "// auto generate constructor end"),
                ("// auto generate assignWindow start", "// auto generate assignWindow end"),
                ("// auto generate init start", "// auto generate init end"),
            ]
            markers_ok = all(region(t, a, b) is not None for a, b in markers)
            source_ok = f"// generate from:{rel}" in t.replace("\\", "/")
            if re.search(r"\b(?:public|protected|private|internal)?\s*(?:override\s+)?void\s+resetProperty\s*\(", t):
                if not match_allow(script_rel, layout_reset_property_allowlist):
                    for m in re.finditer(r"\b(?:public|protected|private|internal)?\s*(?:override\s+)?void\s+resetProperty\s*\(", t):
                        layout_reset_property_candidates.append({
                            "file": script_rel,
                            "line": t.count("\n", 0, m.start()) + 1,
                            "class": class_name,
                        })
            if markers_ok:
                constructor_bounds = region_bounds(t, "// auto generate constructor start", "// auto generate constructor end")
                assign_bounds = region_bounds(t, "// auto generate assignWindow start", "// auto generate assignWindow end")
                lines = t.replace("\r\n", "\n").split("\n")
                for i, line in enumerate(lines):
                    stripped = line.strip()
                    if not stripped or stripped.startswith("//"):
                        continue
                    reason = None
                    if "newObject(" in line and not in_bounds(i, assign_bounds):
                        reason = "newObject outside assignWindow auto region"
                    elif re.search(r"\.\s*assignWindow\s*\(", line) and not in_bounds(i, assign_bounds):
                        reason = "member assignWindow outside assignWindow auto region"
                    elif re.search(r"=\s*new\s*\(\s*this\s*\)", line) and not in_bounds(i, constructor_bounds):
                        reason = "Generator-owned new(this) outside constructor auto region"
                    if reason and not match_allow(script_rel, manual_binding_allowlist):
                        manual_generator_binding_candidates.append({
                            "file": script_rel,
                            "line": i + 1,
                            "reason": reason,
                            "code": stripped[:220],
                        })
            if not markers_ok or not source_ok:
                marker_failures.append({
                    "file": script_rel,
                    "class": class_name,
                    "markers_ok": markers_ok,
                    "generate_from_ok": source_ok,
                    "expected_source": rel,
                })
        prefab_reports.append({
            "prefab": rel,
            "class": class_name,
            "root_generator_count": len(roots),
            "root_on_canvas": canvas_ok,
            "root_parent_type": roots[0].get("parent_type") if root_ok else None,
            "sub_generator_count": len(parsed["sub_generators"]),
            "sub_parent_types": [x.get("parent_type") for x in parsed["sub_generators"]],
            "layout_script": script_rel,
            "markers_ok": markers_ok,
            "generate_from_ok": source_ok,
        })

    expected_set = set(expected_layouts)

    layout_register = root / layout_register_rel
    register_set = set()
    register_region_missing = False
    if layout_register.exists():
        t = read_text(layout_register)
        r = region(t, "// auto generate start", "// auto generate end")
        if r is None:
            register_region_missing = True
        else:
            register_set = set(re.findall(r"\bregisteLayout(?:Persist)?\s*<\s*([A-Za-z_][A-Za-z0-9_]*)\s*>", r))
    else:
        register_region_missing = True

    gbr = root / gbr_rel
    gbr_set = set()
    gbr_region_missing = False
    if gbr.exists():
        t = read_text(gbr)
        r = region(t, "// auto generate LayoutScript start", "// auto generate LayoutScript end")
        if r is None:
            gbr_region_missing = True
        else:
            gbr_set = set(re.findall(r"\bpublic\s+static\s+([A-Za-z_][A-Za-z0-9_]*)\s+m[A-Za-z_][A-Za-z0-9_]*\s*;", r))
    else:
        gbr_region_missing = True

    register_mismatch = {
        "missing": sorted(expected_set - register_set),
        "extra": sorted(register_set - expected_set),
        "region_missing": register_region_missing,
    }
    gbr_mismatch = {
        "missing": sorted(expected_set - gbr_set),
        "extra": sorted(gbr_set - expected_set),
        "region_missing": gbr_region_missing,
    }

    manual_registration = []
    ui_god_systems = []
    class_rx = re.compile(r"\bclass\s+([A-Za-z_][A-Za-z0-9_]*UISystem)\s*:\s*[^\n\{]*\bFrameSystem\b")
    for p in iter_project_cs(root, project_code_roots):
        rel = normalize(str(p.relative_to(root)))
        t = read_text(p)
        if normalize(rel) != normalize(layout_register_rel):
            if re.search(r"\bregisteLayout(?:Persist)?\s*<", t) and not match_allow(rel, manual_register_allowlist):
                manual_registration.append({"file": rel})
        for m in class_rx.finditer(t):
            cls = m.group(1)
            key = f"{rel}:{cls}"
            if match_allow(key, ui_frame_system_allowlist) or match_allow(rel, ui_frame_system_allowlist) or cls in ui_frame_system_allowlist:
                continue
            load_ops = len(re.findall(r"\bLT\s*\.\s*(?:LOAD|LOAD_TOP|HIDE|UNLOAD)\b", t))
            layout_refs = len(set(re.findall(r"\bmUI[A-Z][A-Za-z0-9_]*\b", t)))
            layout_mentions = len(set(re.findall(r"\bUI[A-Z][A-Za-z0-9_]*\b", t)))
            # A FrameSystem named UISystem becomes a hard candidate when it orchestrates multiple layouts.
            if load_ops >= 2 or layout_refs >= 3 or layout_mentions >= 4:
                ui_god_systems.append({
                    "file": rel,
                    "class": cls,
                    "lt_load_hide_ops": load_ops,
                    "layout_ref_count": layout_refs,
                    "ui_type_mentions": layout_mentions,
                })

    summary = {
        "generator_prefabs": len(generator_prefabs),
        "generator_root_failures": len(generator_root_failures),
        "generator_canvas_failures": len(generator_canvas_failures),
        "generator_parent_type_failures": len(generator_parent_type_failures),
        "sub_generator_parent_type_failures": len(sub_generator_parent_type_failures),
        "manual_generator_binding_candidates": len(manual_generator_binding_candidates),
        "layout_reset_property_candidates": len(layout_reset_property_candidates),
        "missing_layout_scripts": len(missing_layout_scripts),
        "layout_marker_or_source_failures": len(marker_failures),
        "layout_register_missing": len(register_mismatch["missing"]),
        "layout_register_extra": len(register_mismatch["extra"]),
        "gbr_layout_missing": len(gbr_mismatch["missing"]),
        "gbr_layout_extra": len(gbr_mismatch["extra"]),
        "manual_layout_registration_candidates": len(manual_registration),
        "ui_god_frame_system_candidates": len(ui_god_systems),
        "known_invalid_builtin_font_refs": len(bad_font_refs),
    }

    report = {
        "root": str(root),
        "config": str(args.config) if args.config else None,
        "summary": summary,
        "prefabs": prefab_reports,
        "generator_root_failures": generator_root_failures,
        "generator_canvas_failures": generator_canvas_failures,
        "generator_parent_type_failures": generator_parent_type_failures,
        "sub_generator_parent_type_failures": sub_generator_parent_type_failures,
        "manual_generator_binding_candidates": manual_generator_binding_candidates,
        "layout_reset_property_candidates": layout_reset_property_candidates,
        "missing_layout_scripts": missing_layout_scripts,
        "marker_failures": marker_failures,
        "layout_register": register_mismatch,
        "gbr": gbr_mismatch,
        "manual_layout_registration_candidates": manual_registration,
        "ui_god_frame_system_candidates": ui_god_systems,
        "known_invalid_builtin_font_refs": bad_font_refs,
        "notes": [
            "This validates static generator contracts only; it cannot prove the official Unity UGUIGenerator was executed.",
            "If generator execution was not observed in Unity, keep the project status GENERATOR_UNVERIFIED.",
            "3.1.0 also checks that common generator-owned binding statements do not leak outside auto-generate regions.",
            "3.1.0 treats LayoutScript resetProperty() as a migration contract violation unless explicitly allowlisted.",
        ],
    }

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("MyFramework UI contract audit")
        print("root:", root)
        if args.config:
            print("config:", args.config)
        for k, v in summary.items():
            print(f"{k:45} {v}")
        if generator_root_failures:
            print("\nRoot generator failures:")
            for x in generator_root_failures:
                print(" -", x)
        if generator_canvas_failures:
            print("\nGenerator not on Canvas:")
            for x in generator_canvas_failures:
                print(" -", x)
        if generator_parent_type_failures or sub_generator_parent_type_failures:
            print("\nGenerator parent type failures:")
            for x in generator_parent_type_failures + sub_generator_parent_type_failures:
                print(" -", x)
        if manual_generator_binding_candidates:
            print("\nManual generator binding candidates:")
            for x in manual_generator_binding_candidates:
                print(" -", x)
        if layout_reset_property_candidates:
            print("\nLayoutScript resetProperty candidates:")
            for x in layout_reset_property_candidates:
                print(" -", x)
        if missing_layout_scripts:
            print("\nMissing LayoutScripts:")
            for x in missing_layout_scripts:
                print(" -", x)
        if marker_failures:
            print("\nGenerator marker/source failures:")
            for x in marker_failures:
                print(" -", x)
        if manual_registration:
            print("\nManual layout registration candidates:")
            for x in manual_registration:
                print(" -", x["file"])
        if ui_god_systems:
            print("\nUI God FrameSystem candidates:")
            for x in ui_god_systems:
                print(" -", x)
        if bad_font_refs:
            print("\nKnown invalid builtin font refs:")
            for x in bad_font_refs:
                print(f" - {x['file']}:{x['line']}")
        print("\nNotes:")
        for n in report["notes"]:
            print("-", n)

    fail = {x.strip() for x in args.fail_on.split(",") if x.strip()}
    bad = False
    if "generator-root" in fail and generator_root_failures:
        bad = True
    if "canvas" in fail and generator_canvas_failures:
        bad = True
    if "parent-type" in fail and (generator_parent_type_failures or sub_generator_parent_type_failures):
        bad = True
    if "binding-owner" in fail and manual_generator_binding_candidates:
        bad = True
    if "layout-reset-property" in fail and layout_reset_property_candidates:
        bad = True
    if "layout-script" in fail and missing_layout_scripts:
        bad = True
    if "markers" in fail and marker_failures:
        bad = True
    if "register-set" in fail and (register_region_missing or register_mismatch["missing"] or register_mismatch["extra"]):
        bad = True
    if "gbr-set" in fail and (gbr_region_missing or gbr_mismatch["missing"] or gbr_mismatch["extra"]):
        bad = True
    if "manual-register" in fail and manual_registration:
        bad = True
    if "ui-god-system" in fail and ui_god_systems:
        bad = True
    if "bad-font" in fail and bad_font_refs:
        bad = True
    raise SystemExit(1 if bad else 0)


if __name__ == "__main__":
    main()
