﻿#!/usr/bin/env python3
"""Static resource-layout audit for MyFramework migration.

Checks the final staged Unity project for:
- unexpected Assets/Resources assets outside an explicit allowlist;
- project-owned Resources.Load calls;
- Legacy/Recovered runtime paths under Assets;
- duplicate Unity GUIDs in project Assets;
- expected path -> GUID contracts for moved assets;
- missing .meta beside Resources assets.

This is a static artifact gate only. It does not replace Unity import/compile/play.
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import re
from collections import defaultdict
from pathlib import Path

GUID_RE = re.compile(r"(?m)^guid:\s*([0-9a-fA-F]{32})\s*$")
RESOURCES_LOAD_RE = re.compile(r"\bResources\s*\.\s*Load(?:Async)?\b")


def read_text(path: Path) -> str:
    return path.read_bytes().decode("utf-8-sig", errors="replace")


def mask_comments_and_strings(src: str) -> str:
    out = list(src)
    i = 0
    n = len(src)
    state = "code"
    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ""
        if state == "code":
            if c == "/" and nxt == "/":
                out[i] = out[i + 1] = " "
                i += 2
                state = "line"
                continue
            if c == "/" and nxt == "*":
                out[i] = out[i + 1] = " "
                i += 2
                state = "block"
                continue
            if c == '"':
                out[i] = " "
                i += 1
                state = "string"
                continue
            if c == "'":
                out[i] = " "
                i += 1
                state = "char"
                continue
        elif state == "line":
            if c == "\n":
                state = "code"
            else:
                out[i] = " "
            i += 1
            continue
        elif state == "block":
            if c == "*" and nxt == "/":
                out[i] = out[i + 1] = " "
                i += 2
                state = "code"
                continue
            if c != "\n":
                out[i] = " "
            i += 1
            continue
        else:
            quote = '"' if state == "string" else "'"
            if c == "\\":
                out[i] = " "
                if i + 1 < n:
                    if src[i + 1] != "\n":
                        out[i + 1] = " "
                    i += 2
                    continue
            if c == quote:
                out[i] = " "
                i += 1
                state = "code"
                continue
            if c != "\n":
                out[i] = " "
            i += 1
            continue
        i += 1
    return "".join(out)


def load_config(path: Path | None) -> dict:
    if path is None:
        return {}
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize(path: str) -> str:
    return path.replace("\\", "/").lstrip("./")


def match_any(path: str, patterns: list[str]) -> bool:
    p = normalize(path)
    for pat in patterns:
        pat = normalize(pat)
        if fnmatch.fnmatchcase(p, pat):
            return True
    return False


def line_numbers(text: str, rx: re.Pattern[str]) -> list[int]:
    return [i for i, line in enumerate(text.splitlines(), 1) if rx.search(line)]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("root", type=Path)
    p.add_argument("--config", type=Path, help="MIGRATION_AUDIT_CONFIG.json")
    p.add_argument("--json", action="store_true")
    p.add_argument(
        "--fail-on",
        default="unexpected-resources,allowlist-reason,resources-load,legacy-path,duplicate-guid,expected-guid,missing-meta",
        help=(
            "comma-separated: unexpected-resources,allowlist-reason,resources-load,legacy-path,"
            "duplicate-guid,expected-guid,missing-meta"
        ),
    )
    return p.parse_args()


def main():
    args = parse_args()
    root = args.root.resolve()
    cfg = load_config(args.config)

    resources_allowlist = cfg.get(
        "resources_allowlist",
        [
            "Assets/Resources/Scene/start.unity",
            "Assets/Resources/Settings/FrameSettings.asset",
        ],
    )
    default_allowlist_reasons = {
        "Assets/Resources/Scene/start.unity": "MyFramework START_SCENE fixed contract",
        "Assets/Resources/Settings/FrameSettings.asset": "MyFramework FrameSettings Resources.Load fixed contract",
    }
    resources_allowlist_reasons = dict(default_allowlist_reasons)
    resources_allowlist_reasons.update(cfg.get("resources_allowlist_reasons", {}))
    allowlist_without_reason = [
        pattern for pattern in resources_allowlist
        if not str(resources_allowlist_reasons.get(pattern, "")).strip()
    ]
    project_code_roots = cfg.get(
        "project_code_roots", ["Assets/Scripts/Game", "Assets/Scripts/HotFix"]
    )
    resources_load_allowlist_files = cfg.get("resources_load_allowlist_files", [])
    legacy_fragments = cfg.get(
        "legacy_runtime_path_fragments",
        [
            "LegacyRuntimeDebt",
            "RecoveredSourceReference",
            "CompatibilityRuntime",
            "LegacyRuntime",
        ],
    )
    legacy_path_allowlist = cfg.get("legacy_runtime_path_allowlist", [])
    expected_guid_paths = cfg.get("expected_guid_paths", {})

    resources_root = root / "Assets/Resources"
    resource_assets: list[Path] = []
    if resources_root.exists():
        resource_assets = sorted(
            p for p in resources_root.rglob("*") if p.is_file() and p.suffix != ".meta"
        )

    resources_entries = []
    unexpected_resources = []
    missing_meta = []
    for p in resource_assets:
        rel = normalize(str(p.relative_to(root)))
        allowed = match_any(rel, resources_allowlist)
        meta = Path(str(p) + ".meta")
        guid = None
        if meta.exists():
            m = GUID_RE.search(read_text(meta))
            guid = m.group(1).lower() if m else None
        else:
            missing_meta.append(rel)
        entry = {"path": rel, "allowlisted": allowed, "guid": guid}
        resources_entries.append(entry)
        if not allowed:
            unexpected_resources.append(entry)

    # Project-owned Resources.Load calls.
    resources_load_hits = []
    for rel_root in project_code_roots:
        code_root = root / rel_root
        if not code_root.exists():
            continue
        for p in sorted(code_root.rglob("*.cs")):
            rel = normalize(str(p.relative_to(root)))
            if match_any(rel, resources_load_allowlist_files):
                continue
            masked = mask_comments_and_strings(read_text(p))
            for line in line_numbers(masked, RESOURCES_LOAD_RE):
                resources_load_hits.append({"file": rel, "line": line})

    # Legacy/recovered runtime paths under Assets.
    legacy_paths = []
    assets_root = root / "Assets"
    if assets_root.exists():
        seen = set()
        for p in assets_root.rglob("*"):
            if p.is_file() and p.suffix == ".meta":
                continue
            rel = normalize(str(p.relative_to(root)))
            if match_any(rel, legacy_path_allowlist):
                continue
            parts = Path(rel).parts
            hit = next((frag for frag in legacy_fragments if any(frag in part for part in parts)), None)
            if hit:
                # Report the first matching path prefix once to avoid thousands of files.
                idx = next(i for i, part in enumerate(parts) if hit in part)
                candidate = normalize(str(Path(*parts[: idx + 1])))
                key = (candidate, hit)
                if key not in seen:
                    seen.add(key)
                    legacy_paths.append({"path": candidate, "fragment": hit})

    # GUID inventory for Assets.
    guid_to_metas: dict[str, list[str]] = defaultdict(list)
    path_to_guid: dict[str, str] = {}
    if assets_root.exists():
        for meta in sorted(assets_root.rglob("*.meta")):
            try:
                text = read_text(meta)
            except OSError:
                continue
            m = GUID_RE.search(text)
            if not m:
                continue
            guid = m.group(1).lower()
            rel_meta = normalize(str(meta.relative_to(root)))
            asset_rel = rel_meta[:-5]  # strip .meta
            guid_to_metas[guid].append(rel_meta)
            path_to_guid[asset_rel] = guid

    duplicate_guids = [
        {"guid": guid, "meta_files": metas}
        for guid, metas in sorted(guid_to_metas.items())
        if len(metas) > 1
    ]

    expected_guid_mismatches = []
    for rel, expected in sorted(expected_guid_paths.items()):
        rel = normalize(rel)
        expected = str(expected).lower()
        actual = path_to_guid.get(rel)
        if actual != expected:
            expected_guid_mismatches.append(
                {"path": rel, "expected": expected, "actual": actual}
            )

    report = {
        "root": str(root),
        "config": str(args.config) if args.config else None,
        "resources_allowlist": resources_allowlist,
        "summary": {
            "resources_actual_assets": len(resources_entries),
            "resources_allowlisted_assets": sum(1 for x in resources_entries if x["allowlisted"]),
            "unexpected_resources_assets": len(unexpected_resources),
            "allowlist_entries_without_reason": len(allowlist_without_reason),
            "resources_assets_missing_meta": len(missing_meta),
            "project_resources_load_hits": len(resources_load_hits),
            "legacy_runtime_paths": len(legacy_paths),
            "duplicate_guids": len(duplicate_guids),
            "expected_guid_mismatches": len(expected_guid_mismatches),
        },
        "resources": resources_entries,
        "unexpected_resources": unexpected_resources,
        "allowlist_without_reason": allowlist_without_reason,
        "resources_allowlist_reasons": resources_allowlist_reasons,
        "missing_meta": missing_meta,
        "resources_load_hits": resources_load_hits,
        "legacy_runtime_paths": legacy_paths,
        "duplicate_guids": duplicate_guids,
        "expected_guid_mismatches": expected_guid_mismatches,
    }

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("MyFramework resource-layout audit")
        print("root:", root)
        if args.config:
            print("config:", args.config)
        for k, v in report["summary"].items():
            print(f"{k:38} {v}")
        if unexpected_resources:
            print("\nUnexpected Resources assets:")
            for x in unexpected_resources:
                print(" -", x["path"])
        if allowlist_without_reason:
            print("\nResources allowlist entries without evidence/reason:")
            for x in allowlist_without_reason:
                print(" -", x)
        if resources_load_hits:
            print("\nProject Resources.Load calls:")
            for x in resources_load_hits:
                print(f" - {x['file']}:{x['line']}")
        if legacy_paths:
            print("\nLegacy runtime paths:")
            for x in legacy_paths:
                print(" -", x["path"], f"({x['fragment']})")
        if duplicate_guids:
            print("\nDuplicate GUIDs:")
            for x in duplicate_guids:
                print(" -", x["guid"], "=>", ", ".join(x["meta_files"]))
        if expected_guid_mismatches:
            print("\nExpected GUID mismatches:")
            for x in expected_guid_mismatches:
                print(" -", x["path"], "expected", x["expected"], "actual", x["actual"])
        print("\nNotes:")
        print("- Assets/Resources is treated as an explicit allowlist, not a migration depot.")
        print("- Add package-required fixed Resources paths to the project config with evidence.")
        print("- This audit does not replace Unity import, compilation, Missing Script checks, or runtime parity.")

    fail = {x.strip() for x in args.fail_on.split(",") if x.strip()}
    bad = False
    s = report["summary"]
    if "unexpected-resources" in fail and s["unexpected_resources_assets"]:
        bad = True
    if "allowlist-reason" in fail and s["allowlist_entries_without_reason"]:
        bad = True
    if "resources-load" in fail and s["project_resources_load_hits"]:
        bad = True
    if "legacy-path" in fail and s["legacy_runtime_paths"]:
        bad = True
    if "duplicate-guid" in fail and s["duplicate_guids"]:
        bad = True
    if "expected-guid" in fail and s["expected_guid_mismatches"]:
        bad = True
    if "missing-meta" in fail and s["resources_assets_missing_meta"]:
        bad = True
    raise SystemExit(1 if bad else 0)


if __name__ == "__main__":
    main()
