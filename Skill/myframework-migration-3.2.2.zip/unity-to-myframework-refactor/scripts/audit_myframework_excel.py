#!/usr/bin/env python3
"""Static Excel toolchain audit for MyFramework migration.

This checks project-declared CSV/bytes/generated-code presence and obvious migration
fallback/hardcoded-data residue. It cannot prove the official CodeGenerator or
CSVToBinary executable was actually run; tool execution remains a separate gate.
"""
from __future__ import annotations

import argparse
import csv
import fnmatch
import json
import re
from pathlib import Path


def read_text(path: Path) -> str:
    return path.read_bytes().decode("utf-8-sig", errors="replace")


def load_config(path: Path | None) -> dict:
    if path is None:
        return {}
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize(path: str) -> str:
    return path.replace("\\", "/").lstrip("./")


def count_csv_data_rows(path: Path, metadata_rows: int = 9) -> int:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f))
    except Exception:
        return -1
    if len(rows) <= metadata_rows:
        return 0
    count = 0
    for row in rows[metadata_rows:]:
        if row and any(str(x).strip() for x in row):
            count += 1
    return count


def match_allow(value: str, patterns: list[str]) -> bool:
    value = normalize(value)
    return any(fnmatch.fnmatchcase(value, normalize(p)) for p in patterns)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", type=Path)
    ap.add_argument("--config", type=Path)
    ap.add_argument("--json", action="store_true")
    ap.add_argument(
        "--fail-on",
        default="missing,rows,register,gamehotfix,hardcoded,fallback",
        help="comma-separated: missing,rows,register,gamehotfix,hardcoded,fallback",
    )
    args = ap.parse_args()
    root = args.root.resolve()
    cfg = load_config(args.config)

    tables = cfg.get("excel_tables", [])
    register_rel = cfg.get("excel_register_path", "Assets/Scripts/HotFix/DataBase/Excel/ExcelRegister.cs")
    game_hotfix_rel = cfg.get("game_hotfix_path", "Assets/Scripts/HotFix/Game/GameHotFix.cs")
    metadata_rows_default = int(cfg.get("excel_csv_metadata_rows", 9))
    fallback_patterns = cfg.get(
        "excel_fallback_markers",
        [r"migration\s+fallback", r"GENERATOR_UNVERIFIED", r"TABLE_STRUCTURE_READY"],
    )

    table_reports = []
    missing = []
    row_failures = []
    fallback_hits = []

    register_path = root / register_rel
    register_text = read_text(register_path) if register_path.exists() else ""

    for item in tables:
        name = str(item.get("name") or "").strip()
        csv_rel = item.get("csv", f"Excels/{name}.csv")
        bytes_rel = item.get("bytes", f"Assets/GameResources/Excel/{name}.bytes")
        data_rel = item.get("data_class")
        table_rel = item.get("table_class")
        metadata_rows = int(item.get("metadata_rows", metadata_rows_default))
        min_rows = int(item.get("min_data_rows", 1))

        paths = {
            "csv": root / csv_rel,
            "bytes": root / bytes_rel,
            "data_class": root / data_rel if data_rel else None,
            "table_class": root / table_rel if table_rel else None,
        }
        exists = {k: (p is not None and p.exists()) for k, p in paths.items()}
        required_keys = ["csv", "bytes"] + (["data_class"] if data_rel else []) + (["table_class"] if table_rel else [])
        for key in required_keys:
            if not exists[key]:
                missing.append({"table": name, "kind": key, "path": normalize(str(paths[key].relative_to(root))) if paths[key] else None})

        data_rows = count_csv_data_rows(paths["csv"], metadata_rows) if exists["csv"] else -1
        if data_rows < min_rows:
            row_failures.append({"table": name, "rows": data_rows, "min": min_rows, "csv": csv_rel})

        bytes_size = paths["bytes"].stat().st_size if exists["bytes"] else 0
        if exists["bytes"] and bytes_size <= 0:
            missing.append({"table": name, "kind": "bytes-empty", "path": bytes_rel})

        register_ok = False
        if name and register_text:
            expected_table_type = Path(table_rel).stem if table_rel else f"Excel{name}"
            register_ok = name in register_text and expected_table_type in register_text

        scan_files = [p for p in [paths["data_class"], paths["table_class"]] if p and p.exists()]
        for p in scan_files:
            text = read_text(p)
            for pat in fallback_patterns:
                for m in re.finditer(pat, text, flags=re.I):
                    fallback_hits.append({
                        "table": name,
                        "file": normalize(str(p.relative_to(root))),
                        "line": text.count("\n", 0, m.start()) + 1,
                        "pattern": pat,
                    })

        table_reports.append({
            "name": name,
            "csv": csv_rel,
            "bytes": bytes_rel,
            "data_class": data_rel,
            "table_class": table_rel,
            "exists": exists,
            "data_rows": data_rows,
            "min_data_rows": min_rows,
            "bytes_size": bytes_size,
            "register_ok": register_ok,
        })

    register_failures = [x for x in table_reports if not x["register_ok"]]
    if tables and not register_path.exists():
        register_failures = [{"name": "<register-file-missing>", "path": register_rel}, *register_failures]

    game_hotfix_path = root / game_hotfix_rel
    game_hotfix_ok = False
    if game_hotfix_path.exists():
        text = read_text(game_hotfix_path)
        game_hotfix_ok = bool(re.search(r"\bregisterAllTable\s*\(", text)) and "ExcelRegister" in text and "registeAll" in text

    hardcoded_hits = []
    hardcoded_patterns = cfg.get("hardcoded_data_patterns", [])
    hardcoded_allowlist = cfg.get("hardcoded_data_allowlist", [])
    code_roots = cfg.get("project_code_roots", ["Assets/Scripts/Game", "Assets/Scripts/HotFix"])
    for rel_root in code_roots:
        base = root / rel_root
        if not base.exists():
            continue
        for p in base.rglob("*.cs"):
            rel = normalize(str(p.relative_to(root)))
            if match_allow(rel, hardcoded_allowlist):
                continue
            text = read_text(p)
            for item in hardcoded_patterns:
                if isinstance(item, str):
                    pat = item
                    label = item
                else:
                    pat = str(item.get("pattern") or "")
                    label = str(item.get("name") or pat)
                if not pat:
                    continue
                for m in re.finditer(pat, text, flags=re.I):
                    hardcoded_hits.append({
                        "file": rel,
                        "line": text.count("\n", 0, m.start()) + 1,
                        "name": label,
                        "match": m.group(0)[:160],
                    })

    summary = {
        "configured_tables": len(tables),
        "missing_artifacts": len(missing),
        "csv_row_failures": len(row_failures),
        "excel_register_failures": len(register_failures),
        "gamehotfix_register_all_table_ok": game_hotfix_ok,
        "hardcoded_data_hits": len(hardcoded_hits),
        "generator_fallback_markers": len(fallback_hits),
    }
    report = {
        "root": str(root),
        "config": str(args.config) if args.config else None,
        "summary": summary,
        "tables": table_reports,
        "missing_artifacts": missing,
        "csv_row_failures": row_failures,
        "excel_register_failures": register_failures,
        "gamehotfix_register_all_table_ok": game_hotfix_ok,
        "hardcoded_data_hits": hardcoded_hits,
        "generator_fallback_markers": fallback_hits,
        "notes": [
            "Static Excel audit cannot prove official CodeGenerator/CSVToBinary execution.",
            "Hand-authored ED/Excel or serializer-compatible bytes must remain GENERATOR_UNVERIFIED until official tool evidence exists.",
        ],
    }

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("MyFramework Excel toolchain audit")
        print("root:", root)
        for k, v in summary.items():
            print(f"{k:42} {v}")
        if missing:
            print("\nMissing artifacts:")
            for x in missing:
                print(" -", x)
        if row_failures:
            print("\nCSV row failures:")
            for x in row_failures:
                print(" -", x)
        if register_failures:
            print("\nExcelRegister failures:")
            for x in register_failures:
                print(" -", x)
        if hardcoded_hits:
            print("\nHardcoded data hits:")
            for x in hardcoded_hits:
                print(" -", x)
        if fallback_hits:
            print("\nGenerator fallback markers:")
            for x in fallback_hits:
                print(" -", x)
        print("\nNotes:")
        for x in report["notes"]:
            print("-", x)

    fail = {x.strip() for x in args.fail_on.split(",") if x.strip()}
    bad = False
    if "missing" in fail and missing:
        bad = True
    if "rows" in fail and row_failures:
        bad = True
    if "register" in fail and register_failures:
        bad = True
    if "gamehotfix" in fail and tables and not game_hotfix_ok:
        bad = True
    if "hardcoded" in fail and hardcoded_hits:
        bad = True
    if "fallback" in fail and fallback_hits:
        bad = True
    raise SystemExit(1 if bad else 0)


if __name__ == "__main__":
    main()
