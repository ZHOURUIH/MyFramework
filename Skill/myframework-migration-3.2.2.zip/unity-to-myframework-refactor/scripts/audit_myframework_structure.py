#!/usr/bin/env python3
"""Hard structural gate for MyFramework 1.1.12-style projects.

This does not replace Unity compilation. It verifies the canonical project bootstrap
shape used by the provided MyFramework 1.1.12 package and reference projects.
If the target framework version/fingerprint differs, update the expected profile
from that target's actual source before treating failures as hard errors.
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path

START_SCENE = Path("Assets/Resources/Scene/start.unity")
GAME_ENTRY = Path("Assets/Scripts/Game/Game/GameEntry.cs")
GAME = Path("Assets/Scripts/Game/Game/Game.cs")
GAME_HOTFIX = Path("Assets/Scripts/HotFix/Game/GameHotFix.cs")
GBR = Path("Assets/Scripts/HotFix/Common/GameBaseHotFix.cs")
LAUNCH_SCENE = Path("Assets/Scripts/Game/GameScene/LaunchScene/LaunchScene.cs")
SCENE_REGISTER = Path("Assets/Scripts/HotFix/SceneSystem/SceneRegister.cs")
BUILD_SETTINGS = Path("ProjectSettings/EditorBuildSettings.asset")
FRAME_SETTINGS = Path("Assets/Resources/Settings/FrameSettings.asset")
KEYFRAME_PREFAB = Path("Assets/GameResources/KeyFrame/Keyframe.prefab")


def read(path: Path) -> str:
    return path.read_text("utf-8-sig", errors="replace")


def has_all(text: str, parts: list[str]) -> bool:
    return all(p in text for p in parts)


def load_config(path: Path | None) -> dict:
    if path is None:
        return {}
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", type=Path)
    ap.add_argument("--config", type=Path)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    root = args.root.resolve()
    cfg = load_config(args.config)
    checks = []

    def check(name: str, ok: bool, detail: str):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    start = root / START_SCENE
    check("start_scene_exact_path", start.exists(), str(START_SCENE))
    if cfg.get("require_frame_settings", True):
        check("frame_settings_exact_path", (root / FRAME_SETTINGS).exists(), str(FRAME_SETTINGS))
    if cfg.get("require_keyframe_prefab", True):
        keyframe_path = Path(cfg.get("keyframe_prefab_path", KEYFRAME_PREFAB.as_posix()))
        check("keyframe_prefab_exact_path", (root / keyframe_path).exists(), str(keyframe_path))
    if start.exists():
        t = read(start)
        check("start_scene_gameentry_root", bool(re.search(r"(?m)^\s*m_Name:\s*GameEntry\s*$", t)), "root GameObject named GameEntry")

    files = {
        "game_entry": root / GAME_ENTRY,
        "game": root / GAME,
        "game_hotfix": root / GAME_HOTFIX,
        "gbr": root / GBR,
        "launch_scene": root / LAUNCH_SCENE,
        "scene_register": root / SCENE_REGISTER,
    }
    for key, p in files.items():
        check(key + "_exists", p.exists(), str(p.relative_to(root)))

    if files["game_entry"].exists():
        t = read(files["game_entry"])
        check("gameentry_inherits_base", "class GameEntry : GameEntryBase" in t, "GameEntry : GameEntryBase")
        check("gameentry_awake_base", "base.Awake()" in t, "GameEntry.Awake calls base.Awake()")
        check("gameentry_sets_aot_framework", "setFrameworkAOT" in t, "AOT framework attached to GameEntryBase")

    if files["game"].exists():
        t = read(files["game"])
        check("game_inherits_framework", "class Game : GameFramework" in t, "Game : GameFramework")
        check("game_init_base", "base.init()" in t, "Game.init calls base.init()")
        check("game_registers_framework_callbacks", has_all(t, ["mOnInitFrameSystem", "mOnRegisteStuff"]), "register callbacks before base.init")
        check("game_enters_launch_scene", "enterScene<LaunchScene>" in t, "AOT enters LaunchScene")

    if files["launch_scene"].exists():
        t = read(files["launch_scene"])
        check("launchscene_is_gamescene", bool(re.search(r"class\s+LaunchScene\s*:\s*GameScene", t)), "LaunchScene : GameScene")
        check("launchscene_start_exit", has_all(t, ["assignStartExitProcedure", "mStartProcedure", "mExitProcedure"]), "start/exit procedure assigned")
        check("launchscene_creates_procedures", "createSceneProcedure" in t and "addProcedure<" in t, "procedures registered")

    if files["game_hotfix"].exists():
        t = read(files["game_hotfix"])
        check("gamehotfix_inherits_base", "GameHotFixBase<GameHotFix>" in t, "GameHotFixBase<GameHotFix>")
        for method in ["registerAllTable", "registerAll", "initFrameSystem", "getStartGameSceneType"]:
            check("gamehotfix_" + method, method in t, method)
        check("gamehotfix_registers_frame_system", "registeFrameSystem<" in t, "application systems use registeFrameSystem")

    if files["gbr"].exists():
        t = read(files["gbr"])
        check("gbr_type", bool(re.search(r"\bclass\s+GBR\b", t)), "class GBR")
        check("gbr_layout_generate_markers", "auto generate LayoutScript start" in t and "auto generate LayoutScript end" in t, "LayoutScript generator markers")

    if files["scene_register"].exists():
        t = read(files["scene_register"])
        check("scene_register_uses_scene_system", "mSceneSystem.registeScene" in t, "SceneInstance registered through SceneSystem")

    bs = root / BUILD_SETTINGS
    if bs.exists():
        t = read(bs)
        scenes = re.findall(r"- enabled:\s*(\d+)\s*\n\s*path:\s*([^\n\r]+)", t)
        if scenes:
            enabled, path = scenes[0]
            check("build_settings_start_first", enabled == "1" and path.strip() == START_SCENE.as_posix(), f"first={path.strip()}, enabled={enabled}")
            enabled_paths = {path.strip() for enabled, path in scenes if enabled == "1"}
            required_scenes = [START_SCENE.as_posix(), *cfg.get("build_settings_required_scenes", [])]
            seen = set()
            for scene_path in required_scenes:
                scene_path = str(scene_path).replace("\\", "/")
                if scene_path in seen:
                    continue
                seen.add(scene_path)
                check(
                    "build_settings_required_scene_" + re.sub(r"[^A-Za-z0-9]+", "_", scene_path).strip("_"),
                    scene_path in enabled_paths and (root / scene_path).exists(),
                    scene_path,
                )
        else:
            check("build_settings_start_first", False, "could not parse first scene")
    else:
        check("build_settings_exists", False, str(BUILD_SETTINGS))

    failed = [x for x in checks if not x["ok"]]
    result = {"root": str(root), "checks": checks, "failed": len(failed), "failed_checks": failed}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        for x in checks:
            print(("PASS" if x["ok"] else "FAIL"), x["name"], "-", x["detail"])
        print("failed:", len(failed))
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
