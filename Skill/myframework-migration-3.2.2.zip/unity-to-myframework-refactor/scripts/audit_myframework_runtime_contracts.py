#!/usr/bin/env python3
"""Audit declared table/runtime contracts and evidence coverage (Python 3.10+).

Read-only. Uses the standard library, not Unity, Roslyn or a replacement serializer.
Exit 0: declared static checks passed; 1: contract gaps/findings; 2: invalid input.
Never promotes user-declared runtime evidence to independently verified results.
"""
from __future__ import annotations

import argparse
import csv
from decimal import Decimal, InvalidOperation
import fnmatch
import hashlib
import json
from pathlib import Path
import re

CATEGORY_FIELDS = {
    "tables": ("identity", "ordering", "consumers", "required_values", "readiness", "legacy_migration", "random_selection"),
    "scenes": ("responsibilities", "async_completion", "duplicate_load", "entry_gate", "failure_cleanup", "restart", "exit_order"),
    "state_lifetimes": ("owner", "scope", "serialized", "load", "ui_hide", "layout_restart", "game_exit", "application_restart"),
    "ui": ("event_owner", "refresh_trigger", "input_policy", "visual_interactable", "animation_channels", "cancel_policy", "generated_boundary"),
    "timing": ("clock", "phase", "interval", "initial_state", "catch_up", "condition_order", "interval_change", "pause", "reset", "rng"),
}
PLACEHOLDERS = {"", "TODO", "TBD", "UNSET", "UNKNOWN", "PENDING", "待填写", "待补充"}
VERIFICATION_STATUSES = {"UNVERIFIED", "STATIC_ONLY", "RUNTIME_EVIDENCE_RECORDED"}


def meaningful(value) -> bool:
    if isinstance(value, bool):
        return True
    if isinstance(value, (int, float)):
        return True
    if isinstance(value, str):
        return value.strip().upper() not in PLACEHOLDERS
    return False


def safe_path(root: Path, rel: str) -> Path:
    if not isinstance(rel, str) or not rel.strip():
        raise ValueError("Expected a nonempty relative path")
    p = Path(rel.replace("\\", "/"))
    if p.is_absolute() or ".." in p.parts:
        raise ValueError(f"Path must stay within its declared root: {rel}")
    result = (root / p).resolve()
    if not result.is_relative_to(root.resolve()):
        raise ValueError(f"Path escapes root: {rel}")
    return result


def integer(value, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def mask_cs_noncode(text: str) -> str:
    """Mask common C# comments/strings while preserving offsets and newlines.

    A conservative lexical aid, not a C# parser. Complex interpolation/raw-string
    syntax and preprocessor branches still require Roslyn/manual confirmation.
    """
    pattern = r'//[^\n]*|/\*[\s\S]*?\*/|"""[\s\S]*?"""|@"(?:""|[^"])*"|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
    return re.sub(pattern, lambda m: re.sub(r"[^\n]", " ", m.group()), text)


def normalize_id(value: str, kind: str) -> str:
    value = value.strip()
    if not value:
        raise ValueError("empty ID")
    if kind == "int":
        if re.fullmatch(r"[+-]?\d+", value) is None:
            raise ValueError(f"invalid integer ID: {value}")
        return str(int(value))
    if kind != "string":
        raise ValueError("id_type must be int or string")
    return value


def finite_number(value: str) -> Decimal:
    try:
        result = Decimal(value.strip())
    except InvalidOperation as exc:
        raise ValueError(f"invalid numeric value: {value}") from exc
    if not result.is_finite():
        raise ValueError(f"nonfinite numeric value: {value}")
    return result


def audit(root: Path, cfg: dict, source_root: Path | None = None) -> dict:
    root = root.resolve()
    if not root.is_dir():
        raise ValueError(f"Project root missing: {root}")
    if source_root is not None:
        source_root = source_root.resolve()
        if not source_root.is_dir():
            raise ValueError(f"Source root missing: {source_root}")
    if not isinstance(cfg, dict):
        raise ValueError("Audit configuration must be a JSON object")
    settings = cfg.get("runtime_contracts")
    if not isinstance(settings, dict) or settings.get("schema_version") != 1:
        raise ValueError("runtime_contracts.schema_version=1 is required; omitted configuration is not a pass")
    categories = settings.get("categories")
    if not isinstance(categories, dict):
        raise ValueError("runtime_contracts.categories must be an object")
    unknown = set(categories) - set(CATEGORY_FIELDS)
    if unknown:
        raise ValueError(f"Unknown categories: {sorted(unknown)}")
    issues, evidence_report, table_reports, rule_reports, candidates = [], [], [], [], []
    item_count = 0
    tables = {}
    deferred_fks = []
    verification_counts = {k: 0 for k in sorted(VERIFICATION_STATUSES)}
    category_reports = []

    def issue(code: str, where: str, message: str):
        issues.append({"code": code, "where": where, "message": message})

    def evidence(items, where: str):
        if not isinstance(items, list) or not items:
            issue("EVIDENCE_MISSING", where, "At least one exact file evidence locator is required")
            return
        for index, item in enumerate(items):
            loc = f"{where}[{index}]"
            if not isinstance(item, dict):
                issue("EVIDENCE_SCHEMA", loc, "Evidence must be an object")
                continue
            side = item.get("root", "project")
            base = root if side == "project" else source_root if side == "source" else None
            if base is None:
                issue("EVIDENCE_ROOT", loc, "Use root=project or source; source requires --source-root")
                continue
            try:
                path = safe_path(base, item.get("path"))
                if not path.is_file() or path.stat().st_size == 0:
                    raise ValueError("Evidence file missing or empty")
                raw = path.read_bytes()
                digest = hashlib.sha256(raw).hexdigest()
                token = item.get("contains")
                expected_hash = item.get("sha256")
                if not token and not expected_hash:
                    raise ValueError("Evidence needs a literal contains locator or sha256")
                if token:
                    if not isinstance(token, str) or not meaningful(token):
                        raise ValueError("contains must be a non-placeholder literal")
                    if token not in raw.decode("utf-8-sig"):
                        raise ValueError(f"Evidence literal not found: {token}")
                if expected_hash and expected_hash != digest:
                    raise ValueError("Evidence SHA-256 does not match current file")
                evidence_report.append({"where": loc, "root": side, "path": item["path"],
                                        "sha256": digest, "status": "LOCATOR_FOUND_NOT_SEMANTIC_PROOF"})
            except (OSError, UnicodeError, ValueError) as exc:
                issue("EVIDENCE_INVALID", loc, str(exc))

    def audit_csv(item_id: str, check):
        if not isinstance(check, dict):
            issue("TABLE_CHECK_MISSING", item_id, "tables items require csv_check; artifact presence alone is insufficient")
            return
        try:
            path = safe_path(root, check.get("path"))
            metadata = integer(check.get("metadata_rows", 9), "metadata_rows")
            id_column = integer(check.get("id_column", 0), "id_column")
            min_rows = integer(check.get("min_data_rows", 1), "min_data_rows", 1)
            kind = check.get("id_type", "int")
            normalize_id("1", kind)
            with path.open("r", encoding="utf-8-sig", newline="") as f:
                # Report CSV logical record numbers (quoted multiline fields are supported).
                rows = [(i + 1, row) for i, row in enumerate(csv.reader(f))
                        if i >= metadata and any(cell.strip() for cell in row)]
        except (OSError, UnicodeError, ValueError, csv.Error) as exc:
            issue("TABLE_READ", item_id, str(exc))
            return
        if len(rows) < min_rows:
            issue("TABLE_ROWS", item_id, f"Expected at least {min_rows} data rows, got {len(rows)}")
        ids = set()
        unique_columns = check.get("unique_columns", [])
        finite_columns = check.get("finite_columns", [])
        if not isinstance(unique_columns, list) or not isinstance(finite_columns, list):
            raise ValueError(f"{item_id}: column lists must be arrays")
        unique_seen = {integer(c, "unique_column"): set() for c in unique_columns}
        finite_columns = [integer(c, "finite_column") for c in finite_columns]
        ranges = check.get("numeric_ranges", [])
        foreign_keys = check.get("foreign_keys", [])
        if not isinstance(ranges, list) or not isinstance(foreign_keys, list):
            raise ValueError(f"{item_id}: numeric_ranges/foreign_keys must be arrays")
        for record, row in rows:
            loc = f"{item_id}:{path.relative_to(root).as_posix()}:record{record}"
            try:
                if id_column >= len(row):
                    raise ValueError("ID column missing")
                key = normalize_id(row[id_column], kind)
                if key in ids:
                    issue("TABLE_DUPLICATE_ID", loc, f"Duplicate ID {key}")
                ids.add(key)
            except ValueError as exc:
                issue("TABLE_ID", loc, str(exc))
            for column, seen in unique_seen.items():
                if column >= len(row) or not row[column].strip():
                    issue("TABLE_UNIQUE_VALUE", loc, f"Column {column} is missing/empty")
                elif row[column].strip() in seen:
                    issue("TABLE_UNIQUE_VALUE", loc, f"Duplicate value in column {column}: {row[column]}")
                else:
                    seen.add(row[column].strip())
            for column in finite_columns:
                try:
                    finite_number(row[column])
                except (ValueError, IndexError) as exc:
                    issue("TABLE_FINITE", loc, f"Column {column}: {exc}")
            for constraint in ranges:
                if not isinstance(constraint, dict):
                    raise ValueError("Each numeric_ranges entry must be an object")
                column = integer(constraint.get("column"), "range column")
                if "min" not in constraint and "max" not in constraint:
                    raise ValueError("Numeric range must specify min and/or max")
                try:
                    value = finite_number(row[column])
                    for edge in ("min", "max"):
                        if edge not in constraint:
                            continue
                        bound = finite_number(str(constraint[edge]))
                        exclusive = constraint.get(edge + "_exclusive", False)
                        if not isinstance(exclusive, bool):
                            raise ValueError(f"{edge}_exclusive must be boolean")
                        invalid = (value < bound or (exclusive and value == bound)) if edge == "min" else (value > bound or (exclusive and value == bound))
                        if invalid:
                            issue("TABLE_RANGE", loc, f"Column {column}: {value} violates {edge}={bound}, exclusive={exclusive}")
                except (ValueError, IndexError) as exc:
                    issue("TABLE_RANGE", loc, f"Column {column}: {exc}")
        required = check.get("required_ids", [])
        if not isinstance(required, list):
            raise ValueError("required_ids must be an array")
        for value in required:
            key = normalize_id(str(value), kind)
            if key not in ids:
                issue("TABLE_REQUIRED_ID", item_id, f"Required ID missing: {key}")
        tables[item_id] = {"ids": ids, "kind": kind}
        for fk in foreign_keys:
            if not isinstance(fk, dict) or not isinstance(fk.get("target_table"), str):
                raise ValueError("Foreign key requires column and target_table item ID")
            column = integer(fk.get("column"), "foreign key column")
            allow_empty = fk.get("allow_empty", False)
            if not isinstance(allow_empty, bool):
                raise ValueError("foreign key allow_empty must be boolean")
            deferred_fks.append((item_id, rows, column, fk["target_table"], allow_empty))
        table_reports.append({"id": item_id, "path": path.relative_to(root).as_posix(),
                              "data_rows": len(rows), "unique_ids": len(ids), "id_type": kind,
                              "csv_sha256": hashlib.sha256(path.read_bytes()).hexdigest()})

    for name, fields in CATEGORY_FIELDS.items():
        group = categories.get(name)
        if not isinstance(group, dict):
            issue("CATEGORY_MISSING", name, "Category must be declared or explicitly not_applicable with evidence")
            category_reports.append({"category": name, "status": "MISSING", "items": 0})
            continue
        state = group.get("status", "pending")
        items = group.get("items", [])
        if not isinstance(items, list):
            raise ValueError(f"{name}.items must be an array")
        category_reports.append({"category": name, "status": state, "items": len(items)})
        if state == "not_applicable":
            if items:
                issue("CATEGORY_CONFLICT", name, "not_applicable cannot contain covered items")
            if not meaningful(group.get("reason")):
                issue("CATEGORY_REASON", name, "not_applicable needs a source-based reason")
            evidence(group.get("evidence"), name + ".not_applicable")
            continue
        if state != "declared" or not items:
            issue("CATEGORY_UNCOVERED", name, "Pending/empty category is not a static pass")
            continue
        seen = set()
        for item in items:
            item_count += 1
            if not isinstance(item, dict) or not meaningful(item.get("id")):
                issue("ITEM_ID", name, "Each contract item requires a stable nonempty id")
                continue
            item_id = str(item["id"])
            loc = f"{name}.{item_id}"
            if item_id in seen:
                issue("ITEM_DUPLICATE", loc, "Duplicate contract ID")
            seen.add(item_id)
            spec = item.get("contract", {})
            if not isinstance(spec, dict):
                issue("CONTRACT_SCHEMA", loc, "contract must be an object")
                spec = {}
            for field in fields:
                if not meaningful(spec.get(field)):
                    issue("CONTRACT_FIELD", loc, f"Missing/placeholder field: {field}")
            if name == "state_lifetimes" and not isinstance(spec.get("serialized"), bool):
                issue("SERIALIZED_TYPE", loc, "serialized must be true or false, not a truthy string")
            evidence(item.get("source_evidence"), loc + ".source")
            evidence(item.get("implementation_evidence"), loc + ".implementation")
            verification = item.get("verification", {})
            if not isinstance(verification, dict):
                verification = {}
            v = verification.get("status")
            if v not in VERIFICATION_STATUSES:
                issue("VERIFICATION_STATUS", loc, f"Use one of {sorted(VERIFICATION_STATUSES)}")
            else:
                verification_counts[v] += 1
                if v == "RUNTIME_EVIDENCE_RECORDED":
                    evidence(verification.get("evidence"), loc + ".runtime")
            if name == "tables":
                audit_csv(item_id, item.get("csv_check"))

    for item_id, rows, column, target, allow_empty in deferred_fks:
        if target not in tables:
            issue("TABLE_FOREIGN_TARGET", item_id, f"Target table not successfully read: {target}")
            continue
        for record, row in rows:
            loc = f"{item_id}:record{record}"
            if column >= len(row):
                issue("TABLE_FOREIGN_KEY", loc, f"Missing column {column}")
                continue
            if not row[column].strip() and allow_empty:
                continue
            try:
                key = normalize_id(row[column], tables[target]["kind"])
                if key not in tables[target]["ids"]:
                    issue("TABLE_FOREIGN_KEY", loc, f"{key} not found in {target}")
            except ValueError as exc:
                issue("TABLE_FOREIGN_KEY", loc, str(exc))

    rules = settings.get("scan_rules", [])
    if not isinstance(rules, list):
        raise ValueError("scan_rules must be an array")
    seen_rules = set()
    for rule in rules:
        if not isinstance(rule, dict) or not meaningful(rule.get("id")):
            raise ValueError("Every scan_rule requires an id")
        rule_id = str(rule["id"])
        if rule_id in seen_rules:
            raise ValueError(f"Duplicate scan_rule id: {rule_id}")
        seen_rules.add(rule_id)
        include = rule.get("include")
        exclude = rule.get("exclude", [])
        if not isinstance(include, list) or not include or not isinstance(exclude, list):
            raise ValueError(f"{rule_id}: include must be nonempty; include/exclude must be arrays")
        for pattern in include + exclude:
            safe_path(root, pattern)
        if not meaningful(rule.get("reason")):
            raise ValueError(f"{rule_id}: source-based review reason is required")
        try:
            regex = re.compile(rule["pattern"], re.MULTILINE)
        except (KeyError, TypeError, re.error) as exc:
            raise ValueError(f"{rule_id}: invalid pattern: {exc}") from exc
        mode = rule.get("mode", "forbid")
        scan = rule.get("scan", "code")
        if mode not in ("forbid", "require") or scan not in ("code", "raw"):
            raise ValueError(f"{rule_id}: invalid mode/scan")
        files = set()
        for glob in include:
            for p in root.glob(glob):
                if not p.is_file():
                    continue
                rel = p.relative_to(root).as_posix()
                safe_path(root, rel)
                if not any(fnmatch.fnmatchcase(rel, pat) for pat in exclude):
                    files.add(p)
        if not files:
            issue("RULE_NO_COVERAGE", rule_id, "No files matched; this rule was not evaluated")
        hit_count = 0
        for p in sorted(files):
            raw = p.read_text(encoding="utf-8-sig")
            text = mask_cs_noncode(raw) if scan == "code" else raw
            matches = list(regex.finditer(text))
            rel = p.relative_to(root).as_posix()
            if mode == "require" and not matches:
                candidates.append({"rule": rule_id, "file": rel, "line": None,
                                   "reason": rule["reason"], "status": "REVIEW_REQUIRED_MISSING_PATTERN"})
                hit_count += 1
            elif mode == "forbid":
                for match in matches:
                    candidates.append({"rule": rule_id, "file": rel,
                                       "line": text.count("\n", 0, match.start()) + 1,
                                       "reason": rule["reason"], "status": "REVIEW_REQUIRED_PATTERN_MATCH"})
                    hit_count += 1
        rule_reports.append({"id": rule_id, "files_scanned": len(files), "review_candidates": hit_count})

    bad = bool(issues or candidates)
    status = "STATIC_FAIL" if issues else "REVIEW_REQUIRED" if candidates else "STATIC_DECLARED_CHECKS_PASS"
    return {"schema_version": 1, "root": str(root), "source_root": str(source_root) if source_root else None,
            "status": status, "exit_code": 1 if bad else 0,
            "summary": {"contract_items": item_count, "categories": len(CATEGORY_FIELDS),
                        "tables_read": len(table_reports), "evidence_locators_found": len(evidence_report),
                        "issues": len(issues), "review_candidates": len(candidates), "scan_rules": len(rules)},
            "category_coverage": category_reports, "tables": table_reports, "issues": issues,
            "rules": rule_reports, "review_candidates": candidates, "evidence": evidence_report,
            "verification_claims": verification_counts,
            "independent_runtime_verification": "NOT_PERFORMED",
            "official_generator_verification": "NOT_PERFORMED",
            "notes": ["Only declared CSV constraints, evidence locators and scoped patterns were checked.",
                      "Semantic correctness, actual bytes decoding, dependency traversal, Unity compilation, runtime timing and parity require separate execution.",
                      "A matching symbol, supplied log or empty pattern list does not prove all consumers or runtime paths are covered."]}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root", type=Path)
    ap.add_argument("--config", type=Path, required=True)
    ap.add_argument("--source-root", type=Path, help="Read-only, already supplied upstream or frozen baseline root")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    try:
        cfg = json.loads(args.config.read_text(encoding="utf-8-sig"))
        report = audit(args.root, cfg, args.source_root)
    except (OSError, UnicodeError, ValueError, TypeError, KeyError, csv.Error) as exc:
        report = {"status": "NOT_EVALUATED", "exit_code": 2, "error": str(exc)}
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("MyFramework runtime contract static audit")
        print("status:", report["status"])
        for key, value in report.get("summary", {}).items():
            print(f"{key:32} {value}")
        for key in ("issues", "review_candidates", "notes"):
            for value in report.get(key, []):
                print(key + ":", value)
        if "error" in report:
            print("error:", report["error"])
    raise SystemExit(report["exit_code"])


if __name__ == "__main__":
    main()
