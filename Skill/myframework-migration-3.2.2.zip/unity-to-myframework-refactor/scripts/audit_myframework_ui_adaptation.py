#!/usr/bin/env python3
"""Read-only ScaleAnchor/PaddingAnchor policy audit of serialized UI Prefabs.

The report inspects declared RectTransforms, component GUIDs, and relevant
nested-Prefab overrides. It never repairs Prefabs or certifies visual parity.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

COMPONENT_NAMES = {"ScaleAnchor", "ResScaleAnchor", "PaddingAnchor", "ResPaddingAnchor"}
EXCEPTION_KEYS = ("padding_exceptions", "nonuniform_scale_exceptions", "automatic_node_exceptions")
OVERRIDE_FIELDS = {"m_AnchorMin", "m_AnchorMax", "m_KeepAspect", "mKeepAspect", "mAspectBase", "mRemoveUGUIAnchor", "m_Script",
                   "m_Pivot", "m_LocalRotation", "m_LocalScale", "mAnchorMode", "mHorizontalNearSide", "mVerticalNearSide",
                   "mRelativeDistance", "mDistanceToBoard", "mAnchorPoint", "mHorizontalPositionRelative",
                   "mHorizontalPositionAbsolute", "mVerticalPositionRelative", "mVerticalPositionAbsolute"}


def read_text(path: Path) -> str:
    return path.read_bytes().decode("utf-8-sig", errors="replace")


def normalize(value: str) -> str:
    return value.replace("\\", "/").removeprefix("./")


def field(block: str, name: str, default: str = "") -> str:
    match = re.search(r"(?m)^  " + re.escape(name) + r":\s*(.*)$", block)
    return match.group(1).strip() if match else default


def vector(block: str, name: str):
    raw = field(block, name)
    values = re.findall(r"[xy]:\s*([-+0-9.eE]+)", raw)
    return tuple(float(x) for x in values) if len(values) == 2 else None


def transform_vector(block: str, name: str, axes: str):
    raw = field(block, name)
    if not raw:
        return None
    values = []
    for axis in axes:
        match = re.search(r"\b" + axis + r":\s*([-+0-9.eE]+)", raw)
        if not match:
            raise ValueError(f"Cannot parse serialized {name}: {raw}")
        values.append(float(match.group(1)))
    return tuple(values)


def name_value(value: str) -> str:
    if value.startswith('"'):
        try:
            return json.loads(value)
        except ValueError:
            return value.strip('"')
    return value.strip("'")


def load_components(root: Path, cfg: dict) -> dict[str, str]:
    declared = cfg.get("anchor_component_guids", {})
    components = {}
    for name, guids in declared.items():
        if name not in COMPONENT_NAMES:
            raise ValueError(f"Unknown anchor component name: {name}")
        for guid in guids:
            if not re.fullmatch(r"[0-9a-fA-F]{32}", guid):
                raise ValueError(f"Invalid component GUID: {guid}")
            key = guid.lower()
            if key in components and components[key] != name:
                raise ValueError(f"Conflicting anchor component GUID identity: {guid}")
            components[key] = name
    if components:
        return components
    # Discover this project's actual framework; do not assume one release GUID.
    for directory in (root / "Packages", root / "Library/PackageCache", root / "Assets"):
        if not directory.exists():
            continue
        for path in directory.rglob("*.cs.meta"):
            name = path.name.removesuffix(".cs.meta")
            if name not in COMPONENT_NAMES:
                continue
            match = re.search(r"(?m)^guid:\s*([0-9a-fA-F]{32})\s*$", read_text(path))
            if match:
                key = match.group(1).lower()
                if key in components and components[key] != name:
                    raise ValueError(f"Conflicting discovered anchor GUID identity: {key}")
                components[key] = name
    if not any(name.endswith("ScaleAnchor") for name in components.values()):
        raise ValueError("No ScaleAnchor/ResScaleAnchor GUID found; provide target-version anchor_component_guids")
    if not any(name.endswith("PaddingAnchor") for name in components.values()):
        raise ValueError("No PaddingAnchor/ResPaddingAnchor GUID found; provide target-version anchor_component_guids")
    return components


def load_exceptions(cfg: dict) -> dict[str, dict[tuple[str, str], str]]:
    result = {}
    for category in EXCEPTION_KEYS:
        entries = {}
        for item in cfg.get(category, []):
            prefab = normalize(item.get("prefab", ""))
            node = item.get("node", "")
            reason = item.get("reason", "").strip()
            if not prefab or not node or not reason or any(c in prefab + node for c in "*?["):
                raise ValueError(f"{category} requires exact prefab + node + a nonempty reason; no wildcard")
            key = (prefab, node)
            if key in entries:
                raise ValueError(f"Duplicate {category} entry: {key}")
            entries[key] = reason
        result[category] = entries
    return result


def load_aspect_values(root: Path, cfg: dict) -> dict[str, int]:
    if "aspect_base_values" in cfg:
        values = cfg["aspect_base_values"]
        if not all(name in values and type(values[name]) is int for name in ("AUTO", "NONE")) or values["AUTO"] == values["NONE"]:
            raise ValueError("aspect_base_values requires verified integer AUTO and NONE values")
        return values
    discovered = []
    for directory in (root / "Packages", root / "Library/PackageCache", root / "Assets"):
        if not directory.exists():
            continue
        for path in directory.rglob("FrameBaseEnum.cs"):
            match = re.search(r"enum\s+ASPECT_BASE\b[^\{]*\{([^}]*)\}", read_text(path), flags=re.S)
            if not match:
                continue
            body = re.sub(r"/\*.*?\*/|//[^\r\n]*|\[[^\]]*\]", "", match.group(1), flags=re.S)
            values, number = {}, 0
            for entry in body.split(","):
                entry = entry.strip()
                if not entry:
                    continue
                item = re.fullmatch(r"([A-Za-z_]\w*)\s*(?:=\s*(\d+))?", entry)
                if not item:
                    raise ValueError(f"Cannot resolve ASPECT_BASE entry in {path}; configure aspect_base_values")
                if item.group(2) is not None:
                    number = int(item.group(2))
                values[item.group(1)] = number
                number += 1
            if "AUTO" in values and "NONE" in values:
                discovered.append(values)
    if not discovered or any(values != discovered[0] for values in discovered):
        raise ValueError("ASPECT_BASE identity missing/conflicting; provide verified aspect_base_values")
    return discovered[0]


def expected_components(prefab: str, cfg: dict) -> tuple[str, str]:
    policies = cfg.get("scale_component_by_root", {"Assets/GameResources": "ScaleAnchor", "Assets/Resources": "ResScaleAnchor"})
    matching = [(normalize(directory), name) for directory, name in policies.items()
                if prefab.startswith(normalize(directory).rstrip("/") + "/")]
    if not matching:
        raise ValueError(f"No Game/HotFix layer declared for {prefab}; configure ui_adaptation.scale_component_by_root")
    directory, scale_name = max(matching, key=lambda entry: len(entry[0]))
    if scale_name not in ("ScaleAnchor", "ResScaleAnchor"):
        raise ValueError(f"Invalid scale component for {directory}: {scale_name}")
    return scale_name, "ResPaddingAnchor" if scale_name == "ResScaleAnchor" else "PaddingAnchor"


def parse_prefab(raw: str):
    names, transforms, components, instances = {}, {}, {}, []
    for block in re.split(r"(?=^--- !u!)", raw, flags=re.M):
        header = re.match(r"--- !u!(\d+) &(-?\d+)(?: stripped)?\s*\n", block)
        if not header:
            continue
        kind, identifier = map(int, header.groups())
        if kind == 1:
            names[identifier] = name_value(field(block, "m_Name", str(identifier)))
        elif kind == 224 and " stripped\n" not in header.group(0):
            go = re.search(r"m_GameObject:\s*\{fileID:\s*(-?\d+)\}", block)
            father = re.search(r"m_Father:\s*\{fileID:\s*(-?\d+)\}", block)
            transforms[identifier] = {"go": int(go.group(1)) if go else 0,
                                      "father": int(father.group(1)) if father else 0,
                                      "block": block}
        elif kind == 114:
            go = re.search(r"m_GameObject:\s*\{fileID:\s*(-?\d+)\}", block)
            script = re.search(r"m_Script:\s*\{[^}]*guid:\s*([0-9a-fA-F]{32})", block)
            if go and script:
                components.setdefault(int(go.group(1)), []).append((script.group(1).lower(), block))
        elif kind == 1001:
            instances.append(block)
    return names, transforms, components, instances


def audit(root: Path, config: dict) -> dict:
    root = root.resolve()
    cfg = config.get("ui_adaptation", {})
    if not root.is_dir():
        raise ValueError(f"Project root missing: {root}")
    components = load_components(root, cfg)
    aspect_values = load_aspect_values(root, cfg)
    exceptions = load_exceptions(cfg)
    used = {category: set() for category in EXCEPTION_KEYS}
    roots = cfg.get("prefab_roots", ["Assets/GameResources/UI/UIPrefab", "Assets/Resources/UI/UIPrefab"])
    paths, missing_roots = set(), []
    for rel in roots:
        base = root / rel
        if base.is_dir():
            paths.update(base.rglob("*.prefab"))
        elif "prefab_roots" in cfg:
            missing_roots.append(normalize(rel))
    source_guids = {}
    for path in paths:
        meta = Path(str(path) + ".meta")
        if meta.exists():
            match = re.search(r"(?m)^guid:\s*([0-9a-fA-F]{32})", read_text(meta))
            if match:
                source_guids[match.group(1).lower()] = normalize(str(path.relative_to(root)))
    issues, nodes, nested, unparsed_prefabs = [], [], [], []

    def problem(rule, prefab, node, detail):
        issues.append({"rule": rule, "prefab": prefab, "node": node, "detail": detail})

    for path in sorted(paths):
        rel = normalize(str(path.relative_to(root)))
        expected_scale, expected_padding = expected_components(rel, cfg)
        names, transforms, by_go, instances = parse_prefab(read_text(path))
        if not transforms and not instances:
            unparsed_prefabs.append(f"No serialized RectTransforms or nested instances inspected: {rel}")

        def hierarchy(identifier, chain=()):
            if identifier in chain:
                raise ValueError(f"Cyclic transform hierarchy: {rel}")
            value = transforms[identifier]
            name = names.get(value["go"], str(value["go"]))
            father = value["father"]
            return hierarchy(father, chain + (identifier,)) + "/" + name if father in transforms else name

        for identifier, transform in transforms.items():
            node = hierarchy(identifier)
            key = (rel, node)
            anchors = [(components[guid], block) for guid, block in by_go.get(transform["go"], []) if guid in components]
            scales = [(name, block) for name, block in anchors if name.endswith("ScaleAnchor")]
            paddings = [(name, block) for name, block in anchors if name.endswith("PaddingAnchor")]
            automatic = key in exceptions["automatic_node_exceptions"]
            if automatic:
                used["automatic_node_exceptions"].add(key)
            nodes.append({"prefab": rel, "node": node, "scale_components": [x[0] for x in scales],
                          "padding_components": [x[0] for x in paddings], "expected_scale_component": expected_scale,
                          "automatic_node_exception": automatic})
            if len(scales) > 1 or len(paddings) > 1:
                problem("duplicate-anchor-component", rel, node, "More than one scale or padding component")
            if not scales and not automatic:
                problem("missing-scale", rel, node, "Ordinary UI node needs ScaleAnchor/ResScaleAnchor")
            for name, block in scales:
                if name != expected_scale:
                    problem("wrong-anchor-layer", rel, node, f"{name} belongs to the wrong layer; expected {expected_scale}")
                aspect_base = field(block, "mAspectBase", str(aspect_values["AUTO"]))
                if field(block, "mKeepAspect", "1") == "0" or aspect_base == str(aspect_values["NONE"]):
                    if key in exceptions["nonuniform_scale_exceptions"]:
                        used["nonuniform_scale_exceptions"].add(key)
                    else:
                        problem("nonuniform-scale", rel, node, "Effective nonuniform scaling (mKeepAspect=false or mAspectBase=NONE) has no explicit coverage purpose")
                if name == "ScaleAnchor" and field(block, "mRemoveUGUIAnchor", "1") == "0" and not automatic:
                    problem("native-anchor-removal-disabled", rel, node, "mRemoveUGUIAnchor must be true")
            if paddings:
                for name, _ in paddings:
                    if name != expected_padding:
                        problem("wrong-anchor-layer", rel, node, f"{name} belongs to the wrong layer; expected {expected_padding}")
                if key in exceptions["padding_exceptions"]:
                    used["padding_exceptions"].add(key)
                else:
                    problem("padding-without-purpose", rel, node, "PaddingAnchor is an edge-docking exception, not default layout")
                pivot = vector(transform["block"], "m_Pivot")
                if pivot is None or any(abs(axis - 0.5) > 1e-6 for axis in pivot):
                    problem("padding-pivot", rel, node, "PaddingAnchor requires centered pivot in the inspected framework implementation")
                rotation = transform_vector(transform["block"], "m_LocalRotation", "xyzw")
                if rotation is not None and (any(abs(axis) > 1e-6 for axis in rotation[:3]) or abs(abs(rotation[3]) - 1.0) > 1e-6):
                    problem("padding-rotation", rel, node, "PaddingAnchor does not support a rotated authored node in the inspected implementation")
                scale = transform_vector(transform["block"], "m_LocalScale", "xyz")
                if scale is not None and any(abs(axis - 1.0) > 1e-6 for axis in scale):
                    problem("padding-local-scale", rel, node, "PaddingAnchor assumes localScale=1; validate or repair the authored geometry")
            if not automatic:
                for property_name in ("m_AnchorMin", "m_AnchorMax"):
                    value = vector(transform["block"], property_name)
                    if value is None or any(abs(axis - 0.5) > 1e-6 for axis in value):
                        problem("native-anchor", rel, node,
                                f"{property_name} must be centered for the framework: {value}")
        for block in instances:
            source = re.search(r"m_SourcePrefab:\s*\{[^}]*guid:\s*([0-9a-fA-F]{32})", block)
            guid = source.group(1).lower() if source else ""
            overrides = [(name.strip(), value.strip()) for name, value in re.findall(r"propertyPath:[ \t]*(.+)\r?\n[ \t]+value:[ \t]*(.*)", block)]
            relevant = [(name, value) for name, value in overrides if name.split(".")[0] in OVERRIDE_FIELDS]
            pending = []
            for name, value in relevant:
                # A centered per-axis override cannot reintroduce native anchoring.
                if name in {f"{prop}.{axis}" for prop in ("m_AnchorMin", "m_AnchorMax") for axis in ("x", "y")}:
                    try:
                        if abs(float(value) - 0.5) <= 1e-6:
                            continue
                    except ValueError:
                        pass
                if name in ("mKeepAspect", "mRemoveUGUIAnchor") and value == "1":
                    continue
                if name == "mAspectBase" and value == str(aspect_values["AUTO"]):
                    continue
                pending.append(name)
            record = {"prefab": rel, "source_guid": guid, "source_prefab": source_guids.get(guid), "adaptation_overrides": relevant, "unresolved_overrides": pending}
            nested.append(record)
            if guid not in source_guids:
                problem("nested-source-outside-scope", rel, "", f"Nested source GUID {guid} must be added to prefab_roots")
            if pending or re.search(r"m_(?:Removed|Added)Components:\s*\n\s*-", block):
                problem("nested-adaptation-override", rel, "", "Resolve relevant nested component/anchor overrides in Unity before declaring PASS: " + ", ".join(pending))
    for category in EXCEPTION_KEYS:
        for prefab, node in set(exceptions[category]) - used[category]:
            problem("unused-exception", prefab, node, f"{category} has no matching inspected use; remove stale exception or inspect the real asset")
    coverage_errors = list(missing_roots) + unparsed_prefabs
    if not paths or not nodes:
        coverage_errors.append("No serialized UI RectTransforms inspected")
    return {"root": str(root), "summary": {"prefabs": len(paths), "rect_nodes": len(nodes),
                "scale_nodes": sum(bool(x["scale_components"]) for x in nodes),
                "padding_nodes": sum(bool(x["padding_components"]) for x in nodes),
                "nested_instances": len(nested), "issues": len(issues), "coverage_errors": len(coverage_errors)},
            "status": "NOT_EVALUATED" if coverage_errors else "FAIL" if issues else "STATIC_DECLARED_CHECKS_PASS",
            "exit_code": 2 if coverage_errors else 1 if issues else 0,
            "coverage_errors": coverage_errors, "issues": issues, "nodes": nodes, "nested_instances": nested,
            "aspect_base_values": aspect_values,
            "exceptions": cfg.get("padding_exceptions", []),
            "notes": ["Only serialized asset policy is checked. Test actual layout and input at the design resolution and a different aspect ratio.",
                      "Padding must have a real edge-docking purpose; an exception reason is declared evidence, not automatic semantic proof.",
                      "Relevant nested overrides require Unity inspection; this parser does not silently claim an effective inherited layout was evaluated."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        config = json.loads(read_text(args.config)) if args.config else {}
        report = audit(args.root, config)
    except (ValueError, OSError) as error:
        report = {"status": "NOT_EVALUATED", "exit_code": 2, "error": str(error)}
    print(json.dumps(report, ensure_ascii=False, indent=2) if args.json else json.dumps({k: v for k, v in report.items() if k not in ("nodes", "nested_instances")}, ensure_ascii=False, indent=2))
    raise SystemExit(report["exit_code"])


if __name__ == "__main__":
    main()
