#!/usr/bin/env python3
"""Read-only RPK byte accounting; never certifies signing or upload acceptance.

The default budget scope is the physical file. A subpackage sum is an explicit
alternative and must not be reported as the physical upload size.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

SCOPES = ("file", "subpackage-sum", "compatibility")


def audit_package(path: Path, limit_bytes: int | None = None,
                  limit_scope: str = "file", compatibility_entry: str | None = None) -> dict:
    path = path.resolve()
    if not path.is_file():
        raise ValueError(f"RPK file not found: {path}")
    if limit_scope not in SCOPES:
        raise ValueError(f"Unknown limit scope: {limit_scope}")
    if limit_bytes is not None and (type(limit_bytes) is not int or limit_bytes <= 0):
        raise ValueError("limit_bytes must be a positive integer number of bytes")
    size = path.stat().st_size
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        seen = set()
        for item in entries:
            name = item.filename
            if name in seen:
                raise ValueError(f"Duplicate ZIP entry: {name}")
            seen.add(name)
            if "\\" in name or re.match(r"^[A-Za-z]:", name) or PurePosixPath(name).is_absolute() or ".." in PurePosixPath(name).parts:
                raise ValueError(f"Ambiguous ZIP entry path: {name}")
        nested = [item for item in entries if not item.is_dir() and item.filename.lower().endswith(".rpk")]
        compatibility = None
        if compatibility_entry is not None:
            matches = [item for item in nested if item.filename == compatibility_entry]
            if len(matches) != 1:
                raise ValueError("compatibility_entry must identify one existing inner RPK")
            compatibility = matches[0]
        else:
            matches = [item for item in nested if PurePosixPath(item.filename).name == path.name]
            if len(matches) > 1:
                raise ValueError("Multiple compatibility candidates; specify the exact entry")
            compatibility = matches[0] if matches else None
        packages = [item for item in nested if item is not compatibility]
        if compatibility is not None and PurePosixPath(compatibility.filename).name == "main.rpk":
            raise ValueError("main.rpk cannot be excluded as a compatibility package")
        main_entries = [item for item in packages if PurePosixPath(item.filename).name == "main.rpk"]
        subpackage_total = sum(item.file_size for item in packages) if len(main_entries) == 1 else None
        compatibility_size = compatibility.file_size if compatibility else None
        notes = []
        if nested and subpackage_total is None:
            notes.append("A unique main.rpk was not identified; subpackage accounting is NOT_EVALUATED.")
        if nested and compatibility is None:
            notes.append("No compatibility package identified. If the outer file was renamed, specify --compatibility-entry; otherwise all inner RPKs are counted.")
        scopes = {"file": size, "subpackage-sum": subpackage_total, "compatibility": compatibility_size}
        measured = scopes[limit_scope]
        if measured is None:
            status, exit_code, within = "NOT_EVALUATED", 2, None
        elif limit_bytes is None:
            status, exit_code, within = "MEASURED", 0, None
        else:
            within = measured <= limit_bytes
            status, exit_code = ("SIZE_BUDGET_PASS", 0) if within else ("SIZE_BUDGET_FAIL", 1)
        return {
            "rpk_path": str(path), "sha256": digest.hexdigest(),
            "physical_file_bytes": size,
            "main_and_subpackages_bytes": subpackage_total,
            "compatibility_bytes": compatibility_size,
            "compatibility_entry": compatibility.filename if compatibility else None,
            "inner_packages": [{"entry": item.filename, "bytes": item.file_size,
                                "zip_compressed_bytes": item.compress_size,
                                "role": "compatibility" if item is compatibility else "main" if item in main_entries else "subpackage"}
                               for item in nested],
            "budget": {"limit_bytes": limit_bytes, "scope": limit_scope,
                       "measured_bytes": measured, "within_limit": within},
            "status": status, "exit_code": exit_code,
            "signature_verification": "NOT_PERFORMED", "crc_verification": "NOT_PERFORMED",
            "runtime_verification": "NOT_PERFORMED", "upload_acceptance": "NOT_VERIFIED",
            "notes": notes + ["ZIP entry byte counts are accounting metadata, not a validity or signing check.",
                              "Use the platform's confirmed accounting scope. Subpackage size does not prove the physical file fits its upload limit."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rpk", type=Path)
    parser.add_argument("--limit-bytes", type=int)
    parser.add_argument("--limit-scope", choices=SCOPES, default="file")
    parser.add_argument("--compatibility-entry")
    parser.add_argument("--json", action="store_true", help="Retained for consistency; output is always JSON")
    args = parser.parse_args()
    try:
        report = audit_package(args.rpk, args.limit_bytes, args.limit_scope, args.compatibility_entry)
    except (ValueError, OSError, zipfile.BadZipFile) as error:
        report = {"status": "NOT_EVALUATED", "exit_code": 2, "error": str(error),
                  "upload_acceptance": "NOT_VERIFIED"}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(report["exit_code"])


if __name__ == "__main__":
    main()
