#!/usr/bin/env python3
"""Static Display Profile audit for MyFramework migration.

This validates project-declared orientation/design-resolution consistency across
FrameSettings, start scene UGUIRoot, runtime Layout prefab roots, and obvious
Screen.orientation assignments. It cannot prove runtime camera framing, Safe Area,
or visual parity; those require Unity/Game View/Build evidence.
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import re
from pathlib import Path

DEFAULT_UGUI_GENERATOR_GUIDS = ["1324c7b97d0cd4d4286eaa7aef336d1d"]
FRAME_SETTINGS = "Assets/Resources/Settings/FrameSettings.asset"
START_SCENE = "Assets/Resources/Scene/start.unity"


def read_text(path: Path) -> str:
    return path.read_bytes().decode("utf-8-sig", errors="replace")


def load_config(path: Path | None) -> dict:
    if path is None:
        return {}
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize(path: str) -> str:
    return path.replace("\\", "/").lstrip("./")


def split_yaml_blocks(raw: str) -> list[str]:
    return [x for x in re.split(r"(?=^--- !u!\d+ &-?\d+\s*$)", raw, flags=re.M) if x.strip()]


def parse_header(block: str):
    m = re.match(r"--- !u!(\d+) &(-?\d+)", block)
    if not m:
        return None, None
    return int(m.group(1)), int(m.group(2))


def parse_vec2(block: str, field: str):
    m = re.search(rf"(?m)^\s*{re.escape(field)}:\s*\{{x:\s*([-+0-9.eE]+),\s*y:\s*([-+0-9.eE]+)\}}", block)
    if not m:
        return None
    try:
        return float(m.group(1)), float(m.group(2))
    except ValueError:
        return None


def parse_yaml_ui(path: Path, gen_guids: set[str] | None = None) -> dict:
    raw = read_text(path)
    names: dict[int, str] = {}
    go_components: dict[int, list[int]] = {}
    comp_to_go: dict[int, int] = {}
    rects: dict[int, dict] = {}
    root_generator_gos: list[int] = []

    for block in split_yaml_blocks(raw):
        typ, fid = parse_header(block)
        if typ is None:
            continue
        if typ == 1:
            nm = re.search(r"(?m)^\s*m_Name:\s*(.*)$", block)
            if nm:
                names[fid] = nm.group(1).strip()
            go_components[fid] = [int(x) for x in re.findall(r"component:\s*\{fileID:\s*(-?\d+)\}", block)]
            continue

        gm = re.search(r"m_GameObject:\s*\{fileID:\s*(-?\d+)\}", block)
        go = int(gm.group(1)) if gm else 0
        if go:
            comp_to_go[fid] = go

        if typ == 224:
            fm = re.search(r"m_Father:\s*\{fileID:\s*(-?\d+)\}", block)
            rects[fid] = {
                "component": fid,
                "game_object": go,
                "father": int(fm.group(1)) if fm else 0,
                "size": parse_vec2(block, "m_SizeDelta"),
                "pos": parse_vec2(block, "m_AnchoredPosition"),
                "anchor_min": parse_vec2(block, "m_AnchorMin"),
                "anchor_max": parse_vec2(block, "m_AnchorMax"),
                "pivot": parse_vec2(block, "m_Pivot"),
            }
        elif typ == 114 and gen_guids:
            sm = re.search(r"m_Script:\s*\{fileID:\s*\d+,\s*guid:\s*([0-9a-fA-F]{32}),", block)
            if sm and sm.group(1).lower() in gen_guids:
                root_generator_gos.append(go)

    rect_by_go = {r["game_object"]: r for r in rects.values() if r["game_object"]}
    return {
        "raw": raw,
        "names": names,
        "go_components": go_components,
        "rects": rects,
        "rect_by_go": rect_by_go,
        "root_generator_gos": root_generator_gos,
    }


def rect_for_name(parsed: dict, name: str):
    for go, nm in parsed["names"].items():
        if nm == name:
            return parsed["rect_by_go"].get(go)
    return None


def close2(a, b, eps=0.01):
    return a is not None and b is not None and abs(a[0] - b[0]) <= eps and abs(a[1] - b[1]) <= eps


def match_allow(value: str, patterns: list[str]) -> bool:
    value = normalize(value)
    return any(fnmatch.fnmatchcase(value, normalize(p)) for p in patterns)


def parse_frame_setting_size(text: str, field: str):
    m = re.search(rf"(?m)^\s*{re.escape(field)}:\s*\{{x:\s*(-?\d+),\s*y:\s*(-?\d+)\}}", text)
    if not m:
        return None
    return int(m.group(1)), int(m.group(2))


def orientation_resolution_consistent(orientation: str, size: tuple[int, int]) -> bool:
    w, h = size
    if orientation in {"Portrait", "PortraitUpsideDown"}:
        return h >= w
    if orientation in {"LandscapeLeft", "LandscapeRight", "Landscape"}:
        return w >= h
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", type=Path)
    ap.add_argument("--config", type=Path)
    ap.add_argument("--json", action="store_true")
    ap.add_argument(
        "--fail-on",
        default="profile,frame-settings,start-root,prefab-root,orientation",
        help="comma-separated: profile,frame-settings,start-root,prefab-root,orientation,bounds",
    )
    args = ap.parse_args()
    root = args.root.resolve()
    cfg = load_config(args.config)
    dp = cfg.get("display_profile", {})

    orientation = str(dp.get("orientation") or "").strip()
    dr = dp.get("design_resolution") or []
    profile_ok = (
        orientation not in {"", "UNSET", "UNKNOWN"}
        and isinstance(dr, list)
        and len(dr) == 2
        and all(isinstance(x, (int, float)) and x > 0 for x in dr)
    )
    design = (int(dr[0]), int(dr[1])) if profile_ok else None
    profile_orientation_ok = bool(profile_ok and orientation_resolution_consistent(orientation, design))

    frame_path = root / dp.get("frame_settings_path", FRAME_SETTINGS)
    frame = {"exists": frame_path.exists(), "standalone": None, "mobile": None, "ok": False}
    if frame_path.exists() and design:
        txt = read_text(frame_path)
        frame["standalone"] = parse_frame_setting_size(txt, "UISizeStandalone")
        frame["mobile"] = parse_frame_setting_size(txt, "UISizeMobile")
        expected_standalone = tuple(dp.get("standalone_resolution", design))
        expected_mobile = tuple(dp.get("mobile_resolution", design))
        frame["ok"] = frame["standalone"] == expected_standalone and frame["mobile"] == expected_mobile

    start_path = root / dp.get("start_scene_path", START_SCENE)
    start_root_name = dp.get("start_ui_root_name", "UGUIRoot")
    start_info = {"exists": start_path.exists(), "root_name": start_root_name, "size": None, "ok": False}
    if start_path.exists() and design:
        parsed = parse_yaml_ui(start_path)
        rect = rect_for_name(parsed, start_root_name)
        if rect:
            start_info["size"] = rect.get("size")
            start_info["ok"] = close2(rect.get("size"), design)

    prefab_roots = cfg.get("ui_prefab_roots", ["Assets/GameResources/UI/UIPrefab"])
    gen_guids = {x.lower() for x in cfg.get("ugui_generator_script_guids", DEFAULT_UGUI_GENERATOR_GUIDS)}
    check_prefab_size = bool(dp.get("check_ui_prefab_root_size", True))
    prefab_reports = []
    prefab_failures = []
    bounds_candidates = []
    bounds_allowlist = dp.get("direct_child_bounds_allowlist", [])
    bounds_tolerance = float(dp.get("bounds_tolerance", 0.5))

    for rel_root in prefab_roots:
        base = root / rel_root
        if not base.exists():
            continue
        for p in sorted(base.rglob("*.prefab")):
            parsed = parse_yaml_ui(p, gen_guids)
            if not parsed["root_generator_gos"]:
                continue
            rel = normalize(str(p.relative_to(root)))
            root_gos = parsed["root_generator_gos"]
            root_rect = parsed["rect_by_go"].get(root_gos[0]) if len(root_gos) == 1 else None
            size = root_rect.get("size") if root_rect else None
            ok = bool(root_rect and design and (not check_prefab_size or close2(size, design)))
            prefab_reports.append({"prefab": rel, "root_generator_count": len(root_gos), "root_size": size, "ok": ok})
            if check_prefab_size and not ok:
                prefab_failures.append({"prefab": rel, "root_size": size, "expected": design})

            if root_rect and design:
                root_rect_id = root_rect["component"]
                half_w, half_h = design[0] * 0.5, design[1] * 0.5
                for child in parsed["rects"].values():
                    if child.get("father") != root_rect_id:
                        continue
                    amin = child.get("anchor_min")
                    amax = child.get("anchor_max")
                    pos = child.get("pos")
                    csize = child.get("size")
                    pivot = child.get("pivot") or (0.5, 0.5)
                    if not (close2(amin, (0.5, 0.5)) and close2(amax, (0.5, 0.5)) and pos and csize):
                        continue
                    x, y = pos
                    w, h = abs(csize[0]), abs(csize[1])
                    px, py = pivot
                    left, right = x - w * px, x + w * (1.0 - px)
                    bottom, top = y - h * py, y + h * (1.0 - py)
                    if left < -half_w - bounds_tolerance or right > half_w + bounds_tolerance or bottom < -half_h - bounds_tolerance or top > half_h + bounds_tolerance:
                        go = child.get("game_object", 0)
                        name = parsed["names"].get(go, str(go))
                        key = f"{rel}:{name}"
                        if not match_allow(key, bounds_allowlist):
                            bounds_candidates.append({
                                "prefab": rel,
                                "child": name,
                                "position": pos,
                                "size": csize,
                                "bounds": [left, bottom, right, top],
                                "root_size": design,
                            })

    orientation_assignments = []
    orientation_mismatches = []
    code_roots = cfg.get("project_code_roots", ["Assets/Scripts/Game", "Assets/Scripts/HotFix"])
    orientation_allowlist = dp.get("orientation_assignment_allowlist", [])
    rx = re.compile(r"Screen\.orientation\s*=\s*ScreenOrientation\.([A-Za-z_][A-Za-z0-9_]*)")
    for rel_root in code_roots:
        base = root / rel_root
        if not base.exists():
            continue
        for p in base.rglob("*.cs"):
            text = read_text(p)
            rel = normalize(str(p.relative_to(root)))
            for m in rx.finditer(text):
                line = text.count("\n", 0, m.start()) + 1
                value = m.group(1)
                item = {"file": rel, "line": line, "value": value}
                orientation_assignments.append(item)
                key = f"{rel}:{line}:{value}"
                if profile_ok and value != orientation and not match_allow(key, orientation_allowlist):
                    orientation_mismatches.append(item)

    summary = {
        "display_profile_configured": profile_ok,
        "orientation_resolution_consistent": profile_orientation_ok,
        "frame_settings_ok": frame["ok"],
        "start_ui_root_ok": start_info["ok"],
        "ui_generator_prefabs_checked": len(prefab_reports),
        "ui_prefab_root_failures": len(prefab_failures),
        "screen_orientation_assignments": len(orientation_assignments),
        "screen_orientation_mismatches": len(orientation_mismatches),
        "direct_child_bounds_candidates": len(bounds_candidates),
    }
    report = {
        "root": str(root),
        "config": str(args.config) if args.config else None,
        "display_profile": dp,
        "summary": summary,
        "frame_settings": frame,
        "start_scene_ui_root": start_info,
        "prefabs": prefab_reports,
        "prefab_root_failures": prefab_failures,
        "orientation_assignments": orientation_assignments,
        "orientation_mismatches": orientation_mismatches,
        "direct_child_bounds_candidates": bounds_candidates,
        "notes": [
            "Static display audit cannot prove Safe Area, World Camera framing, or runtime visual parity.",
            "Direct-child bounds are candidates only; animations/ScaleAnchor can intentionally place nodes outside the root.",
        ],
    }

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("MyFramework display profile audit")
        print("root:", root)
        for k, v in summary.items():
            print(f"{k:42} {v}")
        if prefab_failures:
            print("\nUI prefab root size failures:")
            for x in prefab_failures:
                print(" -", x)
        if orientation_mismatches:
            print("\nOrientation mismatches:")
            for x in orientation_mismatches:
                print(" -", x)
        if bounds_candidates:
            print("\nDirect-child bounds candidates:")
            for x in bounds_candidates:
                print(" -", x)
        print("\nNotes:")
        for x in report["notes"]:
            print("-", x)

    fail = {x.strip() for x in args.fail_on.split(",") if x.strip()}
    bad = False
    if "profile" in fail and (not profile_ok or not profile_orientation_ok):
        bad = True
    if "frame-settings" in fail and not frame["ok"]:
        bad = True
    if "start-root" in fail and not start_info["ok"]:
        bad = True
    if "prefab-root" in fail and prefab_failures:
        bad = True
    if "orientation" in fail and orientation_mismatches:
        bad = True
    if "bounds" in fail and bounds_candidates:
        bad = True
    raise SystemExit(1 if bad else 0)


if __name__ == "__main__":
    main()
