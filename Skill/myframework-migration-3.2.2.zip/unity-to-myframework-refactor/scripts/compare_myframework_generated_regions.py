#!/usr/bin/env python3
"""Compare generator-owned C# regions, without treating no coverage as a pass.

Exit 0: covered diff is clean, or every change has a recorded generator approval.
Exit 1: unexpected changes or malformed markers. Exit 2: invalid/no coverage.
A supplied log records a claim; it cannot authenticate official generator execution.
"""
from __future__ import annotations

import argparse
import fnmatch
import json
from pathlib import Path
import re

REGION_PAIRS = [
    ("ui-member", "// auto generate member start", "// auto generate member end"),
    ("ui-constructor", "// auto generate constructor start", "// auto generate constructor end"),
    ("ui-assignWindow", "// auto generate assignWindow start", "// auto generate assignWindow end"),
    ("ui-init", "// auto generate init start", "// auto generate init end"),
    ("layout-register", "// auto generate start", "// auto generate end"),
    ("gbr-layout", "// auto generate LayoutScript start", "// auto generate LayoutScript end"),
    ("excel", "// auto generate Excel start", "// auto generate Excel end"),
]


def read_text(path: Path) -> str:
    return path.read_bytes().decode("utf-8-sig").replace("\r\n", "\n")


def normalize(path: str) -> str:
    return Path(path.replace("\\", "/")).as_posix()


def safe_path(root: Path, relative: str) -> Path:
    p = Path(relative.replace("\\", "/"))
    if p.is_absolute() or ".." in p.parts:
        raise ValueError(f"Expected a relative path within the project: {relative}")
    result = (root / p).resolve()
    if not result.is_relative_to(root.resolve()):
        raise ValueError(f"Path escapes root: {relative}")
    return result


def parse_regions(text: str) -> tuple[dict[str, str], list[str]]:
    """Recognize known whole-line markers; retain body whitespace except CRLF.

    Deliberately not a C# parser: unknown generator marker formats require a
    target-version profile update, not a claim that unrecognized code is covered.
    """
    result: dict[str, str] = {}
    errors: list[str] = []
    active: tuple[str, int, int] | None = None
    counts: dict[str, int] = {}
    tokens = {}
    for name, start, end in REGION_PAIRS:
        tokens[start] = (name, True)
        tokens[end] = (name, False)
    lines = text.replace("\r\n", "\n").splitlines(keepends=True)
    for index, line in enumerate(lines):
        # Some official versions put a dash separator after the marker.
        marker = re.sub(r"\s*-{3,}\s*$", "", line.strip()).rstrip()
        token = tokens.get(marker)
        if token is None:
            continue
        name, is_start = token
        if is_start:
            if active is not None:
                errors.append(f"line {index + 1}: nested start {name} inside {active[0]}")
                continue
            count = counts.get(name, 0)
            counts[name] = count + 1
            active = (name, count, index + 1)
        elif active is None:
            errors.append(f"line {index + 1}: orphan end {name}")
        elif active[0] != name:
            errors.append(f"line {index + 1}: mismatched end {name}, expected {active[0]}")
        else:
            result[f"{name}#{active[1]}"] = "".join(lines[active[2]:index])
            active = None
    if active is not None:
        errors.append(f"line {active[2]}: missing end for {active[0]}")
    return result, errors


def extract_regions(text: str) -> dict[str, str]:
    """Compatibility helper; audit callers must also check parse_regions errors."""
    return parse_regions(text)[0]


def iter_cs(root: Path, roots: list[str]):
    seen: set[Path] = set()
    for rel in roots:
        base = safe_path(root, rel)
        if not base.is_dir():
            raise ValueError(f"Code root missing/not a directory: {base}")
        for p in sorted(base.rglob("*.cs")):
            resolved = p.resolve()
            if not resolved.is_relative_to(root):
                raise ValueError(f"Symlink escapes project root: {p}")
            if resolved not in seen:
                seen.add(resolved)
                yield p


def collect(root: Path, roots: list[str]):
    out = {}
    errors = []
    files = 0
    for p in iter_cs(root, roots):
        files += 1
        rel = p.relative_to(root).as_posix()
        regions, malformed = parse_regions(read_text(p))
        errors.extend({"file": rel, "error": e} for e in malformed)
        if regions:
            out[rel] = regions
    return out, errors, files


def read_approvals(current: Path, patterns: list[str], evidence_path: Path | None) -> list[dict]:
    if not patterns:
        if evidence_path is not None:
            raise ValueError("--allow-evidence requires at least one explicit --allow pattern")
        return []
    if evidence_path is None:
        raise ValueError("--allow requires --allow-evidence; silent exclusions are not permitted")
    data = json.loads(evidence_path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or not isinstance(data.get("approvals"), list):
        raise ValueError("Approval JSON must have an approvals[] array")
    approved = []
    for pattern in patterns:
        safe_path(current, pattern)
        matches = [x for x in data["approvals"] if isinstance(x, dict) and x.get("path") == pattern]
        if len(matches) != 1:
            raise ValueError(f"Exactly one approval is required for pattern: {pattern}")
        item = matches[0]
        for field in ("tool", "version", "log", "reason"):
            if not isinstance(item.get(field), str) or not item[field].strip():
                raise ValueError(f"Approval {pattern} lacks {field}")
        log = safe_path(current, item["log"])
        if not log.is_file() or log.stat().st_size == 0:
            raise ValueError(f"Missing/empty generator execution log: {log}")
        approved.append(dict(item))
    return approved


def compare(baseline: Path, current: Path, roots: list[str], approvals: list[dict] | None = None) -> dict:
    baseline, current = baseline.resolve(), current.resolve()
    if not baseline.is_dir() or not current.is_dir():
        raise ValueError("Both baseline and current must be existing project directories")
    if baseline == current:
        raise ValueError("Baseline and current must be distinct snapshots, not the same directory")
    a, ae, ac = collect(baseline, roots)
    b, be, bc = collect(current, roots)
    approvals = approvals or []
    changes = []
    compared = 0
    for rel in sorted(set(a) | set(b)):
        ar, br = a.get(rel, {}), b.get(rel, {})
        for key in sorted(set(ar) | set(br)):
            compared += 1
            if ar.get(key) != br.get(key):
                approval = next((x for x in approvals if fnmatch.fnmatchcase(rel, x["path"])), None)
                changes.append({"file": rel, "region": key,
                                "baseline_present": key in ar, "current_present": key in br,
                                "approval_recorded": approval is not None})
    malformed = [{"side": "baseline", **x} for x in ae] + [{"side": "current", **x} for x in be]
    approved_count = sum(x["approval_recorded"] for x in changes)
    unexpected = len(changes) - approved_count
    coverage_errors = []
    if ac == 0 or bc == 0:
        coverage_errors.append("A requested snapshot has no C# files")
    if compared == 0:
        coverage_errors.append("No recognized generator regions; zero differences is not a pass")
    code = 2 if coverage_errors else (1 if unexpected or malformed else 0)
    status = ("NOT_EVALUATED" if coverage_errors else "STATIC_FAIL" if code else
              "GENERATOR_DIFF_RECORDED_REVIEW_REQUIRED" if changes else "STATIC_PASS")
    return {"baseline": str(baseline), "current": str(current), "code_roots": roots,
            "scanned_baseline_cs": ac, "scanned_current_cs": bc,
            "compared_regions": compared, "changed_regions": len(changes),
            "approved_changed_regions": approved_count, "unexpected_changed_regions": unexpected,
            "changes": changes, "malformed_regions": malformed, "coverage_errors": coverage_errors,
            "recorded_approvals": approvals, "status": status, "exit_code": code,
            "official_generator_execution": "NOT_AUTHENTICATED_BY_THIS_SCRIPT",
            "note": "Counts retain all regions, including approved diffs. Static coverage and supplied logs do not prove official execution or Unity compilation."}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("baseline", type=Path)
    ap.add_argument("current", type=Path)
    ap.add_argument("--code-root", action="append", dest="code_roots")
    ap.add_argument("--allow", action="append", default=[], help="Recorded generator-change glob; never an exclusion")
    ap.add_argument("--allow-evidence", type=Path, help="JSON approvals with path/tool/version/log/reason; log relative to current")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    try:
        approvals = read_approvals(args.current.resolve(), args.allow, args.allow_evidence)
        report = compare(args.baseline, args.current, args.code_roots or ["Assets/Scripts"], approvals)
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        report = {"status": "NOT_EVALUATED", "exit_code": 2, "error": str(exc)}
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("MyFramework generated-region comparison")
        for k, v in report.items():
            print(f"{k}: {v}")
    raise SystemExit(report["exit_code"])


if __name__ == "__main__":
    main()
