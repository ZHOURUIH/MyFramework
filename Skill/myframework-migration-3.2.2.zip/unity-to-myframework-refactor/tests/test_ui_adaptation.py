"""UI adaptation auditor fixtures; these tests do not execute Unity layout."""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import audit_myframework_ui_adaptation as adaptation

SCALE = "a" * 32
PADDING = "b" * 32
RES_SCALE = "c" * 32
RES_PADDING = "d" * 32


def prefab(scale=SCALE, keep=1, padding=False):
    value = f"""%YAML 1.1
--- !u!1 &1
GameObject:
  m_Name: Root
--- !u!224 &2
RectTransform:
  m_GameObject: {{fileID: 1}}
  m_Father: {{fileID: 0}}
  m_AnchorMin: {{x: 0.5, y: 0.5}}
  m_AnchorMax: {{x: 0.5, y: 0.5}}
  m_Pivot: {{x: 0.5, y: 0.5}}
"""
    if scale:
        value += f"""--- !u!114 &3
MonoBehaviour:
  m_GameObject: {{fileID: 1}}
  m_Script: {{fileID: 11500000, guid: {scale}, type: 3}}
  mKeepAspect: {keep}
  mRemoveUGUIAnchor: 1
"""
    if padding:
        value += f"""--- !u!114 &4
MonoBehaviour:
  m_GameObject: {{fileID: 1}}
  m_Script: {{fileID: 11500000, guid: {RES_PADDING if scale == RES_SCALE else PADDING}, type: 3}}
"""
    return value


class UIAdaptationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = self.root / "Assets/GameResources/UI/UIPrefab/Page.prefab"
        self.path.parent.mkdir(parents=True)
        self.path.write_text(prefab())
        self.policy = {"prefab_roots": ["Assets/GameResources/UI/UIPrefab"],
                       "aspect_base_values": {"AUTO": 2, "NONE": 4},
                       "anchor_component_guids": {"ScaleAnchor": [SCALE], "PaddingAnchor": [PADDING],
                                                  "ResScaleAnchor": [RES_SCALE], "ResPaddingAnchor": [RES_PADDING]}}
        self.key = {"prefab": "Assets/GameResources/UI/UIPrefab/Page.prefab", "node": "Root", "reason": "fixture purpose"}

    def report(self):
        return adaptation.audit(self.root, {"ui_adaptation": self.policy})

    def rules(self):
        return {item["rule"] for item in self.report()["issues"]}

    def test_uniform_scale_only_passes(self):
        self.assertEqual(self.report()["exit_code"], 0)
        self.assertEqual(self.report()["summary"]["padding_nodes"], 0)

    def test_padding_rotation_is_rejected(self):
        self.path.write_text(prefab(padding=True).replace("RectTransform:\n", "RectTransform:\n  m_LocalRotation: {x: 0, y: 0, z: 0.7071, w: 0.7071}\n"))
        self.policy["padding_exceptions"] = [self.key]
        self.assertIn("padding-rotation", self.rules())

    def test_padding_scale_is_rejected(self):
        self.path.write_text(prefab(padding=True).replace("RectTransform:\n", "RectTransform:\n  m_LocalScale: {x: 2, y: 1, z: 1}\n"))
        self.policy["padding_exceptions"] = [self.key]
        self.assertIn("padding-local-scale", self.rules())

    def test_padding_identity_transform_passes(self):
        self.path.write_text(prefab(padding=True).replace("RectTransform:\n", "RectTransform:\n  m_LocalScale: {x: 1, y: 1, z: 1}\n  m_LocalRotation: {x: 0, y: 0, z: 0, w: -1}\n"))
        self.policy["padding_exceptions"] = [self.key]
        self.assertEqual(self.report()["exit_code"], 0)

    def test_unparsed_prefab_does_not_hide_behind_valid_prefab(self):
        (self.path.parent / "Opaque.prefab").write_bytes(b"binary-or-empty")
        self.assertEqual(self.report()["exit_code"], 2)

    def test_conflicting_component_guid_is_rejected(self):
        self.policy["anchor_component_guids"]["PaddingAnchor"] = [SCALE]
        with self.assertRaises(ValueError):
            self.report()

    def test_discovered_component_guid_conflict_is_rejected(self):
        del self.policy["anchor_component_guids"]
        directory = self.root / "Packages/framework"
        directory.mkdir(parents=True)
        for name in ("ScaleAnchor", "PaddingAnchor"):
            (directory / (name + ".cs.meta")).write_text("guid: " + SCALE)
        with self.assertRaises(ValueError):
            self.report()

    def test_aspect_enum_boolean_and_same_value_rejected(self):
        for values in ({"AUTO": True, "NONE": 4}, {"AUTO": 2, "NONE": 2}):
            self.policy["aspect_base_values"] = values
            with self.subTest(values=values), self.assertRaises(ValueError):
                self.report()

    def test_nested_pivot_and_transform_overrides_require_review(self):
        for prop in ("m_Pivot.x", "m_LocalScale.x", "m_LocalRotation.z", "mAnchorMode", "mDistanceToBoard.Array.data[0].mAbsolute"):
            self.path.with_suffix(".prefab.meta").write_text("guid: " + "e" * 32)
            nested = self.path.parent / "Nested.prefab"
            nested.write_text(prefab() + f"""--- !u!1001 &99
PrefabInstance:
  m_SourcePrefab: {{fileID: 100100000, guid: {'e' * 32}, type: 3}}
  m_Modification:
    m_Modifications:
    - target: {{fileID: 2, guid: {'e' * 32}, type: 3}}
      propertyPath: {prop}
      value: 0
""")
            with self.subTest(prop=prop):
                self.assertIn("nested-adaptation-override", self.rules())

    def test_res_components_are_inspected(self):
        self.path = self.root / "Assets/Resources/UI/UIPrefab/UIDownload.prefab"
        self.path.parent.mkdir(parents=True)
        self.policy["prefab_roots"] = ["Assets/Resources/UI/UIPrefab"]
        self.path.write_text(prefab(RES_SCALE, padding=True))
        self.assertIn("padding-without-purpose", self.rules())
        self.assertEqual(self.report()["nodes"][0]["scale_components"], ["ResScaleAnchor"])

    def test_game_download_rejects_hotfix_scale_component(self):
        self.path = self.root / "Assets/Resources/UI/UIPrefab/UIDownload.prefab"
        self.path.parent.mkdir(parents=True)
        self.policy["prefab_roots"] = ["Assets/Resources/UI/UIPrefab"]
        self.path.write_text(prefab(SCALE))
        self.assertIn("wrong-anchor-layer", self.rules())

    def test_hotfix_ui_rejects_game_scale_component(self):
        self.path.write_text(prefab(RES_SCALE))
        self.assertIn("wrong-anchor-layer", self.rules())

    def test_game_scale_does_not_require_hotfix_only_fields(self):
        self.path = self.root / "Assets/Resources/UI/UIPrefab/UIDownload.prefab"
        self.path.parent.mkdir(parents=True)
        self.policy["prefab_roots"] = ["Assets/Resources/UI/UIPrefab"]
        self.path.write_text(prefab(RES_SCALE).replace("  mRemoveUGUIAnchor: 1\n", ""))
        self.assertEqual(self.report()["exit_code"], 0)

    def test_hotfix_true_keep_with_none_is_still_nonuniform(self):
        self.path.write_text(prefab(keep=1) + "  mAspectBase: 4\n")
        self.assertIn("nonuniform-scale", self.rules())

    def test_game_true_keep_with_none_is_still_nonuniform(self):
        self.path = self.root / "Assets/Resources/UI/UIPrefab/UIDownload.prefab"
        self.path.parent.mkdir(parents=True)
        self.policy["prefab_roots"] = ["Assets/Resources/UI/UIPrefab"]
        self.path.write_text(prefab(RES_SCALE, keep=1) + "  mAspectBase: 4\n")
        self.assertIn("nonuniform-scale", self.rules())

    def test_aspect_enum_resolved_from_target_source(self):
        del self.policy["aspect_base_values"]
        source = self.root / "Packages/framework/FrameBaseEnum.cs"
        source.parent.mkdir(parents=True)
        source.write_text("public enum ASPECT_BASE : byte { USE_WIDTH_SCALE, USE_HEIGHT_SCALE, AUTO, INVERSE_AUTO, NONE, }")
        self.assertEqual(self.report()["aspect_base_values"]["NONE"], 4)

    def test_custom_root_requires_explicit_layer_contract(self):
        self.path = self.root / "Assets/CustomUI/Page.prefab"
        self.path.parent.mkdir(parents=True)
        self.path.write_text(prefab())
        self.policy["prefab_roots"] = ["Assets/CustomUI"]
        with self.assertRaises(ValueError):
            self.report()
        self.policy["scale_component_by_root"] = {"Assets/CustomUI": "ScaleAnchor"}
        self.assertEqual(self.report()["exit_code"], 0)

    def test_legitimate_pivot_is_not_a_native_anchor(self):
        self.path.write_text(prefab().replace("m_Pivot: {x: 0.5, y: 0.5}", "m_Pivot: {x: 0, y: 0.5}"))
        self.assertEqual(self.report()["exit_code"], 0)

    def test_padding_has_its_own_center_pivot_contract(self):
        self.path.write_text(prefab(padding=True).replace("m_Pivot: {x: 0.5, y: 0.5}", "m_Pivot: {x: 0, y: 0.5}"))
        self.policy["padding_exceptions"] = [self.key]
        self.assertIn("padding-pivot", self.rules())

    def test_padding_needs_exact_purpose(self):
        self.path.write_text(prefab(padding=True))
        self.assertIn("padding-without-purpose", self.rules())
        self.policy["padding_exceptions"] = [self.key]
        self.assertEqual(self.report()["exit_code"], 0)

    def test_nonuniform_requires_coverage_exception(self):
        self.path.write_text(prefab(keep=0))
        self.assertIn("nonuniform-scale", self.rules())
        self.policy["nonuniform_scale_exceptions"] = [dict(self.key, reason="Full-screen opaque background")]
        self.assertEqual(self.report()["exit_code"], 0)

    def test_native_anchors_and_disabled_removal_fail(self):
        self.path.write_text(prefab().replace("m_AnchorMax: {x: 0.5, y: 0.5}", "m_AnchorMax: {x: 1, y: 1}").replace("mRemoveUGUIAnchor: 1", "mRemoveUGUIAnchor: 0"))
        self.assertIn("native-anchor", self.rules())
        self.assertIn("native-anchor-removal-disabled", self.rules())

    def test_missing_scale_is_not_padding_replacement(self):
        self.path.write_text(prefab(scale=None, padding=True))
        self.policy["padding_exceptions"] = [self.key]
        self.assertIn("missing-scale", self.rules())

    def test_automatic_node_requires_declared_exception(self):
        self.path.write_text(prefab(scale=None).replace("m_AnchorMax: {x: 0.5, y: 0.5}", "m_AnchorMax: {x: 1, y: 1}"))
        self.policy["automatic_node_exceptions"] = [dict(self.key, reason="TMP runtime-generated submesh controlled by the engine")]
        self.assertEqual(self.report()["exit_code"], 0)

    def test_wildcard_and_reasonless_exceptions_rejected(self):
        for entry in (dict(self.key, node="*"), dict(self.key, reason="")):
            self.policy["padding_exceptions"] = [entry]
            with self.assertRaises(ValueError):
                self.report()

    def test_stale_exception_not_pass(self):
        self.policy["padding_exceptions"] = [dict(self.key, node="Missing")]
        self.assertIn("unused-exception", self.rules())

    def test_empty_scope_not_pass(self):
        self.path.unlink()
        self.assertEqual(self.report()["exit_code"], 2)

    def test_nested_source_outside_scope_not_pass(self):
        self.path.write_text(prefab() + "--- !u!1001 &10\nPrefabInstance:\n  m_SourcePrefab: {fileID: 100100000, guid: " + "e" * 32 + ", type: 3}\n")
        self.assertIn("nested-source-outside-scope", self.rules())

    def test_nested_relevant_override_not_silently_ignored(self):
        source = self.path.parent / "Row.prefab"
        source.write_text(prefab())
        Path(str(source) + ".meta").write_text("guid: " + "e" * 32)
        self.path.write_text(prefab() + "--- !u!1001 &10\nPrefabInstance:\n  m_Modification:\n    m_Modifications:\n    - propertyPath: mKeepAspect\n      value: 0\n  m_SourcePrefab: {fileID: 100100000, guid: " + "e" * 32 + ", type: 3}\n")
        self.assertIn("nested-adaptation-override", self.rules())

    def test_nested_centered_anchor_override_does_not_create_false_failure(self):
        source = self.path.parent / "Row.prefab"
        source.write_text(prefab())
        Path(str(source) + ".meta").write_text("guid: " + "e" * 32)
        self.path.write_text(prefab() + "--- !u!1001 &10\nPrefabInstance:\n  m_Modification:\n    m_Modifications:\n    - propertyPath: m_AnchorMax.x\n      value: 0.5\n  m_SourcePrefab: {fileID: 100100000, guid: " + "e" * 32 + ", type: 3}\n")
        self.assertEqual(self.report()["exit_code"], 0)

    def test_cli_returns_failure_for_padding(self):
        self.path.write_text(prefab(padding=True))
        config = self.root / "audit.json"
        config.write_text(json.dumps({"ui_adaptation": self.policy}))
        result = subprocess.run([sys.executable, str(SCRIPTS / "audit_myframework_ui_adaptation.py"), str(self.root), "--config", str(config), "--json"], capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stdout)["status"], "FAIL")


if __name__ == "__main__":
    unittest.main()
