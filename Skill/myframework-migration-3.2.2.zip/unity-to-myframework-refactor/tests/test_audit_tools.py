"""Regression tests of read-only auditors, using only temporary synthetic files.

These are not Unity engine substitutes or user game tests. Invalid fixture input
is deliberately isolated to test that an auditor does not falsely report PASS.
"""
from __future__ import annotations
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import audit_myframework_runtime_contracts as runtime
import compare_myframework_generated_regions as regions

REGION = "// auto generate member start\n    int mValue;\n// auto generate member end\n"


class GeneratedRegionsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name) / "baseline"
        self.current = Path(self.temp.name) / "current"
        for root in (self.base, self.current):
            (root / "Assets/Scripts").mkdir(parents=True)
            (root / "Assets/Scripts/Page.cs").write_text(REGION, encoding="utf-8-sig")

    def run_audit(self):
        return regions.compare(self.base, self.current, ["Assets/Scripts"])

    def test_unchanged_covered_regions_pass(self):
        report = self.run_audit()
        self.assertEqual(report["exit_code"], 0)
        self.assertEqual(report["compared_regions"], 1)

    def test_body_edit_is_counted(self):
        (self.current / "Assets/Scripts/Page.cs").write_text(REGION.replace("mValue", "mOther"))
        report = self.run_audit()
        self.assertEqual(report["exit_code"], 1)
        self.assertEqual(report["changed_regions"], 1)

    def test_added_region_is_counted(self):
        (self.current / "Assets/Scripts/Other.cs").write_text(REGION)
        self.assertEqual(self.run_audit()["changed_regions"], 1)

    def test_deleted_generated_file_is_counted(self):
        (self.current / "Assets/Scripts/Page.cs").unlink()
        (self.current / "Assets/Scripts/Plain.cs").write_text("class Plain {}")
        report = self.run_audit()
        self.assertEqual(report["changed_regions"], 1)
        self.assertFalse(report["changes"][0]["current_present"])

    def test_missing_root_is_not_pass(self):
        with self.assertRaises(ValueError):
            regions.compare(self.base / "missing", self.current, ["Assets/Scripts"])

    def test_missing_requested_code_root_is_not_pass(self):
        with self.assertRaises(ValueError):
            regions.compare(self.base, self.current, ["DoesNotExist"])

    def test_same_snapshot_is_rejected(self):
        with self.assertRaises(ValueError):
            regions.compare(self.base, self.base, ["Assets/Scripts"])

    def test_empty_cs_scope_is_not_evaluated(self):
        for root in (self.base, self.current):
            (root / "Assets/Scripts/Page.cs").unlink()
        self.assertEqual(self.run_audit()["exit_code"], 2)

    def test_no_recognized_regions_is_not_evaluated(self):
        for root in (self.base, self.current):
            (root / "Assets/Scripts/Page.cs").write_text("class Plain {}")
        self.assertEqual(self.run_audit()["status"], "NOT_EVALUATED")

    def test_same_malformed_regions_do_not_pass(self):
        for root in (self.base, self.current):
            (root / "Assets/Scripts/Page.cs").write_text(REGION + "// auto generate init start\n")
        report = self.run_audit()
        self.assertEqual(report["exit_code"], 1)
        self.assertEqual(len(report["malformed_regions"]), 2)

    def test_orphan_end_is_reported(self):
        text = REGION + "// auto generate init end\n"
        self.assertTrue(regions.parse_regions(text)[1])

    def test_nested_and_mismatched_markers_are_reported(self):
        text = "// auto generate member start\n// auto generate init start\n// auto generate init end\n"
        self.assertGreaterEqual(len(regions.parse_regions(text)[1]), 2)

    def test_crlf_and_bom_do_not_create_drift(self):
        (self.current / "Assets/Scripts/Page.cs").write_bytes(REGION.replace("\n", "\r\n").encode("utf-8"))
        self.assertEqual(self.run_audit()["changed_regions"], 0)

    def test_body_whitespace_drift_is_not_hidden(self):
        (self.current / "Assets/Scripts/Page.cs").write_text(REGION.replace("    int", " int"))
        self.assertEqual(self.run_audit()["changed_regions"], 1)

    def test_marker_in_string_is_not_recognized(self):
        text = 'string text = "// auto generate member start";\n'
        self.assertEqual(regions.parse_regions(text), ({}, []))

    def test_dashed_markers_supported(self):
        text = REGION.replace("start\n", "start----------------\n").replace("end\n", "end----------\n")
        self.assertEqual(regions.parse_regions(text)[0], regions.parse_regions(REGION)[0])

    def test_allow_without_evidence_is_rejected(self):
        with self.assertRaises(ValueError):
            regions.read_approvals(self.current, ["Assets/Scripts/Page.cs"], None)

    def test_allow_missing_log_is_rejected(self):
        path = Path(self.temp.name) / "approval.json"
        path.write_text(json.dumps({"approvals": [{"path": "Assets/Scripts/Page.cs", "tool": "UGUIGenerator", "version": "fixture", "log": "no.log", "reason": "fixture"}]}))
        with self.assertRaises(ValueError):
            regions.read_approvals(self.current, ["Assets/Scripts/Page.cs"], path)

    def test_approval_never_hides_change_count_or_authenticates_tool(self):
        (self.current / "Assets/Scripts/Page.cs").write_text(REGION.replace("mValue", "mOther"))
        (self.current / "generator.log").write_text("synthetic log, not a real generator run")
        path = Path(self.temp.name) / "approval.json"
        path.write_text(json.dumps({"approvals": [{"path": "Assets/Scripts/Page.cs", "tool": "UGUIGenerator", "version": "fixture", "log": "generator.log", "reason": "synthetic audit test"}]}))
        approvals = regions.read_approvals(self.current, ["Assets/Scripts/Page.cs"], path)
        report = regions.compare(self.base, self.current, ["Assets/Scripts"], approvals)
        self.assertEqual(report["changed_regions"], 1)
        self.assertEqual(report["approved_changed_regions"], 1)
        self.assertEqual(report["unexpected_changed_regions"], 0)
        self.assertEqual(report["official_generator_execution"], "NOT_AUTHENTICATED_BY_THIS_SCRIPT")

    def test_cli_bad_directory_json_and_exit_code(self):
        process = subprocess.run([sys.executable, str(SCRIPTS / "compare_myframework_generated_regions.py"), str(self.base / "missing"), str(self.current), "--json"], capture_output=True, text=True)
        self.assertEqual(process.returncode, 2)
        self.assertEqual(json.loads(process.stdout)["status"], "NOT_EVALUATED")


class RuntimeContractsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "source"
        self.source.mkdir()
        (self.root / "Evidence.md").write_text("fixture: source behavior, not a verified runtime")
        (self.root / "Consumer.cs").write_text("class Consumer { int mCount; }")
        self.evidence = [{"path": "Evidence.md", "contains": "fixture: source behavior"}]
        categories = {}
        for name in runtime.CATEGORY_FIELDS:
            categories[name] = {"status": "not_applicable", "reason": "Synthetic fixture excludes this category", "evidence": copy.deepcopy(self.evidence), "items": []}
        self.cfg = {"runtime_contracts": {"schema_version": 1, "categories": categories, "scan_rules": []}}
        self.table("items", [[30, "B", "2.5"], [10, "A", "0"]])

    def item(self, category, identifier):
        result = {"id": identifier, "contract": {k: "Documented fixture contract" for k in runtime.CATEGORY_FIELDS[category]},
                  "source_evidence": copy.deepcopy(self.evidence),
                  "implementation_evidence": [{"path": "Consumer.cs", "contains": "class Consumer"}],
                  "verification": {"status": "UNVERIFIED", "evidence": []}}
        if category == "state_lifetimes":
            result["contract"]["serialized"] = False
        return result

    def table(self, identifier, rows):
        path = self.root / f"{identifier}.csv"
        stream = io.StringIO(newline="")
        writer = csv.writer(stream)
        writer.writerow(["ID", "Name", "Price"])
        writer.writerows(rows)
        path.write_text(stream.getvalue(), encoding="utf-8-sig", newline="")
        item = self.item("tables", identifier)
        item["csv_check"] = {"path": path.name, "metadata_rows": 1, "id_column": 0, "id_type": "int", "min_data_rows": 1, "required_ids": [], "finite_columns": [2], "numeric_ranges": [{"column": 2, "min": 0}], "unique_columns": [1], "foreign_keys": []}
        group = self.cfg["runtime_contracts"]["categories"]["tables"]
        if group["status"] != "declared":
            group.update(status="declared", items=[])
        group["items"].append(item)
        return item

    def run_audit(self):
        return runtime.audit(self.root, self.cfg)

    def codes(self):
        return {i["code"] for i in self.run_audit()["issues"]}

    def test_noncontinuous_reordered_ids_are_valid(self):
        report = self.run_audit()
        self.assertEqual(report["exit_code"], 0)
        self.assertEqual(report["tables"][0]["unique_ids"], 2)
        self.assertEqual(report["independent_runtime_verification"], "NOT_PERFORMED")

    def test_missing_configuration_raises(self):
        with self.assertRaises(ValueError):
            runtime.audit(self.root, {})

    def test_empty_pending_categories_fail(self):
        self.cfg["runtime_contracts"]["categories"] = {x: {"status": "pending", "items": []} for x in runtime.CATEGORY_FIELDS}
        self.assertEqual(self.run_audit()["exit_code"], 1)
        self.assertEqual(len(self.run_audit()["issues"]), 5)

    def test_duplicate_ids_are_detected(self):
        self.table("duplicate", [[10, "A", 1], ["010", "B", 2]])
        self.assertIn("TABLE_DUPLICATE_ID", self.codes())

    def test_duplicate_selection_column_is_detected(self):
        self.table("selected", [[10, "A", 1], [30, "A", 2]])
        self.assertIn("TABLE_UNIQUE_VALUE", self.codes())

    def test_required_id_missing(self):
        self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]["csv_check"]["required_ids"] = [99]
        self.assertIn("TABLE_REQUIRED_ID", self.codes())

    def test_nonfinite_numbers_rejected(self):
        for val in ("NaN", "Infinity", "-Infinity"):
            with self.subTest(value=val):
                self.table("number" + str(len(self.cfg["runtime_contracts"]["categories"]["tables"]["items"])), [[10, "A", val]])
                self.assertIn("TABLE_FINITE", self.codes())

    def test_numeric_range_inclusive_and_exclusive(self):
        check = self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]["csv_check"]
        self.assertEqual(self.run_audit()["exit_code"], 0)
        check["numeric_ranges"][0]["min_exclusive"] = True
        self.assertIn("TABLE_RANGE", self.codes())

    def test_foreign_key_target_and_values(self):
        self.table("rarity", [[2, "R", "0"]])
        item = self.table("loot", [[10, "L", "1", 2]])
        item["csv_check"]["foreign_keys"] = [{"column": 3, "target_table": "rarity", "allow_empty": False}]
        self.assertEqual(self.run_audit()["exit_code"], 0)
        item["csv_check"]["foreign_keys"][0]["target_table"] = "missing-table"
        self.assertIn("TABLE_FOREIGN_TARGET", self.codes())

    def test_foreign_key_unknown_id_rejected(self):
        self.table("rarity", [[2, "R", "0"]])
        item = self.table("loot", [[10, "L", "1", 99]])
        item["csv_check"]["foreign_keys"] = [{"column": 3, "target_table": "rarity"}]
        self.assertIn("TABLE_FOREIGN_KEY", self.codes())

    def test_foreign_key_blank_allowed_only_explicitly(self):
        item = self.table("loot", [[10, "L", "1", ""]])
        item["csv_check"]["foreign_keys"] = [{"column": 3, "target_table": "items", "allow_empty": True}]
        self.assertEqual(self.run_audit()["exit_code"], 0)
        item["csv_check"]["foreign_keys"][0]["allow_empty"] = False
        self.assertIn("TABLE_FOREIGN_KEY", self.codes())

    def test_empty_or_invalid_id_is_detected(self):
        self.table("bad_id", [["", "A", 0], ["x", "B", 1]])
        self.assertIn("TABLE_ID", self.codes())

    def test_string_ids_preserve_case_and_gaps(self):
        item = self.table("stringids", [["a", "First", 0], ["A", "Second", 1]])
        item["csv_check"]["id_type"] = "string"
        self.assertEqual(self.run_audit()["exit_code"], 0)

    def test_csv_multiline_quoted_field_counts_records(self):
        self.table("multiline", [[10, "line1\nline2", 0]])
        self.assertEqual(self.run_audit()["exit_code"], 0)

    def test_empty_table_does_not_pass(self):
        self.table("empty", [])
        self.assertIn("TABLE_ROWS", self.codes())

    def test_wrong_metadata_does_not_pass(self):
        self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]["csv_check"]["metadata_rows"] = 999
        self.assertIn("TABLE_ROWS", self.codes())

    def test_missing_table_file(self):
        (self.root / "items.csv").unlink()
        self.assertIn("TABLE_READ", self.codes())

    def test_missing_evidence_is_detected(self):
        (self.root / "Evidence.md").unlink()
        self.assertIn("EVIDENCE_INVALID", self.codes())

    def test_wrong_literal_or_stale_hash_is_detected(self):
        item = self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]
        item["source_evidence"] = [{"path": "Evidence.md", "contains": "not in file"}]
        self.assertIn("EVIDENCE_INVALID", self.codes())
        item["source_evidence"] = [{"path": "Evidence.md", "sha256": "0" * 64}]
        self.assertIn("EVIDENCE_INVALID", self.codes())

    def test_actual_hash_evidence_is_found_not_verified(self):
        item = self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]
        item["source_evidence"] = [{"path": "Evidence.md", "sha256": hashlib.sha256((self.root / "Evidence.md").read_bytes()).hexdigest()}]
        self.assertEqual(self.run_audit()["exit_code"], 0)

    def test_external_source_requires_explicit_root(self):
        (self.source / "original.cs").write_text("sourceMarker")
        item = self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]
        item["source_evidence"] = [{"root": "source", "path": "original.cs", "contains": "sourceMarker"}]
        self.assertIn("EVIDENCE_ROOT", self.codes())
        self.assertEqual(runtime.audit(self.root, self.cfg, self.source)["exit_code"], 0)

    def test_evidence_path_escape_rejected(self):
        item = self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]
        item["source_evidence"] = [{"path": "../other.txt", "contains": "x"}]
        self.assertIn("EVIDENCE_INVALID", self.codes())

    def test_not_applicable_requires_reason_and_evidence(self):
        self.cfg["runtime_contracts"]["categories"]["ui"] = {"status": "not_applicable", "items": []}
        self.assertIn("CATEGORY_REASON", self.codes())
        self.assertIn("EVIDENCE_MISSING", self.codes())

    def test_all_five_declared_categories(self):
        for cat in ("scenes", "state_lifetimes", "ui", "timing"):
            self.cfg["runtime_contracts"]["categories"][cat] = {"status": "declared", "items": [self.item(cat, cat)]}
        report = self.run_audit()
        self.assertEqual(report["summary"]["contract_items"], 5)
        self.assertEqual(report["exit_code"], 0)

    def test_serialized_must_be_boolean(self):
        item = self.item("state_lifetimes", "selection")
        item["contract"]["serialized"] = "false"
        self.cfg["runtime_contracts"]["categories"]["state_lifetimes"] = {"status": "declared", "items": [item]}
        self.assertIn("SERIALIZED_TYPE", self.codes())

    def test_placeholder_contract_not_accepted(self):
        self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]["contract"]["consumers"] = "TODO"
        self.assertIn("CONTRACT_FIELD", self.codes())

    def test_runtime_claim_requires_evidence(self):
        item = self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]
        item["verification"] = {"status": "RUNTIME_EVIDENCE_RECORDED", "evidence": []}
        self.assertIn("EVIDENCE_MISSING", self.codes())
        item["verification"]["evidence"] = self.evidence
        self.assertEqual(self.run_audit()["independent_runtime_verification"], "NOT_PERFORMED")

    def add_rule(self, **overrides):
        rule = {"id": "query-index", "include": ["Consumer.cs"], "pattern": r"\bquery\s*\(\s*i\s*\+\s*1\s*\)", "mode": "forbid", "scan": "code", "reason": "Fixture stable ID contract"}
        rule.update(overrides)
        self.cfg["runtime_contracts"]["scan_rules"] = [rule]

    def test_rule_reports_candidate_with_correct_line(self):
        self.add_rule()
        (self.root / "Consumer.cs").write_text("class Consumer {\nvoid Test() { query(i + 1); }\n}")
        report = self.run_audit()
        self.assertEqual(report["status"], "REVIEW_REQUIRED")
        self.assertEqual(report["review_candidates"][0]["line"], 2)

    def test_rule_masks_comment_and_string_false_positives(self):
        self.add_rule()
        (self.root / "Consumer.cs").write_text('class Consumer { // query(i + 1)\n string mText = "query(i + 1)"; /* query(i+1) */ }')
        self.assertEqual(self.run_audit()["summary"]["review_candidates"], 0)

    def test_rule_without_file_coverage_does_not_pass(self):
        self.add_rule(include=["Missing/*.cs"])
        self.assertIn("RULE_NO_COVERAGE", self.codes())

    def test_require_rule_missing_symbol_is_review_not_compiler_claim(self):
        self.add_rule(pattern="RequiredSymbol", mode="require")
        self.assertEqual(self.run_audit()["status"], "REVIEW_REQUIRED")

    def test_rule_path_escape_rejected(self):
        self.add_rule(include=["../*.cs"])
        with self.assertRaises(ValueError):
            self.run_audit()

    def test_unknown_category_rejected(self):
        self.cfg["runtime_contracts"]["categories"]["scene_typo"] = {}
        with self.assertRaises(ValueError):
            self.run_audit()

    def test_negative_column_config_rejected(self):
        self.cfg["runtime_contracts"]["categories"]["tables"]["items"][0]["csv_check"]["finite_columns"] = [-1]
        with self.assertRaises(ValueError):
            self.run_audit()

    def test_cli_bad_json_is_not_evaluated(self):
        config = self.root / "bad.json"
        config.write_text("{")
        process = subprocess.run([sys.executable, str(SCRIPTS / "audit_myframework_runtime_contracts.py"), str(self.root), "--config", str(config), "--json"], capture_output=True, text=True)
        self.assertEqual(process.returncode, 2)
        self.assertEqual(json.loads(process.stdout)["status"], "NOT_EVALUATED")

    def test_cli_static_pass_still_reports_runtime_not_performed(self):
        config = self.root / "config.json"
        config.write_text(json.dumps(self.cfg))
        process = subprocess.run([sys.executable, str(SCRIPTS / "audit_myframework_runtime_contracts.py"), str(self.root), "--config", str(config), "--json"], capture_output=True, text=True)
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
        self.assertEqual(json.loads(process.stdout)["independent_runtime_verification"], "NOT_PERFORMED")


if __name__ == "__main__":
    unittest.main()
