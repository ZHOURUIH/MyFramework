"""ZIP accounting fixtures, not real Unity builds or RPK signing tests."""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest
import warnings
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import audit_quickgame_package as package


class QuickGamePackageTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.path = self.root / "game.signed.rpk"

    def write(self, entries=None, compression=zipfile.ZIP_STORED):
        with zipfile.ZipFile(self.path, "w", compression=compression) as archive:
            for name, data in entries or [("main.rpk", b"m" * 100), ("Build.rpk", b"b" * 200),
                                         ("game.signed.rpk", b"w" * 300)]:
                archive.writestr(name, data)

    def test_default_scope_uses_physical_file(self):
        self.write()
        report = package.audit_package(self.path, 300)
        self.assertEqual(report["main_and_subpackages_bytes"], 300)
        self.assertEqual(report["budget"]["scope"], "file")
        self.assertEqual(report["exit_code"], 1)

    def test_explicit_subpackage_scope_excludes_compatibility(self):
        self.write()
        report = package.audit_package(self.path, 300, "subpackage-sum")
        self.assertEqual(report["exit_code"], 0)
        self.assertEqual(report["compatibility_bytes"], 300)
        self.assertEqual(report["upload_acceptance"], "NOT_VERIFIED")
        self.assertEqual(report["signature_verification"], "NOT_PERFORMED")

    def test_limit_boundary_and_one_byte_over(self):
        self.write()
        self.assertEqual(package.audit_package(self.path, 300, "subpackage-sum")["exit_code"], 0)
        self.assertEqual(package.audit_package(self.path, 299, "subpackage-sum")["exit_code"], 1)

    def test_compressed_zip_counts_inner_file_bytes(self):
        self.write(compression=zipfile.ZIP_DEFLATED)
        report = package.audit_package(self.path, 300, "subpackage-sum")
        self.assertEqual(report["main_and_subpackages_bytes"], 300)
        self.assertLess(report["inner_packages"][0]["zip_compressed_bytes"], 100)

    def test_multiple_subpackages_are_all_counted(self):
        self.write([("main.rpk", b"m"), ("Build.rpk", b"b" * 10),
                    ("StreamingAssets.rpk", b"a" * 20), ("other.rpk", b"x" * 30)])
        self.assertEqual(package.audit_package(self.path)["main_and_subpackages_bytes"], 61)

    def test_renamed_outer_is_conservative_without_explicit_entry(self):
        self.write()
        target = self.root / "renamed.rpk"
        self.path.rename(target)
        report = package.audit_package(target, 300, "subpackage-sum")
        self.assertEqual(report["main_and_subpackages_bytes"], 600)
        self.assertEqual(report["exit_code"], 1)
        self.assertIsNone(report["compatibility_entry"])

    def test_renamed_outer_can_use_explicit_compatibility_entry(self):
        self.write()
        target = self.root / "renamed.rpk"
        self.path.rename(target)
        report = package.audit_package(target, 300, "subpackage-sum", "game.signed.rpk")
        self.assertEqual(report["main_and_subpackages_bytes"], 300)

    def test_absent_explicit_compatibility_rejected(self):
        self.write()
        with self.assertRaises(ValueError):
            package.audit_package(self.path, compatibility_entry="not-found.rpk")

    def test_missing_main_does_not_pass_subpackage_budget(self):
        self.write([("Build.rpk", b"x")])
        self.assertEqual(package.audit_package(self.path, 100, "subpackage-sum")["exit_code"], 2)

    def test_two_main_packages_are_ambiguous(self):
        self.write([("main.rpk", b"x"), ("nested/main.rpk", b"y")])
        self.assertEqual(package.audit_package(self.path, 100, "subpackage-sum")["exit_code"], 2)

    def test_standalone_file_has_only_physical_budget(self):
        self.write([("manifest.json", b"{}"), ("game.js", b"x")])
        self.assertEqual(package.audit_package(self.path, 1000)["exit_code"], 0)
        self.assertEqual(package.audit_package(self.path, 1000, "subpackage-sum")["exit_code"], 2)

    def test_compatibility_budget_requires_identification(self):
        self.write([("main.rpk", b"x")])
        self.assertEqual(package.audit_package(self.path, 100, "compatibility")["exit_code"], 2)

    def test_compatibility_budget_is_measured_separately(self):
        self.write()
        self.assertEqual(package.audit_package(self.path, 299, "compatibility")["exit_code"], 1)

    def test_duplicate_zip_entries_rejected(self):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            self.write([("main.rpk", b"x"), ("main.rpk", b"y")])
        with self.assertRaises(ValueError):
            package.audit_package(self.path)

    def test_traversal_entry_rejected(self):
        self.write([("../main.rpk", b"x")])
        with self.assertRaises(ValueError):
            package.audit_package(self.path)

    def test_main_cannot_be_excluded_as_compatibility(self):
        self.write()
        with self.assertRaises(ValueError):
            package.audit_package(self.path, compatibility_entry="main.rpk")

    def test_windows_absolute_entry_rejected(self):
        self.write([("C:/main.rpk", b"x")])
        with self.assertRaises(ValueError):
            package.audit_package(self.path)

    def test_bad_limits_rejected(self):
        self.write()
        for value in (0, -1, True, 2.5):
            with self.subTest(value=value), self.assertRaises(ValueError):
                package.audit_package(self.path, value)

    def test_missing_path_rejected(self):
        with self.assertRaises(ValueError):
            package.audit_package(self.path)

    def test_measurement_preserves_input_bytes(self):
        self.write()
        original = self.path.read_bytes()
        report = package.audit_package(self.path)
        self.assertEqual(report["status"], "MEASURED")
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(len(report["sha256"]), 64)

    def test_cli_corrupt_file_returns_json_not_evaluated(self):
        self.path.write_bytes(b"not a zip")
        result = subprocess.run([sys.executable, str(Path(package.__file__)), str(self.path), "--json"],
                                capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(json.loads(result.stdout)["status"], "NOT_EVALUATED")

    def test_cli_default_physical_limit_fails(self):
        self.write()
        result = subprocess.run([sys.executable, str(Path(package.__file__)), str(self.path), "--limit-bytes", "300"],
                                capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stdout)["budget"]["scope"], "file")


if __name__ == "__main__":
    unittest.main()
