# Changelog

## 3.2.2

- 新增快游戏构建/缩包/裁剪/动态字体/电脑日志/签名/交付工作流，平台阈值和版本不固化为通用默认。
- 新增只读 RPK 字节测量：默认物理文件，显式分包/兼容包口径；后台受理和签名状态不伪报。
- UI 审计补 Padding 的 localRotation/localScale、嵌套 pivot/变换/停靠参数 override，拒绝混合无法解析资产、GUID 身份冲突和无效枚举映射。
- 少量边界停靠明确为实际父容器，而非只限屏幕 root；保持 ScaleAnchor 默认、设计几何和用途例外。
- 入口按范围路由；原详细阶段保存在 references/34。用户/仓库规范优先，局部任务不强制全量重构、自动修改 Skill 或默认输出工程 ZIP。
- 增加包体计量与 UI 漏检回归测试，重跑全套并更新验证记录、版本和完整性摘要；不替换已安装技能。

## 3.2.1

- 纠正 UI 适配默认：普通节点只用 ScaleAnchor/ResScaleAnchor，绝大多数保持比例；移除 authored 原生 UGUI anchors，保留设计几何。
- PaddingAnchor/ResPaddingAnchor 改为精确节点的少量屏幕边界停靠例外，禁止用于普通对齐、文本列、scroll/viewport/content 或进度 fill。
- 明确非等比仅为全屏 root/背景/遮罩和无可见图形输入覆盖等用途，自动节点原生 anchor 例外需生成来源。
- 区分 pivot 与 anchors，保留合法动态文本 pivot；自动宽度更新后用框架排列定位兄弟节点，防止 Name/Value、Score/Season 重叠。
- 区分 Game/HotFix Anchor 类型与真实字段，不给 ResScaleAnchor 写不存在的 mRemoveUGUIAnchor；审计拒绝错误层组件，并从目标 enum 检查 mKeepAspect=true + NONE 仍为非等比的情况。
- 新增所有正式 UI Prefab 的只读适配审计、精确用途配置和工具 fixtures；Game 层启动/下载也在范围内。
- 更新 UI/显示硬要求、核心路由、项目模板；保留 3.2.0 其他合同与原有审计。

## 3.2.0

- 新增表格 consumer/稳定身份合同：区分 ID、排序、选择值、存档身份；历史位置存档冻结版本化映射，新增/乱序/缺失行不得串进度。随机候选需要集合/顺序/权重/端点/映射均一致，不只检查 RNG 次数。
- 新增实际 bytes 加载后的 Ready Gate、有限数值/必需 ID/外键/默认值验证，失败不得覆盖旧存档。继续区分手工准备态与官方 Generator 执行态。
- 新增 GameScene 再入、同步/迟到回调、已有 Scene、不完整初始化、明确失败终态、Reset 与正常退出保存策略及状态寿命矩阵。不能把 pool reset 当每次 onInit，也不能为框架化新增冗余 Manager。
- 新增 UI 刷新时钟、World/HUD/panel 输入政策、玩家入口与系统回调边界、visual enabled、独立 Tween/hold 通道；保留基类已提供的 owner 清理，不按窗口名字强制 modal。
- 新增周期语义合同：clock/phase/catch-up/condition order/interval change/pause/reset/RNG；RagdollFactory 的具体常量只作需验证案例，不进入通用默认值。
- 新增 `audit_myframework_runtime_contracts.py`：五类合同覆盖、证据文件/literal/hash、CSV 主键/必需 ID/有限值/范围/唯一列/外键、定向 C# 候选规则；结果限于已声明静态范围，不认证 Unity/Generator/语义。
- 修复 `compare_myframework_generated_regions.py` 的无效目录/空 C#/空 region 误通过、两边相同损坏 marker 漏报；新增/删除均比较。`--allow` 改为需要真实日志路径的 approval，不再跳过文件，changed 总数始终保留。
- 注意 CLI 行为收紧：旧的无证据 `--allow` 调用现在 exit 2；无覆盖不是 PASS。exit 0 也不能替代官方工具与运行认证。
- 新增 references/28–31、Runtime Contract 模板、Generator evidence 模板、Python unittest 和 Skill 包验证报告；保留原七类审计和全部 3.1.0 规则。
- 明确新版不追认历史版本手写生成区、离线 bytes 或源码对照为官方工具/Unity 运行完成；未经完整核查不得断言“只剩 Unity 验证”。

## 3.1.0

- 将 **不完整中间移植工程** 的真值规则补全：如果任务明确要求与更上游实现保持一致（例如已授权网页/H5 → Unity 的后续 MyFramework 重构），上游可运行源码/运行结果可以高于中间 Unity 工程；参考 MyFramework 项目仍然只提供结构范式，不能覆盖行为。
- 新增 `references/27-upstream-parity-effective-behavior.md`，要求按**最终有效行为**做 parity：CSS/样式表加载顺序、selector specificity、JS 后写覆盖、刷新函数二次覆盖、默认 easing、display/opacity、z-index/渲染层、随机/低精度分支、Shader culling、procedural mesh topology 都必须追到最终生效值，不能拿第一次匹配当真值。
- 将用户已确认的 UI 规范升级为硬门禁：**LayoutScript/UI 页面脚本默认不得实现 `resetProperty()`**。页面临时状态应在 `onGameState()/onHide()/setData()` 等页面生命周期中收口；`ClassObject` / `WindowRecyclableUGUI` 等真实池对象的 reset 合同不受影响。`audit_myframework_ui.py` 新增 `layout_reset_property_candidates`。
- 强化存档兼容：序列化字段“缺失”与“存在但值为 0/负数/非法值”不得用同一个 sentinel 混为一谈；若不能改变 JSON schema，可用 `[NonSerialized]` 字段存在标记恢复原 `clean()/fallback/clamp` 语义。
- 强化视觉与字体闭环：允许在已有授权源资产基础上做格式转换以适配 Unity（如 WOFF2 → TTF）；Variable Font 在 legacy UGUI Text 下优先固定成静态实例，并验证 fallback glyph。字体“名字相同”不等于字形/字宽/weight 一致。
- 强化运行表现 parity：Tween/反馈效果必须核对 duration、delay、keyframe offset、timing-function、坐标空间、层级和 Reduced/Disabled 分支；World 与 HUD Overlay 不能靠反向补偿长期冒充同一层级。
- 强化 Procedural Mesh / Shader parity 与性能门禁：拓扑、端盖、分段数、flat normal、culling、低细节阈值、确定性随机种子都属于表现合同；迁移不得为了 parity 在热路径引入字符串 cache key、临时数组/List/`ToArray()` 等 GC。
- 新增 `scripts/compare_myframework_generated_regions.py`，用于版本间比较 Layout/GBR/Register/Excel 等自动生成区。在“本轮不应改 Generator”的迭代中，自动区必须 0 drift；若确实运行了官方 Generator，则应把变化作为明确证据记录，而不是把手改自动区混入业务 diff。
- Report / Manifest / Audit Config 增加 Upstream Parity、Effective Override、Layout resetProperty、Generated Region Drift、Save Field Presence、Runtime Effect Layering 等证据项。

## 3.0.0

- 将 Skill 范围明确收窄为 **已有普通 Unity 工程 → MyFramework 重构**，不再把网页/H5 抓取或网页首次复刻作为主流程。
- 新增 `26-unity-to-myframework-workflow.md`，明确 MonoBehaviour/Manager/UGUI/Resources/ScriptableObject/Coroutine/Event/Audio/Save 等常规 Unity 架构向 MyFramework 的映射顺序。
- 强化“原 Unity 工程是行为真值，MyFramework 参考项目是结构真值”的边界，禁止参考项目覆盖原玩法、横竖屏和资源合同。
- 明确 UI LayoutScript 默认不因对象池理由主动添加 `resetProperty()`；以目标项目 Generator/基类合同为准。
- 强化普通 Unity 迁移的 serialized contract、旧 script GUID 清理、第二局/销毁顺序、callback(null)、Pool reset 与 Direct-Run 完整包门禁。
- 保留 2.6.0 的 Structure/Migration/UI/Display/Excel/Resource/Dependency 七类审计体系。


## 2.6.0

- 新增 **Display Profile Gate**：迁移前必须从原版/目标平台证据冻结横竖屏、目标 viewport/aspect、设计分辨率与 Safe Area，禁止从参考项目或框架模板机械继承 `1920x1080` 等默认值。
- 新增 `references/24-display-orientation-visual-parity.md` 与 `scripts/audit_myframework_display.py`：校验 `FrameSettings.UISizeStandalone/UISizeMobile`、`start.unity` 的 UGUIRoot、Runtime UI Prefab 根 RectTransform 与项目声明的 Display Profile 一致，并扫描直接 `Screen.orientation` 冲突、明显 Root 直系子节点越界候选。
- 强化横竖屏迁移规则：**不能只交换宽高**。必须重新验证 Root 直系控件边界、ScaleAnchor/PaddingAnchor、Safe Area、全屏 Dim/Guide，以及 World Camera 的 FOV/俯仰/偏航/aspect framing 与世界覆盖。原版存在 ground skirt / backdrop / sky dome / floor filler 等“填屏几何”时，它们属于表现合同，不得因“不是玩法对象”漏迁导致屏幕露出 Camera background。
- 新增视觉 Parity Matrix：至少对目标分辨率下的 Home/Menu、Gameplay、Result/Fail 三类关键状态做截图对照；必须检查空白/纯色 void、角色屏幕占比、相机地平线/地面覆盖、UI safe area、overlay alpha 和主要控件边界。
- 强化 **UGUI Generator Ownership Audit**：仅有 auto-generate marker 不再视为结构合格。`newObject(...)`、成员 WindowObject 的 `.assignWindow(...)`、Generator-owned `new(this)` 等绑定代码若长期出现在对应自动区外，直接报告 `manual_generator_binding_candidates`。Root `UGUIGenerator.mParentType` 默认应为 `LayoutScript`，SubGenerator parent type 不能为空。
- 明确“业务回调 vs Generator click”边界：列表/卡片需要 index/上下文参数时，可让 Generator 只生成强类型成员并关闭该 MemberData 的自动 click，再在业务区注册参数化 callback；禁止 Generator 与业务代码重复注册同一点击。
- 新增 `references/25-excel-hardcode-toolchain-closure.md` 与 `scripts/audit_myframework_excel.py`：稳定业务 Catalog、价格、顺序、显示文案、奖励概率/数值、FTUE revision 等先做 Hardcoded Business Data Inventory，再进入 MyFramework Excel；fixed-step/碰撞/随机调用顺序等 parity-critical 常量不机械迁表。
- Excel 完成标准进一步收紧：手写 ED/Excel、离线脚本手工拼 `.bytes`、复刻 Serializer 协议只算 `TABLE_STRUCTURE_READY / GENERATOR_UNVERIFIED`；只有官方 CodeGenerator + CSVToBinary 真执行并在 Unity 中从 bytes 加载，才算工具链闭环。
- 新增 API/编译教训：`CS0051/CS0052` 先判断成员是否只是实现缓存，优先**收窄成员可见性**而不是把 internal 实现类型扩大为 public；包装控件（如 Button/WindowObject）不得假设拥有底层 `myUGUIObject/Transformable` 的全部方法，必须查真实继承/API。
- FrameSettings 规则加强：`FrameSettings.asset` 必须按目标版本 `FrameSettings.cs` 的真实序列化字段生成/校验，禁止直接复制其他项目/版本的 YAML；同时区分运行时 `Assets/Resources/Settings/FrameSettings.asset` 与编辑器 `ProjectSettings/MyFrameworkSettings.asset`。
- `MIGRATION_AUDIT_CONFIG.json`、Plan/Manifest/Checklist/Report 增加 Display Profile、UI root resolution、Visual Parity、Hardcoded Data/Excel Table Matrix 和官方 Generator evidence 字段。
- 交付审计由五类扩展为 **Structure / Migration / UI / Display / Excel / Resource / Dependency** 七类静态审计；这些仍不能替代 Unity 真编译、官方 Generator 和 Play Mode。

## 2.5.0

- 新增 **UI Contract Audit**：`scripts/audit_myframework_ui.py`，直接扫描 Runtime UI Prefab 上的 root `UGUIGenerator`、Canvas 归属、LayoutScript 生成标记、`generate from` 来源、`LayoutRegisterHotFix`、GBR LayoutScript 集合、手工 fallback 注册、UI God FrameSystem 候选和已知错误 builtin font 引用。
- 将 CrushYard R13→R14 暴露的 UI 架构问题升级为硬规则：独立页面必须由独立 LayoutScript 管理，禁止用 `XXXUISystem : FrameSystem` 统一 LOAD/HIDE/UNLOAD、按钮路由、Popup 状态、存档计时和页面刷新。真正全局 UI 服务只能职责单一并显式白名单。
- 明确 **UGUIGenerator 四层闭环**：Prefab MemberData、LayoutScript 自动区、`LayoutRegisterHotFix` 自动区、GBR LayoutScript 自动区必须同时一致；离线脚本可以审计/预演，但不能冒充官方 Unity UGUIGenerator 已执行。
- 新增 `registeFrameSystem<T>() callback(null)` 生命周期规则和审计项 `frame_system_callback_null_unsafe_candidates`，防止退出时 callback 对空 `com` 调 `setInitOrder/setDestroyOrder` 产生 NRE。
- 新增 **跨 FrameSystem 销毁依赖门禁**：需要其他 System/Manager 存活的解绑优先放 `willDestroy()`；`destroy()` 不得假设 CameraManager/ResourceManager/EventSystem 等仍存在，fallback 必须 null-safe。审计项为 `cross_system_destroy_dependency_candidates`。
- 新增 **Static API Visibility Gate**：不仅验证 API 在目标源码存在，还检查当前调用文件是否通过正确 owner/fully-qualified/`using static` 可见；1.1.12 默认覆盖 `changeProcedure/changeProcedureDelay -> FrameUtility`、`isEditor -> FrameBaseUtility`、`mEventSystem/mGameFrameworkHotFix -> FrameBaseHotFix`。
- `audit_myframework_structure.py` 新增 `--config`、`FrameSettings.asset`、`KeyFrame/Keyframe.prefab` 和 `build_settings_required_scenes` 校验；修复“完整包只有 start.unity，运行 Scene 要用户手工 Add Open Scenes”的漏洞。
- 固化 MyFramework 1.1.12 `FrameDefine.KEY_FRAME_FILE = KeyFrame/Keyframe.prefab` / `KeyFrameManager` Runtime 依赖；完整包不能只复制 `Assets/Packages/ProjectSettings` 骨架而漏掉官方 `ProjectTemplate~` runtime-critical 资产。
- 新增 UI 序列化资源完整性教训：错误的 `unity_builtin_extra` Arial 引用会导致 Panel 正常但全部 UGUI Text 消失；UI 审计加入当前已知错误 builtin font 模式检查。
- `MIGRATION_AUDIT_CONFIG.json` 新增 UI roots/Generator GUID、static API visibility、destroy dependency allowlist、Keyframe/FrameSettings、required Build Settings scenes 等配置。
- 优化 `audit_myframework_migration.py` 扫描范围：默认只审项目 `project_code_roots/audit_code_roots`，不再把 embedded MyFramework/第三方 Packages 自身的 namespace/实现算成业务迁移债务，也避免完整工程审计超时。
- 修正 Static API owner 审计：`mGameSceneManager/mLayoutManager/mResourceManager` 在 1.1.12 同时存在 AOT `FrameBase` 与 HotFix `FrameBaseHotFix` 声明，规则支持 `owners[]`，避免把合法的 `using static FrameBase;` 误报成 HotFix import 缺失。
- 修正 dependency duplicate asmdef 审计：默认跳过 `ProjectTemplate~ / Samples~ / Documentation~ / Tests~` 等 `~` 模板目录，避免完整包把官方 ProjectTemplate 中的 Game/HotFix/AutoGenerated asmdef 与项目实际 asmdef 误判成重复 Assembly。
- Checklist/Manifest/Plan/Report 增加 UI Generator Contract、FrameSystem Dependency/Destroy、Static API Access、Runtime Scene/Template Artifact 证据。

## 2.4.0

- 新增 **Dependency / Assembly 硬门禁**：禁止通过 `MyFrameworkCompatibility`、FakeRuntime/FakeEditor、同名 asmdef、空 class/namespace、placeholder 绕过真实 Package/Plugin 依赖。
- 新增 `scripts/audit_myframework_dependencies.py`：检查 duplicate asmdef Assembly name、伪兼容路径、embedded package 与 `manifest.json` 来源重叠（信息项，不默认判失败），以及项目声明的 Direct-Run runtime-critical 资产缺失。
- 新增 `references/22-dependency-api-directrun.md`：完整定义正式依赖、API Provenance、Unity Editor 版本兼容和 Direct-Run artifact closure。
- 新增 **API Provenance Gate**：MyFramework API 必须从目标版本源码/同版本参考项目核实声明类、static/instance、using、参数和生命周期；禁止凭记忆发明 `finish()` 等 API。
- 固化 MyFramework 1.1.12 实战证据：`changeProcedure<T>()` 来自 `FrameUtility`，`isEditor()` 来自 `FrameBaseUtility`，当前 `SceneProcedure` 无通用 `finish()` 合同。
- 新增 Unity 2022.3 Editor API 教训：Sprite importer alignment/pivot 通过 `TextureImporterSettings + ReadTextureSettings/SetTextureSettings` 读写，不能假设 `TextureImporter.spriteAlignment` 存在。
- 新增 **Direct-Run Gate**：用户要求“解压→打开→Play”时，Scene/Prefab/UI/Material/Settings/bytes 等运行关键资产必须已经存在于最终 ZIP；Tools 菜单或 `InitializeOnLoad` 只能作为维护工具，不能作为首次运行前置条件。
- 固化 MyFramework 1.1.12 UI Prefab 实战路径 `Assets/GameResources/UI/UIPrefab`，并要求不同版本重新读取 `LayoutManager`/路径常量。
- Manifest/Plan/Report/Checklist 新增 Dependency/Assembly Matrix、API Provenance Matrix、Direct-Run Artifact Matrix 和对应阶段门禁。
- 交付审计由 Structure/Migration/Resource 三类扩展为 Structure/Migration/Resource/Dependency 四类。

## 2.3.0

- 新增 **Resources 白名单硬门禁**：`Assets/Resources` 不再允许作为旧项目资源兼容仓库；1.1.12 默认只允许框架固定路径资源，第三方固定 Resources 合同必须显式白名单并写明源码/包依据。
- 新增 `scripts/audit_myframework_resources.py`，审计 Resources 非白名单资源、业务 `Resources.Load`、Legacy/Recovered 运行目录、重复 GUID、指定资源 GUID 漂移。
- 新增 `references/20-resource-layout-artifact-integrity.md`，规定 Resources/GameResources 边界、资源移动保留 `.meta`、GUID 引用验证、完整包/增量包删除语义。
- 新增 `references/21-binding-bridge-serialization.md`，明确 Binding 与 Bridge 边界、空壳 MonoBehaviour 不能作为行为真值源、Unity 序列化字段名/GUID 的迁移要求。
- `PROJECT_MIGRATION_MANIFEST.md` 新增 Resource Layout Matrix、Bridge/Binding Matrix、Serialized Contract、Artifact/Delete Gate。
- `REFACTOR_REPORT.md` 新增 Resources 计数、非白名单资源、Legacy runtime path、GUID 稳定性与最终制品检查。
- 强化 H-G/H-L/H-N/H-O/H-Q：资源布局、序列化兼容、Legacy 目录、最终 ZIP/增量补丁均成为阶段硬门禁。
- 增加 StealAEggs 实战教训：不能因为旧脚本为空就猜行为；必须结合原版、Scene/Prefab YAML、序列化资产和运行证据恢复职责。

## 2.2.1

- 修正 `missing_base_lifecycle` 对 MyFramework 1.1.12 抽象 UI 合同的误报。
- `LayoutScript.assignWindow()` 与 `WindowObjectBase.assignWindowInternal()` 在该版本为 `abstract`，不再要求不存在的 `base.assignWindow()` / `base.assignWindowInternal()`。
- H-C01 明确：生命周期 base 规则允许“目标版本源码证明”的例外，禁止为了审计归零伪造 base 调用。
- 其余 2.2.0 硬门禁保持不变。
