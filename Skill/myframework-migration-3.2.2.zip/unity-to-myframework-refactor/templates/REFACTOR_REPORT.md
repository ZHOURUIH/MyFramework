# MyFramework Refactor Report

## 本轮目标


## 修改内容

### 架构

### 生命周期 / Ownership

- FrameSystem callback(null) unsafe candidates:
- Cross-System destroy dependency candidates:
- willDestroy/destroy evidence:

### Binding / Bridge / Serialized Contract

### Upstream / Effective Behavior Parity

- Authoritative behavior source:
- Intermediate Unity known incomplete: yes / no
- Effective override chain evidence (CSS/config/update/retention/etc.):
- Animation duration/easing/keyframe evidence:
- World/HUD/Overlay layering evidence:
- Save missing-field vs invalid-value evidence:
- SOURCE_PARITY_STATIC_PASS: yes / no / n/a

### Display Profile / Visual Parity

- Orientation / design resolution:
- FrameSettings/start UGUIRoot/Layout root consistency:
- Direct child bounds candidates:
- World Camera framing/coverage:
- Home/Gameplay/Result screenshot parity:

### UI / Generator

- Layout generator prefabs:
- LayoutScript/Generator source match:
- LayoutRegister/GBR set match:
- UI God FrameSystem candidates:
- Manual/fallback layout registration:
- Known invalid builtin font refs:
- Manual generator binding candidates:
- LayoutScript resetProperty candidates:
- Previous → current generated-region drift:
- Generator parent type failures:
- Official UGUIGenerator execution evidence:

### Excel / 资源 / Audio

- Hardcoded Business Data Inventory：
- Excel tables migrated：
- Official CodeGenerator evidence：
- Official CSVToBinary evidence：
- Fallback/generated-code markers：

### 反射 / 兼容层

### Dependency / Assembly / API Provenance

### Direct-Run Artifact Closure

## 行为保护

本轮明确未修改：

-

## Legacy / Resource Debt 对比

| Metric | 上一阶段 | 当前 | Target | 备注 |
|---|---:|---:|---:|---|
| Legacy C# symbols |  |  | 0 |  |
| Legacy prefab components |  |  | 0 |  |
| Legacy script GUID refs |  |  | 0 |  |
| String UI actions/paths |  |  | 0/explicit |  |
| Native Instantiate/Destroy |  |  | 0/explicit |  |
| Old data consumers |  |  | 0 |  |
| Assets/Resources actual assets |  |  | allowlist only |  |
| Unexpected Resources assets |  |  | 0 |  |
| Project Resources.Load |  |  | 0/explicit |  |
| Legacy/Recovered runtime paths |  |  | 0 |  |
| Duplicate asmdef assembly names |  |  | 0 |  |
| Fake compatibility/stub paths |  |  | 0 |  |
| Missing direct-run artifacts |  |  | 0 |  |
| UI God FrameSystem candidates |  |  | 0/explicit |  |
| Manual layout registration |  |  | 0 |  |
| Static API visibility candidates |  |  | 0 |  |
| FrameSystem callback(null) unsafe |  |  | 0 |  |
| Cross-System destroy dependency |  |  | 0/explicit |  |
| Known invalid builtin font refs |  |  | 0 |  |
| Manual generator binding candidates |  |  | 0 |  |
| LayoutScript resetProperty candidates |  |  | 0 |  |
| Changed generated regions (when no Generator run) |  |  | 0 |  |
| Display profile/root mismatch |  |  | 0 |  |
| Hardcoded stable business data |  |  | 0/explicit |  |
| Excel generator fallback markers |  |  | 0 |  |

## 静态审计

| 项目 | 结果 |
|---|---:|
| Structure gate |  |
| Forbidden reflection |  |
| HotFix GetType |  |
| Direct lifecycle new |  |
| Legacy type refs |  |
| Legacy prefab GUID refs |  |
| Runtime UI path candidates |  |
| UI contract audit |  |
| Layout resetProperty audit |  |
| Generated-region drift check |  |
| Display profile audit |  |
| Excel toolchain audit |  |
| Static API visibility |  |
| FrameSystem callback(null) |  |
| Cross-System destroy dependency |  |
| UTF-8 BOM missing |  |
| Resources allowlist |  |
| Duplicate GUID |  |
| Expected moved GUID |  |
| Duplicate asmdef assembly names |  |
| Fake compatibility paths |  |
| Embedded/manifest package overlaps (info) |  |
| Missing direct-run artifacts |  |
| Excel validation |  |

## 资源布局

- Resources allowlist:
- Unexpected Resources assets:
- Moved assets / GUID stability:
- Deleted assets / residual GUID refs:
- GameResources layout:

## Dependency / API Provenance

- Real package sources:
- Duplicate asmdef names:
- Fake compatibility/stub paths:
- New MyFramework API evidence:
- Unity Editor API version evidence:

## Direct-Run

- Runtime-critical artifacts listed:
- Missing artifacts:
- Build Settings closure:
- Required runtime Scene(s):
- KeyFrame/Keyframe.prefab:
- FrameSystem lifecycle closure:
- FrameSettings/start scene closure:
- UI Prefab runtime path:
- Requires Tools menu/custom first-import generation: yes / no

## 生成工具

- [ ] UI Generator（真实执行；未执行时必须写未验证）
- [ ] Display Profile / target-resolution screenshot parity
- [ ] CodeGenerator
- [ ] CSVToBinary

## Unity 编译

- 状态：未执行 / 通过 / 失败
- 错误：

## Runtime

- [ ] 启动
- [ ] 模式 1 首局
- [ ] 模式 1 第二局
- [ ] UI 第一次打开
- [ ] UI 第二次打开
- [ ] 模式切换
- [ ] 设置/暂停/恢复
- [ ] 退出/重进

## 性能/内存回归

- GC：未测 / 结果
- Instantiate/Destroy：未测 / 结果
- Pool 第二局增长：未测 / 结果
- Event/Callback 重复：未测 / 结果
- Resource 重复加载：未测 / 结果

## 目标平台

-

## 与基线差异

- Source/effective behavior parity:
- Pixel/layering parity:

- 无已知差异 / 以下差异：

## 未验证与风险

-

## Artifact Gate

- Full merged staged root audit：未执行 / 通过 / 失败
- Incremental patch delete list：无 / 路径
- Full vs patch result equivalence：未执行 / 通过 / 失败
- ZIP integrity：未执行 / 通过 / 失败
- Dependency audit：未执行 / 通过 / 失败
- Direct-Run clean unzip/import/compile/play：未执行 / 通过 / 失败

## 删除清单

见 `DELETED_FILES.txt` 或版本化 `DELETE_<FROM>_TO_<TO>.txt`。

## 3.2.0 Runtime Contract / Coverage

- `RUNTIME_CONTRACTS.md` 与 JSON item ID：
- 表格：字段→consumer，ID/Order/SelectedValue，旧版本位置映射，required ID/finite/FK，实际 bytes Ready：
- Scene：同步/延迟/过期 callback，Procedure 再入，已有 Scene，entry gate，失败清理/终态，Reset 保存边界：
- 状态寿命：持久化/session/layout/UI，实际序列化输出，Reset/exit/reload 结果：
- UI：业务事件刷新，World/HUD/panel 输入，系统回调边界，visual enabled，独立 Tween/hold/cancel：
- 周期：时钟/相位/余量/补 tick/条件顺序/改 interval/暂停/重开/RNG：
- 原七类审计的实际扫描范围与数量：
- Runtime Contract categories/items/tables/rules/evidence 数量及未覆盖项：
- 自动区 baseline/current 路径、C# files/compared regions/changed/approved/unexpected/malformed：
- 官方 Generator 的 source/version/input/output/log（没有执行写 UNVERIFIED）：
- Unity compile/PlayMode/第二局/Reset/平台/视觉输入对照：分别记录，不与静态结果合并。
- 本轮保留的已知差异、历史生成器债务与未验证项：

## UI 适配（3.2.1）

- [ ] 已枚举全部正式 UI Prefab、Game 层启动/下载和引用模板；适配扫描范围：
- [ ] 普通节点 ScaleAnchor/ResScaleAnchor 保持比例，移除原生 UGUI anchors，转换时设计几何未移动。
- [ ] PaddingAnchor 只保留少量真实父节点边界停靠；没有用于普通父子对齐、文本列、scroll/viewport/content 或进度 fill。
- [ ] 每个非等比节点均有全屏/输入覆盖等明确用途；每个自动节点原生 anchor 例外均有生成来源。

| Prefab / 完整节点路径 | 例外类型 | 实际用途 / 生成来源 | 验证分辨率与结果 |
|---|---|---|---|

- [ ] `audit_myframework_ui_adaptation.py` 返回码与覆盖数量已记录；未解析的嵌套 override 已在 Unity 核实。
- [ ] 设计分辨率与另一个宽高比下，页面、中文、点击、滚动、进度和全屏覆盖已实际验证。


## OPPO/vivo 构建记录（仅平台任务填写）

- Unity/HybridCLR/SDK/CLI/运行时版本：
- 正常构建入口及自动执行的 helper 依赖：
- 产物路径/版本/SHA256/正式或调试签名：
- 物理文件 bytes / main bytes / 全部分包合计 / 兼容整包 bytes：
- 平台确认的阈值、MB/MiB 和限制口径（未确认写 UNVERIFIED）：
- 冷启动设备/新文件名/开始结束时间/日志路径：
- 中文、输入与本轮高风险资源的真实测试结果：
- 登录/实名/真机广告/上传受理的独立状态：
- 源码/helper 与可选文档/证据的保留清单；git add/commit 执行状态：
