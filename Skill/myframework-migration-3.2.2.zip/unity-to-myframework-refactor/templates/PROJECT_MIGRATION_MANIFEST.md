# Project Migration Manifest

## 1. Project / Framework

- Project:
- Unity:
- MyFramework version:
- MyFramework fingerprint:
- Behavior baseline:
- Reference projects:

## 2.1 Upstream / Effective Behavior Parity

| Item | Authoritative source | Initial definition | Later override / final effective behavior | Unity target | Evidence | Status |
|---|---|---|---|---|---|---|

- Intermediate Unity known incomplete: yes / no
- Final cascade/load/update order frozen: yes / no / n/a
- World/HUD/Overlay layering contract:
- Save field presence compatibility notes:

## 2. Legacy → Target Map

| Legacy | 原职责 | Target | 策略 | 删除条件 | 状态 |
|---|---|---|---|---|---|

## 3. Ownership

| 对象 | 逻辑 Owner | Unity/资源 Owner | 创建 | 更新 | 注销/回收 | reset 风险 |
|---|---|---|---|---|---|---|

## 4. Bridge / Binding Matrix

| MonoBehaviour | Category(Entry/Binding/Bridge/Editor/ThirdParty) | Unity callback / serialized refs | Runtime owner | 可删除条件 | 状态 |
|---|---|---|---|---|---|

## 5. Serialized Contract

| Legacy Component/Data | Scene/Prefab/Asset | Serialized field | Type | Current value/ref | Target | Migration/compat rule |
|---|---|---|---|---|---|---|

## 6. Display Profile Matrix

| Item | Baseline evidence | Target value | Asset/code owner | Static check | Runtime parity | Status |
|---|---|---|---|---|---|---|
| Orientation | | | | | | |
| Design resolution | | | | | | |
| FrameSettings UISize | | | | | | |
| start UGUIRoot | | | | | | |
| Layout roots | | | | | | |
| Safe Area | | | | | | |
| World Camera framing/coverage | | | | | | |

## 7. UI Migration Matrix

| UI | Prefab | Generator | 强类型绑定 | String Action/Path | Legacy Component | 第二次显示 | Parity | 状态 |
|---|---|---|---|---|---|---|---|---|

## 8. UI Generator Contract

| Layout | Prefab Generator | Layout auto regions | LayoutRegister | GBR | Official Generator evidence | Font/Sprite/Material refs | Status |
|---|---|---|---|---|---|---|---|

## 8.1 Generated Region Ownership

| Version range | Official Generator executed? | Inputs changed | Compared regions | Changed regions | Evidence / allowlist | Status |
|---|---|---|---:|---:|---|---|

## 9. FrameSystem Dependency / Destroy Matrix

| System | Depends on System/Manager | init/update/destroy order | callback(null) safe | release stage(willDestroy/destroy) | Source evidence / allowlist | Status |
|---|---|---|---|---|---|---|

## 10. Data Mapping

### Excel Toolchain Matrix

| Table | Hardcoded legacy source | CSV | ED/Excel generated | CSVToBinary bytes | Official tool evidence | Runtime query | Status |
|---|---|---|---|---|---|---|---|

### Data Mapping

| Old source/field | New table/field | Type | ID/default/enum rules | Validation |
|---|---|---|---|---|

## 11. Resource Layout Matrix

### Resources Allowlist

| Path | Why fixed Resources path is required | Evidence(source/package) | Final |
|---|---|---|---|
| Assets/Resources/Scene/start.unity | MyFramework START_SCENE | target framework source | yes |
| Assets/Resources/Settings/FrameSettings.asset | framework Resources.Load contract | target framework source | yes |

### Moved / Deleted Assets

| Old path | New path / DELETE | GUID | Reference validation | Status |
|---|---|---|---|---|

## 12. Dependency / Assembly Matrix

| Assembly/Package | Required by | Real source | Version/path | Compiled/imported? | Duplicate name | Status |
|---|---|---|---|---|---|---|

## 13. API Provenance Matrix

| Call/API | Owner/type | Access mode(qualified/inherited/using static) | Calling file | Source file / reference project | Target framework/Unity version | Verified |
|---|---|---|---|---|---|---|

## 14. Direct-Run Artifact Matrix

| Runtime critical artifact | Required path | Exists in final staged root | Generated only? | Build/runtime reference | Status |
|---|---|---|---|---|---|
| FrameSettings | Assets/Resources/Settings/FrameSettings.asset | | no | framework fixed contract | |
| Keyframe Prefab | Assets/GameResources/KeyFrame/Keyframe.prefab | | no | KeyFrameManager | |
| Runtime Scene(s) | project-specific | | no | EditorBuildSettings | |

## 15. Legacy Debt

| Metric | Baseline | Current | Target | Whitelist reason |
|---|---:|---:|---:|---|
| Legacy C# symbols |  |  | 0 |  |
| Legacy prefab components |  |  | 0 |  |
| Legacy script GUID refs |  |  | 0 |  |
| String UI action handlers |  |  | 0 |  |
| Runtime UI path lookups |  |  | 0/explicit |  |
| Native Instantiate/Destroy |  |  | 0/explicit |  |
| GameDatabase/JSON consumers |  |  | 0 |  |
| Unexpected Assets/Resources assets |  |  | 0 |  |
| Project Resources.Load calls |  |  | 0/explicit |  |
| Legacy/Recovered runtime paths |  |  | 0 |  |
| Direct MonoBehaviour not allowlisted |  |  | 0 |  |
| UI God FrameSystem candidates |  |  | 0/explicit |  |
| Manual/fallback Layout registration |  |  | 0 |  |
| Static API visibility candidates |  |  | 0 |  |
| FrameSystem callback(null) unsafe |  |  | 0 |  |
| Cross-System destroy dependency |  |  | 0/explicit |  |
| Known invalid builtin font refs |  |  | 0 |  |
| Manual generator binding candidates |  |  | 0 |  |
| LayoutScript resetProperty candidates |  |  | 0 |  |
| Changed generated regions without Generator run |  |  | 0 |  |
| Display profile/root mismatch |  |  | 0 |  |
| Hardcoded stable business data |  |  | 0/explicit |  |
| Excel generator fallback markers |  |  | 0 |  |

## 16. Phase Gates

| Phase | Structure | Asset | Resource | Dependency/API | Direct-Run | Generator | Behavior | Debt | Artifact | Status |
|---|---|---|---|---|---|---|---|---|---|---|

## 17. Artifact / Patch Contract

- Full merged package root:
- Incremental from version:
- DELETE list:
- Staged root audits:
- Full vs patched file-set comparison:

## 18. Explicit Exceptions

Every exception must state why the MyFramework equivalent cannot preserve behavior or why a fixed Resources/MonoBehaviour contract is unavoidable.

-

## 3.2.0 Runtime Contract / Coverage

- `RUNTIME_CONTRACTS.md` 与 JSON item ID：
- 表格：字段→consumer，ID/Order/SelectedValue，旧版本位置映射，required ID/finite/FK，实际 bytes Ready：
- Scene：同步/延迟/过期 callback，Procedure 再入，已有 Scene，entry gate，失败清理/终态，Reset 保存边界：
- 状态寿命：持久化/session/layout/UI，实际序列化输出，Reset/exit/reload 结果：
- UI：业务事件刷新，World/HUD/panel 输入，系统回调边界，visual enabled，独立 Tween/hold/cancel：
- 周期：时钟/相位/余量/补 tick/条件顺序/改 interval/暂停/重开/RNG：
- 原七类审计的实际扫描范围与数量：
- Runtime Contract categories/items/tables/rules/evidence 数量及未覆盖项：
- 自动区 baseline/current 路径、C# files/compared regions/changed/approved/unexpected/malformed：
- 官方 Generator 的 source/version/input/output/log（没有执行写 UNVERIFIED）：
- Unity compile/PlayMode/第二局/Reset/平台/视觉输入对照：分别记录，不与静态结果合并。
- 本轮保留的已知差异、历史生成器债务与未验证项：

## UI 适配（3.2.1）

- [ ] 已枚举全部正式 UI Prefab、Game 层启动/下载和引用模板；适配扫描范围：
- [ ] 普通节点 ScaleAnchor/ResScaleAnchor 保持比例，移除原生 UGUI anchors，转换时设计几何未移动。
- [ ] PaddingAnchor 只保留少量真实父节点边界停靠；没有用于普通父子对齐、文本列、scroll/viewport/content 或进度 fill。
- [ ] 每个非等比节点均有全屏/输入覆盖等明确用途；每个自动节点原生 anchor 例外均有生成来源。

| Prefab / 完整节点路径 | 例外类型 | 实际用途 / 生成来源 | 验证分辨率与结果 |
|---|---|---|---|

- [ ] `audit_myframework_ui_adaptation.py` 返回码与覆盖数量已记录；未解析的嵌套 override 已在 Unity 核实。
- [ ] 设计分辨率与另一个宽高比下，页面、中文、点击、滚动、进度和全屏覆盖已实际验证。
