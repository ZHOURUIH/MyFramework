# Runtime Contract Matrix

项目/基线版本：
目标 MyFramework/Unity 版本：
本轮修改范围：
行为真值及冻结路径/hash：

不得直接把本模板视为项目证据。每行链接到 `MIGRATION_AUDIT_CONFIG.json` 中相同 item ID；不适用项写来源与原因。

## 表与消费路径

| ID | CSV/ED 字段 | 查询/实际 consumer | 身份/排序/选择值 | 数值/引用约束 | Ready 阶段 | 历史迁移 | RNG 映射 | 证据/状态 |
|---|---|---|---|---|---|---|---|---|

## Scene 流程

| ID | Loading/Gaming/Restarting/Exit 职责 | 同步/延迟/null/迟到回调 | 已存在 Scene | Ready 依赖 | 失败清理 | 正常退出 vs Reset 保存 | 第二次进入 | 证据/状态 |
|---|---|---|---|---|---|---|---|---|

## 状态寿命

| ID/字段 | owner | 实际序列化 | load | UI hide/show | Layout restart | GameScene exit | 应用重启 | 证据/状态 |
|---|---|---|---|---|---|---|---|---|

## UI 输入与动画

| ID/页面 | 业务事件/刷新时钟 | World/HUD/Panel 输入 | 玩家命令 vs 系统回调 | 视觉 enabled | 通道/曲线/hold | owner/取消/叠加 | Generator 边界 | 证据/状态 |
|---|---|---|---|---|---|---|---|---|

## 周期事件

| ID | 时钟/执行阶段 | 初始相位/间隔 | 迟到/补 tick/余量 | 条件先后 | 动态改间隔 | 暂停/重开 | RNG | 对照 trace/状态 |
|---|---|---|---|---|---|---|---|---|

## 本轮新增或变化的数据/节点

| 输入变化 | 官方工具/来源 | 真实执行记录 | 自动区 diff | Unity 导入/编译 | 未闭环项 |
|---|---|---|---|---|---|

## 验证分层

| 检查 | 覆盖范围/数量 | 结果 | 实际执行证据 | 未覆盖/已知差异 |
|---|---|---|---|---|
| 原七类静态审计 | | UNVERIFIED | | |
| Runtime Contract 静态检查 | | UNVERIFIED | | |
| 自动区比较 | | UNVERIFIED | | |
| 官方 UGUI/Excel 工具 | | UNVERIFIED | | |
| 正式 bytes 加载/实际写出存档 | | UNVERIFIED | | |
| Unity 编译/首局/第二局 | | UNVERIFIED | | |
| Reset/异步失败/取消 | | UNVERIFIED | | |
| 时间 trace / 输入 / 多通道 UI | | UNVERIFIED | | |
| 目标平台/原版对照 | | UNVERIFIED | | |
