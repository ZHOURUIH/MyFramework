# MyFramework Hard Requirements Checklist

> 对照 `references/19-hard-requirements.md` 填写。`PASS` 必须有代码/生成器/Unity 证据；未执行写 `UNVERIFIED`，不能写 PASS。

| Gate | Status | Evidence / File / Error | Notes |
|---|---|---|---|
| H-A 启动与热更链 | TODO | | |
| H-B GameHotFix / GBR / Register | TODO | | |
| H-C FrameSystem 生命周期 / base 调用 | TODO | | |
| H-D API 签名 / overload / out-ref | TODO | | |
| H-E Scene / GameScene / Procedure | TODO | | |
| H-F UI / Prefab / Generator | TODO | | |
| H-G Resources allowlist / GameResources / GUID / Pool / Audio | TODO | | |
| H-H ClassObject / owner / reset | TODO | | |
| H-I Event / Command / Tween | TODO | | |
| H-J Gameplay / Input / Physics | TODO | | |
| H-K Excel / DataBase | TODO | | |
| H-L Save / Platform | TODO | | |
| H-M C# code style | TODO | | |
| H-N Analyzer / Compile | TODO | | |
| H-O Project structure | TODO | | |
| H-P Behavior / second run | TODO | | |
| H-Q Dependency / Assembly / fake compatibility | TODO | | |
| H-R API provenance / Unity version | TODO | | |
| H-S Direct-Run / runtime artifact closure | TODO | | |
| UI Contract / Generator 4-layer + binding ownership | TODO | | |
| Display Profile / orientation / design resolution | TODO | | |
| Excel hardcoded-data / official toolchain | TODO | | |
| FrameSystem callback(null) / willDestroy-destroy dependency | TODO | | |
| Static API visibility / owner/import | TODO | | |

## Required static audit command

```bash
python3 <skill>/scripts/audit_myframework_structure.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json
python3 <skill>/scripts/audit_myframework_migration.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json \
  --fail-on reflection,bom,base-call,auto-property,namespace,sealed,direct-new,enum-getter,ambiguous-getoradd,static-api,frame-callback-null,destroy-dependency,legacy-symbol,legacy-guid
python3 <skill>/scripts/audit_myframework_ui.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json \
  --fail-on generator-root,canvas,parent-type,layout-script,markers,binding-owner,register-set,gbr-set,manual-register,ui-god-system,bad-font
python3 <skill>/scripts/audit_myframework_display.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json \
  --fail-on profile,frame-settings,start-root,prefab-root,orientation
python3 <skill>/scripts/audit_myframework_excel.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json \
  --fail-on missing,rows,register,gamehotfix,hardcoded,fallback
python3 <skill>/scripts/audit_myframework_resources.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json \
  --fail-on unexpected-resources,allowlist-reason,resources-load,legacy-path,duplicate-guid,expected-guid,missing-meta
python3 <skill>/scripts/audit_myframework_dependencies.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json \
  --fail-on duplicate-asmdef,invalid-asmdef,fake-compat,missing-direct-run-artifact
```

## Required Unity evidence

- [ ] CodeGenerator executed
- [ ] UGUI Generator executed for every migrated layout（必须是 Unity 内官方 Generator；离线脚本不算）
- [ ] CSVToBinary executed
- [ ] Unity compile = 0 error / 0 Analyzer error
- [ ] Start Scene enters correct MyFramework launch chain
- [ ] FrameSystem registration callbacks survive callback(null) teardown
- [ ] Cross-System release verified in willDestroy/destroy order
- [ ] HotFix start GameScene reached
- [ ] First run passed
- [ ] Second run / second UI show passed
- [ ] Baseline behavior comparison passed
- [ ] Target-resolution Home/Menu screenshot parity passed
- [ ] Target-resolution Gameplay camera/world coverage parity passed
- [ ] Target-resolution Result/Fail screenshot parity passed

## Required resource / artifact evidence

- [ ] Resources actual / allowlisted / unexpected counts recorded
- [ ] Unexpected Resources assets = 0 for final stage
- [ ] Legacy/Recovered runtime paths = 0 in runtime Assets
- [ ] Moved asset `.meta` GUID unchanged
- [ ] Old script/resource GUID residual refs checked
- [ ] Full merged staged root re-audited
- [ ] Incremental patch DELETE list verified when files moved/deleted
- [ ] duplicate asmdef Assembly name = 0
- [ ] no fake compatibility/stub/placeholder paths
- [ ] effective package source is known/real; embedded+manifest overlap reviewed
- [ ] MyFramework API provenance recorded
- [ ] Editor API checked against target Unity version
- [ ] direct-run required artifacts physically exist in final staged root
- [ ] FrameSettings.asset + KeyFrame/Keyframe.prefab exist
- [ ] Display Profile is explicit; FrameSettings/start UGUIRoot/Layout roots use the same design contract
- [ ] FrameSettings serialized fields match the target framework version (not copied from another project/version)
- [ ] every runtime Scene is enabled in Build Settings
- [ ] UI LayoutRegister/GBR/Generator Prefab sets match
- [ ] Generator-owned newObject/assignWindow/new(this) binding code is inside official auto regions
- [ ] Root/SubGenerator parent types are valid
- [ ] Hardcoded Business Data Inventory completed before final UI polish
- [ ] Official CodeGenerator + CSVToBinary evidence recorded for migrated tables
- [ ] known bad builtin font refs = 0
- [ ] full package requires no Tools menu / custom first-import generation

## 3.1.0 新增硬门禁

- [ ] LayoutScript/UI 页面脚本 `resetProperty()` candidates = 0（除目标版本源码证明并显式 allowlist）。
- [ ] 若当前 Unity 是不完整中间移植版本，已冻结用户指定上游行为真值。
- [ ] 多层 CSS/config/update 刷新已追到最终有效值，不使用第一次命中作为 parity 结论。
- [ ] Tween/feedback 已核对 duration/delay/keyframe/easing/坐标空间/层级与 Reduced 等分支。
- [ ] 存档 missing-field 与 present-invalid 语义没有被同一 sentinel 混淆。
- [ ] Procedural Mesh/Shader parity 已核对 topology/normal/cull/LOD/seed，且热路径没有新增无意义 GC。
- [ ] 本轮未运行官方 Generator 时，`compare_myframework_generated_regions.py` = 0 changed regions。

## 3.2.0 Runtime Contract Gate

- [ ] H-K06/07：每个表字段有真实 consumer；ID/顺序/选择值分离，历史映射不随当前表顺序漂移。
- [ ] 实际 bytes 加载后 Ready；缺失/无效表不会覆盖旧存档。
- [ ] H-E05：Procedure 每次进入重置本次状态；同步/迟到/失败回调与已有 Scene 均有定义。
- [ ] 部分初始化失败可清理；正常退出/Reset/初始化失败不会混用保存路径。
- [ ] H-L06：持久化/session/layout/UI 状态矩阵与 serializer 实际输出一致。
- [ ] H-F14/H-P10：World/HUD/panel 输入、业务入口/系统回调、独立动画通道与计时语义有证据。
- [ ] H-I04：基类自动清理已按真实 owner 核对，未新增冗余服务。
- [ ] H-N04/H-S09：覆盖数量非空；缺目录/缺声明/缺 region 未被报告为 PASS。
- [ ] 未运行官方 Generator 时自动区确为有覆盖的 0 drift；历史手改债务未伪装成工具产物。
- [ ] 所有未运行层级单独 UNVERIFIED，未无依据宣布“只剩 Unity 验证”。

```bash
python3 <skill>/scripts/audit_myframework_runtime_contracts.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json --json
python3 <skill>/scripts/compare_myframework_generated_regions.py <previous-root> <current-root> --json
```

## UI 适配（3.2.1）

- [ ] 已枚举全部正式 UI Prefab、Game 层启动/下载和引用模板；适配扫描范围：
- [ ] 普通节点 ScaleAnchor/ResScaleAnchor 保持比例，移除原生 UGUI anchors，转换时设计几何未移动。
- [ ] PaddingAnchor 只保留少量真实父节点边界停靠；没有用于普通父子对齐、文本列、scroll/viewport/content 或进度 fill。
- [ ] 每个非等比节点均有全屏/输入覆盖等明确用途；每个自动节点原生 anchor 例外均有生成来源。

| Prefab / 完整节点路径 | 例外类型 | 实际用途 / 生成来源 | 验证分辨率与结果 |
|---|---|---|---|

- [ ] `audit_myframework_ui_adaptation.py` 返回码与覆盖数量已记录；未解析的嵌套 override 已在 Unity 核实。
- [ ] 设计分辨率与另一个宽高比下，页面、中文、点击、滚动、进度和全屏覆盖已实际验证。
