# MyFramework Migration Plan

## 1. 基线

- Project：
- Unity：
- MyFramework version：
- MyFramework fingerprint：
- 目标平台：
- Orientation：
- Reference viewport/aspect：
- MyFramework design resolution：
- Safe Area：
- 原版运行入口：
- 当前分支/工作树：
- 参考项目：
- Behavior baseline evidence：截图 / 录屏 / 日志 / PlayMode结果 / 测试数据

## 2. 原版必须保持的行为

- [ ] 启动/Loading
- [ ] 主菜单
- [ ] 模式 A
- [ ] 模式 B
- [ ] 输入/物理
- [ ] UI/动画
- [ ] Display/Profile/Camera framing
- [ ] 音频
- [ ] 存档兼容
- [ ] 目标平台

## 3. MyFramework 能力确认

- [ ] Game/GameEntry/GameHotFix
- [ ] GBR
- [ ] FrameSystem
- [ ] ClassObject/ClassPool
- [ ] SceneInstance/SceneSystem
- [ ] GameScene/SceneProcedure（如需要）
- [ ] LayoutScript/WindowObject/UGUI Generator（四层合同 + 官方 Generator 证据）
- [ ] ResourceManager/PrefabPoolManager
- [ ] AudioManager/AT
- [ ] GlobalTouchSystem/InputManager
- [ ] EventSystem/DelayCmdWatcher/TweenerManager
- [ ] Excel 工具链
- [ ] Stable business data inventory / hardcode removal
- [ ] 其他项目需要的现有框架模块
- [ ] 本轮新增 MyFramework API 已建立源码/参考项目证据
- [ ] 目标 Unity Editor API 已按版本核对

## 4. 项目 Manifest

- [ ] 已创建 `PROJECT_MIGRATION_MANIFEST.md`
- [ ] Legacy→Target Map
- [ ] Ownership
- [ ] Bridge / Binding Matrix
- [ ] Serialized Contract
- [ ] UI Migration Matrix
- [ ] Data Mapping
- [ ] Resource Layout Matrix / Resources allowlist
- [ ] Legacy Debt baseline
- [ ] Dependency / Assembly Matrix
- [ ] API Provenance Matrix（含 Access Mode）
- [ ] FrameSystem Dependency / Destroy Matrix
- [ ] UI Generator Contract Matrix
- [ ] Display Profile Matrix
- [ ] Excel Table / Tool Evidence Matrix
- [ ] Direct-Run Artifact Matrix
- [ ] Artifact / Patch contract
- [ ] Explicit exceptions

## 5. Display / Dependency / Direct-Run Baseline

- Display Profile evidence：
- FrameSettings UISize：
- start Scene UGUIRoot size：
- Runtime Layout root size：
- Screen orientation owner：
- World Camera baseline（FOV/rotation/distance/aspect/coverage）：

### Dependency / Direct-Run

- Packages/manifest.json：
- Embedded/local Packages：
- Key asmdef names：
- Duplicate asmdef names：
- Fake compatibility/stub paths：
- Runtime-critical artifacts：
- FrameSettings.asset：
- KeyFrame/Keyframe.prefab：
- Required runtime scenes in Build Settings：
- Build Settings：
- Requires Tools menu/custom first-import generation：

## 6. Resource / Serialized Baseline

- Assets/Resources actual assets：
- Resources allowlist：
- Unexpected Resources assets：
- Legacy/Recovered runtime paths：
- Legacy script GUID refs：
- 待迁 MonoBehaviour serialized contracts：

## 7. Ownership

| 对象 | Owner | 创建 | 更新 | 销毁/回收 | reset 风险 |
|---|---|---|---|---|---|

## 8. 迁移阶段

| 阶段 | 范围 | 风险 | Structure/UI/Asset/Resource/Dependency/API/Lifecycle/Direct-Run/Generator/Behavior/Debt/Artifact Gate | 状态 |
|---|---|---|---|---|
| 0 | 基线/Manifest |  |  |  |
| 1 | 启动/System |  |  |  |
| 2 | Scene/Gameplay |  |  |  |
| 3 | UI（逐页面） |  |  |  |
| 4 | Excel/稳定业务数据/资源 |  |  |  |
| 5 | 生命周期/反射/兼容层删除 |  |  |  |
| 6 | Unity/Runtime/Build/Parity/Performance |  |  |  |

## 9. 必须删除的旧结构

-

## 10. 暂不处理/用户排除

-

## 3.2.0 Runtime Contract / Coverage

- `RUNTIME_CONTRACTS.md` 与 JSON item ID：
- 表格：字段→consumer，ID/Order/SelectedValue，旧版本位置映射，required ID/finite/FK，实际 bytes Ready：
- Scene：同步/延迟/过期 callback，Procedure 再入，已有 Scene，entry gate，失败清理/终态，Reset 保存边界：
- 状态寿命：持久化/session/layout/UI，实际序列化输出，Reset/exit/reload 结果：
- UI：业务事件刷新，World/HUD/panel 输入，系统回调边界，visual enabled，独立 Tween/hold/cancel：
- 周期：时钟/相位/余量/补 tick/条件顺序/改 interval/暂停/重开/RNG：
- 原七类审计的实际扫描范围与数量：
- Runtime Contract categories/items/tables/rules/evidence 数量及未覆盖项：
- 自动区 baseline/current 路径、C# files/compared regions/changed/approved/unexpected/malformed：
- 官方 Generator 的 source/version/input/output/log（没有执行写 UNVERIFIED）：
- Unity compile/PlayMode/第二局/Reset/平台/视觉输入对照：分别记录，不与静态结果合并。
- 本轮保留的已知差异、历史生成器债务与未验证项：

## UI 适配（3.2.1）

- [ ] 已枚举全部正式 UI Prefab、Game 层启动/下载和引用模板；适配扫描范围：
- [ ] 普通节点 ScaleAnchor/ResScaleAnchor 保持比例，移除原生 UGUI anchors，转换时设计几何未移动。
- [ ] PaddingAnchor 只保留少量真实父节点边界停靠；没有用于普通父子对齐、文本列、scroll/viewport/content 或进度 fill。
- [ ] 每个非等比节点均有全屏/输入覆盖等明确用途；每个自动节点原生 anchor 例外均有生成来源。

| Prefab / 完整节点路径 | 例外类型 | 实际用途 / 生成来源 | 验证分辨率与结果 |
|---|---|---|---|

- [ ] `audit_myframework_ui_adaptation.py` 返回码与覆盖数量已记录；未解析的嵌套 override 已在 Unity 核实。
- [ ] 设计分辨率与另一个宽高比下，页面、中文、点击、滚动、进度和全屏覆盖已实际验证。
