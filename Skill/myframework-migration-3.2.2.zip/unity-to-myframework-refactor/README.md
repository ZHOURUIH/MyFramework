# Unity → MyFramework Refactor Skill 3.2.2

用于已有 Unity 工程迁移、继续重构与迁移后平台构建回归。入口为 [SKILL.md](SKILL.md)，按本轮范围加载模块合同；不是网页抓取或首次 H5 复刻工具。

## 本次补充

- 增加 OPPO/vivo 正常构建、缩包、裁剪保留、动态 TMP 字体、电脑运行日志、签名与交付边界。
- RPK 测量默认按物理文件；主包+分包及兼容整包另列，未核实后台计量时不宣称可上传。
- 修复 UI 审计的 Padding 旋转/缩放与 nested override 漏检、混合空覆盖和配置身份冲突。
- 允许极少数节点在实际父容器边界停靠，同时保留默认等比 ScaleAnchor 和禁止滥用 Padding 的规则。
- 缩短入口并保留 [完整迁移阶段清单](references/34-detailed-migration-workflow.md)；局部任务不强制读全包，不自动改写已安装技能，不默认制造完整工程 ZIP。

## 使用与自测

解压本包，技能目录为 `unity-to-myframework-refactor`。需要安装时放到执行环境的技能目录，不放入 Unity Assets/Packages。本次交付不自动替换已安装技能。

```bash
python -m unittest discover -s tests -v
python scripts/audit_myframework_ui_adaptation.py <project-root> --config <project-root>/MIGRATION_AUDIT_CONFIG.json --json
python scripts/audit_quickgame_package.py <signed.rpk> --limit-bytes <confirmed-byte-limit> --json
```

审计脚本使用 Python 3.10+ 标准库，均不修改游戏工程。项目配置模板需填真实事实；静态检查、测量和 fixtures 不替代 Unity 编译、官方生成器、运行、签名验证或后台受理。[验证记录](VALIDATION.md) 说明本次实际测试范围。
