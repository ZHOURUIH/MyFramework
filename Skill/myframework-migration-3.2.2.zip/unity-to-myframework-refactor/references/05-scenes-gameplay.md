# 场景与玩法分层

## 先区分三种“场景”

1. Unity Scene：资源容器、Root、Camera、灯光。
2. MyFramework SceneInstance：Unity Scene 的框架实例。
3. 逻辑 GameScene/SceneProcedure：游戏流程状态机。

不要因为旧项目类名叫 `GameScene` 就直接继承框架 `GameScene`；看职责。

## Scene 负责什么

- 找场景 root / prefab root。
- 绑定稳定 Transform/Camera/世界节点。
- 负责场景 show/hide/init/destroy。
- 把必要的纯引用数据交给 System/Mode/UI。

不负责：

- 做 UI facade。
- 保存所有游戏规则。
- 通过 `getSceneObject(string path)` 给全项目当 Service Locator。

## BattleSystem / Mode

推荐把模式公共命令放 Business System：

```text
UI -> BattleSystem.revive()
              -> CurrentMode.revive()
```

而不是：

```text
UI -> BattleSystem.getView()
   -> (ArcherPvEScene)view
   -> scene.revive()
```

Mode 可以持有当前 Scene 的必要接口/绑定，但 detach 时必须先结束 Mode，再释放 Scene-owned 对象。

## 模式表达

不要 `enterMode(0/1/2)`。

优先：

- enum `GameMode.Single/PvP/PvE`
- 强类型 Mode 类。
- 明确表格 ID。

## 场景切换验证

必须测试：

- 单局退出。
- 同模式重开。
- A 模式 → B 模式 → A 模式。
- 切场景时正有 Tween/延迟/事件。
- 正有箭矢、特效、AI 等对象被销毁。

大量生命周期 bug 只在上述边界出现，首局正常不能证明迁移正确。

## 3.2.0 运行合同补充

继续重构时必读 [GameScene / Reset / 状态寿命](29-scene-restart-save-lifetimes.md)，特别检查缓存 Procedure 再入、失败终态和旧回调，不把 resetProperty 等同每次 onInit。
