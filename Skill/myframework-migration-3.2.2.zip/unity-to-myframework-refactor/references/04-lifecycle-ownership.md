# 生命周期与所有权

这是 MyFramework 迁移最容易“能编译但第二局崩”的部分。

## 所有权表

每个复杂对象至少记录：

| 对象 | Owner | 创建 | 更新 | 注销 | 回收 |
|---|---|---|---|---|---|
| Actor | ActorSystem | CLASS | ActorSystem snapshot | ActorSystem | UN_CLASS |
| 子组件 | Actor | CLASS | Actor | Actor.destroy | UN_CLASS |
| Pooled GameObject | PoolSystem | PrefabPoolManager | Gameplay | PoolSystem | destroyObject |
| Helmet 索引 | ObjectSystem 只索引 | 真正 owner | 无/查询 | 对象 destroy 自注销 | owner UN_CLASS |

**索引者不是 owner。**

## ClassObject 迁移步骤

1. 确认类型及其父类确实是 ClassObject 体系。
2. 运行实例创建改为 `CLASS<T>()`。
3. 找到唯一 owner。
4. owner 在确定生命周期结束时 `UN_CLASS`。
5. `destroy()` 解除事件、子对象、资源、索引。
6. `resetProperty()` 清理所有可变状态。
7. 连续创建→销毁→复用至少两次验证。

### 不要机械替换

```csharp
// 错误思路
new Actor() -> CLASS<Actor>()
```

如果 Actor 的子对象仍 `new`、GameObject 销毁未通知 ActorSystem、或最终仍只调用 `actor.destroy()`，就会变成池泄漏或半销毁对象。

## resetProperty 规则

必须清理：

- bool 状态。
- 计时器和计数。
- callbacks/delegates。
- List/HashSet/Dictionary 内容。
- 对其他 ClassObject/Unity Object 的运行引用。
- 当前目标、碰撞缓存、伤害缓存。
- Tween/Command assign ID。
- 上一局选择、临时模式。

固定只读缓存可保留，但必须证明不会携带运行态。例如固定数组如用于 hit cache，也应 `Array.Clear`。

## destroy 与 willDestroy

- `willDestroy()`：EventSystem、TimeManager、其他 System 仍存活时解除依赖。
- `destroy()`：销毁自身拥有对象并进入 destroyed 状态。
- Scene 退出时先 detach 依赖 Scene 的 Mode/System，再释放 Scene 自己的对象。

## 集合修改与重入

高风险形式：

```csharp
foreach (Actor actor in mActors)
{
    actor.update(dt); // 内部可能 destroy -> unregister -> 修改 mActors
}
```

正确做法：

```csharp
List<Actor> snapshot = LIST<Actor>();
snapshot.AddRange(mActors);
foreach (Actor actor in snapshot)
{
    if (actor.isValid())
    {
        actor.update(dt);
    }
}
UN_LIST(ref snapshot);
```

同理：如果 `UN_CLASS_LIST(mHelmets)` 中 `Helmet.destroy()` 会从 `mHelmets` 自注销，不要直接用；先快照再回收。

## 重复销毁

- `isDestroy()` / `isPendingDestroy()` 可用于幂等保护。
- 但不要用“已经 destroyed 所以 owner 不 UN_CLASS”掩盖池泄漏。
- 玩法阶段的 `destroy()` 与最终 owner 的 `UN_CLASS` 必须定义清楚关系。

## Unity Object 与 ClassObject 不同

Unity `Object` 的 null 语义不能直接套到普通 ClassObject。

- Unity Object：销毁后 `== null` 有特殊行为。
- ClassObject：用 `obj != null && !obj.isDestroy()` / `isValid()`。

迁移后重点检查旧代码中 `if (arrow != null)` 是否需要加生命周期判断。

## 2.5.0 补充：FrameSystem callback 与跨系统销毁依赖

MyFramework 1.1.12 会在 FrameSystem 真正销毁后对其注册 callback 传入 `null` 清理引用。因此应用层 `registeFrameSystem<T>()` callback 必须 null-safe；不能在没有 `com != null` 保护时调用 `com.setInitOrder/setUpdateOrder/setDestroyOrder`。

同版本销毁总流程是：先对全部 FrameSystem 调 `willDestroy()`，再按 destroy order 调 `destroy()`。因此：

- 需要其他 System/Manager 活着才能归还的对象在 `willDestroy()` 处理。
- `destroy()` 不得无证据假设 CameraManager/ResourceManager/EventSystem 等还存在。
- 如依赖明确 destroy order，必须有目标版本源码证据并进入项目 allowlist。
- `destroyComponent<T>()` 路径不经过统一 `willDestroy()`，因此必要 fallback 仍要 null-safe、幂等。

## 3.2.0 运行合同补充

3.2.0 另填状态寿命矩阵，见 [GameScene / Reset / 存档/session](29-scene-restart-save-lifetimes.md)。页面 reset 禁令不改变真实池对象合同；基类已清理的 owner 不重复造清理系统。
