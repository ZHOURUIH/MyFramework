# 稳定业务数据 / Excel 官方工具链闭环

本章解决一种常见“代码已经像 MyFramework，但业务配置仍写死在 C#”的半迁移状态。

典型残留包括：

```text
Shop Catalog 数组
ID -> 名称/描述/价格/图标 switch
奖励概率/金币数量
FTUE revision
解锁价格范围
固定关卡/角色目录
```

这些数据如果本质是稳定业务配置，就应该进入 MyFramework Excel 工具链，而不是等 UI 全部做完以后再补。

---

# 1. 先做 Hardcoded Business Data Inventory

在 UI 最终 polish 前，扫描并分类所有硬编码数据：

| 数据 | 例子 | 默认去向 |
|---|---|---|
| 稳定 Catalog | item/skin/vehicle/weapon ID、排序 | Excel |
| 展示配置 | 名称、描述、图标、价格 | Excel / Localization |
| 运营/规则参数 | reward chance、reward value、revision | Excel/Global config |
| 资源稳定 ID 映射 | ID -> resource key | Excel/强类型资源表 |
| 确定性核心常量 | fixed-step、碰撞半径、RNG 调用阈值 | **默认保留代码**，除非原版本来就是配置 |
| 算法内部状态 | accumulator、cooldown runtime state | 绝不进表 |

原则：**不是“所有 const 都进 Excel”，而是“稳定业务数据不继续散落在业务代码”。**

对于普通 Unity 工程重构，若某数值直接参与固定 RNG 调用顺序、物理/碰撞或逐帧算法，迁表可能改变原行为。只有在原版数据本来就属于配置或已有精确等价测试时才迁。

---

# 2. 表结构以稳定业务模型为中心

推荐字段：

```text
ID
Kind/Type
Order
DisplayName / LocalizationKey
Description / LocalizationKey
Price
Icon/ResourceID
DefaultOwned
DefaultEquipped
```

不要把下面这些迁移内部信息长期放进业务表：

```text
C# ClassName
FieldName
ManagedType
反射路径
迁移 SourcePath
临时 Legacy 标记
```

默认/拥有/装备等语义优先由表中明确字段表达，不在 Profile 构造函数再次写死同一 ID。

---

# 3. 官方链路必须完整

正式完成状态：

```text
Excels/*.csv
   ↓
官方 CodeGenerator
   ↓
ED*.cs / Excel*.cs / ExcelRegister 自动段 / GBR Excel 自动段
   ↓
官方 CSVToBinary
   ↓
Assets/GameResources/Excel/*.bytes
   ↓
ExcelManager.loadAllAsync
   ↓
业务 query
```

并验证 `GameHotFix.registerAllTable()` 使用项目正式 ExcelRegister。

## 不算完成的情况

以下只可用于迁移准备/诊断：

- 手工写 `EDFoo : ExcelDataT<EDFoo>`。
- 手工写 `ExcelFoo : ExcelTableT<EDFoo>`。
- 手工修改 ExcelRegister auto-generate 区。
- Python/C# 脚本自己复刻 SerializerRead/加密协议后拼 `.bytes`。
- 从别的工程复制 `.bytes`。

即使这些文件能被当前框架读出来，也只能标记：

```text
TABLE_STRUCTURE_READY
GENERATOR_UNVERIFIED
```

只有官方 CodeGenerator / CSVToBinary 在目标工具版本真实执行后，才能写 `GENERATOR_VERIFIED`。

---

# 4. CSV 类型能力不能凭经验猜

必须读取当前项目实际的：

- CodeGenerator。
- CSVToBinary。
- 同版本表样例。
- 目标 ED/Excel 生成代码。

例如 bool/Color/enum/Vector 的支持可能随版本变化。

如果当前工具不支持某类型：

- 使用工具真实支持的稳定表达。
- 在一个明确入口集中解析。
- 不自行扩展一份“兼容 CSV 解析器”与正式工具并存。

---

# 5. 迁表后必须删除重复真值源

迁表完成后扫描：

- 原静态 Catalog 数组。
- 同 ID switch。
- 默认拥有/装备硬编码。
- 旧 JSON/ScriptableObject consumer。
- 重复价格/描述/奖励参数。

如果代码中仍有相同数据，Excel 就只是“复制了一份”，不算完成迁移。

可在 `MIGRATION_AUDIT_CONFIG.json` 为当前项目配置 `hardcoded_data_patterns`，让 `audit_myframework_excel.py` 报告指定字符串/数值/旧符号是否仍出现在业务代码。

---

# 6. 数据等价性验证

至少验证：

- 行数。
- 主键唯一。
- 排序。
- enum/type 数值。
- 默认值。
- 价格/概率精度。
- 图标/资源路径存在。
- DefaultOwned / DefaultEquipped 语义。
- 旧存档加载后 query 结果不变。

对于原静态 Catalog，建议写一次迁移测试：旧数据快照与新 Excel query 逐记录逐字段对比，确认后再删除旧真值源。

---

# 7. 静态审计

2.6.0 新增：

```bash
python scripts/audit_myframework_excel.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json
```

项目配置示例：

```json
{
  "excel_tables": [
    {
      "name": "ItemCatalog",
      "csv": "Excels/ItemCatalog.csv",
      "bytes": "Assets/GameResources/Excel/ItemCatalog.bytes",
      "data_class": "Assets/Scripts/HotFix/DataBase/Excel/Data/EDItemCatalog.cs",
      "table_class": "Assets/Scripts/HotFix/DataBase/Excel/Table/ExcelItemCatalog.cs",
      "min_data_rows": 1
    }
  ],
  "excel_register_path": "Assets/Scripts/HotFix/DataBase/Excel/ExcelRegister.cs",
  "game_hotfix_path": "Assets/Scripts/HotFix/Game/GameHotFix.cs",
  "hardcoded_data_patterns": []
}
```

脚本检查：

- CSV / bytes / ED / ExcelTable 是否存在。
- CSV 数据行是否达到项目声明下限。
- `.bytes` 非空。
- ExcelRegister 是否引用表类型/表名。
- GameHotFix 是否调用 ExcelRegister。
- 业务代码是否仍包含项目声明的硬编码残留模式。
- 生成代码中是否存在 `migration fallback / GENERATOR_UNVERIFIED` 等迁移标记。

它仍然不能证明官方工具已经运行；Generator execution evidence 必须来自实际命令/Unity 工程结果。

## 3.2.0 运行合同补充

3.2.0 增加 [表格实际消费与身份合同](28-table-consumption-identity-readiness.md) 及 `audit_myframework_runtime_contracts.py`；原 Excel 审计继续保留，不用新脚本冒充官方 bytes 验证。
