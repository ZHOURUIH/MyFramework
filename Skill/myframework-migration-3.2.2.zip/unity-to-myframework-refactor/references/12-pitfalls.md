# 常见陷阱

## 1. 旧类型删了，调用方仍引用

症状：`Settings could not be found`。

错误修法：新建一个空 `Settings` 兼容类。

正确修法：找到重构后的真实职责，例如 `ArcherSettingsController`，把字段、构造、调用链一起迁移。

## 2. Gameplay 里混入 UI

症状：Gameplay 直接 `GBR.mUIxxx`，或 UI 目录里藏 Gameplay 状态。

修法：业务命令进 System/Mode，UI 只显示/交互。

## 3. GameBase/SceneInstance 变万能入口

症状：大量 `getSceneComponent/getSceneObject/getView`。

这通常意味着旧 Service Locator 被换了名字，而不是真正分层。

## 4. ClassObject 只改创建不改回收

症状：首局正常，第二局状态错、池越来越大、字典留旧对象。

检查 owner、destroy、UN_CLASS、resetProperty、GameObject 销毁同步。

## 5. 销毁顺序错误

典型：Scene 先把 `mBotSpawner=null`，之后 detach Mode，Mode.destroy 又访问 BotSpawner。

原则：先 detach 依赖者，再释放依赖对象。

## 6. UN_CLASS_LIST 自注销

如果对象 destroy 会从正在遍历的 HashSet/List 删除自己，会触发集合修改异常。先 `LIST<T>()` 快照。

## 7. 共用 snapshot 导致嵌套重入

ActorSystem update 和 destroyActors 共用同一 List，update 中发生 destroy 会 Clear 外层 snapshot。每条可重入链使用独立临时 LIST。

## 8. Excel 类型超出工具能力

例如 CSVToBinary 不识别 `Color`。不要强行写 Color；按工具支持改成 Hex string，并用统一解析器。

## 9. 表格看似“强类型”但仍不规范

`ClassName/FieldName/ManagedType/SourcePath/ModeMask` 仍在表里，说明迁移内部实现仍泄漏到数据层。

## 10. UI 通过具体 Scene 工作

首局能跑，但切模式后 UI 类型判断和 Scene 生命周期纠缠。改成 UI→System→Mode，并用纯 Binding 传世界引用。

## 11. 为了去 MonoBehaviour 写错误 override

如果普通业务基类没有 `onTriggerEnter` virtual，不能假设存在。真正 Unity 消息用薄 Bridge。

## 12. 生成器没跑就手改代码

UI/Excel 自动段手改后，下次生成会全部丢失。改输入或生成器。

## 13. 过度清理

MyFramework 自己合法的 `GameEntryBase.startCoroutine`、Tween enum 等不能因为“看起来旧”就替换。先读框架源码和参考用法。

## 14. 只看首局

MyFramework ClassPool 迁移后必须测试第二局/切场景；复用状态问题往往只在下一次分配暴露。


## 15. Resources 被当成迁移垃圾桶

症状：项目结构审计都通过，但 `Assets/Resources` 里还有几十/几百个 Egg/Pet/Bot/UI/Font/Config。

这不是“资源都能找到所以没问题”，而是旧资源体系仍未迁移。建立白名单，把业务资源迁到 GameResources/Excel，删除旧副本。

## 16. 只删脚本，不清 Scene/Prefab GUID

`.cs` 没了但 YAML 仍引用旧 script guid，会形成 Missing Script 或隐性残留。迁移后必须扫描 `.unity/.prefab/.asset`。

## 17. 移动资源时丢 `.meta`

文件看起来仍存在，但 GUID 改变导致 Scene/Prefab 引用断开。离线移动必须资源 + `.meta` 一起移动，并校验 GUID。

## 18. 空壳 MonoBehaviour 被当成完整业务源码

旧类只有字段/空方法时，不能根据类名脑补行为。应从原 Unity 运行、C# 源码、Scene/Prefab 序列化参数和数据资产恢复。

## 19. serialized field 为了风格直接改名

旧资产按字段名序列化；把 `pet/weight` 直接改成 `mPet/mWeight` 会读空。用兼容 carrier、`FormerlySerializedAs` 或真实数据迁移，再在 Unity 中验证。

## 20. 完整包仍依赖“先删旧文件”

这是增量补丁语义，不是完整包。完整包解压后必须自身就是干净目标工程；删除清单只属于 patch。


## 21. 缺依赖时自己造同名 asmdef

症状：先为了消掉缺 Assembly 报错创建 `HybridCLR.Runtime.asmdef`/`Obfuz.Runtime.asmdef`，之后真实 Package 一安装就报：

```text
Assembly with name 'HybridCLR.Runtime' already exists
```

正确做法：使用项目正式 Package/Plugin；扫描所有 asmdef 的 `name`，duplicate 必须为 0。不要用 `MyFrameworkCompatibility`、FakeRuntime、空 namespace/class 代替真实依赖。

## 22. 凭记忆写 MyFramework API

典型：

```text
finish()
isEditor()
changeProcedure<T>()
```

方法名看起来合理不代表当前版本存在或属于当前类。新增调用前查目标 MyFramework 源码与参考项目，确认声明类、static/instance、using、参数和生命周期。

## 23. Editor Builder 使用了别的 Unity 版本 API

例如 Unity 2022.3 直接访问 `TextureImporter.spriteAlignment` 会编译失败。应按该版本真实 API 使用 `TextureImporterSettings` 的读写流程。

Editor 代码也是工程编译的一部分，不能因为“只在 Editor 里跑”而跳过版本验证。

## 24. 运行资产靠首次打开后生成

Scene/Prefab/UI/Material 在 ZIP 里不存在，只靠 `InitializeOnLoad` 或 Tools 菜单生成，这不叫 Direct-Run 完整工程。

最终完整包必须把 runtime-critical 资产预先落盘；Builder 只能是维护工具。

## 25. 完整包需要用户先删上一版目录

“先删 `MyFrameworkCompatibility` 再覆盖”是 patch 语义。完整包必须从空目录解压就成立。

## 26. UI Prefab 生成到错误目录

代码生成了 `Assets/GameResources/UI/Prefab`，但当前框架 `LayoutManager` 实际读 `Assets/GameResources/UI/UIPrefab`，结果文件都存在仍然加载不到。

目录不能凭习惯命名，必须查目标版本加载常量/源码。


## 27. 有 LayoutScript，但又造了一个 UI God FrameSystem

症状：`XXXUISystem : FrameSystem` 统一加载/关闭十几个页面、处理所有按钮、维护 Popup 类型、保存计时和 UI refresh。

这不是 MyFramework UI 终态。页面行为回到对应 LayoutScript，业务状态回 Business System，流程加载回 SceneProcedure/业务流程。真正全局 Toast/Loading 服务必须职责单一并白名单。

## 28. 手工填 auto-generate 区后声称 Generator 完成

Prefab 有 UGUIGenerator，C# 也有 marker，不等于官方 Generator 真执行。必须同时对齐 Prefab MemberData、LayoutScript、LayoutRegister、GBR；离线脚本只能做审计/预演。未在 Unity 中真实执行时写 `GENERATOR_UNVERIFIED`。

## 29. `registeFrameSystem` callback 在退出时 NRE

框架会在销毁后 `callback(null)`。如果 callback 中直接 `com.setInitOrder(...)`，退出 Play Mode 就会空引用。任何对 `com` 的解引用都必须放在 `com != null` 保护内。

## 30. 在 `destroy()` 里调用已销毁的 CameraManager/其他 System

MyFramework 先统一 `willDestroy()`，再逐个 `destroy()`。需要别的 System 仍存活才能解绑/归还的逻辑放 `willDestroy()`；`destroy()` fallback 必须 null-safe。若依赖明确 destroy order，必须有目标版本源码证据。

## 31. API 在源码里存在，但当前文件还是 `CS0103`

典型：`changeProcedureDelay<T>()` 确实存在，但文件漏了 `using static FrameUtility;`；LayoutScript 使用 `mEventSystem/mGameFrameworkHotFix` 却漏 `using static FrameBaseHotFix;`。API Provenance 必须记录调用文件 Access Mode。

## 32. FullInstall 有三大目录，却漏 Keyframe 或业务 Scene Build Settings

`Assets/Packages/ProjectSettings` 都存在不代表可直接 Play。MyFramework 1.1.12 的 `KeyFrame/Keyframe.prefab` 是运行依赖，业务 runtime Scene 也必须预先加入 Build Settings。组装完整包优先继承同版本官方 `ProjectTemplate~`，不要只拼骨架。

## 33. UI 面板能显示但所有文字消失

检查 Prefab 的 Font serialized reference。CrushYard 实战中把默认 Arial 写成 `unity_builtin_extra` 的 `fileID:12800000 + f...`，结果 Image/Panel 正常而所有 Text 不显示。不能只看 `m_Text` 内容判断 UI 正确。

## 34. 把 AOT 的 `FrameBase` 静态成员误判成必须来自 `FrameBaseHotFix`

MyFramework 1.1.12 中 `mGameSceneManager/mLayoutManager/mResourceManager` 在 AOT `FrameBase` 和 HotFix `FrameBaseHotFix` 都有真实声明。`Game.cs`、AOT `LaunchScene` 使用 `using static FrameBase;` 是合法结构。

Static API 审计必须支持 source-confirmed owner 集合，再依据调用文件所在层和实际 import 判断。不能把“HotFix 中最常见 owner”硬编码成全工程唯一 owner，否则审计会制造假错误。

## 35. 把 `ProjectTemplate~` 里的 asmdef 当成当前项目重复 Assembly

完整包内嵌 MyFramework 时，官方 `ProjectTemplate~` 可能包含模板用 `Game/HotFix/AutoGenerated.asmdef`，而目标项目 Assets 下也有实际同名 Assembly。模板目录不是当前工程编译 Assembly。

Dependency Audit 必须排除 `ProjectTemplate~ / Samples~ / Documentation~ / Tests~` 等 `~` 非运行导入目录；真正参与 Unity 编译的 asmdef 才进入 duplicate Assembly name 门禁。

## 2.6.0 新增陷阱

### 参考项目是横版，所以直接把 FrameSettings 设成 1920x1080

错。参考项目只证明框架用法，不证明当前游戏显示合同。先从原版运行/源码冻结 Display Profile，再配置 FrameSettings/start UGUIRoot/Layout roots。

### 把 1920x1080 交换成 1080x1920 就算竖屏适配完成

错。Root 直系子节点仍可能按横版坐标越界/重叠，World Camera 还可能露出纯色 background。必须重验 Anchor/Safe Area/Camera framing/填屏几何。

### LayoutScript 里加了 auto-generate marker，所以手写 newObject 也算 Generator 代码

错。Generator ownership 要看绑定语句是否位于对应自动区，并与 Prefab MemberData/parent type 一致。marker 不能给手工绑定“洗白”。

### 自己按 Serializer 协议拼出 Excel bytes 就等价于 CSVToBinary

错。可以用于诊断，但不能冒充官方工具链证据。没有官方 CodeGenerator/CSVToBinary 真执行就保持 `GENERATOR_UNVERIFIED`。

### CS0052 直接把 internal 类型改 public

通常先检查字段是否只是内部 cache。若外部不需要，收窄字段可见性比扩大整个实现类型 API 更符合封装。

## UI 适配错误：把两种 Anchor 当作每个节点的通用组合

普通节点只需要等比 ScaleAnchor/ResScaleAnchor。PaddingAnchor/ResPaddingAnchor 仅用于少量明确父节点边界停靠；不能给普通父子关系、文本列、scroll/viewport/content 或进度 fill 逐个添加。非等比仅给明确的全屏/输入覆盖节点；规则见 [UI 适配](32-ui-scale-anchor-policy.md)。

## UI 适配错误：禁止原生 anchors 就把所有 pivot 改成中心

pivot 不是 anchors。动态 `myUGUITextAuto` 可能以左/右 pivot 保持一端固定；`applyPreferredWidth` 只改宽度，不代表自动移动兄弟节点。将它改为中心并移除原生 anchors 后，属性 Name/Value、Score/Season 等容易重叠。保留合法 pivot，或在内容刷新后使用框架对齐/排列方法处理真实兄弟关系；不要加 PaddingAnchor 给每列补位置。仅 PaddingAnchor 本身受其源码中心 pivot 等几何前提约束。
