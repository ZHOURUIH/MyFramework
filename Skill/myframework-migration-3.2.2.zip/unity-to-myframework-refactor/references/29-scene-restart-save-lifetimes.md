# GameScene / 重开 / 存档与 Session 生命周期

本章解决“首局能进，但重开、隐藏 UI、异步返回、失败退出会改变行为”的问题。MyFramework 的真实源码决定 API 和生命周期；项目行为真值决定哪些状态应重置。

## 1. 分开五种所有权

| 角色 | 职责 | 不应承担 |
|---|---|---|
| GameScene / SceneProcedure | Loading、Gaming、Restarting、Exit 等流程组织 | 物理模拟、整个 UI 树、存档数据容器 |
| SceneInstance | 绑定真实 Unity Scene 的静态节点、相机、区域 | 反向查询 Gameplay 来补齐自己的序列化字段 |
| Gameplay FrameSystem / Mode | 局内对象、更新、规则、业务事件 | 直接引用具体 LayoutScript |
| ClientSystem / 数据组件等现有 owner | 加载、迁移、保存与账户/session 数据 | 页面显隐和窗口布局 |
| LayoutScript | 显示、输入意图、监听业务事件、表现动画 | 定义业务 session 寿命或直接写存档字段 |

表中角色是职责，不是要求每个项目强行新增五个类。已存在的框架服务应复用。

## 2. 流程切换先核对真实 SceneProcedure 合同

在所提供 MyFramework 1.1.12 源码中，`SceneProcedure.onInit` 注释要求初始化期间的跳转使用延迟命令；`exit` 会中断归属于流程的命令。不同版本必须重新检查，不能把 API 名凭记忆照抄。

异步加载可能同步命中缓存，也可能在退出后返回。常见可用表达是回调记录加载结果，由 `onUpdate` 或框架正式延迟命令在允许阶段切换；具体方式仍要保持项目规定的帧顺序。

必须审查：

- 每次 `onInit` 是否重置本次请求标记；不能只在 `resetProperty()` 重置。缓存 Procedure 再进入不等于对象重新出池。
- 同步、延迟、失败/null、重复回调、上一轮回调是否都有定义。
- 回调是否确认请求仍属于当前 scene/session/owner；优先复用框架的取消/owner 机制，确有缺口才增加最小请求代号。
- 一个完成结果是否最多触发一次流程切换。
- load 失败是否进入可诊断终态；禁止只 log 然后无限等待一个永远不会变成 true 的 flag。

不要为了这些检查另建 AsyncManager、第二套状态机或全局回调调度器。

## 3. Scene 已存在与 Scene 已 Ready 不是同一回事

同名 SceneInstance 可能：不存在、加载中、加载成功且绑定完整、已存在但绑定损坏、正在退出。

如果已有 Scene 的绑定损坏，不能再次 additive load 一份同名 Scene 来“补齐”。要报告具体缺失项，并按项目合同失败/清理/重试。

Ready 至少由项目声明的依赖构成：

```text
实际表加载/验证 + 可用数据 + 资源引用 + Scene serialized binding
```

相机、Font/Material、DynamicRoot、交互区域等是否必需，来自该项目；不把 22 个 Slot、3 条 Lane 当通用规则。

Binding 所需资源优先由 Scene 序列化引用或现有资源 owner 提供。禁止 SceneInstance → Gameplay → SceneInstance 的循环就绪依赖。

## 4. 进入玩法是可回滚过程

初始化一半失败时，应只清理本次 owner 已经创建/取得的对象、订阅、索引和资源引用，不能留下半套碰撞映射、Pin、Actor 或 UI。

明确区分：

- 正常退出：是否保存由业务定义；
- Reset：按 reset 合同清数据，不得补存旧状态；
- 初始化失败：不应通过通用退出路径意外保存半初始化状态。

UI 在失败状态不应看起来可操作却没有世界。先 LOAD UI 还是先 enterWorld 不能统一改写：若初始化会发奖励/离线事件，调整顺序可能丢消息。记录“订阅者 Ready → 生产事件 → 显示”时序，按原行为安排。

## 5. 用状态寿命矩阵决定保留和重置

每个关键字段至少记录：owner、是否序列化、load、UI hide/show、Layout restart、GameScene exit、应用重启。

典型区分：

- 持久化数据：经济、进度等，具体以源 SaveGame 写入集合为准；
- session 数据：某些选择、临时倍率、教程事件标记；
- layout/world 数据：当前世界对象、周期相位、局内动画等；
- UI presentation：正在显示的提示、Tween handle、临时选中表现。

这些示例不预设哪些字段必须保存。某个游戏不保存音效开关，不能泛化为所有游戏均不得保存设置。

UI 被隐藏、释放后重建，不应该自动抹掉长于页面寿命的业务状态。反过来，Layout restart 也不一定等于应用重启；源引擎全局变量与 layout-local 状态应分别核对。

`[NonSerialized]` 只对遵守该特性的真实 serializer 有效。必须检查实际写出的 JSON/二进制 key，而不是仅检查 attribute 或“读完后重新赋默认值”。字段存在标记同样需要真实 parser 填写，不会自动获得 presence 信息。

## 6. Reset 必须保持动作、写入和可见性顺序

先从原逻辑追出：停止交互/模拟、清存档、等待持久化完成、世界退出、UI 释放、重建、首次显示的实际顺序。不要无证据把这串动作换成 `new SaveData()` 或 `resetGame()` 原地重置。

要保证的底线：

- 旧 save job / autosave / focus callback 不能在 clear 完成后把旧存档写回来；
- 不能通过退出时自动 save 复活刚删除的数据；
- 旧 Tween/异步回调不能修改重建后的 UI/世界；
- Reset 连点、重入退出、退出过程中广告/奖励回调都有明确处理；
- 重新进入的第一帧，计数、倍率、任务、教程显示来自新状态，不短暂闪上一局数据。

具体使用暂停现有保存调度、取消任务、等待任务完成或请求版本校验，应依据框架与源流程，不要求新增 SaveSystem。异步 clear 的失败也必须有结果，不能假装已清空后继续。

## 7. 重开不一定需要卸载静态 Unity Scene

是否保留静态 SceneInstance 是项目决策，不是默认优化。仅在确认下面条件时复用：

- 可变 world/session 对象已清理；
- Scene 静态内容未被永久改变，或能按合同复位；
- Camera/Collider/Font/区域绑定仍有效；
- 没有依赖重新加载 Unity Scene 才触发的源行为；
- 复用与卸载路径的初始化、事件、奖励和随机时序等价。

需要真正换地图/重置静态组件时，走框架 SceneSystem 正式卸载加载链；禁止为了避免竞态永久漏掉所需卸载。

## 8. 事件/命令清理由真实基类负责的部分不要重复造

本次提供的 `LayoutScript.onHide()` 已包含命令中断和 `mEventSystem?.unlistenEvent(this)`；派生页面应遵守该基类合同，不为“listen/unlisten 字面匹配”增加第二套生命周期。

必须核查 owner：注册在页面自身、子控件、其他 listener、外部 Tween/任务上的操作，不一定由同一个基类方法清理。只有 owner 和调用时机一致才算覆盖。

UI 仍禁止添加 `resetProperty()`；页面表现放合适的 show/hide/init 接口，真实池对象按其 reset 合同实现。

## 9. 至少验证的流程

正常进入、同步缓存回调、加载失败、退出后回调、已有损坏 Scene、第二次进入同一 Procedure、半初始化失败、连续两次 Reset、Reset 与自动保存同帧、隐藏再显示 UI、应用退出/恢复。

记录 Scene/对象/事件/资源数量与首个可见帧，不用静态空引用检查冒充已经运行。
