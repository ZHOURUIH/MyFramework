# 显示方向 / 设计分辨率 / 世界画面闭环

本章来自竖屏项目迁移实战。它解决一类此前容易被“UI 已经显示出来”掩盖的问题：**项目实际是竖版，但 FrameSettings、start Scene、UI Prefab 根节点和 World Camera 仍沿用横版或参考项目默认值。**

这类错误会同时造成：UI 越界、顶部控件互相覆盖、全屏遮罩尺寸错误、世界画面只铺半屏、Camera background 暴露、角色屏幕占比失真，以及 Result/Home 与原版构图明显不一致。

---

# 1. 迁移前必须冻结 Display Profile

每个项目在改 UI/Camera 前，必须从原版运行证据、源码或目标平台合同确定：

```text
Orientation        Portrait / Landscape / AutoRotation
Reference viewport 例如 390x844 / 1080x1920 / 1920x1080
Design resolution  MyFramework UI 的逻辑设计尺寸
Safe Area          是否需要刘海/圆角/系统条适配
World aspect       Gameplay Camera 实际 aspect 处理方式
```

证据优先级：

1. 原 Unity 项目的真实运行画面、PlayerSettings、Scene/Camera/UI 配置与源码。
2. 目标平台/发行配置。
3. 目标项目现有正式设置。
4. 同版本参考项目仅用于理解框架 API，**不能作为本项目分辨率真值源**。

禁止：

- 因为参考项目用 1920x1080，就给竖屏游戏也写 1920x1080。
- 仅根据“手机游戏通常竖版/横版”猜方向。
- 只改 Game View 分辨率，却不改 FrameSettings/Prefab Root。

Manifest 必须记录 Display Profile 和证据。

---

# 2. 设计分辨率是一个跨资产合同

若项目采用固定设计分辨率，以下位置必须一致：

```text
FrameSettings.UISizeStandalone
FrameSettings.UISizeMobile
Assets/Resources/Scene/start.unity 的 UGUIRoot RectTransform
所有 Runtime Layout Prefab 的 root RectTransform
全屏 Dim / Guide / Tutorial / HomeCover 等节点
项目级 UI Camera / Canvas 基准（若框架版本需要）
```

这里的“相同”指项目设计合同相同，不代表所有平台物理分辨率相同。

不同平台确实需要不同设计尺寸时，应在 Display Profile 中显式配置，不要在 Prefab 里混用旧横版尺寸。

## 重要：不能只交换宽高（下述坐标只用于 Editor 资产迁移分析，不作为业务运行时适配代码）

从 1920x1080 迁成 1080x1920 时，以下操作都不够：

```text
FrameSettings: 1920x1080 -> 1080x1920
Root RectTransform: 1920x1080 -> 1080x1920
```

还必须重新检查 Root 直系子节点：

- AnchoredPosition。
- SizeDelta。
- Pivot。
- ScaleAnchor 是否保持比例；少量 PaddingAnchor 是否真有屏幕边界停靠用途。
- Safe Area。
- 是否发生裁切或互相覆盖。

例如一个宽 230、中心 x=-460 的控件，在 1080 宽 Root 上已经非常接近左边界；如果仍沿用横版的 x=-768，则一定越界。

静态坐标换算只能作为起点，最终必须看目标分辨率真运行图。

---

# 3. FrameSettings 不能复制别的项目 YAML

`Assets/Resources/Settings/FrameSettings.asset` 是运行时固定资产，但它的 serialized fields 必须来自**目标版本 `FrameSettings.cs`**。

硬规则：

- 先读取目标 Package 中 `FrameSettings.cs`。
- 优先使用该版本官方 Menu/ProjectTemplate 生成标准资产。
- 再修改本项目真实需要的 UISize、插件包名、加密键或其他正式字段。
- 禁止从另一项目/另一框架版本复制一份 YAML 后自行添加猜测字段。

同时区分：

```text
Assets/Resources/Settings/FrameSettings.asset    运行时配置
ProjectSettings/MyFrameworkSettings.asset        Editor/Project 配置（若当前版本存在）
```

两者不是同一资产，不能互相替代。

---

# 4. 屏幕方向属于显示合同，不属于 Gameplay 临时状态

先确认当前 MyFramework 是否已有 `ScreenOrientationSystem` 或同类能力。

优先级：

1. 框架正式方向系统 / 项目正式 Player Settings。
2. Scene 级显示 owner（仅当不同 Scene 确实需要不同方向）。
3. 禁止 Gameplay/Simulation/System 为方便直接到处写 `Screen.orientation`。

如果 Scene 临时改变方向，owner 必须负责恢复；如果整个 App 固定竖屏，则不要把它伪装成某个 BattleSystem 的临时状态。

`audit_myframework_display.py` 会扫描明确冲突的 `ScreenOrientation.X` 赋值，但不能证明 Player Settings 已正确配置，因此 Unity 仍需验证。

---

# 5. UI Prefab Root 与 Generator 是两个不同合同

UGUIGenerator 生成的是绑定代码，不会替你修正确的 Root 尺寸。

因此某 Layout 即使四层 Generator 都闭环，也仍可能因为 Root 是旧横版尺寸而表现错误。

每张 Runtime UI Prefab 至少验证：

```text
root Generator 在 Canvas
root RectTransform == 项目设计分辨率（若项目合同要求固定尺寸）
普通节点使用 ScaleAnchor/ResScaleAnchor 等比缩放，原生 anchors 中心化
PaddingAnchor/ResPaddingAnchor 仅有精确记录的屏幕边界停靠例外
非等比缩放只给明确的全屏/输入覆盖节点
全屏节点覆盖整个设计 Root
主要顶层控件不越界/不重叠
```

布局适配按 [ScaleAnchor 默认与例外规则](32-ui-scale-anchor-policy.md)；布局错误不能用运行时 `setPosition/setScale/hide` 大量补丁掩盖。

---

# 6. World Camera 也必须随横竖屏做 parity

竖屏 UI 正确并不代表 Gameplay 世界正确。

需要对照原版验证：

- Projection（Perspective/Orthographic）。
- FOV 或 orthographic size。
- Pitch/Yaw/Roll。
- Camera 距离与 aspect 的计算。
- 玩家在屏幕中的目标位置。
- 可见前方/后方世界范围。
- Near/Far Clip。
- Fog / Background / Skybox。

## “填屏几何”也是表现合同

原版 renderer 中常见：

```text
ground skirt
large floor plane
backdrop
sky dome
void cover
far background mesh
```

这些对象可能不参与玩法碰撞，但负责保证 Camera 在宽高比变化时始终被世界覆盖。

迁移时如果只创建真实 Row/Tile，而漏掉原版的大地面底板，常见结果就是：

- 横版看起来勉强正常；
- 换竖版后近景/下半屏直接露出 Camera background 纯色。

**不能因为它“不影响玩法”就省略。视觉 parity 任务中它属于必须迁移的 Renderer 逻辑。**

---

# 7. 最小视觉 Parity Matrix

目标分辨率、同一存档/种子条件下至少保存并比较：

| State | 必查 |
|---|---|
| Home/Menu | Logo/角色占比、顶部 HUD safe area、主按钮、底部导航、背景裁切 |
| Gameplay | 玩家屏幕位置、世界是否铺满、相机倾角/FOV、顶部 HUD、无纯色 void |
| Result/Fail | 背景世界 framing、scrim alpha、面板尺寸/位置、按钮 safe area |

项目有 Shop/Career/Settings 等重要页面时继续扩展。

每张截图至少记录：

- Runtime resolution。
- Orientation。
- 原版截图。
- Unity 截图。
- 已知差异。

不要用 Scene View 或 Prefab Preview 代替 Game View/Build 结果。

---

# 8. 静态审计

2.6.0 新增：

```bash
python scripts/audit_myframework_display.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json
```

配置示例：

```json
{
  "display_profile": {
    "orientation": "Portrait",
    "design_resolution": [1080, 1920],
    "start_ui_root_name": "UGUIRoot",
    "check_ui_prefab_root_size": true,
    "direct_child_bounds_allowlist": []
  }
}
```

它至少检查：

- Display Profile 已配置。
- orientation 与 design resolution 不自相矛盾。
- FrameSettings 的 UISizeStandalone/UISizeMobile。
- start Scene 指定 UGUIRoot 的 RectTransform。
- Generator UI Prefab root RectTransform。
- 代码中明确冲突的 `Screen.orientation = ScreenOrientation.X`。
- 中心锚点 Root 直系子节点的明显越界候选（默认报告，项目可白名单）。

该脚本不能证明 World Camera framing 或运行时 Safe Area 正确，仍需 Play/Build 截图证据。
