# 验证与完成标准

## 七层验证

| 层 | 证明什么 | 不能被什么替代 |
|---|---|---|
| 静态 | 架构/禁用 API/Legacy/资源白名单/GUID | 不能证明能编译 |
| 生成工具 | UI/Excel 真由工具产出 | 不能证明运行正确 |
| Unity 编译 | 类型、序列化、API 签名 | 不能证明玩法一致 |
| Runtime | 生命周期、交互、第二局 | 不能证明目标平台 |
| Build | WebGL/Android/Windows 真能启动 | 不能证明所有模式 |
| Source/effective parity | 上游源码、最终覆盖顺序、公式/时序/层级与目标实现对应 | 不能只看第一次定义/单个文件 |
| Baseline parity | 与原版运行行为/视觉一致 | 不能只靠编译或源码静态对照 |

## 静态检查

建议运行：

```bash
python scripts/audit_myframework_structure.py <project-root> --config MIGRATION_AUDIT_CONFIG.json
python scripts/audit_myframework_migration.py <project-root> --config MIGRATION_AUDIT_CONFIG.json
python scripts/audit_myframework_ui.py <project-root> --config MIGRATION_AUDIT_CONFIG.json
python scripts/audit_myframework_display.py <project-root> --config MIGRATION_AUDIT_CONFIG.json
python scripts/audit_myframework_excel.py <project-root> --config MIGRATION_AUDIT_CONFIG.json
python scripts/audit_myframework_resources.py <project-root> --config MIGRATION_AUDIT_CONFIG.json
python scripts/audit_myframework_dependencies.py <project-root> --config MIGRATION_AUDIT_CONFIG.json
```

若本轮**没有**运行官方 Generator，再额外执行版本间保护区检查：

```bash
python scripts/compare_myframework_generated_regions.py <previous-root> <current-root>
```

预期 `changed_regions = 0`。

再用 Roslyn/Unity 处理脚本不能准确判断的语义。资源脚本只能证明静态目录/GUID候选，不证明 Unity 已成功导入。

项目自有业务源码另核对函数间空行、全文连续空行、复杂语句换行、可内联却提前声明的局部变量，并检查是否重复实现框架已有 API。保护官方生成区和不可改的依赖代码，不为通过格式审计而改坏语义。

## Unity 真编译

使用目标 Unity 版本编译本轮受影响的程序集并核对 Console/构建日志：零错误、零警告才算通过。新增语言特性必须在目标版本编译通过；警告先修可编辑源码，不靠屏蔽或降低警告级别。不可编辑第三方或生成代码的存量警告如实记录来源和未通过边界。

修复顺序：

1. 依赖来源/duplicate asmdef；先删除 fake compatibility，恢复正式 Package。
2. 缺类型/using/asmdef。
3. override 签名错误。
4. Static API owner/`using static` 可见性；例如 `changeProcedureDelay -> FrameUtility`、`mEventSystem -> FrameBaseHotFix`。
5. `registeFrameSystem<T>()` callback 对销毁阶段 null 不安全。
6. MyFramework API/包装类型能力不匹配；查目标源码，不写 wrapper/stub/extension 伪装不存在的方法。
7. `CS0051/CS0052` 可见性错误；先判断实现成员是否应收窄，而不是机械扩大 internal 类型。
8. Unity Editor API 版本不匹配。
9. 生成代码未更新或 Generator ownership 错位。
10. FrameSettings/设计分辨率/UI Root/方向不一致。
11. Prefab/Scene/UI Font/Sprite/Material 序列化字段。
12. Runtime NRE；优先检查 FrameSystem callback(null)、willDestroy/destroy 跨系统顺序。

禁止为了消掉错误新增“同名空类”而不确认原职责。

## Runtime 最小完整链

按项目实际模式执行：

```text
启动
-> 资源/Excel
-> 场景/UI
-> 开始玩法
-> 输入/攻击/受击
-> 死亡或结算
-> 重开
-> 设置/暂停/继续
-> 返回/切模式
-> 再进入
```

至少跑第二局，因为 ClassPool reset、重复事件和旧 Scene 回调通常首局不暴露。

## 上游真值 / 最终覆盖验证

如果当前 Unity 是不完整中间移植产物，至少保存一个项目级 Effective Behavior Matrix，追踪：

- CSS/配置/资源加载顺序。
- 同一字段的后写覆盖链。
- 状态刷新函数对 HUD/文本/进度的二次覆盖。
- CSS 默认 `ease`、transition/keyframe offset。
- world / HUD / overlay 的真实渲染层。
- Reduced/Auto/Disabled 等分支。
- procedural mesh/shader 的拓扑与低细节阈值。
- 存档 missing-field 与 invalid-value 的不同处理。

静态对照可标记 `SOURCE_PARITY_STATIC_PASS`，但没有 Unity 真运行时仍必须同时保留 `PLAYMODE_UNVERIFIED/PIXEL_PARITY_UNVERIFIED`。

## 基线对照

同条件：

- 分辨率/横竖屏。
- 配置。
- 存档。
- 随机种子（能固定时）。
- 输入序列。

比较：

- 状态机阶段。
- 数值和事件顺序。
- 物理轨迹。
- UI 显隐/位置/文本。
- Tween/动画。
- Audio 触发。

## 交付前哈希控制

当本轮不应修改某资产类别时，比较上一版与当前版：

- `Excels/`
- `UIPrefab/`
- 强类型 Binding Registry
- 关键 Prefab/资源

0 差异是很强的控制变量证据。

## 报告措辞

只写真实证据：

- `静态扫描通过`
- `Unity 编译通过`
- `Single/PvP/PvE 已运行`
- `WebGL 已构建并浏览器启动`

如果没做：明确写 `未执行`。不要写“应该没问题”“静态等同于运行”。


## 最终制品验证

所有审计应对**最终待压缩目录**再跑一次。完整包和增量包分别验证：

- 完整包：解压后没有上一版遗留依赖；不需要手动 Tools 菜单或首次导入生成 runtime-critical 资产。
- duplicate asmdef Assembly name = 0；无 `MyFrameworkCompatibility/FakeRuntime/Placeholder*`。
- `direct_run_required_artifacts` 全部存在于最终 staged root。
- MyFramework 1.1.12 的 `FrameSettings.asset`、`KeyFrame/Keyframe.prefab` 已存在。
- 项目 `build_settings_required_scenes` 全部在 Build Settings 启用。
- UGUI Generator Prefab/LayoutScript/LayoutRegister/GBR 集合一致；known bad builtin font refs=0。
- 若本轮未运行官方 Generator：上一版→当前版自动生成区 drift=0；建议使用 `compare_myframework_generated_regions.py`。
- LayoutScript `resetProperty()` candidates=0（除明确 allowlist）。
- embedded package + manifest overlap 已确认实际生效来源（信息项，不默认判失败）。
- 增量包：先按 DELETE 清单删除，再覆盖，结果与完整包文件集合一致（允许明确忽略生成缓存）。
- `Assets/Resources` 仅白名单。
- `Assets` 下无 LegacyRuntimeDebt/RecoveredSourceReference 运行副本。
- 移动资源 GUID 与预期一致。

## 2.6.0 显示 / 数据新增验证

新增 Display / Excel 静态审计已并入上面的交付前命令集。

Display 验证不能只看 UI Prefab：目标分辨率下至少截图对比 Home/Menu、Gameplay、Result/Fail。Gameplay 必须确认 World Camera 没有因横竖屏迁移暴露 Camera background 纯色区域；原版的 ground skirt/backdrop/floor filler 等填屏几何也属于 parity。

Excel 验证必须区分“静态结构已准备”与“官方工具已执行”。手工 bytes 能反序列化不能替代 CodeGenerator/CSVToBinary evidence。

## UI 适配的静态与画面验证

在 UI/显示任务中执行 `audit_myframework_ui_adaptation.py`，覆盖所有页面、Game 层启动/下载以及引用模板；将 PaddingAnchor、非等比与自动节点例外逐个填入项目配置。缺失/空扫描范围不能通过。实际检查设计分辨率及至少一个不同宽高比下的中文布局、点击命中、列表滚动、进度和全屏覆盖。详见 [UI 适配规则](32-ui-scale-anchor-policy.md)。

## 3.2.0 运行合同补充

3.2.0 在七类静态检查之外执行 `audit_myframework_runtime_contracts.py`；矩阵、CSV 身份/约束、证据定位及指定规则需要实际覆盖。自动区脚本 exit 2 表示未检查，不能当 0 drift。详见 [覆盖规则与命令](31-contract-audit-evidence-coverage.md)。

运行补充：旧 ID 映射/序列化输出、Procedure 再入/迟到回调、Reset 与保存同帧、部分初始化失败、UI 输入层与通道重叠、周期阈值/条件顺序。源对照、工具执行、静态合同、Unity 运行分别记录。


## 快游戏构建验证（3.2.2）

平台、包体或启动改动按 [快游戏构建与调试](33-quickgame-build-debug-release.md) 记录版本、签名、物理/分包大小、冷启动日志和真实输入。大小检查只验证本次确认的计量口径；模拟器运行不等于后台上传受理。局部任务选择能覆盖本轮风险的审计，未覆盖项明确列出。
