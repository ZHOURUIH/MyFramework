# Excel 与配置规范

## 目标

配置表应描述**稳定业务数据**，而不是序列化 C# 内部实现。

## MyFramework CSV 基本结构

当前案例常见 9 行元信息后接数据：

```text
表说明
使用端(Both/Client/Server...)
字段名...
字段类型...
字段使用端...
字段说明...
关联/约束元数据...
...
...
数据...
```

具体行含义和类型能力必须以当前 CodeGenerator/CSVToBinary 为准。

## 应清理的数据味道

通常不应直接进入业务表：

- `ClassName`
- `FieldName`
- `ManagedType`
- `System.Reflection` 用的成员路径
- `SourcePath` 迁移来源字段
- `ModeMask` 这种位掩码但业务只需要明确 bool/enum
- `PointPaths="a|b|c"` 可以拆子表的一对多字段
- Prefab 内部私有节点名与业务 ID 混在一张表

## 类型

优先使用转换器**真实支持**的强类型：

- int/long/float/string/bool。
- 支持时使用 Vector2/Vector3/枚举。
- 枚举必须保留原数值，不要仅按名字重排。

### 颜色

当前 RagdollArchers 使用的 CSVToBinary 不识别 `Color`。通用 Skill 因此规定：

- 颜色表优先 `string`。
- `RRGGBB`：Alpha 默认为 FF。
- `RRGGBBAA`：末两位 Alpha。
- **不带 `#`**。
- 运行时由一个统一 Hex 解析函数转 Color。

如果未来项目转换器明确支持 Color，可按其真实规范使用，不机械受此限制。

## 关系正规化

示例：

原来：

```text
GameplayScene: SpawnBotIDs="1|2|3", SpawnPoints="A|B|C"
```

优先改为：

```text
SpawnConfig
SpawnBot(ConfigID, BotID, PointID, ...)
```

好处：

- 外键可校验。
- 不依赖字符串 split。
- 顺序可显式字段表达。
- 不把 Prefab 路径混进玩法配置。

## 反射绑定表

如果旧项目有 `ActorBinding(ClassName, FieldName, Path, Type...)`：

1. 先导出完整记录数和对象数。
2. 生成强类型 Registry 代码。
3. Registry 对每个 Actor/资源分支逐字段赋值。
4. 对旧表每条记录验证 Registry 有等价访问链。
5. 确认后删除 ActorBinding 表及 ED/Excel 代码。

不要把反射表简单改名继续使用。

## 数据迁移等价性

至少校验：

- 表记录数（允许正规化拆表时按映射核对）。
- 主键唯一。
- 外键存在。
- enum 数值一致。
- float 精度。
- bool 语义。
- 数组/子表顺序。
- 颜色/Vector 数据转换。
- 默认值。

## 工具闭环

必须实际运行：

```text
CodeGenerator -> 生成 ED/Excel/ExcelRegister
CSVToBinary   -> 生成 Assets/GameResources/Excel/*.bytes
Unity         -> 从 bytes 加载
```

“CSV 文本看起来对”不是完成。

## 2.6.0 补充：硬编码业务数据盘点与工具真实性

进入 UI 最终收尾前，先做 Hardcoded Business Data Inventory。稳定 Catalog、ID/排序、价格、显示文案、奖励概率/数量、FTUE revision 等如果仍在 C# 中，优先迁入 MyFramework Excel；fixed-step、碰撞半径、随机调用顺序阈值等 parity-critical 算法常量默认不机械迁表。

官方工具链未真实执行时：

```text
手写 ED/Excel
离线脚本拼 bytes
复刻 Serializer 协议
```

都只能标记 `TABLE_STRUCTURE_READY / GENERATOR_UNVERIFIED`。只有目标版本官方 CodeGenerator + CSVToBinary 真执行，并由 Unity 从 bytes 加载，才算 Excel 工具链闭环。

详见 `references/25-excel-hardcode-toolchain-closure.md`。

## 3.2.0 运行合同补充

3.2.0 必须补 [表格 consumer / 稳定身份 / Runtime Ready](28-table-consumption-identity-readiness.md)。CSV/bytes 存在与业务表驱动、实际 runtime 加载分别验收。
