# Dependency / API Provenance / Direct-Run 完整性

本章来自 RagdollFactory 继续迁移中的真实失败案例。它解决三类此前容易被“静态结构通过”掩盖的问题：

1. 为了让 MyFramework 编译而自行制造同名 asmdef / stub / placeholder。
2. 凭记忆猜 MyFramework API 或 Unity Editor API，直到 Unity 真编译才发现方法不存在。
3. 把运行必需 Scene/Prefab/UI/Material 留给“首次打开后执行菜单/自动生成”，却把包称为可直接运行完整工程。

这些问题现在属于硬门禁，而不是经验建议。

---

# 1. 正式依赖优先，禁止伪兼容 Assembly

如果当前 MyFramework / 项目 asmdef 引用了：

```text
HybridCLR.Runtime
HybridCLR.Editor
Obfuz.Runtime
Obfuz.Editor
TTWebGL
QiNiu
...
```

处理顺序必须是：

1. 检查目标工程 `Packages/manifest.json`、`Packages/*/package.json`、`Assets/Plugins`。
2. 检查参考项目实际如何提供该 Assembly。
3. 使用项目真实 Package/插件来源。
4. 只有确认该模块在目标项目完全不启用、且框架源码支持裁剪时，才能按框架原生方式裁剪依赖。

**禁止**为了消除缺 Assembly 报错而新增：

```text
Assets/Plugins/MyFrameworkCompatibility/HybridCLRRuntime/HybridCLR.Runtime.asmdef
Assets/Plugins/MyFrameworkCompatibility/ObfuzRuntime/Obfuz.Runtime.asmdef
FakeRuntime.asmdef
Placeholder*.cs
同名空 namespace / 同名空 class
```

原因不是“目录不好看”，而是 Unity Assembly 名称是全局身份。真实 Package 安装后会直接触发：

```text
Assembly with name 'X' already exists
```

即使暂时没有重名，stub 也会把真实 API 缺失隐藏到更晚阶段。

---

# 2. Duplicate Assembly Name = 硬失败

最终 staged root 中：

- `Assets/**/*.asmdef`
- `Packages/**/*.asmdef`（embedded/local package 的**实际导入部分**）

解析 `name` 后，除项目显式且有证据的特殊白名单外，重复 Assembly name 必须为 0。

注意包中的 `ProjectTemplate~ / Samples~ / Documentation~ / Tests~` 等目录是模板/样例/文档来源，不应按当前工程编译 Assembly 参与 duplicate 判断。2.5.0 审计器默认跳过路径段以 `~` 结尾的目录，并支持 `asmdef_scan_exclude_path_fragments`。

这项检查不能只扫描文件名；asmdef 文件名与 `name` 可以不同。

推荐：

```bash
python scripts/audit_myframework_dependencies.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json
```

---

# 3. Embedded Package 与 manifest 的来源关系要记录，但不能误判

Unity 允许 embedded package 同时仍出现在 `Packages/manifest.json` 中；这种情况下磁盘上的 embedded package 优先。**不能把“embedded + manifest 同名”本身判成错误。**

迁移时必须明确每个关键包的实际生效来源：

| Package/Assembly | Effective source | Manifest entry | Evidence |
|---|---|---|---|
| com.zhourui.myframework | embedded/git/registry | optional | package.json + manifest |
| HybridCLR | actual installed/embedded package | optional | actual Packages path |
| Obfuz | actual installed/embedded package | optional | actual Packages path |

真正的硬错误是：

- 同一个 Assembly `name` 被多个 asmdef 物理定义。
- 为已有正式包再造一套 fake compatibility asmdef/class。
- 不知道实际生效包是哪一份，却继续按另一版本 API 写代码。

`audit_myframework_dependencies.py` 会把 embedded + manifest 作为 provenance overlap 报告，默认不因此失败。

---

# 4. MyFramework API 必须有源码证据

新增/修改任意 MyFramework 调用前，至少满足一个：

1. 在**目标工程实际安装的 MyFramework 源码**中找到声明。
2. 在用户提供的、同版本参考项目中找到实际调用。
3. 如果两者有差异，以目标工程源码为准。

禁止凭类名/旧版本记忆发明 API，例如：

```text
SceneProcedure.finish()
someSystem.changeProcedure<T>()  // 未确认 owner/static source
isEditor()                       // 未确认来自哪个 Utility
```

每次遇到 `CS0103/CS0115/CS1620` 这类框架 API 错误，不要用 wrapper/stub 绕过；先回到目标源码核对：

- 声明类。
- static / instance。
- namespace / `using static`。
- 参数 `out/ref`。
- 泛型约束。
- virtual/abstract。
- 生命周期调用者。

---

# 5. MyFramework 1.1.12 当前已验证的几个 API 合同

这些是当前快照，不代替重新读目标源码：

### `changeProcedure<T>()`

位于 `FrameUtility` 的框架 Utility 入口。需要按真实调用上下文：

```csharp
using static FrameUtility;
```

或显式限定调用。

### `isEditor()`

位于 `FrameBaseUtility`。若使用静态导入，应：

```csharp
using static FrameBaseUtility;
```

不能因为编译找不到就自己新建 `isEditor()` helper 冒充框架 API。

### `SceneProcedure`

当前实战未发现通用 `finish()` 合同。Procedure 的退出/清理由 `GameScene` 流程和对应 `onExit/exit/willDestroy/destroy` 合同驱动。若需要“完成当前流程”，必须查目标 `SceneProcedure/GameScene` 源码，而不是发明 `finish()`。

### UI Prefab 目录

MyFramework 1.1.12 当前实战的 `LayoutManager` 读取正式 UI Prefab 目录为：

```text
Assets/GameResources/UI/UIPrefab
```

不同版本必须查实际 `LayoutManager`/路径常量。生成到 `Assets/GameResources/UI/Prefab` 但代码读取 `UI/UIPrefab`，属于资源闭环失败。

---

# 6. Unity Editor API 也必须按目标 Unity 版本核对

项目使用哪个 Unity 版本，就以该版本 Editor API 为准。

例如 Unity 2022.3 中，Sprite importer 的 alignment/pivot 应通过 `TextureImporterSettings` 读写：

```csharp
TextureImporterSettings settings = new TextureImporterSettings();
importer.ReadTextureSettings(settings);
settings.spriteAlignment = ...;
settings.spritePivot = ...;
importer.SetTextureSettings(settings);
```

不要假设旧版本或其他版本存在：

```csharp
importer.spriteAlignment
```

Editor 工具同样必须真实编译；“它只在 Editor 下运行”不是跳过 API 验证的理由。

---

# 7. Runtime Critical Asset Closure

最终完整工程如果运行依赖：

- Scene
- Gameplay Prefab
- UI Prefab
- Material
- PhysicsMaterial
- ScriptableObject/Settings
- Excel bytes
- Font/Sprite binding asset

这些资源必须在**最终 ZIP/staged root 中已经真实存在**。

允许保留 Editor Builder 作为：

- 后续维护工具。
- 重建工具。
- 对比/修复工具。

但完整工程**不能以 Builder 作为首次运行前置条件**。

以下表述都不算 Direct-Run 完成：

```text
打开 Unity 后执行 Tools -> XXX -> Generate
首次导入会自动生成所有运行资源
如果 Prefab 不存在，InitializeOnLoad 会补出来
请先执行 Editor menu 再 Play
```

如果这些步骤是运行必需条件，交付状态只能是：

```text
Source/Migration package; runtime artifact closure pending
```

不能称“完整可直接运行工程”。

---

# 8. Direct-Run Gate

当用户要求“直接放进去就能运行”时，完整包必须满足：

1. ZIP 根就是 Unity Project root，至少包含 `Assets / Packages / ProjectSettings`。
2. 运行关键 Scene/Prefab/UI/Material 已在 ZIP 内。
3. `Assets/Resources/Scene/start.unity` 与目标框架固定设置已存在。
4. Build Settings 已包含启动和运行需要的 Scene；不能靠菜单补。
5. `FrameSettings.asset` 等固定资源已存在；不能靠菜单补。
6. UI Prefab 已位于目标版本 `LayoutManager` 真正读取的路径。
7. 真实 Package/Plugin 依赖已声明或随工程提供；没有 fake asmdef/stub。
8. duplicate Assembly name = 0。
9. 不需要用户删除上一版特殊目录。
10. 不需要用户执行 Tools 菜单/脚本/命令。
11. 最终 staged root 再跑全部审计。
12. Unity Compile/Play 若未实际执行，必须写 `UNVERIFIED`，不能写“可正常运行已验证”。

“打开 Unity 后等待正常 import/compile”不算手动初始化步骤；但 import 期间依赖自定义生成器去创造缺失运行资产，仍然不算 artifact closure。

---

# 9. 修编译错误的正确顺序

出现编译错误时：

```text
1. 判断是项目 API、MyFramework API、Unity API、第三方 Package 还是生成代码
2. 查目标版本源码/包
3. 查同版本参考项目
4. 修真实调用/依赖
5. 扫描同类错误模式
6. 重新 Unity Compile
```

禁止：

```text
缺 class -> 新建空同名 class
缺 assembly -> 新建同名 asmdef
缺 method -> 新建 extension 让旧调用过
override 不存在 -> 在基类伪造 virtual
Editor API 不存在 -> 用反射兜底并称已适配
```

这些做法会让迁移“看起来继续前进”，实际把错误转移到运行时或下一次包安装。

---

# 10. Project Manifest 新增证据

项目级 Manifest 至少增加：

## Dependency / Assembly Matrix

| Assembly/Package | Required by | Real source | Version/path | Duplicate? | Status |
|---|---|---|---|---|---|

## API Provenance Matrix

| Call/API | Owner/type | Source file / reference project | Target version | Verified |
|---|---|---|---|---|

## Direct-Run Artifact Matrix

| Runtime critical artifact | Required path | Exists in final ZIP | Generated only? | Build/runtime reference | Status |
|---|---|---|---|---|---|

只有这三张表闭环，才能把“结构通过”推进为“完整工程交付”。

---

# 11. 2.5.0：FullInstall Runtime Template / Build Settings / Static API 闭环

## KeyFrame Runtime Asset

MyFramework 1.1.12 `FrameDefine.KEY_FRAME_FILE` 为 `KeyFrame/Keyframe.prefab`，`KeyFrameManager` 会在运行时从 GameResources 加载它。因此 FullInstall 至少必须包含：

```text
Assets/GameResources/KeyFrame/Keyframe.prefab
```

完整工程不能只拼出 `Assets / Packages / ProjectSettings` 三个目录外形；当原始输入只有 Assets 时，优先以同版本官方 `ProjectTemplate~` 作为工程骨架和 runtime template 资产来源。

## Runtime Scene 必须预先进入 Build Settings

`start.unity` 第一位只是启动合同，不代表业务 Scene 已闭环。任何运行时由 SceneSystem/SceneManager 加载的 Scene 都必须在最终 `ProjectSettings/EditorBuildSettings.asset` 中启用。

通过项目配置：

```json
"build_settings_required_scenes": [
  "Assets/GameResources/XXX/Scene/XXX.unity"
]
```

由 `audit_myframework_structure.py --config ...` 检查。用户不应再手工 Add Open Scenes。

## Static API Visibility

API Provenance Matrix 新增 Access Mode：

| API | Owner | Access Mode | Calling file | Verified |
|---|---|---|---|---|
| changeProcedureDelay | FrameUtility | using static / qualified | XXXSceneLoading.cs | yes/no |
| mEventSystem | FrameBaseHotFix | using static / inherited | UIXXX.cs | yes/no |
| mLayoutManager | FrameBase **或** FrameBaseHotFix | 取决于 AOT/HotFix 调用层 | XXX.cs | yes/no |

仅确认 API 在源码存在，不能防止调用文件因缺少 `using static` 产生 `CS0103`。同名静态成员在 AOT/HotFix 有多个真实 owner 时，必须记录 owner 集合并按调用层验证，不能强制所有文件使用同一个 owner。

# 12. 2.6.0：API Capability / Accessibility Gate

API Provenance 不仅检查“符号存在”，还要检查**当前对象层级是否真的拥有该能力**。包装类型不能因为内部持有某个 `myUGUIObject` 就被假设拥有它的全部 Transformable 方法。

Unity 编译出现：

```text
CS0051 / CS0052 inconsistent accessibility
```

时，优先问：

- public/protected 成员是否真的需要暴露？
- 参数/字段类型是否只是 internal 实现细节？

若只是内部 cache，应收窄成员到 private/internal 合同，而不是把实现类型扩大成 public。

这类改动要进入 API Provenance/Compile 记录，不能只当“随手修编译”。
