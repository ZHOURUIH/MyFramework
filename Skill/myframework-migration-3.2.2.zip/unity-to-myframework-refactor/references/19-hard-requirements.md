# MyFramework 硬要求总表（必须逐项满足）

> 本文件是迁移任务的**一级门禁**。它不是“建议”“最佳实践”或可选风格，而是本 Skill 对 MyFramework 项目迁移的硬约束清单。
>
> 当前核对版本：`com.zhourui.myframework 1.1.12`，fingerprint `265d8413b933ba07df40bdbb5781b498497dbc70`。若目标工程版本/fingerprint 不同，必须先重读目标 `PackageCache/Packages` 源码，再更新项目级 Profile；**不得直接套本文件中的 API 签名**。

## 0. 规则来源优先级

发生冲突时按以下顺序判定：

1. 用户明确的任务范围和仓库采用的规范。
2. **目标工程实际安装的 MyFramework 源码与 Analyzer 编译结果**，用于确认 API、生命周期和序列化事实。
3. 用户提供且使用同版本框架的参考项目，以及本 Skill 的版本 Profile/模块合同。
4. 通用 Unity/C# 习惯。

任务要求不能使不存在的 API 成为可用 API；事实冲突应查源码并调整实现。局部修复仅执行与改动有关的规则和回归，不把所有模块全量重构作为前置。编码风格默认只适用于采用该规范的手写业务范围，不扩散到框架、插件或生成区。

---

# A. 启动、工程入口与热更链

## H-A01：只允许一套 MyFramework 启动链

目标工程必须只有一条框架启动链：

```text
Unity Start Scene
 -> GameEntry : GameEntryBase
 -> Game : GameFramework
 -> AOT LaunchScene : GameScene
 -> LaunchSceneProcedure
 -> HybridCLRSystem.launchHotFix(...)（启用热更时）
 -> GameHotFix : GameHotFixBase<GameHotFix>
 -> getStartGameSceneType()
 -> HotFix GameScene
```

禁止：

- 再建 `Bootstrap/Root/App/GameManager` 第二套启动体系。
- 让玩法 Main Scene 本身充当框架启动 Scene。
- 在普通 MonoBehaviour 中手动 new/初始化 GameHotFix。
- 直接跳过 AOT LaunchScene，却保留一半热更/资源更新结构。

如果项目明确禁用热更，仍必须保持 GameEntry/GameFramework 的唯一入口；是否保留简化 LaunchScene 由当前参考项目和目标工程发布链决定，不能自行发明第二套流程。

## H-A02：GameEntry.Awake 必须先调用 base.Awake()

标准形态：

```csharp
public class GameEntry : GameEntryBase
{
    public override void Awake()
    {
        base.Awake();
        Game framework = new();
        framework.init();
        setFrameworkAOT(framework);
    }
}
```

或参考项目已有 `Game.startGame()` 薄封装，但本质必须相同。

`base.Awake()` 负责 MyFramework 基础环境、屏幕、物理模拟、主线程、异常处理等初始化；不能省略、后置或复制实现。

## H-A03：Game.init 的框架回调注册必须在 base.init() 之前

参考结构：

```csharp
public override void init()
{
    mOnInitFrameSystem += gameInitFrameSystem;
    mOnRegisteStuff += gameRegiste;
    base.init();
    mGameSceneManager.enterScene<LaunchScene>();
}
```

禁止在 `base.init()` 之后才注册 `mOnInitFrameSystem/mOnRegisteStuff`，否则系统/注册时机已经错过。

## H-A04：1.1.12 的启动场景路径和根节点是框架硬合同

当前 1.1.12 源码：

```csharp
public const string START_SCENE = P_RESOURCES_SCENE_PATH + "start.unity";
```

其中 `P_RESOURCES_SCENE_PATH = Assets/Resources/Scene/`，因此标准启动场景必须是：

```text
Assets/Resources/Scene/start.unity
```

并且 MyFramework Editor 初始化逻辑会：

- 查找该精确路径；缺失直接报 `MISSING_START_SCENE`。
- 查找启动场景根节点 `GameEntry`。
- 自动把项目的 `GameEntry` 脚本挂到该根节点。
- 把 `START_SCENE` 加到 Build Settings **第一位并启用**。

所以不能把启动场景随意命名成 `Main.unity/Boot.unity` 并声称符合 MyFramework；如果目标版本源码改变了 START_SCENE，再以目标版本源码为准。

## H-A05：Start Scene 是最小启动场景，不承载业务

Start Scene 只保留框架启动必需对象/配置。不得把：

- 玩法 HUD
- Gameplay Root
- 业务 Manager
- 关卡对象
- 运行时动态 UI 构造器

塞进启动 Scene 来绕过 MyFramework Scene 生命周期。

若用户提供参考工程的 Start Scene，则必须对照其 GameEntry、Camera/EventSystem、FrameSettings/启动参数等真实结构，而不是凭空手写一个“能 Play”的 Main.unity。

---

# B. GameHotFix、注册器与 GBR

## H-B01：GameHotFix 必须继承 `GameHotFixBase<GameHotFix>`

必须按当前版本实际抽象/virtual 合同实现：

- `registerAllTable()`：Excel/Table 注册。
- `registerAll()`：Layout、Scene、State、业务 Registry 等。
- `initFrameSystem()`：应用层 FrameSystem 注册。
- `getStartGameSceneType()`：HotFix 逻辑首场景。
- 需要覆盖 `onPreInit/onPostInit` 时必须遵守 base 调用合同。

不得新增另一个“HotFixRoot”替代这些入口。

## H-B02：FrameSystem 只能通过框架 `registeFrameSystem<T>()` 注册

应用层系统统一在 `GameHotFix.initFrameSystem()` 注册，并把引用赋给 GBR：

```csharp
registeFrameSystem<ClientSystem>(com => { mClientSystem = com; });
```

需要 init/update/destroy 顺序时使用该 API 的 order 参数，而不是另外造一个 RuntimeSystem 手工每帧依次调用全部 System。

禁止：

- `new SomeSystem()` 后自己调用 `init/update/destroy`。
- 另建 `SystemRunner` / `RuntimeSystem` 接管整个 FrameSystem 调度。
- 用 MonoBehaviour.Update 再重复调一遍 FrameSystem。

## H-B03：GBR 只保存框架级引用，不保存业务运行态

GBR 可以保存：

- FrameSystem 引用。
- Excel 表引用（Generator 自动区）。
- SceneInstance 引用。
- LayoutScript 引用（Generator 自动区）。

GBR 禁止保存：

- 当前血量、钱、分数、关卡阶段。
- `mReady/mPaused/mCurrentMode` 等运行时状态。
- 临时列表、对象池运行实例。

业务状态属于对应 System / Game / Mode / Data owner。

## H-B04：Generator 自动区不能手写伪造

GBR 的：

```text
// auto generate Excel start/end
// auto generate LayoutScript start/end
```

以及 LayoutRegister/ExcelRegister 的自动段只能由官方生成器真实写入。

无法运行 Unity 时可以保留**明确命名的迁移 fallback**，但必须：

- 位于非自动区。
- 单一调用点。
- 在 Manifest 中记录删除条件。
- 不得声称 Generator 已完成。

---

## H-B05：`registeFrameSystem<T>()` callback 必须接受销毁阶段的 `null`

当前 1.1.12 框架销毁/解绑阶段可能再次调用应用层 FrameSystem 注册 callback，并用 `null` 清理 GBR 引用。

禁止：

```csharp
registeFrameSystem<FooSystem>(com =>
{
    mFooSystem = com;
    com.setInitOrder(10);
});
```

必须保证任何 `com.xxx` 解引用都在非空保护内：

```csharp
registeFrameSystem<FooSystem>(com =>
{
    mFooSystem = com;
    if (com != null)
    {
        com.setInitOrder(10);
        com.setUpdateOrder(10);
        com.setDestroyOrder(20);
    }
});
```

审计项：`frame_system_callback_null_unsafe_candidates`。


# C. FrameSystem / ComponentOwner 生命周期硬合同

## H-C01：任何 override 的框架生命周期方法必须调用匹配的 base 方法

MyFramework Analyzer 会以 `BASE001` 强制部分 override。迁移规则更严格：凡覆盖框架生命周期，默认都必须调用匹配的 `base.xxx(...)`；只有目标版本源码明确证明无需/禁止时才能例外并记录。

典型包括：

```text
init
lateInit
update
fixedUpdate
lateUpdate
willDestroy
destroy
resetProperty
onCreate
onGameState
onHide
```

**源码已证明的抽象合同例外：** 当前 MyFramework 1.1.12 中 `LayoutScript.assignWindow()` 与 `WindowObjectBase.assignWindowInternal()` 为 `abstract`，派生类实现时不存在可调用的对应 `base`。这两类方法不得为了通过审计伪造 `base.assignWindow()` / `base.assignWindowInternal()`。若目标版本改为非 abstract，以目标版本源码为准。

正确：

```csharp
public override void update(float elapsedTime)
{
    base.update(elapsedTime);
    ...
}
```

```csharp
public override void lateUpdate(float elapsedTime)
{
    base.lateUpdate(elapsedTime);
    ...
}
```

**提前 return 也不能绕过 base 调用。** 推荐 base 放在方法最前；若当前基类语义要求后置，必须从源码证明并在代码中保持参考项目写法。

## H-C02：FrameSystem.update 不得用 `return` 跳过 base.update

错误：

```csharp
public override void update(float elapsedTime)
{
    if (!mRunning)
    {
        return;
    }
    ...
}
```

正确：

```csharp
public override void update(float elapsedTime)
{
    base.update(elapsedTime);
    if (!mRunning)
    {
        return;
    }
    ...
}
```

这不仅是 Analyzer 要求；`FrameSystem -> ComponentOwner` 的 base update/lateUpdate/fixedUpdate 会驱动其 GameComponent。

## H-C03：System 顺序使用 `registeFrameSystem` order，不使用手工 fan-out

当前 HotFix Framework 会按：

- `mInitOrder`
- `mUpdateOrder`
- `mDestroyOrder`

排序。

跨 System 顺序依赖必须通过注册 order 或事件/显式命令表达。不要用一个 God RuntimeSystem 手动：

```text
ui.update -> game.update -> render.update -> audio.update
```

来绕过框架调度。

## H-C04：系统初始化阶段按框架时序放置

当前 FrameSystem 支持：

```text
preInitAsync -> initAsync -> init -> lateInit
```

依赖其他 System 已完成 `init()` 的逻辑放 `lateInit()`，不要在构造函数/字段初始化中访问尚未注册完成的 GBR System。

## H-C05：ApplicationFocus/ApplicationQuit 使用 GameFrameworkHotFix 注册接口

需要应用焦点/退出事件的 System，应优先使用：

```text
registeOnApplicationFocus / unregisteOnApplicationFocus
registeOnApplicationQuit / unregisteOnApplicationQuit
```

并与 owner 生命周期成对解除，不再新增 MonoBehaviour 只为收这两个 Unity 消息。

---

## H-C06：跨 System/Manager 解绑优先 `willDestroy()`；`destroy()` 不得假设其他系统仍存活

MyFramework 1.1.12 会先对全部 FrameSystem 调 `willDestroy()`，随后按 destroy order 真正执行 `destroy()`。因此 CameraManager、ResourceManager、EventSystem 等跨 System 依赖如果在项目 System 的 `destroy()` 时已经被销毁/置空，会产生退出 NRE。

硬规则：

- 依赖其他 System/Manager 仍存活才能完成的归还/解绑放 `willDestroy()`。
- `destroy()` 主要释放自身拥有对象；跨 System fallback 必须 null-safe、幂等。
- 不得只凭项目自己的 `destroyOrder` 猜框架内置 System 一定还活着；必须查目标版本源码。
- Manifest 必须记录 FrameSystem Dependency/Destroy Matrix。

审计项：`cross_system_destroy_dependency_candidates`；确有版本源码证明的例外写入 `destroy_dependency_allowlist`。


# D. API 签名与名字冲突硬规则

## H-D01：调用 MyFramework API 前必须以目标源码签名为准

不得凭“之前版本记忆”写接口。迁移前必须定位真实定义，包括：

- 泛型约束。
- `out/ref`。
- 返回值。
- static / instance。
- 所属基类。
- HotFix / AOT 同名 API 差异。

## H-D02：继承类存在同名实例方法时，不允许依赖 `using static` 做重载解析

当前 1.1.12 存在典型冲突：

```csharp
ComponentOwner.getOrAddComponent<T>()
ComponentOwner.getOrAddComponent<T>(out T com)
FrameBaseUtility.getOrAddComponent<T>(GameObject go)
FrameBaseUtility.getOrAddComponent<T>(GameObject go, out T com)
```

在 `FrameSystem : ComponentOwner` 中写：

```csharp
getOrAddComponent<Camera>(go);
```

可能优先匹配继承的实例成员并产生 `CS1620` 等错误。

**硬规则：跨对象操作 Unity Component 时显式限定 static utility：**

```csharp
FrameBaseUtility.getOrAddComponent<Camera>(go);
```

或按目标源码使用明确 `out` 重载。不要靠 `using static FrameBaseUtility` 猜解析结果。

同类规则适用于任何“基类实例方法”和“静态 Utility”同名的 API。

## H-D03：出现 CS1620/CS1501/CS0121 时先查真实签名，不用强行补 out/ref

编译器说“必须使用 out”不等于业务本来就应该用 out。先确定：

1. 当前实际绑定到了哪个同名方法。
2. 是否因继承实例方法遮蔽 static helper。
3. 是否应该写完全限定名。

禁止为了消除错误盲目给参数加 `out`，改变调用语义。

---

## H-D04：Static API 必须同时验证“声明来源”和“当前文件可见方式”

确认 API 在框架源码存在还不够。当前调用文件必须通过以下之一真实可见：

- fully-qualified owner。
- 正确继承关系。
- 正确 `using static`。

MyFramework 1.1.12 当前实战：

```text
changeProcedure<T>() / changeProcedureDelay<T>() -> FrameUtility
isEditor()                                       -> FrameBaseUtility
mEventSystem / mGameFrameworkHotFix              -> FrameBaseHotFix
mGameSceneManager / mLayoutManager / mResourceManager
  -> AOT 层可来自 FrameBase，HotFix 层可来自 FrameBaseHotFix
```

**同一个静态全局成员可能在 AOT 与 HotFix 各有真实 owner。** 审计规则允许记录多个 source-confirmed owners；必须按调用文件所在层确认实际 `using static`/qualified owner，禁止因为 HotFix 常用 `FrameBaseHotFix` 就把 AOT `using static FrameBase;` 误判为缺失。

例如 `SceneProcedure` 中直接调用 `changeProcedureDelay<T>()`，必须确认有 `using static FrameUtility;` 或显式限定；LayoutScript 使用 `mEventSystem/mGameFrameworkHotFix` 时同理。

出现 `CS0103` 时先修 owner/import，不新造 helper。审计项：`static_api_visibility_candidates`。


# E. Scene / SceneInstance / GameScene / SceneProcedure

## H-E01：必须区分 Unity Scene、SceneInstance、GameScene

- Unity Scene：资源容器。
- `SceneInstance`：Unity Scene/资源场景框架绑定。
- `GameScene/SceneProcedure`：逻辑流程状态机。

不得因为类名带 Scene 就随便继承任意一种。

## H-E02：逻辑 GameScene 必须显式声明开始/退出 Procedure

当前参考结构：

```csharp
public class XXXScene : GameScene
{
    public override void assignStartExitProcedure()
    {
        mStartProcedure = typeof(XXXSceneStart);
        mExitProcedure = typeof(XXXSceneExit);
    }

    public override void createSceneProcedure()
    {
        addProcedure<XXXSceneStart>();
        ...
        addProcedure<XXXSceneExit>();
    }
}
```

`SceneProcedure.init/exit/willDestroy/destroy` 覆盖时遵守 base 调用合同。

## H-E03：SceneInstance 注册统一走 SceneRegister / SceneSystem

不能由 UI/Gameplay 用路径临时 load 并自己保存 Scene singleton。

参考：

```csharp
mSceneSystem.registeScene(typeof(T), path, scene => ...);
```

场景引用再由 GBR/明确 owner 保存。

## H-E04：Scene 不做万能 Service Locator

禁止长期保留：

```text
getSceneComponent(path)
find("A/B/C")
getObjectByString(...)
```

作为 Gameplay/UI 主依赖入口。

---

## H-E05：进入、失败、退出和重开必须分别闭环

回调可同步完成，也可在退出后返回；每次进入要重置本次状态，并按当前框架合同延迟/阶段化切换。不能只依赖对象池 reset，不用第二次 additive load 掩盖已存在 Scene 的坏绑定。表/数据/资源/Scene Ready 后才允许有效玩法；失败要清理部分初始化并留下明确结果，不能写坏存档或无限等待。

Reset 与正常退出的保存策略必须分开。静态 Scene 是否保留取决于可变状态及源生命周期，不机械要求“必须卸载”或“永远复用”。详见 [GameScene / 重开 / 状态寿命](29-scene-restart-save-lifetimes.md)。

# F. UI / Prefab / LayoutScript / Generator

## H-F01：业务 UI 必须是 Prefab + LayoutScript，不在运行时创建完整 UI 树

禁止在 HotFix UI 中用：

```text
new GameObject
AddComponent<Image/Text/Button/...>
```

构造页面。

运行时动态内容必须基于已存在模板/WindowObject/WindowStructPool，不是动态造整个页面。

## H-F02：一个独立页面一个 LayoutScript

Settings / Shop / Goals / Pause 等独立显示关闭页面不能长期塞进一个通用 Modal + 字符串 action router。

可复用行/卡片用：

- `WindowObjectUGUI`
- `WindowStructPoolBase/WindowStructPool<T>`
- 项目参考代码中的等价机制。

## H-F03：UGUIGenerator 必须真实运行才算完成

1. Generator 挂在 Canvas 根。
2. Prefab Mode 中配置真实 MemberData。
3. 必要子块使用 UGUISubGenerator。
4. 点击官方 Generator。
5. 自动更新 LayoutScript/GBR/LayoutRegister 对应自动区。
6. 编译通过。

手写相同字段/assignWindow 不算 Generator 完成。

## H-F04：UI 节点不使用普通 UGUI Anchor 作为项目布局规范

所有正式 UI Prefab、引用模板与 Game 层启动/下载 UI 按 [UI 适配规则](32-ui-scale-anchor-policy.md) 处理：

- 普通 authored 节点只添加 HotFix `ScaleAnchor` 或 Game `ResScaleAnchor`，不能互换层级，默认 `mKeepAspect = true`。`mRemoveUGUIAnchor = true` 只属于实际存在该字段的 HotFix 类型；当前 Game Res 类型由 `UnityUtility.applyAnchor` 处理 anchors 中心化，不添加虚构字段。
- 有效等比还需检查 `mAspectBase`：目标版本的默认 `ASPECT_BASE.AUTO` 保持两轴一致，而 `NONE` 即使配合 `mKeepAspect = true` 也会沿独立轴缩放，必须计入非等比例外。枚举值按目标源码核实，不能仅检布尔值。
- authored 节点 `anchorMin = anchorMax = (0.5, 0.5)`，转换时保持设计分辨率下的实际几何；pivot 不是 anchor，保留合法的左/右对齐、动态文本等用途，不能全量强制居中。原生 UGUI anchors 仅允许有明确生成来源的自动节点例外。
- `PaddingAnchor` / `ResPaddingAnchor` 只在极少数有真实父节点边界停靠用途的节点使用；每个用途须精确记录。不能用于普通父子对齐、文本列、scroll/viewport/content、进度 fill 或复制原生 stretch anchors。
- `mKeepAspect = false` 仅给布局全屏 root、背景/遮罩及无可见图形的全屏/分屏输入覆盖区域等实际需要两轴覆盖的特定节点，每个例外写明用途。
- 列表与行排列使用 autoGrid/autoGridVertical/WindowStructPoolBase 已有封装；真实名称和签名按目标版本源码核实。
- 动态文本自动宽度变化后，保留其合法 pivot 或通过框架对齐/排列定位兄弟节点；`applyPreferredWidth` 不代表旁边的数值自动重新排列。Name/Value、Score/Season 等组合必须验证不同文字和数字长度，禁止以 PaddingAnchor 处理普通列对齐。

基准尺寸来自项目 Display Profile / FrameSettings / 原版证据。不能从参考项目默认值推断，也不能用业务逐路径 setPosition/setScale/anchoredPosition 补丁弥补 Prefab 配置。ScaleAnchor 当前实现修改每个节点 rect/位置/字体而非父节点 transform.localScale，所以父子挂载并不等于重复缩放；按目标版本源码核实。

## H-F05：按钮优先框架控件；禁止使用已明确禁用的控件

- Image + Text 常规按钮优先 `LegendButton`。
- 需要 down/up/hold 时必须选择能保留真实事件语义的 MyFramework 控件接口。
- 若项目明确禁止 `myUGUIButton`，不得生成/使用它。
- Drag/Scroll/Input/Checkbox/Slider 等按当前 Generator 类型能力选择。

## H-F06：UI 不直接修改业务数据

UI 只：

- 调业务 System 命令。
- 查询只读数据。
- 监听事件。

禁止：

```csharp
mGame.mSaveData.xxx = ...;
```

或绕过 System 直接执行领域 mutation。

## H-F07：UI 必须第二次 show/hide 验证

只验证首次显示不够。每个目标 Layout 必须至少：

```text
show -> interact -> hide -> show -> interact
```

确认 Pool、event、command、reset、scroll、mask、临时状态均正确。

---

## H-F08：禁止多页面 UI God FrameSystem 作为终态

默认 UI 依赖方向：

```text
SceneProcedure / 业务流程 -> LT.LOAD/HIDE/UNLOAD
LayoutScript -> 当前页面交互/临时表现 -> Business System
Business System -> 业务状态/存档/Gameplay -> Event -> UI
```

禁止 `XXXUISystem : FrameSystem` 同时承担多个页面的 LOAD/HIDE/UNLOAD、按钮路由、Popup 状态机、存档计时、输入、页面 refresh。真正全局 Toast/Loading/Guide 服务可例外，但必须职责单一并进入 `ui_frame_system_allowlist`。

## H-F09：UGUIGenerator 必须四层合同一致，禁止手工 fallback 注册

每个正式 Layout 必须同时闭环：

1. Prefab 上真实 root `UGUIGenerator` / MemberData。
2. LayoutScript 的 member/constructor/assignWindow/init 自动区和 `generate from` 来源。
3. `LayoutRegisterHotFix` auto-generate 注册集合。
4. GBR LayoutScript auto-generate 引用集合。

禁止 `LayoutMigrationBootstrap`、运行时 fallback `registeLayout`、`GetLoadedLayout<T>()` 等长期桥接。离线脚本只能做审计/预演，不能冒充官方 Unity UGUIGenerator 已执行。

静态合同通过仍只能证明 STRUCTURE；没有 Unity Generator 执行证据时必须写 `GENERATOR_UNVERIFIED`。

## H-F10：UI Font/Sprite/Material 序列化引用属于硬合同

Prefab 有 Text 字符串不代表文字能显示。必须检查 Font/TMP FontAsset/Sprite/Material 引用有效且非错误 builtin resource。

CrushYard 实战已确认以下默认 Arial 引用错误并会导致全部 UGUI Text 不显示：

```text
m_Font: {fileID: 12800000, guid: 0000000000000000f000000000000000, type: 0}
```

Unity 2022.3 常见默认 Arial 正确内置引用为：

```text
m_Font: {fileID: 10102, guid: 0000000000000000e000000000000000, type: 0}
```

自定义字体/材质仍以目标项目真实资产 GUID 和 Unity Import 结果为准。


## H-F11：Display Profile 必须先于 UI Layout 冻结

迁移 UI 前必须从原版/目标平台证据明确：

- Orientation。
- Reference viewport/aspect。
- MyFramework 设计分辨率。
- Safe Area 策略。

禁止从参考项目或框架模板直接继承 `1920x1080` 等值。

采用固定设计分辨率时，以下必须一致：

```text
FrameSettings.UISizeStandalone / UISizeMobile
start.unity 的 UGUIRoot RectTransform
Runtime Layout Prefab root RectTransform
全屏 Dim/Guide/Tutorial 等覆盖节点
```

横竖屏迁移不能只交换宽高；必须重新验证 Root 直系子节点边界、ScaleAnchor 默认等比、PaddingAnchor 的少量真实边界例外与 Safe Area。

## H-F12：Generator 代码所有权必须真实，marker 不能掩盖手工绑定

仅有 `// auto generate ...` marker 不算闭环。正式 Layout 中：

- `newObject(...)` 节点绑定默认属于 assignWindow 自动区。
- 成员 WindowObject 的 `.assignWindow(...)` 默认属于 assignWindow 自动区。
- Generator-owned `new(this)` 默认属于 constructor 自动区。
- root `UGUIGenerator.mParentType` 必须与正式 Layout 基类一致；当前 1.1.12 普通 Layout 默认 `LayoutScript`。
- `UGUISubGenerator.mParentType` 不得为空，必须与真实子窗基类一致。

若业务 callback 需要 index/上下文参数，可以在 MemberData 关闭 Generator 自动 click，只让 Generator 生成强类型成员，再在业务区注册参数化 callback；禁止 Generator 与业务区同时注册同一点击。

静态审计发现 `manual_generator_binding_candidates` 视为 UI 迁移未闭环。

## H-F13：LayoutScript/UI 页面脚本不得实现 `resetProperty()`

项目 UI 页面脚本不把 `resetProperty()` 当成对象池生命周期。默认要求：

- `LayoutScript` 中 `resetProperty()` candidates = 0。
- 页面每次显示的临时状态在 `onGameState()` 初始化。
- 隐藏时需要恢复的动画、pause、selection、临时数据在 `onHide()` 收口。
- 本次页面参数由 `setData()/setXXX()` 等显式入口写入。
- 只有目标版本框架源码或项目正式规范明确要求时才允许例外，并加入 `layout_reset_property_allowlist`。

这条规则**不适用于** `ClassObject`、`WindowRecyclableUGUI`、WindowStruct item 等真实池对象；这些对象仍按自身 reset 合同执行。

## H-F14：输入层、视觉状态、业务刷新和动画通道不得混为一谈

为每个页面明确 World/HUD/当前面板/业务入口的输入策略；系统事件与玩家命令分别判断。不能只挡世界遗漏 HUD，也不能根据窗口名字一律 modal 或强制变灰。刷新消费源业务时钟，独立动画通道不相互覆盖，TweenPlaying 与 hold/visible 分开。

新增静态节点及绑定必须走正式 Generator；未执行工具不能手改自动区补齐。详见 [周期/UI/输入/通道合同](30-cadence-ui-input-animation.md)。

# G. 资源 / GameResources / Atlas / Audio

## H-G01：运行时游戏资源统一进入 GameResources / 正式资源链；业务不得散落原生加载

HotFix 业务不得散落：

```text
Resources.Load
AssetDatabase.LoadAssetAtPath（Editor 工具除外）
File.ReadAllBytes + 自己 Instantiate 游戏资产
```

真正动态加载优先 ResourceManager；高频 GameObject 结合 PrefabPoolManager。稳定 Scene/Prefab serialized reference 可以直接保留，不要求改成路径加载。

## H-G02：`Assets/Resources` 必须白名单化

`Assets/Resources` 不是业务资源目录，也不是迁移兼容仓库。

MyFramework 1.1.12 由源码已确认的框架固定项至少包括：

```text
Assets/Resources/Scene/start.unity
Assets/Resources/Settings/FrameSettings.asset
```

其他条目只有满足以下条件才能保留：

1. 目标工程实际框架/第三方包源码证明使用固定 `Resources.Load` 合同；
2. 在项目 `resources_allowlist` 中显式列出；
3. Manifest 记录保留原因和证据。

最终阶段 `Unexpected Resources assets = 0`。不能因为资源目前“能被 Resources.Load 找到”就保留。

## H-G03：禁止 Resources / Legacy 兼容仓库作为终态

以下均属于迁移债务，最终运行 Assets 中必须清理：

- Egg/Pet/Bot/Weapon/Level 等业务资源整批留在 Resources。
- `LegacyRuntimeDebt`。
- `RecoveredSourceReference`。
- `CompatibilityRuntime` / `LegacyRuntime`。
- 旧资源树完整复制一份，新代码再套 MyFramework。

原工程源码、迁移说明或合法的反编译参考可作为迁移证据，但备份/参考材料应放在运行 Assets 外的 Docs/MigrationReference，或明确 Editor-only。

## H-G04：资源移动必须保留 `.meta` GUID

资源移动必须连同 `.meta`；每轮涉及移动时记录 old path/new path/GUID。

至少检查：

- GUID unchanged。
- duplicate GUID = 0。
- Scene/Prefab/Asset 对 moved GUID 的引用未异常丢失。
- 删除资源 GUID 无非预期运行 YAML 残留。
- 原路径没有旧副本。

禁止通过重新生成 `.meta` 来“修路径”。

## H-G05：GameResources 不等于字符串路径加载

静态 UI Sprite、Material、Prefab、FontAsset 等若原本由 Scene/Prefab 字段直接序列化引用，可以保持强引用。把资源移动到 GameResources 后，不要为了“框架化”强制改为字符串路径 + ResourceManager。

ResourceManager 用于真实动态加载职责；序列化强引用与框架资源目录不冲突。

## H-G06：动态 GameObject 优先 PrefabPoolManager

高频生成物必须评估框架 Pool。若不使用，需要有明确理由（一次性、生命周期、行为不适配）。

## H-G07：静态 UI Sprite 可以直接序列化引用；不要为了“框架化”强造 Atlas

只有运行时需要按名字/路径换图、当前项目已有 Atlas 体系、或资源规模要求时才接 `AtlasManager`。

## H-G08：音频优先 AudioManager/AudioHelper/AT

禁止业务代码临时 `AddComponent<AudioSource>` 形成第二套音频管理。

必须保留：BGM 跨场景、SFX 叠加、Pause、loop stop、分类音量等原语义。

## H-G09：项目 Shader 不使用 `_Mobile` 变体作为迁移产物

当前项目规范中 Shader 资源不得生成/保留 `_Mobile` 变体来作为默认兼容方案；使用项目已验证的正常 Shader 资源。若原项目确实依赖平台专用 Shader，必须单独记录行为/性能依据，而不是按文件名习惯制造 `_Mobile` 版本。

## H-G10：完整包与增量包的删除语义必须分开

- 完整包：解压后自身就是目标工程，不依赖用户先删除上一版。
- 增量包：若发生移动/删除，必须附明确 `DELETE_<FROM>_TO_<TO>.txt`，并验证“先删再覆盖”后的文件集合与完整包等价。

最终 staged root 必须重新运行 Structure/Migration/Resource 审计。

---

# H. ClassObject / Pool / reset / owner

## H-H01：ClassObject 运行实例必须走 CLASS/UN_CLASS

继承 `ClassObject` 的可回收运行对象：

- owner 使用 `CLASS<T>()` 获取。
- owner 使用 `UN_CLASS` 回收。
- 禁止 `new T()` 创建运行实例（工具/测试特殊情形必须白名单）。

## H-H02：ClassObject 子类必须完整 resetProperty，并调用 base.resetProperty()

所有可变字段必须恢复默认值，包括引用、callback、collection、timer、ID、状态。

MyFramework Analyzer/单测体系对 reset/base 合同敏感；不能只清部分字段。

## H-H03：owner 唯一

索引 System、查询 System、UI 不得回收不属于自己的对象。

双层对象：

```text
ClassObject wrapper <-> Unity GameObject/Prefab instance
```

必须写清两个 owner 与销毁顺序。

## H-H04：遍历期间可能自注销时必须快照

`foreach` 的目标集合若可能在 update/destroy/event 内被修改，使用 `LIST<T>()`/对应 Scope 创建快照再遍历。

---

# I. Event / Command / Async / Tween

## H-I01：EventSystem 监听与反监听必须成对

`listenEvent(..., this)` 对应 owner 生命周期中的 `unlistenEvent(this)`。

必须验证第二局/第二次 show 不会重复回调。

## H-I02：事件类型使用强类型 enum/class，不使用字符串 Router

事件 enum 是**符号常量**，不能在“属性改 getter”批量操作中被改成方法调用。

例如：

```csharp
CrushYardEventType.Yard
```

绝不能被错误替换成：

```csharp
CrushYardEventType.getYard()
```

**任何全局 Property→getter 重构必须使用语义范围内重命名，禁止简单文本替换。** 重构后必须编译或至少扫描 enum/static const 的调用形态。

## H-I03：Command/Delay/Tween 生命周期必须可取消

owner destroy/hide 后不能继续回调到旧对象。

Tween 迁移必须保持原曲线、loop、Yoyo、scaled/unscaled、break 完成语义。

---

## H-I04：先核实基类自动清理，再补缺失的 owner 合同

当前版本若由 `LayoutScript.onHide()` 等基类中断命令/注销 listener，按真实 owner 和 base 调用确认已覆盖，不添加冗余路由或第二套注销框架。外部 Tween、子 owner、异步工作不能因为存在基类清理就自动视为安全。

# J. Gameplay / Input / Physics

## H-J01：玩法逻辑不直接依赖 LayoutScript

依赖方向：

```text
UI -> Business System -> Gameplay/Mode -> Scene/Resource
```

Gameplay 通过事件/数据通知 UI，不直接操作 `mUIxxx`。

## H-J02：输入优先 MyFramework Input/Touch；Unity 消息只保留最薄 Bridge

需要 `OnCollision/OnTrigger/OnJointBreak` 等 Unity 消息时可以有 MonoBehaviour Bridge，但 Bridge：

- 只持 owner/ID。
- 只转发。
- 不保存玩法状态。
- 不承担更新循环。

## H-J03：不要为“去 MonoBehaviour”伪造 override

基类没有 virtual 的方法不能写 override。迁移前必须查目标基类源码。

## H-J04：Binding 与 Bridge 不能承载玩法状态

- Binding：只保存 Scene/Prefab 稳定引用和必要静态参数。
- Bridge：只接收框架无法直接获得的 Unity callback 并转发 owner/ID/参数。
- Runtime owner：FrameSystem/SceneInstance/GameScene/ClassObject/Gameplay 对象保存玩法状态。

如果所谓 Binding/Bridge 出现 AI、业务 timer、存档、Update 玩法循环、资源加载或对象所有权，它只是旧 MonoBehaviour 换名，必须继续迁移。

---

# J2. MyFramework-first 与 Unity API 边界

## H-J201：框架已有能力时，业务层不得直接使用 Unity 原生替代

每次新增/迁移能力前必须先查当前 MyFramework。存在等价能力时优先使用框架：

- Time → `GameFrameworkHotFix/TimeManager` 等框架时间。
- Random → `MathUtility`/项目框架随机入口。
- Input/Touch → `InputSystem/GlobalTouchSystem`。
- Resource → `ResourceManager`。
- Instantiate/Destroy → `PrefabPoolManager/GameObjectPool` 或框架 Utility。
- Camera → `CameraManager`。
- Audio → `AudioManager/AudioHelper`。
- Event → MyFramework `EventSystem`，不是 `UnityEngine.EventSystems.EventSystem.current`。
- Tween → `TweenerManager`。
- Animator/Spine 状态切换 → 项目已有 `GameUtility.SetTrigger/SetBool/playSpineAnimation` 等封装。

只有框架确实没有对应能力、或必须接收 Unity 原生回调时才能直接调用 Unity API，并把调用限制在最薄的边界层。

## H-J202：HotFix 业务层禁止直接散落 `Time.* / UnityEngine.Random.* / EventSystem.current`

这些调用会绕开框架的时间缩放、输入/事件生命周期或测试能力。确有例外必须在 Manifest 白名单中写清原因。

---

# K. Excel / DataBase / 配置

## H-K01：最终配置必须进入 MyFramework Excel 生成链（若项目范围包含配置迁移）

闭环：

```text
Excel/CSV source
 -> CodeGenerator
 -> ED*.cs / Excel*.cs / ExcelRegister.cs
 -> CSVToBinary
 -> Assets/GameResources/Excel/*.bytes
 -> ExcelManager load/query
```

手写 `static GameDefinitions`/Catalog 只能是明确迁移阶段，不是最终态。

## H-K02：不得手写生成的 ED/Excel 自动代码冒充工具产物

没有真实运行生成器，就标记“Data structure prepared / Generator 未执行”。

## H-K03：颜色格式按当前工具能力

当前 1.1.12 实战默认使用不带 `#` 的 `RRGGBB/RRGGBBAA` string，再集中解析；若目标转换器源码明确支持 Color，才改变规则。

---

## H-K04：UI 最终收尾前必须完成 Hardcoded Business Data Inventory

稳定业务数据若仍写死在 C# 中，不能一边继续 Shop/Career 等 UI polish，一边把数据层留成静态数组/switch。典型应迁表：

- Catalog ID / Kind / Order。
- 名称/描述/图标/价格。
- 奖励概率/奖励值/可配置范围。
- FTUE revision / version gate。
- 默认拥有/默认装备等稳定业务标记。

但 fixed-step、碰撞半径、RNG 调用顺序阈值等 parity-critical 算法常量**不得机械迁表**；只有原项目本来就是配置或已有严格等价验证时才迁。

## H-K05：手工 ED/Excel/bytes 不算官方工具链闭环

以下只能作为迁移准备/诊断：

```text
手写 ED*.cs / Excel*.cs
手写 ExcelRegister auto 段
离线脚本复刻 Serializer 协议并拼 .bytes
从其他项目复制生成产物
```

即使运行时能读，也只能标记：

```text
TABLE_STRUCTURE_READY
GENERATOR_UNVERIFIED
```

只有目标版本官方 CodeGenerator + CSVToBinary 真执行，并在 Unity 中实际加载 bytes，才算 H-K 完成。

## H-K06：表格需要 consumer、稳定身份和 runtime Ready 三重闭环

不得用 CSV/bytes 数量证明业务已表驱动。逐字段追踪 consumer，区分 ID、Catalog 顺序、选择值和存档身份；旧位置存档使用版本化历史映射。运行期实际 bytes 加载后校验必需 ID、有限数值、外键/默认值，失败不得创建并写回默认存档覆盖原数据。详见 [表格语义合同](28-table-consumption-identity-readiness.md)。

## H-K07：随机候选和历史 schema 不能为“硬编码归零”而破坏

随机候选集合/顺序/概率/端点/取整和同 RNG 值映射必须保持，调用次数相等不充分。版本化旧位置映射、固定物理槽位和算法常量可有明确例外，不把所有索引/常量一律机械迁表。

# L. 存档 / 序列化 / 平台

## H-L01：架构重构不得无证据改变存档 schema/path/key

先保持旧存档兼容，再重构 API。任何字段改名/拆表都必须有迁移逻辑和旧存档测试。

## H-L02：平台差异使用现有框架能力

WebGL / Android / iOS / 小游戏平台相关资源、文件、SDK、屏幕、方向优先查 MyFramework 对应模块，不在 Gameplay 自建一套。

## H-L03：Unity serialized field 名称属于兼容合同

已有 `.asset/.prefab/.unity` 的字段改名不能只按代码风格直接替换。必须采用至少一种：

- 保留原 serialized field 名；
- `[FormerlySerializedAs]`；
- 显式资产/数据迁移并在 Unity 中验证。

嵌套 serializable class/struct 同样适用。若兼容字段不符合 `m` 风格，可把它隔离在 serialized carrier/Binding，再显式映射到运行模型；不能让旧资产静默读空。

## H-L04：空壳/占位 MonoBehaviour 不是行为真值源

若旧类仅有字段、空方法或恢复不完整，必须从以下证据恢复职责：原 Unity 运行 > 原 C# 源码/调用链 > Scene/Prefab YAML > ScriptableObject/配置 > 物理/动画/层级。

禁止根据类型名或常见玩法经验自行发明规则并宣称行为一致。

## H-L05：存档字段“缺失”与“存在但值异常”不得共用同一业务 sentinel

当原版存在：

```text
missing field -> old-version fallback
present but invalid -> clamp/default
```

迁移后必须保留两种语义。若不能改变 JSON/schema，可在运行时增加 `[NonSerialized]` 字段存在标记，并由 parser/load 阶段记录 presence。禁止把“字段缺失”直接映射成业务可合法出现的 `0/-1/false` 后再用同一分支处理。

---

## H-L06：存档/session/layout/UI 状态必须分别声明寿命

源 SaveGame 写入字段是持久化边界；属性标记只有被实际 serializer 遵守才有效。不能把读后重置当成未保存，不能让 UI 重建抹掉 session 业务状态。Reset 时旧 autosave/异步写入不得恢复已清除的数据；每种退出原因的保存行为必须明确。

# M. C# 项目代码规范（本迁移 Skill 硬要求）

以下针对**项目自有 Game/HotFix 源码**；Packages、第三方插件、官方生成代码不强行改写。

## H-M01：禁止 C# 自动属性

禁止：

```csharp
public SaveData Data { get; private set; }
public bool Ready => mReady;
```

使用明确 `m` 字段 + getter/setter 方法：

```csharp
protected SaveData mData;
public SaveData getData() { return mData; }
```

原因：与参考项目风格、对象 reset、字段审计及生成工具保持一致。

## H-M02：成员字段默认 `m` 前缀

项目手写成员字段：

```text
mGame
mSaveData
mRunning
```

不得使用 `_game/_data` 风格。官方生成字段保持生成器输出，不手改生成代码。

## H-M03：HotFix/项目业务代码不自定义 namespace

当前三个参考项目 HotFix 均采用全局类型。迁移项目业务代码保持相同约定；第三方/Packages 不改。

## H-M04：业务 class 不使用 sealed

与当前 MyFramework Analyzer/参考项目规范保持一致。第三方和框架源码除外。

## H-M05：不要用文本全局替换做语义重构

尤其禁止：

- `Foo` Property → `getFoo()` 时全局字符串替换。
- enum member / const / field / method 同名时盲改。
- 生成区全文替换。

必须按符号类别逐处改，并执行至少：

- enum/static const 形态扫描。
- 方法调用编译检查。
- 旧符号引用计数。

## H-M06：修改/生成源码统一 UTF-8 BOM

默认对 `.cs/.h/.cpp` 保持 UTF-8 BOM。不要批量修改 Packages/第三方特殊编码。

---

# N. 生成器 / Analyzer / 编译硬门禁

## H-N01：Analyzer 错误等同编译错误，不能忽略

例如 `BASE001` 必须修复根因，不能：

- 禁用 Analyzer。
- 屏蔽规则。
- 从 asmdef 移除 analyzer。
- 通过“另写一个同名类”绕过。

## H-N02：静态审计不能代替 Unity Compile

Python grep 结果为 0 只说明候选扫描通过，**不代表 API overload/泛型/Analyzer/序列化能编译**。

最终必须真实执行 Unity 编译；无法执行时必须报告“Compile 未验证”。

## H-N03：完整迁移交付前的扫描清单（局部任务选择受影响项）

- Reflection/GetType。
- namespace / sealed。
- auto property。
- `_xxx` 成员字段。
- override 生命周期缺少 `base.xxx`。
- ClassObject direct new。
- `Resources.Load/Instantiate/Destroy` 候选。
- Runtime Component lookup。
- UI path lookup。
- enum member 被误写成 `getX()` 候选。
- `getOrAddComponent<T>(gameObject)` 未限定 static utility 候选。
- static API owner/`using static` 可见性候选。
- `registeFrameSystem<T>()` callback 对 null 不安全候选。
- `destroy()` 跨 System/Manager 非空保护/释放阶段候选。
- UGUIGenerator/LayoutRegister/GBR/UI God System/错误字体引用/Generator 绑定代码越界候选（`audit_myframework_ui.py`）。
- Display Profile/FrameSettings/start UGUIRoot/Layout root/orientation 候选（`audit_myframework_display.py`）。
- Excel CSV/bytes/注册/硬编码残留/fallback 标记（`audit_myframework_excel.py`）。
- UTF-8 BOM。
- legacy symbols/GUID。
- Resources allowlist / unexpected Resources assets。
- project `Resources.Load`。
- Legacy/Recovered runtime paths。
- duplicate GUID / expected moved GUID。

---

## H-N04：未覆盖不等于通过，候选匹配不等于语义证明

静态审计必须报告扫描文件/表/规则/region 数量。目录不存在、声明为空、模式没有覆盖到文件不得作为 0 error 证据；不适用项需理由与来源。七类原审计之外运行 Runtime Contract 检查；工具定位到源码/日志不代表自动验证其语义或真实性。详见 [审计覆盖规则](31-contract-audit-evidence-coverage.md)。

# O. 结构级完成门禁

## H-O01：不能“编译过了但结构不像 MyFramework”

交付前逐项对照参考项目：

- `Assets/Scripts/Game/Game/GameEntry.cs`
- `Assets/Scripts/Game/Game/Game.cs`
- AOT `GameScene/LaunchScene/...`
- `Assets/Scripts/HotFix/Game/GameHotFix.cs`
- `Assets/Scripts/HotFix/Common/GameBaseHotFix.cs`（GBR）
- `HotFix/SceneSystem/SceneRegister.cs`
- `HotFix/GameScene/...`
- `HotFix/*System/...`
- `HotFix/UI/...`
- `HotFix/DataBase/Excel/...`
- `Assets/GameResources/...`

目录名可因项目裁剪，但职责和启动链不能缺失或被兼容壳替代。

## H-O02：启动场景、主场景、资源场景必须分别定义职责

不能为了“直接 Play”把所有东西都放到一个 `Main.unity`。

## H-O03：禁止以下假迁移终态

- 一个巨型 `CrushYardRoot`/`GameApp` 换名成 System。
- 一个 RuntimeSystem 手工调用所有其他 System。
- UI System 运行时建整棵 UI。
- 一个 `XXXUISystem : FrameSystem` 统一控制多个 Layout 的加载、交互、Popup 状态、存档和 refresh。
- 手工 `LayoutMigrationBootstrap/fallback registeLayout` 永久替代官方 Generator 注册链。
- System 对外返回具体 Scene/UI 让调用者继续旧链。
- 静态 Catalog 永久替代 Excel 工具链。
- fallback 注册永久存在。
- 新旧事件系统同时运行。
- 新旧资源加载同时运行。
- `Assets/Resources` 作为旧业务资源兼容仓库。
- `LegacyRuntimeDebt/RecoveredSourceReference` 仍作为运行 Assets 的一部分。
- 旧 MonoBehaviour 改名为 Binding/Bridge 但仍承载 Update/AI/状态/资源加载。

---

# P. 行为与回归硬门禁

## H-P01：任务指定的可运行基线是行为真值源

普通 Unity 重构默认以原 Unity 工程为行为真值。但如果用户明确说明当前 Unity 是尚未完全对齐的中间移植版本，并提供合法上游源码/运行结果，则上游实现优先于中间 Unity。MyFramework 参考项目永远只提供结构范式。

框架重构不允许无证据改变：

- 输入时序。
- Update/FixedUpdate 阶段。
- 随机调用顺序。
- 物理参数。
- UI 层级/遮罩/触摸范围。
- 音频触发。
- 存档结果。

## H-P02：至少验证首局 + 第二局

必须覆盖：

- 冷启动。
- 首局。
- 退出/重进。
- 同场景第二局。
- UI 第二次显示。
- 事件无重复监听。
- Pool 无状态残留。

## H-P03：无法运行的门禁必须明确写“未验证”

不得用：

- 代码扫描
- YAML 检查
- zip 完整性

替代 Unity Compile/Play/Generator 的实际结果。

---


## H-P04：横竖屏变化后必须验证 World Camera 与世界覆盖

显示方向改变不只影响 UI。必须对照原版验证：

- Projection/FOV 或 orthographic size。
- Pitch/Yaw/Camera distance/aspect 公式。
- 玩家在屏幕中的目标位置与占比。
- 世界近景/远景是否覆盖整个 viewport。
- Fog/Background/Skybox。

原版 renderer 中用于填屏的 `ground skirt / floor plane / backdrop / sky dome / void cover` 即使不参与玩法，也属于表现合同。漏迁后出现 Camera background 纯色空区视为 parity 失败。

## H-P05：至少保存目标分辨率三状态视觉证据

视觉 parity 最小矩阵：

```text
Home/Menu
Gameplay
Result/Fail
```

每个状态必须在目标 resolution/orientation 下对照原版，至少检查 UI safe area、主要控件边界、角色/世界占比、Camera framing、overlay alpha 与纯色 void。Scene View/Prefab Preview 不能替代 Game View/Build 截图。

## H-P06：多层来源必须追到“最终有效行为”，第一次命中不算真值

存在 CSS/样式表、多阶段 UI 刷新、配置覆盖或后写赋值时，必须记录最终覆盖链：load order、specificity、后写函数、默认 CSS 行为和最终用户可见结果。不能拿 `updateUI()` 的第一次赋值忽略后续 `retentionUI()` 覆盖，也不能拿早期 stylesheet 忽略后加载规则。

## H-P07：表现 parity 必须包含 duration / easing / keyframe / layer

效果一致不仅是“出现了”：

- duration/delay/stagger。
- keyframe offset。
- timing-function/easing。
- transform/alpha/rotation。
- World/HUD/Overlay 坐标空间与最终层级。
- Reduced/Auto/Disabled 分支。

Prefab 缺少真实 Glow/Badge/Track/Fill/Overlay 节点时，不得用缩放/改颜色等近似方案冒充完全一致；应记录为 Generator 待闭环项。

## H-P08：Procedural Mesh / Shader parity 必须保留拓扑与确定性

程序化渲染迁移必须核对端盖、segment、winding、normal、Shader Cull、low-detail 阈值、subdivide/dropout/distort 规则、deterministic seed 与必要的 RNG 调用顺序。使用 Unity 内置 primitive 只有在拓扑/行为确实等价时才允许。

## H-P09：Parity 修复不得引入热路径无意义 GC

C# 热路径禁止因为照搬上游脚本写法而新增每帧字符串 cache key、临时数组/List/LINQ/`ToArray()`。允许用值类型 key、分层 mesh cache、预分配容器消除无关分配，但不能因此改变上游确定性输出。

## H-P10：周期和条件顺序是行为合同

时钟/阶段、初始相位、卡顿补 tick、余量、动态 interval 生效点、条件先后、暂停/Reset 和随机消耗必须逐事件验证。不得把源引擎 Every、TweenPlaying、Wait 等机械替换成方便的通用 timer/visible 判断。项目特定周期/迟到阈值只能来自对应源版本，不能写成框架默认值。

# Q. Dependency / Assembly 完整性硬门禁

## H-Q01：禁止伪兼容 asmdef / stub / placeholder

缺失 `HybridCLR.Runtime/Editor`、`Obfuz.Runtime/Editor`、TTWebGL、QiNiu 或其他 Assembly 时，必须查目标项目真实 Package/Plugin/参考项目来源。

禁止为了“先让编译过”而新增：

```text
MyFrameworkCompatibility
FakeRuntime/FakeEditor
PlaceholderRuntime/PlaceholderEditor
同名空 asmdef
同名空 class/namespace
```

真实 Package 安装后，同名 asmdef 会直接导致 Unity `Assembly with name 'X' already exists`。

## H-Q02：duplicate Assembly name 必须为 0

最终 staged root 中扫描**真正会被 Unity 编译/导入**的 `Assets/**/*.asmdef` 与 embedded/local `Packages/**/*.asmdef` 的 `name` 字段；除有明确证据且工具链允许的项目白名单外，重复 Assembly name 为硬失败。

包内 `ProjectTemplate~ / Samples~ / Documentation~ / Tests~` 等非运行导入目录不能按普通编译 Assembly 计入 duplicate；否则完整包会把官方模板中的同名 asmdef 误报为项目重名。默认审计器会排除路径段以 `~` 结尾的目录，并允许配置额外排除项。

不能只按 asmdef 文件名判断。

## H-Q03：Package 实际生效来源必须明确且真实

Unity 允许 embedded package 同时保留 manifest dependency，此时 embedded copy 优先，因此**不能把 embedded + manifest 同名本身当错误**。

但关键依赖必须在 Manifest 的 Dependency/Assembly Matrix 中记录：

- 实际生效来源。
- manifest entry（若有）。
- 版本/路径。
- 依赖者。

禁止在来源不清楚时再额外创建 fake asmdef/stub。

## H-Q04：不能通过删除/屏蔽真实 Package 来迁就伪兼容层

如果项目原本已有正式 HybridCLR/Obfuz/插件包，应删除 fake compatibility，而不是删除正式包。

---

# R. API Provenance / Unity 版本硬门禁

## H-R01：MyFramework API 不得凭记忆猜

本轮新增/修改的框架调用必须在目标工程实际安装的 MyFramework 源码或同版本参考项目中找到证据，并记录：

- 声明类。
- static / instance。
- namespace / `using static`。
- 参数/`out/ref`。
- virtual/abstract。
- 生命周期函数。

出现 `CS0103/CS0115/CS1620` 时先回源码核对，不新建 helper/stub 掩盖。

## H-R02：不存在的生命周期 API 不得伪造

例如当前 1.1.12 实战：

- `changeProcedure<T>()` 来自 `FrameUtility`。
- `isEditor()` 来自 `FrameBaseUtility`。
- `SceneProcedure` 不存在通用 `finish()` 合同。

这些只是版本快照；不同版本必须重新核对源码。

## H-R03：Editor 工具 API 必须与目标 Unity 版本一致

Editor 脚本也必须真实编译。禁止因为“只在 Editor 运行”就使用其他 Unity 版本 API。

例如 Unity 2022.3 的 Sprite importer alignment/pivot 通过 `TextureImporterSettings + ReadTextureSettings/SetTextureSettings` 设置；不能假设 `TextureImporter.spriteAlignment` 存在。

## H-R04：错误 API 不用反射/extension 伪装成“兼容”

如果 API 在目标版本不存在，应改成目标版本真实 API，不通过反射、空 extension、同名 wrapper 把错误调用继续保留。

---

## H-R05：包装类型能力与 C# 可见性必须按真实 API 收口

包装控件/WindowObject 不能因为内部持有 `myUGUIObject` 就被假设拥有底层全部 Transformable API。出现 `CS1061` 时先查真实继承与 owner，不通过 extension/wrapper 伪造不存在的方法。

出现 `CS0051/CS0052` inconsistent accessibility 时：

1. 先判断 public/protected 成员是否真的需要跨程序集/派生类暴露。
2. 若只是内部 cache/实现细节，优先把成员收窄到 `private/internal` 合同。
3. 不得为了消错误把 internal 实现类型机械扩大成 public API。

# S. Direct-Run / Runtime Artifact Closure 硬门禁

## H-S01：完整包中的 runtime-critical 资产必须已落盘

用户要求“直接放进去就能运行”时，最终 ZIP 在压缩前必须已经包含运行所需的：

- Scene。
- Gameplay Prefab。
- UI Prefab。
- Material / PhysicsMaterial。
- Settings / ScriptableObject。
- Excel bytes / Data。
- Font/Sprite binding 等运行关键资产。

不能把这些资产留给首次打开后的自定义生成器去创建。

## H-S02：Tools 菜单/InitializeOnLoad 不能是完整包运行前置条件

Editor Builder 可以作为维护/重建工具保留，但以下情况不能称 Direct-Run 完整工程：

```text
先执行 Tools -> XXX -> Generate
首次导入自动创建运行 Scene/Prefab
缺资产时 InitializeOnLoad 自动补齐
```

如果运行依赖这些步骤，必须标记 artifact closure pending。

## H-S03：Build Settings / FrameSettings / UI 读取路径必须在最终包闭环

至少验证：

- `Assets/Resources/Scene/start.unity`。
- `Assets/Resources/Settings/FrameSettings.asset`。
- Build Settings 第一场景与运行场景。
- 目标版本 LayoutManager 实际读取的 UI Prefab 目录。
- 所有代码引用的 runtime-critical asset path。

MyFramework 1.1.12 当前实战 UI Prefab 目录为 `Assets/GameResources/UI/UIPrefab`；不同版本重新核对。

同时 1.1.12 源码确认 `FrameDefine.KEY_FRAME_FILE = "KeyFrame/Keyframe.prefab"`，`KeyFrameManager` 会从 GameResources 加载，因此完整包必须包含 `Assets/GameResources/KeyFrame/Keyframe.prefab`。

## H-S04：完整包不依赖上一版残留或手动删除

完整包必须在全新空目录解压后成立；不能要求用户：

- 先删 `Assets/Plugins/MyFrameworkCompatibility`。
- 先覆盖某个旧版本。
- 先保留上一版 Library/生成资产。

这些语义属于增量 patch，不属于 full package。

## H-S05：Direct-Run 未真实 Unity 验证时必须标 UNVERIFIED

ZIP 完整性、静态 asset existence、审计脚本通过，不能代替 Unity Package Resolve / Import / Compile / Play。

无法执行 Unity 时可以交付结构完整的包，但不能写“已验证可正常运行”。

## H-S06：所有 runtime Scene 必须已加入 Build Settings

不能只保证 `start.unity` 是第一场景。如果 SceneSystem/SceneManager 会在运行期加载项目 Scene，则该 `.unity` 必须已经存在并在 `ProjectSettings/EditorBuildSettings.asset` 中启用。

用户不应再手工“Add Open Scenes”。项目 `MIGRATION_AUDIT_CONFIG.json` 必须通过 `build_settings_required_scenes` 列出本项目运行 Scene。

## H-S07：FullInstall 组装必须继承同版本 Runtime Template 资产，不只拼工程骨架

当原始迁移输入只有 `Assets` 时，补 `Packages/ProjectSettings` 不能凭猜测。优先使用：

1. 同版本 MyFramework 官方 `ProjectTemplate~`。
2. 同版本已验证参考工程。

并逐项核对官方模板中的 runtime-critical 资产（如 1.1.12 的 Keyframe Prefab）。只复制项目三目录外形但漏运行资产，不得称完整安装包。



## H-S08：FrameSettings 必须来自目标版本 schema，且显示配置与 UI Root 一致

`Assets/Resources/Settings/FrameSettings.asset` 是运行时必需资产，但禁止直接复制另一工程/另一框架版本的 YAML。必须读取目标版本 `FrameSettings.cs` 或使用该版本官方 Menu/ProjectTemplate 生成。

同时区分：

```text
Assets/Resources/Settings/FrameSettings.asset
ProjectSettings/MyFrameworkSettings.asset
```

二者用途不同，不能互相替代。

项目声明固定设计分辨率时，FrameSettings UISize 必须与 start Scene UGUIRoot、Runtime Layout Prefab roots 的设计尺寸一致。

## H-S09：本轮未运行官方 Generator 时，自动生成区必须保持有覆盖的 0 drift

“继续重构”的每轮版本都要明确本轮是否运行了官方 UGUIGenerator/Excel Generator。

- 未运行：上一版→当前版对应自动生成区应字节/文本语义一致，`compare_myframework_generated_regions.py` 结果应为 0 changed。
- 已运行：记录 Generator、输入 Prefab/Table、生成 diff 与 Unity import/compile evidence。
- 禁止在普通业务/视觉修改中夹带手工自动区改动。

# T. 完整迁移的复核流程（局部任务按影响范围选择）

1. 读取最新 `PROJECT_MIGRATION_MANIFEST.md`，确认本轮目标、Resource Layout、Bridge/Binding、Serialized Contract 和 Legacy Debt。
2. 对照本文件 H-A~H-S 重新跑结构扫描，不能只看上一轮剩余任务；UI Generator、Layout resetProperty、Display Profile、FrameSystem callback/null、willDestroy/destroy、Excel toolchain、Direct-Run Scene/模板资产必须重新检查。若存在上游 parity 真值，还要复核最终覆盖链而非沿用上轮结论。
3. 对最终 staged root 运行：`audit_myframework_structure.py`、`audit_myframework_migration.py`、`audit_myframework_ui.py`、`audit_myframework_display.py`、`audit_myframework_excel.py`、`audit_myframework_resources.py`、`audit_myframework_dependencies.py`。
4. 每轮资源移动必须记录 old/new path + GUID，并检查 `.meta`、duplicate GUID、旧路径副本和引用残留；每轮报告 Resources actual/allowlisted/unexpected 数量。
5. 删除 Legacy MonoBehaviour 前先完成 Serialized Contract；切换后扫描旧 script GUID 为 0。空壳旧脚本不得作为行为实现依据。
6. 发现 Skill 未覆盖的真实错误时，先在项目记录原因并完成授权修复。只有用户明确要求维护 Skill 时才更新 Skill/审计器；不把自动修改已安装 Skill 设为项目修复前置。
7. 每轮只声明真实完成项；Generator/Compile/Play 未执行就标记未验证。任何全局重命名/风格收敛后，都必须额外扫描 enum/const/generated code 是否被误改。
8. 打包前验证源码 BOM、ZIP 完整性、legacy debt、Resources 白名单、UI Generator 代码所有权、Layout resetProperty=0、Display Profile/FrameSettings/UI roots、Excel 官方工具状态、FrameSystem callback/null 与销毁依赖、duplicate asmdef、伪兼容路径、Keyframe/required Build Settings scenes、Direct-Run 必需资产、本轮不应变化的资源/Prefab/hash；若本轮未运行 Generator，还要验证自动生成区 drift=0；增量包有移动/删除时必须附版本化 DELETE 清单。


### 3.2.0 补充：每轮必须检查真实覆盖与运行合同

填写五类 Runtime Contract；先核对表格 consumer、Procedure 再入、Reset 写入边界和 UI/timing 时序，再修改业务。自动区比较必须显示实际 region 数，所有新增/删除/损坏 marker 和批准差异保留在报告中；没有官方执行证据不允许批准手写变化。完整执行流程见 references/28–31。


## 平台构建任务的适用边界（3.2.2）

迁移后的 OPPO/vivo 构建、包体、签名或启动调试按 [快游戏工作流](33-quickgame-build-debug-release.md) 执行。平台构建成功、大小检查、运行和后台受理分别记录；物理包与主包/分包计量不互换，阈值不固化为所有项目默认。
