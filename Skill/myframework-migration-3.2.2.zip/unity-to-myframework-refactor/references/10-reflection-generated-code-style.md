﻿# 反射、生成代码与代码规范

## 业务运行时禁用反射

默认禁止范围：

```text
System.Reflection
BindingFlags
Activator
GetField / GetFields
GetProperty / GetProperties
GetMethod / GetMethods
GetMember / GetMembers
Assembly.Load / LoadFrom / GetTypes
字符串类型名 + 运行时扫描
```

### GetType

`GetType()` 不等于所有反射。

允许场景：

- 框架 API 真实要求 Type。
- 类型身份比较。
- Editor 诊断输出类型名。

不允许把 `obj.GetType().GetField(...)` 作为字段绑定。

重构目标通常是 HotFix 业务 `GetType()` 尽量为 0，Editor/框架必要使用有白名单。

## 强类型替代

- 类型工厂：显式 `switch/Dictionary<ID, factory>` 或生成代码。
- ActorBinding：Editor 导出 → 强类型 Registry。
- UI：Prefab 生成器产生字段绑定。
- Excel：stable ID + ED 强类型字段。

## 自动生成代码

识别并保护：

```text
// auto generate ... start
// auto generate ... end
```

规则：

- 不格式化破坏自动段。
- 不手工补自动段让审计通过。
- 需要改变输出结构时修改生成器/Prefab/CSV，然后重新生成。

## 项目代码风格硬要求

对 MyFramework 迁移产生/修改的**项目自有 Game/HotFix 业务代码**，默认强制：

- 不自定义 namespace；参考 Obby/TDDemo/MicroLegend HotFix 均为全局类型。
- 业务 class 不使用 sealed。
- **禁止 C# 自动属性和属性式只读表达**，使用 `m` 前缀字段 + `getX()/setX()` 方法。
- 手写成员字段默认 `m` 前缀，不使用 `_xxx`；官方生成代码按生成器原样保留。
- 不使用简单文本全局替换完成 Property→getter、field rename 等语义重构；必须避免误伤 enum/const/generated code。
- 继承框架类后覆盖生命周期方法必须调用匹配 `base.xxx(...)`；Analyzer `BASE001` 视同编译失败。
- 修改/生成源码保持 UTF-8 BOM。
- 复杂条件、长参数列表和链式调用按语义边界换行并正确缩进；可读性需要换行时必须换行，不把复杂逻辑挤成单行，也不机械拆碎简单表达式。
- 相邻函数之间不留空行，文件任何位置（含字段、函数体和结尾）都不允许连续空行；保留确有必要的分组或解释性注释。
- 能在首次使用处声明的局部变量就内联声明，优先使用合适的 `out var`、`using var`、`foreach` 变量和目标类型 `new()`；只有跨分支共享、生命周期或清晰度确有需要时提前声明。
- 使用目标 Unity、实际 C# 编译器与 asmdef 支持的较新语法简化代码，先编译确认，不套用不受支持的语言版本；保持 AOT/热更兼容。
- 写业务层 Unity 引擎调用前先查目标版本框架的资源、布局、对象池、时间、事件及文件访问封装；有等价能力就复用，避免重复代码。确实需要底层引擎能力时直接调用并说明理由，不新增空转发层。
- 交付的受影响程序集要求零编译错误、零编译警告；新警告必须修复，不用 `#pragma`、关闭分析器或降低警告级别遮掩。已有警告应定位并在可编辑范围内清除；第三方或生成代码无法改时记录具体来源，不能声称“无警告”。

以下属于项目可进一步采用的组织约定，不作为所有项目的语义门禁：

- 每文件一个业务 class。
- public/override 在前，protected/private helper 在后。
- `//------------------------------------------------------------------------------------------------------------------------------` 分隔。

第三方插件、Packages、官方生成代码不为满足手写业务风格而批量改写。

## UTF-8 BOM

用户当前工作流要求生成/修改的 `.cs/.h/.cpp` 使用 UTF-8 BOM。交付前检查 BOM。

不要批量转换 Packages/第三方已有特殊编码，除非明确要求。
