﻿# 性能与内存回归门禁

MyFramework 迁移的主要目标是架构和生命周期统一，不承诺自动提高 FPS；但迁移不得造成明显性能回退。

## 至少比较

对原版/迁移版的代表性流程记录：

- GC Alloc/frame 或关键操作分配。
- 高频 `Instantiate/Destroy` 次数。
- 活跃 MonoBehaviour Update/协程数量（能观测时）。
- PrefabPool/ClassPool 使用量与第二局是否持续增长。
- 重复 Event listener/重复 callback。
- 资源常驻量和明显重复加载。
- UI 动态列表创建数量。

## 结构性性能规则

- 不为消除 `new` 机械池化极低频、短生命周期对象；先看 owner 与真实频率。
- 高频 GameObject 优先 PrefabPoolManager。
- 高频临时 List 使用框架 scope/pool 时必须避免嵌套重入共用同一容器。
- UI Generator/强类型缓存的意义之一是减少长期字符串节点查找，不应迁完仍每帧 `Transform.Find/Node(path)`。
- 不应为了 MyFramework 化把原本事件驱动逻辑改成每帧轮询。

## 回归判定

如果指标明显变差：

1. 先确认是否迁移引入，而不是基线差异。
2. 找出新增分配/Update/加载路径。
3. 修复后再继续下一阶段。
4. 报告中必须写明未测指标，不能用“用了 Pool 所以性能更好”作为证据。


## Procedural Mesh / Effect 热路径

从网页/脚本化 renderer 迁入 Unity 的 parity 算法必须额外检查：

- 不能每帧拼接字符串 cache key；优先 readonly/value-type key。
- 不能在压缩/破碎/粒子/feedback 每帧创建临时数组、`List<T>`、LINQ 或 `ToArray()`。
- 不重复细分不变源 Mesh；source mesh 与完全终态 mesh 可分层缓存。
- 缓存不能改变 deterministic seed/RNG 调用顺序。
- low-detail 分支仍按上游阈值执行，不得为了缓存把所有模型强制成同一精度。
- Shader/Cull/normal/topology parity 修复后仍需重新观察 draw/vertex/GC，不以“视觉更准”豁免性能回归。
