﻿# 旧架构 → MyFramework 迁移模式库

本文件定义常见的**拆解顺序**。目标是避免把旧架构一次性推倒后再靠 wrapper 补洞。

## Pattern A：God MonoBehaviour / GameApp

旧结构：

```text
GameApp : MonoBehaviour
  ├─ 初始化所有模块
  ├─ 保存场景/UI/音频/存档引用
  ├─ Coroutine
  ├─ Gameplay 状态
  └─ 平台回调
```

建议顺序：

1. 冻结行为和序列化引用。
2. 全局业务拆到有真实职责的 FrameSystem。
3. Scene 稳定引用进入 SceneInstance/Scene binding。
4. Coroutine/Delay 迁到真实 owner；不要让 System 借 GameApp 当协程宿主。
5. Audio/Save/Resource/Platform 进入现有框架系统或薄项目 System。
6. GameApp 最后只剩 Unity 必需回调；若框架已有等价入口则删除。

禁止：先建 `NewGameSystem`，内部仍把所有调用转给 `GameApp.Instance`。

## Pattern B：字符串 UI Runtime / Action Router

旧结构：

```text
LayoutScript -> PortedScreen.Node("A/B")
             -> SourceButton action string
             -> onAction("btn_xxx")
             -> 巨型 switch
```

建议顺序（按页面逐张闭环）：

1. 记录 Prefab 节点、按钮视觉状态、动画、输入时序。
2. 在 Prefab 上补 Generator 成员元数据。
3. 使用强类型 `myUGUI* / WindowObjectUGUI / LegendButton/...`。
4. 每个按钮改成明确方法/业务 command，不再用字符串 action。
5. 删除该页面的旧 Runtime bind/unbind。
6. 删除 Prefab 上旧 PortedScreen/SourceButton 等组件。
7. 检查 YAML/Missing Script，跑第二次打开/关闭。
8. 页面全部迁完后再删除全局旧 Router 类型。

不要一次性删除全局 Router 再同时改几十张页面。

## Pattern C：MonoBehaviour Gameplay + Runtime Object 双层包装

旧结构：

```text
CellView : MonoBehaviour
   <-> ICellRuntime
   <-> CellObject
```

先判断 Unity 消息是否真的需要 MonoBehaviour：

- 不需要：行为全部进 `CellObject/ClassObject/WindowObject`，删 View runtime 桥。
- 需要 Physics/Pointer Unity callback：保留最薄 `CellUnityBridge`，只转发参数给 owner，不保存玩法状态、不创建子对象、不跑业务 Coroutine。

迁移顺序：owner → init/bind → update → callbacks → destroy/reset → 删除旧接口。

## Pattern D：ScriptableObject + JSON Database

旧结构：

```text
GameDatabase(ScriptableObject)
  ├─ TextAsset JSON
  ├─ Sprite/Audio arrays
  └─ JsonUtility.FromJson
```

拆为两类：

- 稳定业务配置 → Excel/bytes/ED/ExcelTable。
- 资产 → ResourceManager/Atlas/Audio 注册或稳定资源 ID。

先产出 old→new schema mapping 和数据等价性检查，再切运行代码；禁止把完整 JSON 字符串塞进 Excel 一列冒充迁移。

## Pattern E：Instantiate/Destroy 高频对象

1. 识别真正 owner 和复用边界。
2. 资产通过 ResourceManager/PrefabPoolManager 进入池。
3. owner createObject；owner destroyObject。
4. 索引/查询 System 只 unregister，不代 owner 回收。
5. 比较首局/第二局 active/free 数量。

## Pattern F：旧 Service wrapper

如果：

```text
SaveSystem -> SaveService -> PlayerPrefs
```

而 `SaveService` 没有独立生命周期/实现价值，则把真实实现并入 `SaveSystem` 后删除 wrapper。反过来，如果底层服务确实跨项目复用且有独立测试价值，可保留，但必须明确职责，不是只为保留旧函数名。

## Pattern G：迁移顺序选择

优先顺序通常是：

```text
启动/生命周期宿主
→ Save/Audio/Resource 等低耦合全局职责
→ 简单外围 UI（逐张闭环）
→ 中等动态 UI
→ 核心 HUD/Menu
→ Gameplay Bridge/Object owner
→ Data/Excel 切换
→ 删除全局兼容层
→ Unity/第二局/Build/Parity
```

这不是固定排序。若某个旧系统是多个模块的唯一依赖源，应先切断它；每一阶段都必须保持工程可回滚、依赖可量化。


## Pattern H：Resources 兼容仓库 → 白名单 + GameResources

旧结构：

```text
Assets/Resources/
  Eggs/
  Pets/
  Bots/
  WorldUI/
  Fonts/
  LegacyConfigs/
```

迁移步骤：

1. 从目标 MyFramework/第三方源码列出真正固定 Resources 路径。
2. 建立 `resources_allowlist`。
3. 对其余资源逐项判定：GameResources / Excel / 删除。
4. 移动资源与 `.meta`，保持 GUID。
5. 扫 Scene/Prefab/Asset 引用与 duplicate GUID。
6. 删除旧目录并在增量包提供 DELETE 清单。
7. 最终 `unexpected_resources = 0`。

不能把“Resources 里什么都能加载”当迁移便利方案。

## Pattern I：空壳 Legacy MonoBehaviour → Serialized Contract + Runtime Owner

当旧 `Foo : MonoBehaviour` 只有字段或完全为空时：

1. 不从空类猜行为。
2. 从原 Unity 运行、C# 源码/调用链、Scene/Prefab YAML、序列化资产恢复真实职责。
3. 导出字段表。
4. 静态引用进入 Binding。
5. Unity callback 进入最薄 Bridge。
6. 玩法状态进入 FrameSystem/Scene/Gameplay owner。
7. 切 Prefab/Scene 后删旧 script GUID。

## Pattern J：Unity serialized data carrier → 兼容字段 + Runtime Model

旧 `.asset` 已大量使用字段名时，不要直接按 MyFramework `m` 风格重命名所有 serialized field。

可采用：

```text
Legacy-compatible serialized carrier
        -> explicit mapping
Runtime model / Excel row / System state
```

这样既保持旧资产可读，也避免把序列化兼容字段扩散到业务层。字段重命名只有在 `[FormerlySerializedAs]` + Unity 真验证后才能完成。
