﻿# Resources / GameResources / 最终制品完整性

本章把资源目录从“风格建议”提升为迁移硬合同。目标不是机械清空 `Resources`，而是让每个留在其中的资源都有**明确的固定加载合同**。

## 1. `Assets/Resources` 是白名单目录，不是兼容仓库

对 MyFramework 1.1.12，框架源码已经证明的固定资源包括：

```text
Assets/Resources/Scene/start.unity
Assets/Resources/Settings/FrameSettings.asset
```

除此以外，只有当目标工程实际安装的第三方包或项目框架源码明确使用 Unity `Resources.Load` 固定路径时，才能加入项目级 `resources_allowlist`。例如 TMP 默认设置若当前版本确实按固定 Resources 名称加载，可显式白名单；不能因为“以前一般这么放”就默认保留整套 TMP 示例资源。

禁止把以下内容长期留在 `Assets/Resources`：

- Egg/Pet/Bot/关卡/武器/怪物等业务 Prefab。
- 业务 ScriptableObject/Catalog。
- 世界 UI / Popup / 业务字体材质。
- “先放这里保证能跑”的 Legacy 资产。
- `LegacyRuntimeDebt`、`RecoveredSourceReference`、Compatibility 资源副本。

每轮报告必须给出：

```text
Resources actual assets: N
Resources allowlisted assets: M
Unexpected Resources assets: N-M
```

最终态 `Unexpected Resources assets` 必须为 0。

## 2. `GameResources` 是运行游戏资源的主目录，但不等于所有资源都必须按路径加载

运行资源按项目实际分类整理进：

```text
Assets/GameResources/
  Prefab/
  UI/
  Font/
  Audio/
  Material/
  Data/
  Excel/
  ...
```

目录名可以裁剪，职责不能混乱。

重要：**资源位于 GameResources 并不意味着必须把原有 Prefab/Scene 序列化引用改成字符串路径 + ResourceManager 加载。**

如果原对象通过 Scene/Prefab 序列化字段稳定引用 Sprite/Material/Prefab，保留这种强引用通常更安全；只需要在移动资源时保留 `.meta` GUID。`ResourceManager` 用于真正的动态加载职责，不应为了“框架化”把稳定序列化引用改成脆弱路径。

## 3. 移动资源必须保留 `.meta`，并验证 GUID

资源移动优先使用 Unity Editor；在离线文件操作中必须把资源和同名 `.meta` 一起移动。

移动后至少验证：

1. 资源 `.meta` 中 GUID 未改变。
2. Scene/Prefab/Material/Asset 中引用该 GUID 的数量没有异常归零。
3. 原路径没有遗留重复副本。
4. 新旧目录没有相同 GUID 的重复 meta。
5. 删除资源的 GUID 在可扫描运行 YAML 中无残留引用。

不要通过“重新导入生成一个新 meta”来修路径，否则引用可能静默断掉。

## 4. ScriptableObject 的最终归属

区分两类：

### 稳定业务数据

例如数值、概率、等级、价格、掉落、成长等，若项目范围要求配置迁移，最终应进入 MyFramework Excel/bytes 工具链。

### Unity 资产绑定数据

例如 Prefab/Sprite/Material/AudioClip 的强引用组合，若 Excel 无法安全表达且生命周期合理，可以作为资源绑定资产保留在 `GameResources`，但不能因为方便就藏在 `Resources`。

“临时 ScriptableObject Catalog”必须在 Manifest 中标记为 transitional，并写删除条件；不能永久取代 Excel 后还声称完成。

## 5. Legacy / Recovered Source 不进入最终运行资产

原工程源码、迁移脚本、反编译参考（如确有合法来源）、旧 C# 备份可以作为迁移证据，但最终不应以运行脚本/运行资产形式放在 `Assets` 下。

推荐：

```text
Docs/ReferenceSource/
MigrationReference/
```

若必须临时放在 Assets，必须放 Editor-only/不参与运行编译的明确区域，并在最终门禁前清除。

以下目录名若出现在最终运行 Assets，应默认视为债务候选：

```text
LegacyRuntimeDebt
RecoveredSourceReference
CompatibilityRuntime
LegacyRuntime
```

不要只把目录重命名来规避审计；判断依据是职责。

## 6. 完整包与增量包语义

### 完整合并包

完整包必须是最终目标工程本身，不依赖用户先删除上一版某些目录才能正确。对完整包的审计应在**最终 staged root** 上执行。

如果用户要求“解压后直接打开并 Play”，运行关键 Scene/Prefab/UI/Material/Settings/bytes 必须已经存在于 ZIP。Editor Builder/`InitializeOnLoad`/Tools 菜单可以作为维护工具，但不能负责首次运行前补齐缺失 runtime-critical 资产；否则只能称迁移源码包或 artifact closure pending。

### 增量补丁

增量包如果涉及移动/删除，必须包含显式删除清单，例如：

```text
DELETE_R6_TO_R7.txt
```

清单应包含旧资源与 `.meta`，并说明“先删再覆盖”。否则用户本地旧文件会残留，形成新旧资源并存。

## 7. Resource Gate

每轮涉及资源时至少完成：

- `audit_myframework_resources.py`。
- `Resources.Load` 项目代码扫描。
- Resources allowlist 检查。
- legacy runtime path 检查。
- moved asset GUID stability。
- duplicated GUID 检查。
- 修改 Scene/Prefab 的 Missing Script/YAML component 检查。

静态资源审计通过仍不能代替 Unity Import/Compile/Play。
