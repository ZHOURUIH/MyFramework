﻿# 发现与基线

## 项目盘点

开始修改前收集：

- Unity Editor 版本、渲染管线、Physics 2D/3D、输入系统。
- `Packages/manifest.json` / PackageCache 中 MyFramework 的准确版本。
- asmdef 边界、HotFix/非 HotFix 层。
- 首场景、Build Settings、启动脚本。
- 资源目录：Resources、Addressables、AssetBundle、StreamingAssets、自定义下载目录。
- 数据源：CSV/Excel/JSON/ScriptableObject/二进制。
- UI：UGUI/TMP、Canvas、Prefab、代码生成器。
- 第三方：DOTween、UniRx/UniTask、Spine、Addressables、广告/SDK。
- 目标平台及同步/异步加载限制。

## 工作树保护

- 先看 `git status --short`。
- 用户未提交改动视为资产，不 reset、不 clean、不覆盖。
- 基线运行用独立副本/worktree。
- 验证副本同步当前源码、Packages、Assets、ProjectSettings；不要复制 Library/Temp 当源码。

## 行为基线清单

根据项目存在的功能记录：

- 启动和 loading。
- 主菜单、设置、存档。
- 每种玩法模式。
- 玩家输入、移动、攻击、技能。
- AI、怪物、生成与销毁。
- 物理与碰撞。
- UI 交互、滚动、弹窗、适配。
- 音频。
- 结算、重开、切场景。
- 第二局/第三局。

普通 Unity 重构必须保存原工程可运行入口、Build Settings、关键 Scene/Prefab、运行日志与测试基线；不要凭类名或截图重新发明逻辑，能从原 C#、序列化数据和调用链恢复时应逐项恢复。


## 上游真值源（若存在）

如果用户明确说明当前 Unity 工程是从其他实现迁移而来且尚未完全对齐，需要额外冻结：

- 上游源码/运行入口与版本。
- 样式表/脚本/配置加载顺序。
- 同一 UI/数值字段的后写覆盖链。
- 关键动画 duration/easing/keyframe。
- World/HUD/Overlay 层级。
- 存档 clean/migrate 对 missing/present-invalid 的不同语义。

此时不要把“当前 Unity 能运行”误当成“当前 Unity 行为就是最终真值”。

## 初始 Inventory

输出至少包括：

- C# 文件数量、MonoBehaviour 类型数量。
- System/Manager/Singleton 数量。
- Prefab/Scene 数量。
- UI Layout 数量。
- 配置表数量。
- 直接反射 API 数量。
- `Resources.Load/Instantiate/Destroy` 数量。
- `Assets/Resources` 实际资源数量、每个资源的保留理由、非白名单数量。
- `Assets/GameResources` 目录分类与主要动态加载入口。
- Legacy/Recovered/Compatibility 运行目录数量。
- Scene/Prefab 中 legacy script GUID 与组件实例数量。
- 待删除 MonoBehaviour 的 serialized field contract。
- 已存在 MyFramework 类型使用情况。

Inventory 是迁移起点，不是 KPI。目标不是把数字机械清零，而是识别真实迁移面。

## 2.6.0：Display / Hardcoded Data Baseline

新增基线项：

- 原版实际 orientation、运行 viewport/aspect、目标 design resolution、Safe Area。
- Home/Menu、Gameplay、Result/Fail 的目标分辨率截图。
- Gameplay Camera FOV/rotation/distance/aspect 与世界填屏方式（ground skirt/backdrop/sky/floor filler）。
- 稳定业务硬编码数据清单：Catalog、价格、文案、奖励参数、revision、默认拥有/装备等。

这些必须在大规模 UI/layout 和 data migration 前冻结，避免后期发现方向/数据模型根基错误。
