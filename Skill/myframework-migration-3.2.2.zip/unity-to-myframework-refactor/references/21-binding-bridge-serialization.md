﻿# Binding / Bridge / Unity 序列化合同

MyFramework 迁移最容易出现两种假迁移：把旧 MonoBehaviour 改名成 Binding，或看到旧脚本只剩空壳后凭猜测重写玩法。本章明确边界。

## 1. 三类 Unity 侧对象必须分开

### Binding

Binding 只保存 Unity Scene/Prefab 中的稳定引用和必要静态参数，例如：

```text
Transform
Collider/Rigidbody/Joint
Animator/Skeleton
Prefab/Material/Sprite
slot/root/carryPoint/safeBoundary
序列化静态 tuning 参数
```

Binding 不负责：

- Update/FixedUpdate 玩法循环。
- AI/状态机。
- 存档。
- 业务事件路由。
- 动态创建一整套业务对象。

### Bridge

Bridge 只用于框架无法直接收到的 Unity callback，例如：

```text
OnTrigger/OnCollision/OnJointBreak
IPointerDown/IPointerUp
少量 Unity 生命周期回调
```

Bridge 只转发 owner/ID + callback 参数，不保存业务状态，不自行计时，不运行玩法 Coroutine，不拥有业务对象。

### Runtime Owner

真正玩法状态属于 FrameSystem / SceneInstance / GameScene / ClassObject / Gameplay owner。owner 决定创建、更新、事件、销毁、回收。

## 2. 旧 MonoBehaviour 是空壳时，不能把“空壳代码”当行为真值源

迁移项目常出现：

- 抓取工程只恢复了字段，没有原方法体。
- 反编译脚本被裁剪。
- 旧 C# 只是占位 MonoBehaviour。

这时行为恢复顺序必须是：

1. 原 Unity 工程可运行行为。
2. 原 C# 源码与程序集调用链。
3. Scene/Prefab YAML 中的组件字段、引用关系、默认参数。
4. ScriptableObject/JSON/Excel 等真实数据。
5. 动画、Collider、Rigidbody、层级和事件配置。
6. 最后才是空壳 C# 类型名。

禁止因为类名叫 `EggGuard` 就凭经验发明守卫规则，再声称“与原工程一致”。

## 3. 迁移前先提取 Serialized Contract

对要删除的 MonoBehaviour，在 Manifest 记录：

| Legacy Component | Prefab/Scene | serialized field | type | current value/ref | target owner/binding |
|---|---|---|---|---|---|

所有字段必须逐项决定：

- 迁到 Binding。
- 迁到 Excel/Data。
- 迁到 Runtime owner 默认值。
- 明确删除（并说明原版不使用）。

没有字段去向表，不应直接删除旧组件。

## 4. Unity 序列化字段名是兼容合同

已有 `.asset/.prefab/.unity` 会按字段名反序列化。重构数据载体时：

- 最安全：保留原序列化字段名。
- 必须改名时：使用 Unity 支持的 `[FormerlySerializedAs]` 并在 Unity 中验证。
- 不能用“更漂亮的字段名”直接替换后假设旧资产会自动映射。
- 嵌套 struct/class 的字段名同样属于合同。

例如原资产保存 `pet/weight`，新代码若改成 `mPet/mWeight` 而没有迁移机制，旧资产会读空；代码能编译也不代表数据正确。

MyFramework 的 `m` 字段规范针对项目手写运行成员。对于必须兼容既有 Unity 序列化资产的字段，优先保证数据可读；可通过专用 serialized carrier + runtime mapping 把兼容字段隔离在边界层。

## 5. 删除旧 MonoBehaviour 的正确顺序

1. 提取 Serialized Contract。
2. 建立 Target owner + Binding/Bridge。
3. 把 Scene/Prefab 引用切到新 Binding。
4. 验证字段值/GUID/Transform 引用均保留。
5. 删除旧组件和脚本。
6. 扫旧 script GUID：运行 `.unity/.prefab/.asset` 中必须为 0。
7. Unity Import/Compile/Play 验证。

“旧 `.cs` 删除了”不等于旧组件迁移完成；Prefab/Scene 中 script GUID 残留同样是未完成。

## 6. Binding/Bridge 白名单必须可解释

`mono_behaviour_allowlist` 不应写成“大量旧组件全部允许”。每个允许的 MonoBehaviour 都要有类别：

```text
Binding: serialized Unity reference carrier
Bridge: required Unity callback receiver
Entry: GameEntry / framework-required host
Editor: editor-only tooling
ThirdParty: package-owned
```

若一个“Binding”出现 `Update()`、AI 状态、业务 timer、Save、Resource Load，应立即重新分类；它很可能只是换名后的旧 Runtime。

## 7. Scene / Prefab 是迁移输入，不只是输出

静态分析旧源码之前，必须同时盘点 Scene/Prefab：

- legacy script GUID 数量。
- 每种 legacy component 实例数。
- 字段绑定对象。
- GameObject active/layer/tag。
- Collider/Rigidbody/Joint 参数。
- Animator/Spine controller。
- Canvas/sorting/mask/raycast。

这些都是行为与结构恢复证据。
