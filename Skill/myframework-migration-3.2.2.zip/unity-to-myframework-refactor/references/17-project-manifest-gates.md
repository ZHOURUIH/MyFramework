﻿# 项目 Migration Manifest 与阶段门禁

通用 Skill 不能知道某个游戏的全部类、Prefab、旧组件和行为，因此每个迁移项目必须维护一份 `PROJECT_MIGRATION_MANIFEST.md`。

模板见 `templates/PROJECT_MIGRATION_MANIFEST.md`。

## Manifest 必须回答

### 0. Upstream / Effective Behavior

若当前 Unity 是不完整中间移植版本，记录权威上游真值源、最终覆盖链、动画/层级/存档 presence 语义；否则明确写 `n/a`。

### 1. Legacy → Target 映射

对每个旧核心对象记录：

- 原职责。
- 当前依赖者。
- 最终 MyFramework 类型/模块。
- 迁移策略（保留/拆分/合并/删除/薄 Bridge）。
- 删除条件。
- 当前状态。

### 2. UI Matrix

每张业务 UI 至少记录：

- Prefab。
- 原 Runtime/Bridge。
- Generator 状态。
- 强类型成员状态。
- String action/path 残留。
- Prefab 旧组件残留。
- 首次显示/第二次显示验证。
- Baseline parity。

### 3. Data Mapping

旧 JSON/SO/CSV → 新 Excel/bytes：字段、ID、默认值、枚举、数组/子表、资产引用的映射。

### 4. Ownership

所有复杂对象必须有唯一 owner。对于 Bridge/Pooled Object 同时记录“逻辑 owner”和“Unity GameObject owner”。

### 5. Resource Layout Matrix

至少记录 `Assets/Resources` 每个非 meta 资源：路径、为什么必须留在 Resources、源码/包依据、最终状态。业务资源没有固定加载合同就应迁出。

同时记录 moved asset 的 old path/new path/GUID，以及增量包删除清单。

### 6. Bridge / Binding / Serialized Contract

对每个保留 MonoBehaviour 标明 `Entry / Binding / Bridge / Editor / ThirdParty` 类别；对待删除 Legacy Component 记录 serialized field 的去向。

### 7. Dependency / API / Direct-Run Evidence

必须维护：

- Dependency / Assembly Matrix：真实 Package/Plugin 来源、依赖者、版本/路径、duplicate 状态。
- API Provenance Matrix：新增 MyFramework/Unity Editor API 的声明位置与目标版本。
- Direct-Run Artifact Matrix：运行关键 Scene/Prefab/UI/Material/bytes 是否已在最终 ZIP 中落盘，是否仍依赖生成器。

### 8. Legacy Debt Budget

每一阶段记录剩余数量，例如：

```text
PortedScreen C# refs: 22 -> 18 -> 10 -> 0
SourceButton prefab components: 18 -> 12 -> 0
Runtime string action handlers: 14 -> 8 -> 0
GameDatabase consumers: 6 -> 0
Instantiate/Destroy gameplay candidates: 12 -> 5 -> 0/白名单
```

只有数值下降且没有新增等价旧债，阶段才算推进。

## 阶段门禁

### Structure Gate

- 本阶段目标 legacy symbols 不再被目标模块引用。
- 新代码没有反向依赖旧 facade。
- owner 表更新。

### Asset Gate

- 修改的 Prefab/Scene 无 Missing Script。
- 删除 MonoBehaviour 组件后 YAML `m_Component` 无悬空 fileID。
- GUID/资源引用未意外改变。
- `Assets/Resources` 非白名单资源为 0（或仍处迁移阶段时数量明确下降）。
- `LegacyRuntimeDebt/RecoveredSourceReference` 等运行目录无新增。
- moved asset 的 `.meta`/GUID 稳定。
- 增量包存在删除/移动时有明确 DELETE 清单。

### Generator Gate

- 能运行 Unity 时：真实运行 Generator。
- 不能运行时：只能标记“Generator 待验证”，并保存需要在 Unity 中执行的明确步骤。

### Behavior Gate

- 本阶段不应改变的行为列在报告里。
- 能运行时执行对应页面/流程的首轮+第二轮。

### Debt Gate

- 报告 old/new 残留计数。
- 不允许“删一个旧类，新增另一个功能完全相同的 CompatibilityManager”来制造假下降。


### Dependency/API Gate

- duplicate asmdef name = 0。
- 不存在 fake compatibility/stub/placeholder。
- embedded package + manifest overlap 已记录实际生效来源；该 overlap 本身不作为错误。
- 本轮新增框架 API 有目标源码/参考项目证据。
- Editor API 与目标 Unity 版本一致。

### Direct-Run Gate

- 项目声明的 runtime-critical 资产全部已落盘。
- 完整包不要求 Tools 菜单或首次 import 自定义生成。
- Build Settings/FrameSettings/UI 读取路径闭环。
- 若未真实 Unity Compile/Play，状态必须是 UNVERIFIED。

### Artifact Gate

审计对象必须是最终准备交付的 staged root，而不是修改前目录或中间工作目录。

- 完整包解压后本身就是目标工程，不依赖上一版残留文件。
- 增量包的删除清单可以把上一版精确变成当前版。
- ZIP 内不含 `Library/Temp/obj` 等非源码缓存。
- 最终 staged root 再跑 Structure/Migration/UI/Display/Excel/Resource/Dependency 七类 audit。

## 2.5.0 新增 Manifest / Gate

### UI Generator Contract

每张 Layout 除 UI Matrix 外再记录：

- Prefab root UGUIGenerator / Canvas。
- LayoutScript 四个 auto-generate region。
- `generate from:` 来源。
- `LayoutRegisterHotFix` 注册。
- GBR LayoutScript 引用。
- 官方 Unity UGUIGenerator 是否真实执行。
- Font/TMP FontAsset/Sprite/Material 引用状态。

### FrameSystem Dependency / Destroy Matrix

每个项目 FrameSystem 至少记录：

- 依赖哪些其他 System/Manager。
- init/update/destroy order。
- `registeFrameSystem<T>()` callback 是否能处理 null。
- 依赖解绑放在 `willDestroy()` 还是 `destroy()`。
- 若 `destroy()` 仍访问其他 System，必须记录目标版本 destroy order 源码证据或 allowlist。

### Static API Access Evidence

API Provenance Matrix 增加 Access Mode：

```text
fully-qualified / inherited / using static
```

避免“API 在源码存在，但调用文件缺 using static”直到 Unity 编译才报 `CS0103`。

### Direct-Run Runtime Template / Scene Gate

MyFramework 1.1.12 FullInstall 额外确认：

- `Assets/Resources/Settings/FrameSettings.asset`。
- `Assets/GameResources/KeyFrame/Keyframe.prefab`。
- 项目全部 runtime Scene 已在 Build Settings 启用。
- 当原始输入不含完整工程根时，完整工程骨架来自同版本官方 ProjectTemplate 或已验证参考工程，而不是随意拼装。

### UI/Lifecycle Gate

- `audit_myframework_ui.py` 通过。
- UI God FrameSystem = 0/明确白名单。
- 手工/fallback Layout registration = 0。
- known bad builtin font refs = 0。
- static API visibility candidates = 0。
- FrameSystem callback(null) unsafe = 0。
- cross-System destroy dependency = 0/有源码证据白名单。
- LayoutScript `resetProperty()` candidates = 0/有目标版本源码证据白名单。

Artifact Gate 现在要求最终 staged root 运行 **Structure / Migration / UI / Display / Excel / Resource / Dependency 七类审计**。

## 2.6.0 新增 Display / Data / Generator Ownership Gate

Manifest 必须增加：

- Display Profile Matrix：orientation、reference viewport、design resolution、FrameSettings、start UGUIRoot、Layout roots、Safe Area、World Camera framing/coverage。
- Excel Toolchain Matrix：硬编码旧来源、CSV、ED/Excel、bytes、官方工具执行证据、运行 query。
- Legacy Debt 增加 `Manual generator binding candidates / Display profile mismatch / Hardcoded stable business data / Excel generator fallback markers`。

阶段顺序建议：Display Profile 先于 UI 大规模布局；Stable Business Data Inventory 先于 Shop/Career 等最终 polish。


### 3.1.0 新增 Effective Parity / Generated Region Gate

- 若有上游真值源：Manifest 必须保存 Effective Behavior Matrix，记录初始定义、后续覆盖、最终有效值和 Unity 目标实现。
- 未运行官方 Generator 的迭代：上一版→当前版 auto-generate regions changed = 0。
- 运行官方 Generator 的迭代：记录输入 Prefab/Table、工具执行证据、generated diff 与 Unity import/compile 结果。
- 保存/协议迁移必须单独记录字段 presence 语义，不能只记录最终数值默认值。
- Procedural Render/Effect parity 如进入本轮范围，报告热路径 GC 和 deterministic seed 保护。
