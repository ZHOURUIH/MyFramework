# MyFramework 能力图

以下是当前实战验证过的核心入口。**仍需以项目实际安装版本源码为准**，不能假设未来版本 API 完全相同。

## ClassObject / ClassPool

`ClassObject` 生命周期：

- 构造后默认 destroyed。
- 从池分配后框架设置为 active，并调用 `onCreate()`。
- `destroy()` 标记并释放当前生命周期资源。
- 回池后 `resetProperty()` 清状态。
- `isDestroy()` 判断普通框架对象有效性，不再依赖 Unity Object 隐式 null。

常用：

```csharp
T obj = CLASS<T>();
UN_CLASS(ref obj);
List<T> snapshot = LIST<T>();
UN_LIST(ref snapshot);
```

### 重要限制

`UN_CLASS_LIST(HashSet<T>)`/List/Dictionary 的实现会遍历集合调用对象 destroy。如果对象的 `destroy()` 会从同一个集合注销自己，就可能发生“遍历期间修改集合”。此时应先复制到 `LIST<T>()` 快照，再逐个 `UN_CLASS`。

## FrameSystem

生命周期：

- `init()`
- `update(float)`
- `willDestroy()`：所有系统正式 destroy 前先执行，适合依赖其他系统仍存活的解绑。
- `destroy()`

FrameSystem 应表示真正的全局服务，不是“任何类都变 System”。

## SceneInstance 与 GameScene

### SceneInstance

表示 Unity 3D/2D Scene 实例，负责：

- root、Unity Scene、加载状态。
- init/onShow/onHide/update/lateUpdate。
- SceneSystem show/hide/load 生命周期。

### GameScene / SceneProcedure

表示**逻辑场景与流程状态机**，可拥有多个 Procedure，用于登录→大厅→战斗准备→战斗→结算等逻辑流程。

不要因为框架同时有二者，就强制项目两套都用。先判断原项目是否真的需要“Unity Scene 生命周期”和“逻辑流程状态机”两层。

## LayoutScript / WindowObject

`LayoutScript` 是业务布局脚本基类，典型顺序：

- constructor：创建 WindowObject wrapper 等。
- `assignWindow()`：由生成器绑定 Prefab 节点。
- `init()`：注册 collider/事件和初始化。
- `onGameState()`：每次进入游戏状态/显示周期初始化。
- `onShow()/onHide()`：显示生命周期。
- `destroy()`：基类会清事件、Command、WindowObject/Pool。

子界面优先 WindowObjectUGUI / WindowStructPoolBase，不要让多个业务 LayoutScript 继承出 UI 树。

## GBR

GBR 是高频全局对象引用入口，参考项目通常包含：

- ExcelTable。
- FrameSystem。
- SceneInstance。
- LayoutScript。

GBR 不应该成为业务状态黑板。

## ResourceManager / PrefabPoolManager

已验证参考项目使用：

- `mResourceManager.loadGameResourceAsync<T>()`
- `mPrefabPoolManager.initObjectToPool/initObjectToPoolAsync()`
- `mPrefabPoolManager.createObject/createObjectAsync()`
- `mPrefabPoolManager.destroyObject()`

优先复用真实资源系统与 PrefabPool，不再在业务散落 Unity 原生加载/实例化。

## EventSystem

常见：

- `listenEvent<T>(callback, listener)`
- 带对象 GUID 的事件监听。
- `pushEvent<T>()` / `pushEvent(param, id)`
- `unlistenEvent(this)`

事件对象和 listener 都有生命周期；重开场景时重点检查重复监听。

## DelayCmdWatcher / Command / Waiting

用于可取消的延迟、等待、逐帧流程。迁移协程/Rx/UniTask 时，首先保留原取消和回调语义；不要为了“零协程”改变 FixedUpdate 或首帧时序。

## Excel

典型结构：

- `EDFoo : ExcelDataT<EDFoo>`
- `ExcelFoo : ExcelTableT<EDFoo>`
- `ExcelRegister.registeAll()` 注册到 GBR。
- CSV/Excel 工具生成代码和 `.bytes`。

自动生成段由工具维护，不手工伪造。
