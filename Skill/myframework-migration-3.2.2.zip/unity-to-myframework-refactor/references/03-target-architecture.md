﻿# 目标架构

## 推荐目录（按项目实际裁剪）

```text
Assets/
  Scripts/
    Game/
      GameEntry.cs
      Game.cs
    HotFix/
      Common/
        GameBaseHotFix.cs   # GBR
      ClientSystem/
      ResourceSystem/
      AudioSystem/
      SettingsSystem/
      SceneSystem/
      GameScene/
      BattleSystem/
      Gameplay/
      UI/
      DataBase/Excel/
    Editor/
  Resources/
    Scene/start.unity            # 仅固定加载合同/白名单资源
    Settings/FrameSettings.asset
  GameResources/
    UI/UIPrefab/
    Prefab/
    Font/
    Audio/
    Data/
    Excel/
    ...
Excels/
```

目录是职责提示，不是要求所有项目都创建所有文件夹。

## 职责边界

### Game/GameEntry

只做框架启动和非常薄的平台入口；不堆业务逻辑。

### System

- 拥有跨场景或明确全局寿命的数据/服务。
- 对外提供业务命令和查询。
- 不把具体 Scene/UIView 当公共 API 泄漏。

### SceneSystem

- Unity Scene 对象、资源、相机、场景 root 的生命周期。
- 场景里的稳定引用绑定。
- 不承载大量玩法状态机。

### Gameplay / Mode

- 玩法规则、Actor、AI、生成、伤害、状态。
- 不直接控制 LayoutScript。
- 不依赖某个 UI 的节点路径。

### UI

- 显示、交互、短期动画。
- 通过 System 命令改变业务。
- 业务数据由 System/Mode 推送或查询。

### Excel

- 稳定业务配置。
- 不承担对象图反射绑定。

### Resources / GameResources

- `Assets/Resources` 是固定加载合同白名单，不是业务资源兼容仓库。
- 运行游戏资产主要进入 `Assets/GameResources`。
- Scene/Prefab 的稳定序列化引用可以保留，不要求为了“框架化”全部改成字符串路径加载。
- 移动资源必须保留 `.meta` GUID，并在最终 staged artifact 上审计。

## 依赖方向

推荐：

```text
UI -> Business System -> Mode/Gameplay -> Scene/Resource services
          ^                    |
          |---- events/data ---|
```

不推荐：

```text
UI -> BattleSystem.getView() -> ConcreteScene -> Gameplay
Gameplay -> GBR.mUIxxx -> UI
```

如果世界 HUD 需要 Scene 中 Transform，可构造纯 `BattleUIBinding` 一次性传给 UI，不让 UI 持有具体 Scene 类型。

## 迁移期兼容层

兼容层只能短期存在，而且必须有删除计划。以下兼容层通常应该最终删除：

- 旧 GameBase/SceneInstance facade。
- `getSceneComponent(path)` 万能入口。
- 旧 Manager 调新 System 或新 System 调旧 Manager 的双向转发。
- 仅为维持旧函数名存在的空方法。
- 旧 Excel 表与新 Excel 同时运行。

每轮报告列出“仍存在的兼容层”和预计删除条件。

另外，`LegacyRuntimeDebt`、`RecoveredSourceReference`、旧资源完整副本、Resources 兼容仓库都属于兼容层的一部分；不能因为它们“只是目录/资产”就不计入 Legacy Debt。原版参考源码应移出运行 Assets，或明确 Editor-only。

## 2.6.0 Display / Data Layer 补充

目标架构额外包含两个跨模块合同：

```text
Display Profile
  -> FrameSettings
  -> start UGUIRoot
  -> Layout Prefab Roots / Safe Area
  -> World Camera framing / backdrop coverage

Stable Business Data
  -> Excels/*.csv
  -> official CodeGenerator / CSVToBinary
  -> ED/Excel/bytes
  -> Profile/System/UI query
```

这两层不能被 UI 临时坐标补丁或 C# 静态 Catalog 取代。
