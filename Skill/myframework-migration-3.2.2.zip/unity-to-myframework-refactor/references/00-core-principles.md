﻿# 核心规则

## 1. 两个基线

MyFramework 重构同时存在两个不可混淆的基线：

- **行为基线**：任务指定的权威可运行结果。普通 Unity 重构默认是原 Unity 工程；若当前 Unity 被明确标注为不完整中间移植产物，则是用户指定的合法上游原版。决定“游戏应该怎么表现”。
- **架构基线**：当前版本 MyFramework 源码 + 已使用该版本的参考项目。决定“代码应该怎么组织”。

不要反过来：参考项目的玩法不能覆盖原项目行为，原项目的旧架构也不能成为保留反射和旧 Manager 的理由。

## 2. 不接受假迁移

以下都不算完成：

- 旧 MonoBehaviour 原样保留，只增加一个 MyFramework Manager。
- 新 System 只转发到旧 Singleton。
- 新 UI 调 `System.getView().oldScene.xxx()`。
- 为了编译新增同名空类型、兼容接口或万能 `getSceneComponent()`。
- 反射仍负责 Actor/Prefab 字段恢复，只是藏到 Registry 后面。
- Excel 只是把原 JSON/对象序列化成一列字符串。
- Prefab 仍在运行时生成，而用户要求直接可用 Prefab。
- 旧业务资源完整保留在 `Assets/Resources`，新代码只是在外面套 ResourceManager/System。
- `LegacyRuntimeDebt/RecoveredSourceReference` 仍参与运行编译或 Prefab/Scene 引用。
- 旧 MonoBehaviour 仅改名为 Binding/Bridge，但仍保存 AI、timer、Update、存档或资源加载。

## 3. 不接受“为了规范破坏行为”

禁止未经证据修改：

- FixedUpdate/Update 阶段。
- 随机调用次数和顺序。
- 伤害/攻击节拍。
- 物理材质、质量、重力、Joint 参数。
- Tween 曲线、循环和首帧行为。
- 输入按下/抬起顺序。
- AI 选择规则。
- UI 初始显隐、层级、遮罩和交互范围。

如果原行为本身像 bug，也先记录并询问/依据任务范围处理。

## 4. 优先证据，不凭“最佳实践”否定已有设计

修改理由应来自：

- Unity 编译错误。
- 可复现行为差异。
- 明确生命周期 NRE/重复回收/集合修改。
- 数据迁移差异。
- 内存/性能测量。
- 框架 API 真实约束。

“通常这样更好”不能单独成为改动依据。

## 5. 每轮改动控制变量

如果本轮目标是生命周期：尽量保持 Excel、UIPrefab、资源和玩法参数哈希不变。

如果本轮目标是 Excel：对代码运行逻辑做最小适配，并提供旧→新数据等价性。

这样才能知道差异来自哪一层。

## 2.6.0：显示合同和数据真值源也属于架构

- Display Profile（orientation / design resolution / Safe Area / World Camera framing）必须像启动链一样先冻结，再迁 UI；参考项目分辨率不是当前项目真值源。
- 稳定业务 Catalog/价格/奖励配置不能长期与 Excel 并存两份真值源；迁表后删除 C# 静态副本。
- Generator marker 不是代码所有权证据；绑定代码必须真正落在官方生成区并由 Prefab MemberData 驱动。


## 3.1.0：最终有效行为与保护区

- 多层 CSS/config/update/render 来源必须追到最终有效行为；第一次搜索命中不是 parity 结论。
- UI LayoutScript 不实现 `resetProperty()`；真实池对象仍按各自 reset 合同。
- 动画 parity 包含 timing-function、keyframe offset、layer/坐标空间，不能用“看起来接近”的替代。
- 未运行官方 Generator 的版本迭代，自动生成区必须 0 drift；运行了 Generator 则明确记录工具执行证据。
- 程序化 Mesh/Shader parity 不能以热路径 GC 回退为代价。
