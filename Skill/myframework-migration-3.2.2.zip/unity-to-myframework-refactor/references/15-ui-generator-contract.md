﻿# UGUI Generator 精确合同（MyFramework 1.1.12 快照）

UI 迁移的最终目标不是“手写代码看起来像 MyFramework”，而是让 **Prefab 元数据 → 官方 UGUI Generator → LayoutScript/注册代码** 成为真实工具链。

> 若目标工程 MyFramework 版本不是 1.1.12，必须重新核对 `UGUIGeneratorBase/UGUIGenerator/MemberData/UGUIGeneratorInspector/UGUIGeneratorUtility`。

## Generator 前置条件

当前版本源码确认：

- `UGUIGenerator` 必须挂在 `Canvas` 所在 GameObject；`OnValidate` 会拒绝非 Canvas。
- 生成代码必须在 Prefab Mode 中执行；Inspector 会通过 `PrefabStageUtility.GetCurrentPrefabStage()` 检查。
- 点击“生成代码”前，Generator 会排序 `mMemberList`、保存 Prefab、刷新 AssetDatabase。
- `checkMembers()` 会确保成员节点确实属于当前 Generator 根节点。
- 生成 UI 脚本同时会更新：
  - `Assets/Scripts/HotFix/UI/LayoutRegisterHotFix.cs` 的 auto-generate 区；
  - `Assets/Scripts/HotFix/Common/GameBaseHotFix.cs` 的 LayoutScript auto-generate 区。
- 如果已有 UI 脚本的 `// generate from:` 指向其他 Prefab，Generator 会要求确认；迁移时不能静默覆盖不同来源。

## MemberData 的真实生成规则

成员不是靠“扫描所有节点名称”自动猜出来，而是由 `UGUIGenerator.mMemberList` 明确描述。迁移时必须编辑 Prefab 上的 Generator 数据，再生成代码。

常见行为：

- 选中节点可通过 `GameObject/将节点添加到成员变量`（快捷键 `%W`）加入最近的 `UGUISubGenerator` 或 `UGUIGenerator`。
- 根节点不能作为成员加入。
- 同一个 GameObject 不能重复加入成员表。
- 名称以 `0` 结尾并满足数组命名规则时，Generator 会倾向静态数组并自动推导长度。
- 节点名包含 `Checkbox` → 倾向 `UGUICheckbox`。
- 节点名包含 `Tab` → 倾向 `UGUITab`。
- 节点名包含 `Progress` → 倾向 `UGUIProgress`。
- 节点名包含 `Button`，或节点仅有一个名为 `Text` 的子节点 → 倾向 `LegendButton`。
- 节点名包含 `Slider` → 倾向 `UGUISlider`。
- 节点名包含 `DropList/Dropdown` → 倾向 `UGUIDropList`。
- 带 `UGUISubGenerator` 的节点 → `SUB_UI`，类型来自该节点生成类。

这些只是当前版本默认推断；如果原项目控件行为与默认控件不等价，应在 Generator Inspector 中明确选择正确类型，不能为了让生成器“通过”改变原行为。

## 生成区合同

Generator 维护：

```text
// auto generate member start/end
// auto generate constructor start/end
// auto generate assignWindow start/end
// auto generate init start/end
```

迁移规则：

- **不得手写或长期维护自动生成区。**
- 业务代码写在生成区外。
- Generator 生成的 click callback 空壳可在非生成区完成业务实现；不要把业务逻辑塞进生成器本身。
- Prefab 节点变化后再次运行 Generator，并检查 diff，不能只手工同步 C#。

## Layout 生命周期合同

当前 `LayoutScript` 会统一管理：

- `WindowObjectBase`、WindowPool、WindowStructPool 的注册与 destroy。
- `onGameState()` 时 root WindowObject reset/onShow。
- `onHide()` 时取消 Command、清本地化、unlisten Event/Input，并按配置回收 UI Pool。
- `destroy()` 再次兜底 unlisten Event、interrupt Command、销毁 root WindowObject/Pool。

因此：

- WindowObject 创建后应由 Layout/父 WindowObject 持有，不要另建第二套手工 destroy owner。
- 页面隐藏态重置优先放 `onGameState/reset/onHide`，不要用旧 MonoBehaviour `OnEnable/OnDisable` 再维护一套。

## 页面完成门槛（Per-Layout Gate）

某张 UI 只有同时满足以下条件才能标记“已完成 MyFramework UI 迁移”：

1. Prefab 有正确 `UGUIGenerator`/必要 `UGUISubGenerator` 元数据。
2. Generator 已实际运行，并产出/更新脚本和注册自动段；若当前环境不能运行 Unity Generator，必须明确标记“结构已迁，Generator 未验证”，不能写“已完全生成”。
3. Layout 业务不再依赖旧字符串 Action Router。
4. 业务节点不再依赖 `Transform.Find`/`Node("a/b")` 作为长期主访问方式。
5. 按钮/Slider/Scroll/Input 等进入 MyFramework 控件或有明确“原行为无法等价”的例外记录。
6. Prefab 上旧 UI Runtime/Bridge 组件已删除，且无 Missing Script/悬空 fileID。
7. 页面 show → interact → hide → show 第二次状态正确。
8. 页面视觉/动画/输入与原版基线一致。

如果只完成 3~6 而没有真实 Generator 运行，应报告为“Native Layout 结构迁移完成，Generator 验证待执行”，而不是“UI Generator 完成”。


## Runtime UI Prefab 路径合同

UGUI Generator 的代码生成路径与 LayoutManager 的运行时 Prefab 加载路径是两个不同维度，二者必须同时闭环。

MyFramework 1.1.12 当前实战确认正式 UI Prefab 目录为：

```text
Assets/GameResources/UI/UIPrefab
```

不能仅因为 Editor Builder 成功生成了 Prefab，就把它放在：

```text
Assets/GameResources/UI/Prefab
```

然后声称 UI 资源闭环。最终必须读取目标版本 `LayoutManager`/路径常量确认实际加载目录。

对于用户要求 Direct-Run 的完整包，目标 UI Prefab 必须已经物理存在于最终 staged root；Generator/Builder 可以保留做维护，但不能作为首次运行前置条件。

## 2.5.0：四层 Generator 合同与 UI 架构补充

仅“Prefab 上有 UGUIGenerator”或“LayoutScript 里有 auto generate marker”都不够。正式 UI 迁移必须同时验证：

```text
Prefab UGUIGenerator / MemberData
        ↓
LayoutScript auto-generate regions + generate-from source
        ↓
LayoutRegisterHotFix auto-generate set
        ↓
GBR LayoutScript auto-generate set
```

四层集合必须一致。任何 `LayoutMigrationBootstrap`、fallback `registeLayout`、`GetLoadedLayout<T>()` 长期桥接都属于未完成迁移。

离线 Python/Editor 外脚本可以：

- 审计 Prefab MemberData。
- 预演 Generator 结果。
- 检查 marker/注册集合。
- 辅助修复 Prefab 元数据。

但**不能**因为离线脚本把 C# auto-generate 区写成与 Generator 类似，就声明“官方 UGUIGenerator 已执行”。没有 Unity Editor 真实执行证据时，状态必须是：

```text
STRUCTURE_READY
GENERATOR_UNVERIFIED
```

### 禁止 UI God FrameSystem

LayoutScript 是页面 owner。默认职责分布：

- SceneProcedure/业务流程：决定何时 `LT.LOAD/LOAD_TOP/HIDE/UNLOAD`。
- LayoutScript：页面成员、页面点击、页面短生命周期表现。
- Business System：玩法状态、存档、跨页面业务规则。

禁止创建 `XXXUISystem : FrameSystem` 来统一管理多个页面的加载、点击、Popup 类型、页面 refresh、存档计时、focus/input。真正全局 Toast/Loading/Guide 可单独存在，但必须职责单一并明确白名单。

### UI 序列化资源合同

Generator 只负责窗口绑定，不会替你证明 Font/Sprite/Material 引用有效。每个 Prefab 还必须检查：

- `UnityEngine.UI.Text.m_Font` / TMP FontAsset。
- Image Sprite。
- Material。
- Atlas/Font fallback。
- Missing Script / Missing serialized object。

CrushYard 实战中错误的 default Arial builtin 引用导致 137 个 Text 全部不可见；因此 `audit_myframework_ui.py` 会检查当前已知错误 builtin font 模式。

### 静态 UI Contract Audit

2.5.0 新增：

```bash
python scripts/audit_myframework_ui.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json
```

它至少检查：

- Generator Prefab 数量。
- 每 Prefab root Generator 数量与 Canvas 归属。
- 对应 LayoutScript 是否存在。
- member/constructor/assignWindow/init marker 与 generate-from source。
- LayoutRegister/GBR Layout 集合是否一致。
- 手工 `registeLayout` fallback 候选。
- UI God FrameSystem 候选。
- 已知错误 builtin font 引用。

该脚本仍不能证明官方 Generator 已真实运行，Unity evidence gate 保持不变。

## 2.6.0：生成代码所有权不只看 marker

LayoutScript 存在四个 auto-generate marker 仍不代表 Generator 合同正确。至少进一步检查：

- `newObject(...)` 是否只存在于 Generator `assignWindow` 自动区（明确业务动态节点除外并记录例外）。
- 成员 WindowObject 的 `.assignWindow(...)` 是否只在自动绑定区。
- Generator-owned `new(this)` 是否在 constructor 自动区。
- root `UGUIGenerator.mParentType` 是否为实际 Layout 基类；当前 1.1.12 普通 Layout 默认 `LayoutScript`。
- `UGUISubGenerator.mParentType` 是否非空且与真实子窗基类一致。

业务点击需要 index/上下文参数时，不强迫 Generator 生成无参 click。正确做法是：Prefab MemberData 关闭自动 click，只生成强类型成员，在业务区注册参数化 callback。这样既保持 Generator ownership，也避免双重注册。

`audit_myframework_ui.py` 2.6.0 新增 `manual_generator_binding_candidates` 与 parent type 检查。


## 3.1.0：LayoutScript 生命周期不使用 resetProperty

UGUIGenerator 负责 Layout 的成员/构造/assign/init 绑定，不意味着 LayoutScript 是 ClassObject 池对象。项目 UI 页面脚本不要额外实现 `resetProperty()`。页面本次显示状态应在 `onGameState()/onHide()/setData()` 等业务区处理，避免出现 Generator/UI 生命周期之外的第二套 reset 路径。

如果本轮只改业务区而未运行 Generator，使用：

```bash
python scripts/compare_myframework_generated_regions.py <previous-root> <current-root>
```

自动区应保持 0 changed。
