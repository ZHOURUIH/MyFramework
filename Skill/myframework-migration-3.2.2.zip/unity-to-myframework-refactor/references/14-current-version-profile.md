﻿# 当前 MyFramework 版本能力 Profile

本文件记录本次实战读取到的框架版本，用于避免“凭记忆写 API”。它是**版本快照**，不是永恒 API 文档。

## 已核对版本

- Package：`com.zhourui.myframework`
- Version：`1.1.12`
- Fingerprint：`265d8413b933ba07df40bdbb5781b498497dbc70`
- `package.json` 基础依赖：UGUI、TextMeshPro、Newtonsoft Json。
- 实际项目还可能通过 asmdef/功能模块依赖 HybridCLR、Obfuz、TTWebGL、QiNiu 等外部 Assembly；必须读取目标项目真实 `Packages/manifest.json`、embedded Packages 和 asmdef，不能因为 package.json 未列出就自行造同名兼容 Assembly。

如果目标工程安装版本或 fingerprint 不同，必须重新读取该工程实际 PackageCache/Packages 源码，并在 `MIGRATION_PLAN.md` 中记录差异。禁止因为本文件存在就跳过源码确认。

## 当前版本已存在的主要能力

迁移前优先确认下面已有能力能否表达原行为，再决定新增项目层封装：

| 领域 | 当前框架入口/模块 | 迁移原则 |
|---|---|---|
| 启动 | Game / GameEntry / GameHotFix | 保持唯一启动链，不建第二套 bootstrap |
| 全局系统 | FrameSystem | 仅真正跨场景/全局职责使用 |
| 普通对象 | ClassObject / CLASS / UN_CLASS | 必须 owner + reset + destroy 闭环 |
| Scene | SceneSystem / SceneInstance | 管 Unity Scene 实例与稳定引用 |
| 逻辑流程 | GameScene / SceneProcedure | 仅有真实流程状态机时使用 |
| UI | LayoutScript / WindowObjectUGUI / WindowStructPool* / myUGUI* | Prefab + Generator + 强类型成员 |
| 输入 | GlobalTouchSystem / InputManager | UI/输入优先走框架输入；Unity 消息只保留薄 Bridge |
| 资源 | ResourceManager | 统一资产加载，不在业务散落 Resources.Load |
| Prefab | PrefabPoolManager | 高频 GameObject 统一 spawn/unspawn |
| 音频 | AudioManager / `AT.MUSIC` / `AT.SOUND_2D/3D` | 不在业务临时 AddComponent<AudioSource> |
| 事件 | EventSystem | listen/unlisten 与 owner 生命周期绑定 |
| 延迟/命令 | DelayCmdWatcher / CommandSystem / WaitingManager | 保留取消/首帧/回调顺序 |
| Tween | TweenerManager | 保留曲线、循环、Yoyo、时缩放、break 语义 |
| 配置 | ExcelManager / ExcelDataT / ExcelTableT / ExcelRegister | 生成代码 + CSV→bytes 真落地 |
| 图集 | AtlasManager | 不自建重复 atlas loader |
| 本地化 | LocalizationManager | UI 文本本地化优先接框架生命周期 |
| 时间 | TimeManager | 跨系统时间/定时语义优先复用 |
| 状态 | StateManager | 有明确状态机需求时复用，不为“框架化”强行套 |
| 关键帧 | KeyFrameManager / PathKeyframeManager | 对应原项目关键帧/路径动画时优先核对 |
| 特效 | Effect | 高频特效优先核对现有 Effect 能力和池化 |
| 屏幕方向 | ScreenOrientationSystem | 横竖屏/方向生命周期集中处理 |
| 对象存储 | ObjectStorageSystem | 需要全局对象索引时确认 owner/索引边界 |
| 异步组 | AsyncTaskGroup / AsyncTaskGroupManager | 多异步任务聚合时优先复用 |
| 红点 | RedPointSystem | 有红点需求时不要另造依赖图系统 |
| Shader | ShaderManager | 项目有运行时 Shader 管理需求时先核对 |
| 登录/购买/网络 | Login / Purchase / Net | 平台/联网项目优先按框架现有接口接入 |
| 资源版本/热更 | AssetVersionSystem / HybridCLRSystem | 依项目发布链决定，不在普通玩法层直接依赖 |

## 版本化能力确认规则

对于每个待迁职责，在 `PROJECT_MIGRATION_MANIFEST.md` 中记录：

1. 原实现职责。
2. 当前版本框架候选能力。
3. 从源码确认到的具体 API/生命周期。
4. 参考项目实际用法。
5. 是否直接使用、项目层薄封装、或保留必要 Unity Bridge。
6. 若不用已有框架能力，写明原因（行为不等价/API 缺失/目标平台限制）。

没有完成这一步，不应新增新的 Manager、Pool、Audio、Input、Tween、UI Runtime 或 Resource wrapper。

## 1.1.12 必须特别注意的硬 API 合同

### FrameSystem 实际继承关系

HotFix 层：

```text
FrameSystem : ComponentOwner : CommandReceiver : ClassObject ...
```

因此 `FrameSystem.update/lateUpdate/fixedUpdate` 的 `base` 调用不是空形式：`ComponentOwner` 会更新其 GameComponent。项目 System 覆盖这些方法时必须调用匹配 `base.xxx(...)`，否则既会触发 `BASE001`，也可能跳过组件生命周期。

### HotFix Framework 的系统顺序

`GameFrameworkHotFix.registeFrameSystem<T>(callback, initOrder, updateOrder, destroyOrder)` 会把系统分别放入 init/update/destroy 列表并排序。应用层有严格顺序依赖时优先使用这些 order，而不是创建一个 RuntimeSystem 手工 fan-out 所有 System。

### `getOrAddComponent` 同名遮蔽

当前版本同时存在：

```csharp
ComponentOwner.getOrAddComponent<T>() where T : GameComponent
ComponentOwner.getOrAddComponent<T>(out T com) where T : GameComponent
FrameBaseUtility.getOrAddComponent<T>(GameObject go) where T : UnityEngine.Component
FrameBaseUtility.getOrAddComponent<T>(GameObject go, out T com) where T : UnityEngine.Component
```

在 `FrameSystem/ComponentOwner` 子类中需要给**别的 GameObject**增加 Unity Component 时，必须显式写：

```csharp
FrameBaseUtility.getOrAddComponent<Camera>(go);
```

不要依赖 `using static FrameBaseUtility` 后的未限定调用，否则实例成员解析可能导致 `CS1620` 等错误。

### GameFrameworkHotFix 的应用级回调

当前版本提供：

```text
registeOnApplicationQuit / unregisteOnApplicationQuit
registeOnApplicationFocus / unregisteOnApplicationFocus
```

项目 System 若只需要 Focus/Quit 生命周期，优先用此接口，不新增 MonoBehaviour Bridge。

### 启动参考链

当前三个参考项目共同结构为：

```text
GameEntry : GameEntryBase
Game : GameFramework
AOT LaunchScene : GameScene
LaunchScene* : SceneProcedure
HybridCLRSystem.launchHotFix(...)
GameHotFix : GameHotFixBase<GameHotFix>
HotFix start GameScene = getStartGameSceneType()
```

迁移项目不得用 `Main.unity + Root MonoBehaviour` 替代这条链，仅因为它更容易直接 Play。

### START_SCENE 精确合同

当前 `FrameDefine.START_SCENE`：

```text
Assets/Resources/Scene/start.unity
```

MyFramework `MenuInit` 会在初始化时检查这个精确路径，在该场景根节点查找名为 `GameEntry` 的对象，自动挂接项目 `GameEntry` 类型，并把该场景放到 Build Settings 第一位且启用。因此 1.1.12 项目不能用任意 `Main.unity/Boot.unity` 替代 start scene 后仍声称遵循框架标准结构。

### Resources 固定路径与白名单

当前版本已确认 `START_SCENE` 固定为：

```text
Assets/Resources/Scene/start.unity
```

当前 1.1.12 源码同时定义 `FrameBaseDefine.RUNTIME_SETTINGS_RES_PATH = "Settings/FrameSettings.asset"`，`FrameSettings.get()` 会通过 `Resources.Load<FrameSettings>` 读取该路径，因此 `Assets/Resources/Settings/FrameSettings.asset` 是已确认固定项。目标版本仍必须重新核对源码并写入项目 `resources_allowlist`。除这些源码证明的固定合同外，业务 Prefab/ScriptableObject/UI/Bot/字体材质不得因为“方便加载”长期放在 `Assets/Resources`。

资源移动到 `Assets/GameResources` 时，保持原 `.meta` GUID；稳定 Scene/Prefab serialized reference 不需要改成字符串路径加载。


### 1.1.12 实战新增 API 证据（RagdollFactory）

以下用于避免凭记忆写框架 API，仍然必须以目标工程源码为最终真值。

#### `FrameUtility.changeProcedure<T>()`

当前实战 `SceneProcedure` 切换使用 `FrameUtility` 的静态入口。调用文件若不显式限定，需要：

```csharp
using static FrameUtility;
```

不能因为 `CS0103` 就新增自己的 `changeProcedure<T>()` helper。

#### `FrameBaseUtility.isEditor()`

当前版本 `isEditor()` 来自 `FrameBaseUtility`：

```csharp
using static FrameBaseUtility;
```

或显式调用 `FrameBaseUtility.isEditor()`。

#### `SceneProcedure` 无通用 `finish()` 合同

当前版本 Procedure 退出由 `GameScene`/Procedure 生命周期推进，清理进入 `onExit/exit/willDestroy/destroy` 等真实合同。不要凭其他状态机框架经验写：

```csharp
finish();
```

若业务需要“完成 Procedure”，先读该版本 `SceneProcedure/GameScene` 源码确认正式切换方式。

#### UI Prefab 读取目录

当前 1.1.12 实战确认 `LayoutManager` 使用：

```text
Assets/GameResources/UI/UIPrefab
```

迁移 Builder/资源目录必须与实际读取路径一致；`UI/Prefab` 与 `UI/UIPrefab` 不是可互换的“风格差异”。

### 正式依赖不得用 fake asmdef 代替

如果目标项目已经有：

```text
Packages/com.code-philosophy.hybridclr/Runtime/HybridCLR.Runtime.asmdef
Packages/com.code-philosophy.obfuz/Runtime/Obfuz.Runtime.asmdef
```

不得再在 `Assets/Plugins/MyFrameworkCompatibility` 创建同名 Assembly。最终 staged root 必须扫描 asmdef `name`，duplicate = 0。

## 1.1.12 CrushYard 实战新增合同（2.5.0）

### `registeFrameSystem<T>()` callback 在销毁后会收到 `null`

当前 `GameFrameworkHotFix.destroy()` 源码顺序为：

```text
mOnDestroy
-> foreach FrameSystem: willDestroy()
-> foreach FrameSystem: destroy()
-> mFrameCallbackList.Remove(...)
-> callback?.Invoke(null)
```

`destroyComponent<T>(ref T com)` 同样在 `com.destroy()` 后执行 callback(null)。

因此应用层写：

```csharp
registeFrameSystem<FooSystem>(com =>
{
    mFooSystem = com;
    com.setInitOrder(...);
});
```

在销毁阶段不安全。任何对 `com` 的解引用必须有非空保护。

### `willDestroy()` 在任何 FrameSystem 真正 `destroy()` 前统一执行

当前版本会先遍历 destroy list 调全部 `willDestroy()`，再进入真正 `destroy()`。因此需要其他 System/Manager 仍存活的解绑/归还，优先放 `willDestroy()`。

如果必须在 `destroy()` 中调用其他 System，必须从目标源码确认 destroy order 并在项目配置中白名单，同时保持 null-safe fallback。当前版本内置 `ResourceManager` 注册 destroyOrder=3000、`PrefabPoolManager`=2000、Class/List/Dictionary/Array pools 更晚；这只是 1.1.12 快照，不得跨版本假设。

### Static API 访问方式

当前实战进一步确认：

```text
changeProcedure<T>() / changeProcedureDelay<T>() -> FrameUtility
mEventSystem / mGameFrameworkHotFix              -> FrameBaseHotFix
isEditor()                                       -> FrameBaseUtility
mGameSceneManager / mLayoutManager / mResourceManager
  -> Frame_Game 使用 FrameBase；Frame_HotFix 使用 FrameBaseHotFix
```

API Provenance 必须记录 owner 和调用文件如何访问它；仅写“API 存在”不足以防止 `CS0103`。注意后三个全局成员在 AOT/HotFix 各有真实声明，审计不能机械固定成 `FrameBaseHotFix`。

### KeyFrame Runtime Artifact

当前 `FrameDefine.KEY_FRAME_FILE`：

```text
KeyFrame/Keyframe.prefab
```

`KeyFrameManager.init()` 会通过 `ResourceManager.loadGameResourceAsync<GameObject>(KEY_FRAME_FILE, ...)` 加载它，因此标准 1.1.12 FullInstall 必须包含：

```text
Assets/GameResources/KeyFrame/Keyframe.prefab
```

官方 `ProjectTemplate~` 已提供该资产。组装完整工程时不能只拿模板的 `Packages/ProjectSettings` 或部分 Assets 而漏掉它。

`ProjectTemplate~` 目录中的 `Game/HotFix/AutoGenerated.asmdef` 也是模板输入，不属于最终工程当前编译 Assembly；duplicate-asmdef 审计必须排除此类 `~` 模板目录。

### Runtime Scene 与 Build Settings

`SceneSystem` 最终仍由 Unity SceneManager 加载运行 Scene。除 `start.unity` 必须第一位外，项目实际运行期会加载的 Scene 也必须已加入 `ProjectSettings/EditorBuildSettings.asset` 并启用。完整包不能要求用户手工 Add Open Scenes。

### UGUI 内置 Arial 序列化引用

CrushYard 实战确认错误引用：

```text
m_Font: {fileID: 12800000, guid: 0000000000000000f000000000000000, type: 0}
```

会造成 UGUI Text 不显示。Unity 2022.3 默认 Arial 常见正确内置引用：

```text
m_Font: {fileID: 10102, guid: 0000000000000000e000000000000000, type: 0}
```

自定义 Font/TMP FontAsset 不套用该固定值，应检查其真实 GUID 和导入结果。

## 1.1.12 HeistHop 实战新增合同（2.6.0）

### FrameSettings 不携带通用“横版默认值”

`FrameSettings.asset` 的 UISize 是项目显示合同，不是框架固定 1920x1080。必须从目标项目/原版证据确定；参考项目中的 1920x1080、2436x1125 等只能说明参考项目自身配置。

### 包装 UI 类型不能假设底层 API

MyFramework UI 包装器与底层 `myUGUIObject/Transformable` 的能力边界必须按继承源码确认。遇到 `CS1061` 时不能因为“底层应该有 setScale”就给 wrapper 补 extension；应找真实 root/owner API 或调整业务表达。

### 工具方法 owner 仍需显式核对

类似 `findGameObject` 的 helper 可能属于 `FrameBaseUtility` 而不是当前继承类型。出现 `CS0103` 时按 API Provenance 规则确认声明 owner，再决定 fully-qualified/using static。

### CS0051 / CS0052 优先收窄实现成员

当 `public/protected` 成员暴露 `internal` 实现类型时，先判断该成员是否只是类内部 cache。若外部无需访问，优先改为 `private`，不要为了消除编译错误把内部实现类型扩大成 public API。
