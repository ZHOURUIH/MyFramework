# 事件、异步、动画、输入与物理桥

## EventSystem

### 注册/注销必须成对

```csharp
mEventSystem.listenEvent<EventX>(onX, this);
...
mEventSystem?.unlistenEvent(this);
```

重点验证：

- UI hide/show 多次。
- Scene 重开。
- Mode 替换。
- owner 提前销毁。

如果第二局回调两次，多半是监听未注销或旧对象未回池。

## Delay / Coroutine / Rx / UniTask

迁移要保存语义：

- 是否注册后立即执行一次。
- 首次 delay 前还是立即。
- Update 还是 FixedUpdate。
- 取消后是否还触发 finally/完成回调。
- Take(1)/First 的一次性语义。
- 对象销毁时取消。

协程不是必须“清零”的 KPI。MyFramework 已有桥接或原行为强依赖 Unity yield 时，可保留薄桥，但 owner 必须能取消。

## Tween

核对：

- Ease 公式。
- Loop 次数。
- Yoyo。
- 超过一个周期的 delta 是否正确消耗。
- unscaled/scaled time。
- 终值是否精确落点。
- break 时是否执行完成 callback。

“duration 一样”不能证明动画一致。

## 输入

检查：

- Down/Up 同帧。
- Hold。
- Pointer ID / touch。
- Drag threshold。
- 世界坐标与屏幕坐标。
- EventSystem/GlobalTouchSystem 的穿透规则。

## Unity 物理 Bridge

MyFramework 普通对象无法直接收到 Unity `OnCollisionEnter2D` 等消息时，可以保留 MonoBehaviour Bridge。

Bridge 规则：

- 只持有 owner/ID。
- OnCollision/OnTrigger/OnJointBreak 只转发。
- 不保存血量、伤害、AI 等业务状态。
- owner 销毁时 Bridge 清引用或跟 GameObject 一起销毁。

错误示例：为了去 MonoBehaviour，把 `onTriggerEnter(Collider2D)` 写成普通基类 override，但基类根本没有该 virtual 方法。这会直接造成编译错误，而且说明迁移层级判断错误。

## 物理时序

不能随意把：

```text
FixedUpdate -> Update
OnCollision -> 手工距离检测
Rigidbody2D -> Transform.Translate
```

除非原项目本身就是这么实现，或者有可验证等价方案。

## 3.2.0 运行合同补充

3.2.0 必读 [周期 / 输入层 / 动画通道](30-cadence-ui-input-animation.md)：每个 timer、modal、Tween/hold 独立建模，刷新由真实业务变化驱动。
