# 上游真值源 / 最终有效行为 / 运行表现 Parity

本章适用于一种常见场景：已经存在一个普通 Unity 工程，但它本身是从更上游实现迁移而来，而且用户明确要求“继续重构为 MyFramework，同时仍与上游原版保持一致”。例如：网页/H5 已经先转成 Unity，再做 MyFramework 重构。

本 Skill **仍不负责网页抓取或首次网页→Unity 复刻**；本章只规定：当上游实现已经合法提供并被指定为 parity 真值时，MyFramework 重构如何避免把中间 Unity 版本的历史偏差固化下来。

## 1. 真值优先级必须由任务事实决定

默认普通 Unity 重构：

1. 原 Unity 工程目标版本下的真实运行结果。
2. 原 C# / Scene / Prefab / serialized data。
3. 测试、日志、截图。
4. MyFramework 参考项目仅作为结构范式。

但如果用户明确说明 Unity 工程是**尚未完全对齐的中间移植产物**，并提供更上游的授权源码/运行证据，则优先级改为：

1. 用户指定的上游可运行行为/源码。
2. 上游运行截图、日志、数据。
3. 当前 Unity 中间工程（用于确认已经迁移了哪些职责）。
4. MyFramework 参考项目仍只决定结构表达。

禁止因为“现在 Unity 里就是这样”而保留一个已经被上游源码证明错误的行为。

## 2. Parity 看“最终有效值”，不能看第一次搜索结果

对网页/多层样式/多阶段刷新来源，第一次找到的值往往不是最终值。至少追踪：

```text
CSS / stylesheet load order
selector specificity
!important
later rules
JS class/style mutation
render/update/retention 等后续刷新函数再次写入
默认 CSS timing-function / display / opacity 行为
```

同理，JS 里一个字段可能在 `updateUI()` 先写一次，又被 `retentionUI()` 覆盖。Parity 真值是**这一帧最终呈现给用户的有效状态**，不是中间赋值。

项目级 Parity Matrix 应记录：

| Item | 初始定义 | 后续覆盖 | 最终有效值/行为 | 证据 | Unity 实现 |
|---|---|---|---|---|---|

## 3. 动画必须对齐时序曲线，不用“差不多”的 Tween

表现一致至少包含：

- duration。
- delay / stagger。
- keyframe offset。
- easing / CSS timing-function。
- scale/position/rotation/alpha 的关键值。
- 动画结束后的基线状态。
- Reduced Motion / Disabled / Auto 等分支。

例如网页未显式声明 timing-function 时，CSS 默认 `ease` 也属于真值；不能因为 Unity `Lerp` 方便就默认线性。

如果当前 Prefab 缺少实现某种视觉状态所需的真实节点（Glow/Badge/Track/Fill 等），不要用“改图标颜色/缩放一下”近似冒充。应标记为 Prefab + 官方 UGUIGenerator 待闭环。

## 4. 坐标空间和渲染层级属于表现合同

必须区分：

```text
World camera / world RenderTexture
HUD Canvas
Overlay / FloatLayer
Popup / Modal
Top-most feedback layer
```

如果上游效果属于 HUD 上方的独立 Overlay，放进 World RenderTexture 后再用反向位移补偿只能算过渡实现，不能声明像素级层级一致。

需要核对：

- z-index / sorting / Canvas order。
- 是否随 world shake。
- 是否受 camera perspective/FOV。
- 是否被 HUD/Mask 裁切。
- 输入穿透与 raycast。

## 5. Procedural Mesh / Shader parity 不只看“形状大概一样”

程序化渲染至少核对：

- primitive topology。
- 圆柱/杆件是否有端盖。
- segment 数。
- flat/smooth normal。
- winding。
- Shader `Cull`。
- depth/shadow pass 的 culling。
- low-detail 阈值与降级规则。
- 颜色与 alpha。
- deterministic seed / RNG 调用顺序。
- 碎片 dropout / subdivide / distort 算法。

“Unity Cylinder 看起来接近网页 rod”不是完成证据。

## 6. Parity 不能成为热路径 GC 回退的理由

把上游算法移到 C# 时，保持行为不代表必须照搬其内存分配方式。

优先：

- 源几何缓存与最终状态缓存分层。
- cache key 使用值类型，避免每帧字符串拼接。
- 高频路径避免临时数组、`List<T>`、LINQ、`ToArray()`。
- 确定性噪声/随机可以用无分配函数。
- 只有行为依赖调用顺序时才保留 RNG 消耗顺序。

完成 parity 后仍需跑 GC/CPU 回归门禁。

## 7. 存档字段“缺失”和“值异常”是两个语义

很多旧实现会写：

```text
字段不存在 -> old-version fallback
字段存在但小于 0 -> clamp 0
```

如果 C# 反序列化后都变成同一个默认 sentinel，就会改变兼容行为。

要求：

- 先确认原 schema 是否允许改。
- 不允许改 schema 时，可增加 `[NonSerialized]` 的 `mHasXxx` presence marker。
- load/parser 阶段记录字段是否真实出现。
- clean/migrate 阶段分别执行 missing fallback 与 invalid clamp。

不要为了方便把“字段缺失”映射成业务可合法出现的数值。

## 8. 数字格式和 Culture 也属于可见行为

如果上游 JS/协议固定使用 `.` 小数点、固定大小写或固定格式，C# 必须显式使用对应 Culture（常见为 `InvariantCulture`）。

尤其检查：

- 倒计时。
- 倍率。
- 百分比。
- 存档/协议字符串。
- CSV/文本导出。

不能只在开发机英语区域验证。

## 9. 字体以真实字形为准，不以名字为准

如果合法上游资产包含 WOFF/WOFF2 等 Web 字体，而 Unity UI 需要 TTF/OTF，可以做**格式适配**，但应保留原字形来源。

建议：

- WOFF2 → TTF/OTF 时记录来源和转换工具。
- Variable Font 在 legacy `UnityEngine.UI.Text` 上优先实例化为明确 weight 的静态字体。
- 保留/验证 fallback glyph，特别是 `★ / ● / ↗ / ⬆` 等符号。
- 标题字体/正文字体按上游真实用途逐节点映射。

禁止为了“差不多”随意换一套相似字体后声明 parity。

## 10. 每轮迭代要做“保护区 diff”

如果本轮目标只改业务/表现，而没有运行官方 Generator，应比较上一版与当前版的自动生成区：

```bash
python scripts/compare_myframework_generated_regions.py <previous-root> <current-root>
```

期望：

```text
changed generated regions = 0
```

如果确实运行了官方 UGUIGenerator/Excel Generator，允许自动区变化，但必须记录：

- 哪个官方工具执行。
- 哪些 Prefab/Table 输入变化。
- 自动区 diff。
- Unity import/compile evidence。

不能把手工修改自动区混在视觉/业务 diff 里。

## 11. 完成状态必须分层描述

建议使用：

```text
SOURCE_PARITY_STATIC_PASS
GENERATOR_UNVERIFIED
UNITY_COMPILE_UNVERIFIED
PLAYMODE_UNVERIFIED
BUILD_UNVERIFIED
PIXEL_PARITY_UNVERIFIED
```

静态逐行对照通过只能说明源码层证据闭环，不能替代 Unity 真运行。

## 3.2.0 运行合同补充

3.2.0 的保护区比较器会拒绝无效目录/空覆盖；批准 diff 仍显示 changed 总数。详见 [证据覆盖](31-contract-audit-evidence-coverage.md)。项目历史报告不等于新版本验收，未运行官方 Generator 不能用 approval 为手工自动区变更补票。
