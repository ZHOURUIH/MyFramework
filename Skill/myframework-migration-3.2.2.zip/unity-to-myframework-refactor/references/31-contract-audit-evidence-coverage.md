# 运行合同审计 / 覆盖范围 / 证据可信度

3.2.0 保留原七类审计，增加 `audit_myframework_runtime_contracts.py`，并修复自动区比较器的空覆盖误通过。所有脚本均为只读工具，不替代真实生成器，也不修改项目。

## 1. 三种“通过”不能混用

1. **文件结构**：声明的 CSV/Prefab/bytes/脚本存在。
2. **已声明静态合同**：CSV 约束、证据定位、指定候选规则经过检查。
3. **真实执行**：官方工具、Unity 编译、PlayMode、平台、原版对照真实执行。

第 1 层不能证明第 2 层；前两层都不能证明第 3 层。引用存在/哈希匹配只能证明引用指向该文件，不证明引用的含义与结论一致。

报告必须同时给出扫描范围、文件/表/规则/region 数量、未覆盖项、allowlist 理由和结论边界。“0 issue”只有在实际覆盖了相应范围时才有意义。

## 2. Runtime Contract 配置

复制 `templates/MIGRATION_AUDIT_CONFIG.json` 后，填写新增 `runtime_contracts`。完整示例结构在 `templates/RUNTIME_CONTRACTS.example.json`；它是未适配的示例，不是可直接拿来获得 PASS 的项目配置。

```bash
python scripts/audit_myframework_runtime_contracts.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json --json
```

证据在已经提供的上游/冻结原版目录时：

```bash
python scripts/audit_myframework_runtime_contracts.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json \
  --source-root <supplied-source-root> --json
```

工具不会联网抓源，也不会把原版资源复制到游戏中。

### 分类

`schema_version` 当前为 `1`。`categories` 包含：

- `tables`：identity、ordering、consumers、required_values、readiness、legacy_migration、random_selection。
- `scenes`：responsibilities、async_completion、duplicate_load、entry_gate、failure_cleanup、restart、exit_order。
- `state_lifetimes`：owner、scope、serialized、load、ui_hide、layout_restart、game_exit、application_restart；`serialized` 必须为 JSON boolean。
- `ui`：event_owner、refresh_trigger、input_policy、visual_interactable、animation_channels、cancel_policy、generated_boundary。
- `timing`：clock、phase、interval、initial_state、catch_up、condition_order、interval_change、pause、reset、rng。

每项具有独立 ID。合同字段填写具体可核对说明，不填 TODO/UNSET。`source_evidence` 与 `implementation_evidence` 均必需：

```json
{"root":"project","path":"Assets/Scripts/HotFix/Example.cs","contains":"exactExistingSymbol"}
```

也可使用 `root:"source"` 定位 `--source-root`，或 `sha256` 定位二进制证据。指定 `contains` 与 `sha256` 时两者都需匹配。路径必须在各自 root 内；不允许越界或符号链接跳出。

每个类别 `status:"declared"` 时必须至少声明一项。确实不适用时用 `not_applicable`，附具体 `reason`、可定位 `evidence`，且 `items` 为空。缺失/pending/空声明不等于通过。

`verification.status` 只能是 `UNVERIFIED`、`STATIC_ONLY`、`RUNTIME_EVIDENCE_RECORDED`；后者要求 runtime evidence，但工具只报告“用户提供了记录”，不独立认证运行成功。

### CSV 语义约束

tables 每项必须带 `csv_check`：

```json
{
  "path":"Excels/ItemCatalog.csv", "metadata_rows":9,
  "id_column":0, "id_type":"int", "min_data_rows":1,
  "required_ids":[10,30], "finite_columns":[2],
  "unique_columns":[1],
  "numeric_ranges":[{"column":2,"min":0}],
  "foreign_keys":[{"column":3,"target_table":"rarity-catalog","allow_empty":false}]
}
```

列索引从 0 开始；`metadata_rows` 是 CSV 逻辑记录数。带引号的多行字段按 CSV 记录解析，不把物理行误当数据行。`target_table` 指同配置中 tables item 的 ID，不是 C# 类名。

工具检查：非空且合法 ID、重复 ID、必需 ID、声明的唯一列、有限数值、上下界/开闭边界、外键、最少数据行。int ID 归一化整数身份；string ID 保留大小写，不假设其连续或自动排序。

工具**不检查**官方 bytes 协议、不执行 ValueFormula、不推断排序/概率正确、不静态遍历所有 consumer；这些仍需源码审查和真实加载测试。精度、取整、ID 与序列化键的语义也不能靠 CSV 校验决定。

### 定向候选扫描

`scan_rules` 每项：`id`、`include`、`exclude`（可省略）、`pattern`、`mode`、`scan`、`reason`。

- `include/exclude`：项目根目录相对 glob，必须覆盖当前项目实际代码。
- `pattern`：Python 正则，默认多行匹配。
- `mode:"forbid"`：命中产生候选；`mode:"require"`：每个匹配文件没有该模式则产生候选。
- `scan:"code"`：屏蔽常见 C# 注释/字符串；`raw`：原文匹配。复杂插值/raw string/预处理仍需人工或 Roslyn 判断。
- `reason`：必须说明为什么这个项目需要检查。

用于查 `query(i+1)`、Task ID 转 index、已知旧计时器、Gameplay → 具体 UI 等。不要无范围把全工程 `-1`、数组索引、`Time` 全判错。扫描出候选是 REVIEW_REQUIRED，不是编译错误证明。

规则匹配不到文件属于未覆盖问题。`scan_rules:[]` 会在报告显示 0 条规则，不能表述为“所有坏模式均为 0”。项目可调整明确不适用的 include/exclude，但必须记录来源和范围，不能为降低数字隐藏错误。

### 返回值

| Exit | 含义 |
|---|---|
| 0 | 已声明的静态检查通过；真实运行仍未由工具执行 |
| 1 | 合同缺失、CSV/证据问题或待人工复核候选 |
| 2 | 目录/配置/编码等无效，检查未完成 |

## 3. 自动区比较器 3.2.0 的变化

保持原默认命令：

```bash
python scripts/compare_myframework_generated_regions.py <previous-root> <current-root> --json
```

新增保证：

- 两个快照必须存在且不同；请求的 code root 必须存在。
- 没有 C# 或没有识别到自动区：`NOT_EVALUATED`，不能返回“0 drift PASS”。
- 新增/删除 region、新增/删除含自动区文件都会计入 diff。
- 相同的损坏 marker 也会报错，不因两边“坏得一样”通过。
- 保留生成区正文空白差异，只归一化 UTF-8 BOM/CRLF；避免随意格式化自动区被藏掉。
- 仅识别 `REGION_PAIRS` 中的 marker 格式，目标版本使用不同格式时必须更新 Profile。未识别自动区不能被默认为已覆盖。

默认 exit 0 为已覆盖的 0 drift，exit 1 为 unexpected diff/损坏 marker，exit 2 为无效输入/无覆盖。若有损坏 marker 同时又无覆盖，报告会保留二者，不可作 PASS。

### 官方生成器确实执行过的变更

`--allow` 不再静默排除整个文件；必须提供 `--allow-evidence`。示例：

```bash
python scripts/compare_myframework_generated_regions.py <previous-root> <current-root> \
  --allow 'Assets/Scripts/HotFix/UI/Example.cs' \
  --allow-evidence <current-root>/GENERATOR_CHANGE_EVIDENCE.json --json
```

证据 JSON 模板见 `templates/GENERATOR_CHANGE_EVIDENCE.example.json`。每个 glob 要有唯一 approval，填写 tool/version/log/reason；log 必须是 current root 内的真实非空文件。输入/输出文件、工具来源、执行命令、日期和编译结果仍需在项目报告记录并核实。

比较器保留 `changed_regions` 总数，再分 `approved_changed_regions` 和 `unexpected_changed_regions`。提供 approval 不会把变化变成 0，也不会认证日志的真实性。批准变更时状态为 `GENERATOR_DIFF_RECORDED_REVIEW_REQUIRED`，需要人工核对它是否确由正式工具产生。

本轮未运行官方 Generator 时，不得使用 approval 为手写自动区补票。历史版本已手改时先承认债务，后续通过官方工具重新闭环，不能把它们当官方产物基线。

## 4. 本轮交付报告必须独立展示

静态覆盖结果、官方生成证据、Unity 编译、第二局/Reset、存档写出检查、时序 trace、视觉/输入对照各列单独状态。

禁止：把 Rxx 文件名中的 CompileClosure 当 Unity 编译证据；把回调符号/括号检查当类型检查；把 Prefab metadata 一致当生成器已执行；把源公式匹配当最终运行一致。

如果某一层没运行，写未运行；如果尚有已知差异，单列差异。不要在未穷尽核查时宣称“只剩 Unity 验证”。
