# 普通 Unity 工程 → MyFramework 专用重构流程

本 Skill 的输入前提是：**已经存在一个普通 Unity 工程**。它可能使用 MonoBehaviour、Singleton/Manager、ScriptableObject、Resources、原生 UGUI、Animator、Coroutine、UnityEvent、PlayerPrefs、JSON/CSV 等常规 Unity 方案。目标不是重新实现游戏，而是在保持原工程行为与表现的前提下，把架构、生命周期、资源、UI、数据和系统管理迁移到 MyFramework。

## 真值优先级

普通 Unity → MyFramework 重构默认：

1. 原 Unity 工程在目标 Unity 版本下的实际运行结果。
2. 原 C# 业务代码和调用链。
3. Scene/Prefab/Asset 的 YAML 与 serialized reference。
4. ScriptableObject、JSON、CSV、二进制、PlayerPrefs 等真实数据。
5. 原工程测试、日志、录屏、截图。
6. MyFramework 参考项目只作为“如何表达”的结构范式，**不能覆盖原工程行为**。

但如果用户明确说明当前 Unity 工程是“尚未完全对齐的中间移植产物”，并提供了合法的上游源码/运行结果，则上游实现是行为真值，Unity 中间工程只作为迁移进度输入。此时必须额外阅读 `27-upstream-parity-effective-behavior.md`。

## 必须先做的盘点

重构前输出以下矩阵：

- MonoBehaviour → Target Type：FrameSystem / SceneInstance / GameScene / ClassObject / WindowObject / Bridge / Binding。
- Manager/Singleton → MyFramework System 能力映射。
- Scene → SceneRegister / SceneInstance / GameScene / SceneProcedure。
- UGUI Prefab → LayoutScript / WindowObject / Generator MemberData。
- Resources/Addressables/serialized reference → ResourceManager / GameResources / 保留序列化引用。
- ScriptableObject/JSON/CSV → 保留资产 / Excel 表 / Runtime 状态。
- Coroutine/Invoke/Update → Command/Delay/Tween/FrameSystem update 等框架生命周期。
- UnityEvent/C# event → MyFramework EventSystem 或明确的强类型回调。
- Instantiate/Destroy → PrefabPoolManager 或 owner 管理的 ClassObject。
- AudioSource/AudioManager → MyFramework AudioManager/AudioHelper。
- PlayerPrefs/Save → 项目正式存档系统，不允许迁移过程中换语义。

## 重构顺序

### 1. 先冻结原工程

先保证原工程能打开、编译、运行，并记录主流程。不要一开始就删除旧 Manager、Resources 或 MonoBehaviour。

### 2. 建 MyFramework 唯一启动链

建立 GameEntry / Game / GameHotFix / GBR / SceneRegister 等目标骨架，但不要让旧 Bootstrap 和新 Bootstrap 长期并存。迁移阶段可以有临时桥，最终必须只保留一条启动链。

### 3. 迁移全局 Manager

只把真正全局、跨 Scene、有独立生命周期的职责迁为 FrameSystem。不要把每个旧 MonoBehaviour 都升级成 System。

### 4. 迁移 Scene 与玩法对象

Scene 负责场景绑定和场景所有权；玩法对象按 ClassObject/MovableObject/必要 Bridge 拆分。删除旧 MonoBehaviour 前先迁移 serialized contract。

### 5. 迁移 UI

逐页面迁移：Prefab 节点 → Generator MemberData → LayoutScript → 自动注册 → 业务回调。禁止运行时生成整套 UI，禁止用一个 UISystem FrameSystem 接管全部页面。

### 6. 迁移资源与对象池

Resources 只保留框架/第三方确有固定合同的白名单。运行资源进入 GameResources 或继续使用稳定 serialized reference。高频 GameObject 走 PrefabPoolManager；普通 C# 对象按 owner 使用 CLASS/UN_CLASS。

### 7. 迁移配置数据

稳定业务表进入官方 Excel 工具链；不要为了“数据化”把逐帧算法、物理常量、RNG 调用顺序机械迁表。官方 Generator 未执行时只能标记为 UNVERIFIED。

### 8. 删除旧架构

只有当新链已经接管并通过测试后，才删除 Legacy Manager、旧 Bootstrap、旧 UI Runtime、旧 Resources 副本和临时 Bridge。删除后要扫描 Scene/Prefab 中旧 script GUID 残留。

### 9. 做第二局与销毁验证

MyFramework 重构最容易在“第一次能玩、第二次出错”。必须验证：退出场景、FrameSystem destroy 顺序、callback(null)、事件注销、对象池 reset、音频停止、延迟命令取消、UI 再次 show。

### 10. 最终验证

静态审计只证明结构候选正确，不能替代 Unity 真编译和 Play Mode。最终至少要通过：编译、入口运行、主流程、Scene 切换、第二局、UI 页面、目标分辨率、资源缺失扫描、Console 无新增错误。

## 明确禁止

- 只改 namespace/类名就称为 MyFramework 重构。
- 新建 `XXXCompatibility`、FakeRuntime/FakeEditor、同名 asmdef、空类型绕过真实依赖。
- 运行时 `Find/Resources.Load/AddComponent` 大量补洞来绕过 Prefab/Generator/资源链。
- 一个 `XXXUISystem : FrameSystem` 管全部页面。
- 为了过审计手写官方 Generator 应生成的自动区并声称已执行生成器。
- 参考项目是横屏就把原工程也强改 1920×1080。
- 在 LayoutScript/UI 页面脚本中实现 `resetProperty()`；页面临时状态使用 `onGameState()/onHide()/setData()` 等正式页面生命周期收口。ClassObject/WindowRecyclableUGUI 等真实池对象的 reset 合同另行处理。
- 使用 C# 自动属性作为项目业务风格；遵循目标 MyFramework 项目的显式 `m` 字段/getter 风格。
- 直接用 Unity 原生 API 替代 MyFramework 已经存在且适用的系统，只因为写起来更快。

## 版本间保护区 diff

每轮“继续重构”都要区分本轮是否**应该**改变官方生成区：

- 未运行官方 Generator：Layout/GBR/Register/Excel 自动区应保持 0 drift，可运行 `compare_myframework_generated_regions.py`。
- 已运行官方 Generator：记录输入 Prefab/Table、Generator 执行证据和自动区 diff。
- 禁止在业务/视觉提交里夹带手工 auto-generate 修改。

## 完成判定

“完成重构”必须同时满足：

- 原工程主流程行为未改变。
- 唯一 MyFramework 启动链。
- Legacy runtime debt 清零或有明确、合理、可审计的保留项。
- UI/Excel 官方 Generator 状态真实。
- Resources/GameResources/serialized references 边界清晰。
- 所有 pooled 对象有 owner/reset/destroy 闭环。
- Scene/Prefab 无已删除脚本 GUID 残留。
- 目标 MyFramework Package/asmdef 依赖真实唯一。
- Unity 真编译、Play Mode、第二局通过。
- 完整交付包包含运行所需 ProjectSettings/Packages/Assets 与 Build Settings 所需 Scene；不依赖用户手工执行初始化菜单才能首次 Play。

## 3.2.0 运行合同补充

3.2.0 每轮增加 [表格消费](28-table-consumption-identity-readiness.md)、[Scene/状态寿命](29-scene-restart-save-lifetimes.md)、[UI/周期](30-cadence-ui-input-animation.md) 与 [证据覆盖](31-contract-audit-evidence-coverage.md)。这些是普通 Unity 重构规则，不扩大为网页抓取工具。
