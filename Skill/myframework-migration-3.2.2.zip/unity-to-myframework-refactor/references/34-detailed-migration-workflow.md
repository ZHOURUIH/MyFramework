# 完整迁移阶段与验收清单（按任务范围适用）

## 最终目标

把“原项目能运行”转换成“**原项目行为保持不变，同时代码、资源、生命周期和工具链都真正进入 MyFramework**”。

重构完成必须同时满足十二件事：

1. **行为等价**：玩法、输入、物理、AI、随机顺序、伤害、动画、UI 状态、音效、存档和平台流程以任务指定的可运行基线为真值源；普通 Unity 重构默认以原 Unity 工程为真值，但已知不完整的中间移植工程必须回到用户指定的上游原版真值。
2. **架构真实迁移**：不是改类名、包一层 wrapper 或保留旧系统后套 MyFramework 外壳，而是对象创建、初始化、更新、事件、资源、销毁、重开全部进入框架生命周期。
3. **资源与数据进入工具链**：Prefab、UI、GameResources、Excel/bytes、生成代码由项目真实工具生成和加载，不靠运行时临时生成、反射或硬编码路径补洞。
4. **证据闭环**：静态扫描、Unity 真编译、生成工具、运行模式、场景切换/第二局、目标平台和基线对照各自有证据，不能互相替代。
5. **迁移债务可量化**：每个项目维护 Legacy→Target Manifest 和残留计数；“兼容层还在但换了名字”不算进度。
6. **工具链真实执行**：UI/Excel 自动生成段只有真实生成器执行后才能标记完成；无法运行 Unity 时必须明确写“Generator 未验证”，不得手写伪造。
7. **资源布局真实收口**：`Assets/Resources` 只保留有固定加载合同的白名单资源；业务资源进入 GameResources/Excel/正式资源链，不能保留 Legacy/Recovered 兼容仓库。
8. **序列化与制品完整**：删除旧 MonoBehaviour 前必须迁移其 serialized contract；资源移动保持 `.meta` GUID；完整包与增量包都必须在最终 staged root 上通过审计。
9. **依赖/API/Direct-Run 完整**：真实 Package/Assembly 来源唯一，不制造同名 asmdef/stub；MyFramework/Unity Editor API 必须按目标版本源码核实；用户要求完整可运行包时，运行关键资产必须已经落盘，不能依赖 Tools 菜单或首次导入生成器补齐。
10. **显示合同闭环**：横竖屏、设计分辨率、FrameSettings、start Scene 的 UGUIRoot、所有 Layout Prefab 根节点、Safe Area 与 World Camera framing 必须来自原版/目标平台证据并保持一致；禁止套用参考项目 1920x1080 等默认值。
11. **数据与生成器所有权闭环**：稳定业务 Catalog/价格/文案/奖励参数等必须先做硬编码盘点再进入 MyFramework Excel；UGUI/Excel 自动生成区只由官方工具拥有，离线重建或手工序列化 bytes 只能标记为迁移准备态，不能冒充官方 Generator 已执行。

12. **运行合同与审计覆盖闭环**：表格必须有真实 consumer 与稳定身份；Scene/Reset、持久化/session/UI 寿命、周期时序、输入层和动画通道分别记录。缺少扫描范围/空声明不是通过，静态文件一致不代表运行等价。

## 使用边界

本页保留完整迁移的阶段、架构和验收细节；任务范围以新版 SKILL.md 为准。局部修复不要求重做全部迁移、执行无关生成器或产出完整工程 ZIP。实际 API 以目标版本源码为准，编码风格以用户和仓库规范为准。

相关模块的具体约束见 [硬要求总表](19-hard-requirements.md)。发现规则缺口先记录并解决项目问题；只有用户要求维护技能时才改写技能。

## 3.2.1 UI 适配纠正

所有正式 UI Prefab（含 Game 层启动/下载和引用模板）默认只用 ScaleAnchor/ResScaleAnchor，绝大多数保持宽高比。PaddingAnchor/ResPaddingAnchor 仅用于极少数明确的父节点边界停靠（父节点可为屏幕 root 或实际目标容器）；不能用于普通父子对齐、文本列、scroll/viewport/content 或进度 fill。业务 authored 节点禁止 UGUI 原生 anchors，只有有生成来源的精确自动节点可例外；转换时保留设计几何。全屏 root/背景/遮罩与无可见图形的输入覆盖区域等可按明确用途非等比。详见 [UI 适配规则及审计](32-ui-scale-anchor-policy.md)，不得用旧版并列写法把两个 Anchor 当作通用组合。

## 3.2.0 必增检查

- 表格：逐字段 consumer、ID/排序/选择值、历史位置映射、随机候选映射、实际 bytes 加载后的 Ready Gate。
- GameScene：每次进入重置状态，同步/延迟/退出后回调、已有 Scene、不完整初始化、失败终态、正常退出与 Reset 分开。
- 状态：存档、session、layout/world、UI 表现分寿命；实际写出字段与源 SaveGame 对照。
- UI/时间：业务事件刷新、World/HUD/面板输入政策、视觉 enabled、独立 Tween/hold 通道与源周期相位分别验收。
- 审计：原七类 + Runtime Contract + 自动区 diff；显示覆盖数量，空目录/空 region/缺失合同不得报 PASS。

这些是通用检查维度；不得硬编码某项目的表名、Slot 数量、40ms 阈值或 1/2/30 秒周期。

## 第一原则

- **先分析 MyFramework，再改项目。** 必须阅读当前项目实际安装的 MyFramework 源码；如果用户提供了使用 MyFramework 的参考项目，至少抽取启动、GBR、FrameSystem、Scene、UI、Excel、资源/对象池和事件的真实实现作为范式。
- **任务指定的可运行原版是行为基线，MyFramework 是结构基线。** 普通 Unity 重构默认以原 Unity 工程为原版；若当前 Unity 是已知不完整的中间移植产物，则以用户指定的合法上游原版为行为基线。任何情况下都不能为了“框架更漂亮”擅自改变原行为。
- **完整生命周期迁移。** 创建、bind/init、update/fixedUpdate、事件注册、异步、停用、willDestroy/destroy、回池必须一起迁移；`resetProperty()` 只属于真实需要 reset 合同的 ClassObject/池对象，**LayoutScript/UI 页面脚本不把 `resetProperty()` 当成生命周期规范**。
- **先明确所有权，再使用对象池。** 每个可回收对象必须知道 owner。owner 创建，owner 回收；索引系统、查询系统和 UI 不越权 destroy。
- **业务运行时代码不使用反射恢复结构。** 禁止 `System.Reflection`、`BindingFlags`、`Activator`、`GetField/GetProperty/GetMethod`、Assembly 扫描等。必要 `GetType()` 仅用于真实类型身份、框架接口、日志或 Editor 诊断，不能用来替代明确的业务注册表。
- **生成代码只由生成器生成。** `auto generate` 区域、ExcelRegister、ED/Excel 自动段、UI assignWindow 自动段不手写模拟。手工写出等价代码只可作为迁移期非生成区实现，不能声称“Generator 已完成”。
- **每个项目维护 Migration Manifest。** 通用 Skill 不替代项目事实；旧类→新类、UI 页面、Data schema、Owner、删除条件和 Legacy debt 必须项目级记录。
- **先复用现有框架能力，再新增项目封装。** Audio/Input/Touch/Pool/Resource/Tween/Async/Localization/Atlas/Effect 等新增 Manager 前必须核对当前版本框架源码。
- **C# 源码默认 UTF-8 BOM。** 用户项目已有不同编码规范时以仓库规范为准；不要批量改第三方包或框架源码编码。
- **不要轻易“修”原设计。** 只有明确 bug、行为差异、生命周期错误、数据竞争或性能证据时才修改；通用最佳实践不是改变原行为的理由。
- **Parity 看最终有效行为。** 多层 CSS/配置/刷新函数存在覆盖时，必须追到最后真正显示/执行的值；第一次搜索命中不是证据。duration、easing、keyframe offset、z-order、world/overlay 坐标空间都属于行为合同。
- **Parity 不能以热路径 GC 为代价。** 程序化 Mesh/特效算法迁到 C# 时允许用缓存和值类型 key 消除无关分配，但不得改变确定性 seed、RNG 调用顺序或最终输出。
- **空壳旧脚本不是行为基线。** 旧 MonoBehaviour 如果只有字段/空方法，必须结合原 Unity 工程运行、Scene/Prefab YAML、序列化资产、调用链和测试恢复职责，不能凭类名脑补逻辑。
- **资源目录也是架构。** 把旧资源塞进 `Resources`、复制一份到 `GameResources`、或保留完整 Legacy 资产树都不算迁移完成。
- **正式依赖也是架构。** 缺 Assembly/API 时先查目标 Package 和参考项目；禁止新增同名 asmdef、fake runtime/editor、空类型或 placeholder 来让编译暂时前进。
- **API 不靠记忆。** MyFramework 方法、生命周期和 Unity Editor API 都按目标版本源码/文档核对；出现 `CS0103/CS0115/CS1620` 时先修真实调用合同，不写兼容 wrapper 掩盖。
- **Static API 要区分 AOT/HotFix owner。** 同名全局成员可能同时存在于 `FrameBase` 与 `FrameBaseHotFix`；审计与修复必须根据调用文件所在层和真实 `using static` 判断，不能把 HotFix owner 机械套到 AOT 文件。
- **完整包必须 artifact-closed。** Runtime critical 资产在压缩前就要真实存在；Editor Builder 可以保留作维护工具，但不能是首次运行前置条件。

## 必读顺序

完整迁移可按以下索引选择详细合同；局部任务只读取影响模块：

1. [MyFramework 硬要求总表](19-hard-requirements.md)
2. [普通 Unity → MyFramework 专用流程](26-unity-to-myframework-workflow.md)
3. [核心规则](00-core-principles.md)
4. [发现与基线](01-discovery-baseline.md)
5. [MyFramework 能力图](02-framework-capability-map.md)
6. [目标架构](03-target-architecture.md)
7. [生命周期与所有权](04-lifecycle-ownership.md)
8. [当前版本能力 Profile](14-current-version-profile.md)
9. [迁移模式库](16-migration-patterns.md)
10. [项目 Manifest 与阶段门禁](17-project-manifest-gates.md)
11. [Resources / GameResources / 最终制品完整性](20-resource-layout-artifact-integrity.md)
12. [Binding / Bridge / Unity 序列化合同](21-binding-bridge-serialization.md)
13. [Dependency / API Provenance / Direct-Run 完整性](22-dependency-api-directrun.md)
14. [UI Generator / FrameSystem 销毁 / Direct-Run 运行闭环](23-ui-generator-lifecycle-directrun-closure.md)
15. [显示方向 / 设计分辨率 / 世界画面闭环](24-display-orientation-visual-parity.md)
16. [稳定业务数据 / Excel 官方工具链闭环](25-excel-hardcode-toolchain-closure.md)
17. [上游真值源 / 最终有效行为 / 运行表现 Parity](27-upstream-parity-effective-behavior.md)
18. [表格实际消费 / 稳定身份 / Runtime Ready](28-table-consumption-identity-readiness.md)
19. [GameScene / Reset / 状态寿命](29-scene-restart-save-lifetimes.md)
20. [周期时序 / UI 输入层 / 动画通道](30-cadence-ui-input-animation.md)
21. [运行合同审计 / 覆盖范围 / 证据](31-contract-audit-evidence-coverage.md)

涉及对应模块时再读：

- Scene / Gameplay：[场景与玩法分层](05-scenes-gameplay.md)
- UI：先读 [ScaleAnchor 默认与例外规则](32-ui-scale-anchor-policy.md)，再读 [UI 与 Prefab 生成](06-ui-prefab-generation.md) + [UGUI Generator 精确合同](15-ui-generator-contract.md) + [UI Generator / 生命周期 / Direct-Run 闭环](23-ui-generator-lifecycle-directrun-closure.md) + [显示方向 / 设计分辨率 / 世界画面闭环](24-display-orientation-visual-parity.md)
- Excel：[Excel 与配置规范](07-excel-data.md) + [稳定业务数据 / Excel 官方工具链闭环](25-excel-hardcode-toolchain-closure.md)
- 资源 / Pool / Audio：[资源、对象池、音频](08-resources-pools-audio.md) + [Resources / GameResources / 最终制品完整性](20-resource-layout-artifact-integrity.md)
- MonoBehaviour / Scene-Prefab 序列化迁移：[Binding / Bridge / Unity 序列化合同](21-binding-bridge-serialization.md)
- 事件 / Tween / 输入 / 物理：[事件、异步、动画、输入与物理桥](09-events-async-tween-input-physics.md)
- 去反射 / 代码规范：[反射、生成代码与代码规范](10-reflection-generated-code-style.md)
- 验证：[验证与完成标准](11-verification.md)
- 上游/多层覆盖 parity：[上游真值源 / 最终有效行为 / 运行表现 Parity](27-upstream-parity-effective-behavior.md)
- 出问题时：[常见陷阱](12-pitfalls.md)
- 性能/内存回归：[性能与内存回归门禁](18-performance-regression.md)
- Package/asmdef/API/完整包直接运行：[Dependency / API Provenance / Direct-Run 完整性](22-dependency-api-directrun.md) + [UI Generator / 生命周期 / Direct-Run 闭环](23-ui-generator-lifecycle-directrun-closure.md)
- 需要理解这些规则为何存在时：[RagdollArchers 实战沉淀](13-ragdoll-archers-lessons.md)

## 执行阶段

### Phase 0：冻结可运行基线

在改动前必须得到：

- Unity 版本、MyFramework 版本/PackageCache 路径、目标平台。
- **Display Profile**：原版实际横/竖屏、目标 viewport/aspect、项目设计分辨率、Safe Area 策略；不得从参考项目或框架模板默认值推断。
- 可运行入口、主场景、所有游戏模式。
- 原工程关键流程的截图/录屏/日志/配置数据。
- 如果当前 Unity 是不完整中间移植版本：冻结用户指定的上游真值源、运行入口、脚本/样式加载顺序、关键刷新覆盖链和已知 parity 差异；不能默认中间 Unity 就是行为真值。
- 当前工作树状态；不得 reset、clean 或覆盖用户未提交修改。
- `Packages/manifest.json`、embedded/local Packages、关键 asmdef Assembly 名称清单；先记录真实依赖来源，禁止迁移过程中临时造同名兼容 Assembly。

输出 `MIGRATION_PLAN.md`，并建立 `PROJECT_MIGRATION_MANIFEST.md`（模板见 `templates/`）。

Manifest 至少包含：Legacy→Target 映射、Ownership、Bridge/Binding Matrix、Serialized Contract、UI Matrix、Data Mapping、Resource Layout Matrix、Legacy Debt 计数和各阶段门禁。后续每轮“继续重构”都更新它，而不是只依赖聊天上下文。

### Phase 1：盘点 MyFramework 能力

禁止先凭印象写 wrapper。至少确认：

- Game / GameEntry / GameHotFix 启动方式。
- GBR 中系统、Excel、SceneInstance、LayoutScript 的注册方式。
- FrameSystem 生命周期。
- ClassObject、`CLASS/UN_CLASS`、`LIST/UN_LIST` 的真实语义。
- SceneSystem / SceneInstance 与 GameScene / SceneProcedure 的适用边界。
- LayoutScript / WindowObjectUGUI / WindowStructPoolBase / myUGUI*。
- EventSystem、DelayCmdWatcher、WaitingManager/CommandSystem。
- ResourceManager、PrefabPoolManager、AudioManager。
- ExcelManager、ExcelDataT、ExcelTableT、ExcelRegister、CSVToBinary/CodeGenerator。

如果参考项目存在，至少选择 2 个与当前功能最接近的项目核对实际用法，不要只看框架类定义。

同时建立 **API Provenance Matrix**：本轮新增/修改的 MyFramework 调用必须记录声明类、源码文件或同版本参考项目，并记录当前调用文件的访问方式（fully-qualified / inherited / `using static`）；不得凭记忆使用 `finish()/isEditor()/changeProcedure<T>()` 等方法名。Editor 工具还必须按目标 Unity 版本核对 API。

同时记录目标工程 MyFramework 的 package version/fingerprint。若与 `references/14-current-version-profile.md` 不一致，以目标工程源码为准，并把 API 差异写进计划。新增项目 Manager/System 前必须先确认框架是否已有等价能力。

### Phase 2：建立目标架构和所有权表

先设计，再搬代码。建议将职责拆为：

- `Game/`：Unity/框架启动壳。
- `HotFix/Common/`：GBR、常量、纯工具。
- `HotFix/*System/`：全局业务服务；继承 FrameSystem 时必须有明确全局职责。
- `HotFix/SceneSystem/`：Unity Scene 实例与场景资源绑定。
- `HotFix/GameScene/`：需要逻辑流程状态机时使用 GameScene/SceneProcedure；不要与 SceneInstance 重复表达同一职责。
- `HotFix/Gameplay/`：玩法对象、Actor、控制器；不持有业务 UI。
- `HotFix/UI/`：每个布局独立 LayoutScript，子控件用 WindowObject/WindowStruct。
- `HotFix/DataBase/Excel/`：ED、ExcelTable、ExcelRegister。
- `Assets/Resources/`：仅固定加载合同白名单（1.1.12 默认包含 start scene / FrameSettings；第三方例外需证据）。
- `Assets/GameResources/`：运行游戏资源主目录；稳定 serialized reference 可以继续直接引用，不强制改成字符串路径。

为所有非平凡对象建立 owner 表：谁创建、谁更新、谁注销、谁回收、何时 reset。没有 owner 的对象不允许进入 ClassPool。

同时建立 Legacy→Target 映射和删除条件。例如旧 `GameApp/PortedScreen/SourceButton/GameDatabase/XXXRuntime` 应明确“保留、拆分、薄 Bridge、删除”的最终状态，不能无限期留为兼容层。

### Phase 3：迁移启动、系统和全局引用

- 保留项目唯一的 Game / GameEntry / GameHotFix 链，不创建第二套启动体系。
- GBR 只保存系统、表格、场景、布局等**对象引用**，不把 `mReady`、当前模式、血量、分数等业务状态塞进 GBR。
- 原 Manager 只有明确全局职责时才迁为 FrameSystem；小对象不要“一类一系统”。
- 系统之间通过明确方法、事件或数据交互；不要让系统为了 UI 暴露 `getView()/getScene()`。
- `registeFrameSystem<T>()` 的 callback 必须能接收销毁阶段传入的 `null`：先同步 GBR 引用，任何 `com.setInitOrder/setUpdateOrder/setDestroyOrder` 等解引用都必须置于 `com != null` 保护内。

### Phase 4：迁移对象生命周期

对每种对象逐类迁移：

1. 判断它应是 FrameSystem、SceneInstance、GameScene、ClassObject、MovableObject、WindowObject，还是必要 Unity Bridge。
2. 导出并恢复原 MonoBehaviour 序列化字段/Transform/Collider/Rigidbody/Joint/Particle 引用，先形成 Serialized Contract；旧脚本为空也不能跳过。
3. 如果继承 ClassObject：运行实例使用 `CLASS<T>()` 创建，owner 用 `UN_CLASS` 回收。
4. `resetProperty()` 清空**所有会随运行变化的字段**，因为对象会被真正复用。
5. `destroy()` 只做当前对象生命周期内的释放，不越权销毁其他 owner 的对象。
6. 需要依赖其他 System/Manager 仍存活的解绑/归还放 `willDestroy()`；`destroy()` 不得假设其他 FrameSystem 仍存活，保留的 fallback 必须 null-safe、幂等。
7. 遍历时对象可能自注销/销毁，必须使用 `LIST<T>()` 临时快照，避免直接遍历被修改集合。
8. Unity 静态引用进入 Binding；必须收 Unity callback 的进入最薄 Bridge；玩法状态不能留在 Binding/Bridge。
9. 删除旧组件后扫描其 script GUID 在 `.unity/.prefab/.asset` 中为 0。

禁止只做 `new X -> CLASS<X>` 而不迁移 destroy/reset/owner。

### Phase 5：Scene / Gameplay / Mode 分层

- Scene 负责场景对象绑定与生命周期，不作为 UI 命令门面。
- Gameplay/Mode 负责玩法规则，不继承 UI，不直接操作 LayoutScript。
- UI 命令优先进入 BattleSystem/业务 System，再由 System 调用当前 Mode。
- UI 如需世界对象，只传纯绑定数据、接口或必要引用，不把具体 `XXXScene` 暴露给 UI。
- 模式使用显式 enum/类型，不使用 `0/1/2` 魔法数字。
- 切场景时先 detach 依赖该 Scene 的 System/Mode，再释放 Scene 自己拥有的对象。

进入/重开前按 `templates/RUNTIME_CONTRACTS.md` 登记 Scene/状态寿命矩阵；读本次真实 framework 合同。Loading 缓存命中、同一 Procedure 再入、失败/过期回调、已有坏绑定 Scene、初始化中断和 Reset 写回竞争都必须有处理与验证；不假设 resetProperty 每次进入都会被调用。

### Phase 6：UI 迁移

UI 必须**逐页面闭环**，不要一次删除全局 UI Runtime 后再同时修几十个页面。每迁一张页面，都更新 UI Migration Matrix。

- 每个布局独立 `LayoutScript`，不要让业务 UI 相互继承；公共弹窗壳可用项目级 LayoutScript 基类，但禁止用 `XXXUISystem : FrameSystem` 统一管理多个页面的 LOAD/HIDE/UNLOAD、按钮路由、Popup 状态、存档计时和页面 refresh。
- Prefab 节点先规范，再配置 `UGUIGenerator/UGUISubGenerator` 的真实 MemberData，随后在 Prefab Mode 中运行原 UGUI 生成器；生成区不手改。
- 仅有 auto-generate marker 不代表生成器闭环：`newObject(...)`、成员 WindowObject 的 `assignWindow(...)`、Generator-owned `new(this)` 等绑定代码不得长期留在自动区外；root `mParentType` 与 sub generator parent type 必须与真实基类一致。
- 需要业务参数（如列表 index）的点击回调时，可以让 Generator 只生成强类型成员，再在业务区注册回调；此时 Prefab MemberData 必须关闭 Generator 自己的 click 生成，禁止双重注册。
- Generator 完成必须四层闭环：Prefab MemberData、LayoutScript 自动区、`LayoutRegisterHotFix` 自动区、GBR LayoutScript 自动区集合一致；不得保留 `LayoutMigrationBootstrap`/fallback 注册。
- 离线脚本只能做元数据修复辅助/审计/差异预演，不能把自己写入的 auto-generate 区冒充“官方 UGUIGenerator 已执行”；未在 Unity 中真实运行时状态必须保持 `GENERATOR_UNVERIFIED`。
- UI Prefab 除节点结构外还要验证 Font/TMP FontAsset/Sprite/Material 序列化引用；“Text 里有字符串”不能证明文字能渲染。
- 当前 1.1.12 的精确 Generator 规则见 `references/15-ui-generator-contract.md`；不同版本必须重新读源码。
- 可复用子窗口使用 WindowObjectUGUI / WindowStructPoolBase 等项目已有方式。
- 按钮、滚动、输入、Collider、Tween 优先使用 MyFramework 现有控件。
- UI 只保存显示态和短生命周期交互态；业务状态归 System/Mode/Data。
- 不用运行时路径查找 + scale/hide 大量补丁代替正确 Prefab/Anchor 配置；`Node("A/B")/Transform.Find` 只能是明确记录的迁移期债务或必要动态结构。
- UI 迁移前先锁定设计分辨率；`FrameSettings.UISize*`、start Scene `UGUIRoot`、Layout Prefab 根 RectTransform、全屏遮罩/Dim/Guide 必须同一合同。横竖屏切换不能只交换宽高，还要重新验证 Root 直系子节点边界、ScaleAnchor 默认等比、PaddingAnchor 的少量真实边界例外与 Safe Area。
- 页面完成至少满足：旧字符串 Action Router 退出、旧 Runtime/Bridge 组件从 Prefab 删除、强类型控件接管、第二次 show 状态正确、Generator 状态有真实证据。
- 世界空间 UI 与屏幕 UI 分离，相机、Canvas、排序和坐标转换保持原语义。

每个页面另外登记 Input Policy、刷新事件和动画通道。不要以 visible 代替 TweenPlaying，不让独立奖励共享状态而互相关闭，不让 UI 生命周期定义 session 状态。新增 Prefab 节点导致绑定变化时必须有真实官方 Generator 证据。

### Phase 7：Excel / 配置迁移

目标不是“把数据塞进 CSV”，而是让表结构成为稳定业务模型。

进入 UI 最终收尾前，先做一次 **Hardcoded Business Data Inventory**：Catalog、ID/顺序、价格、名称/描述、奖励概率/数值、FTUE revision、可配置范围等稳定业务数据若仍在 C# 中，应优先迁入表；fixed-step、碰撞半径、随机调用顺序阈值等直接决定原版确定性行为的常量，只有在原项目本来就是配置数据且有等价验证时才迁表。

- 不在业务表保存 C# 类名、字段名、ManagedType、反射路径。
- Scene/Prefab 内部节点路径仅在确实属于资源绑定数据时保留；业务关系优先稳定 ID。
- `0/1` 假布尔改真实 bool（以当前转换器支持为前提）。
- 稳定枚举使用转换器支持的 enum 类型，保留原数值。
- 能拆成一对多子表的 `|` 拼接数组/多点字段应正规化。
- 颜色在当前 MyFramework CSV 工具不支持 `Color` 时统一使用 `string`：`RRGGBB` 或 `RRGGBBAA`，不带 `#`，运行时集中解析。
- 保留 ID、排序、精度、默认值、外键、枚举数值和原随机语义。
- 生成 `ED*.cs / Excel*.cs / ExcelRegister.cs` 后必须实际运行 CSV→Binary，并验证 bytes 加载。
- 手工写 ED/Excel、离线脚本手工拼 `.bytes`、自己复刻 Serializer 协议都只能用于诊断/迁移准备，状态必须是 `TABLE_STRUCTURE_READY / GENERATOR_UNVERIFIED`；不能宣称官方 CodeGenerator/CSVToBinary 已闭环。
- 对旧表→新表写迁移等价性检查：逐记录、逐字段、外键和枚举数值对比。

逐列补 consumer 证据；ID/Order/SelectedValue 分离，旧位置存档冻结历史映射；随机集合和返回值映射保持。验证实际 bytes 加载后的表状态，再允许创建/迁移存档和 enterWorld。表缺失不得写默认数据覆盖旧存档。

### Phase 8：资源、Pool、Audio、存档、平台

- 先建立 `Assets/Resources` 白名单。MyFramework 1.1.12 默认以目标源码确认的 `Scene/start.unity`、`Settings/FrameSettings.asset` 为框架固定项；第三方固定 Resources 合同必须项目级显式记录。
- 业务 Prefab/SO/Bot/WorldUI/Font/Config 不得把 Resources 当兼容仓库；按职责迁入 GameResources、Excel 或删除。
- 移动资源必须连同 `.meta`，记录 old path/new path/GUID，并做 duplicate GUID 与引用残留检查。
- 稳定 Scene/Prefab serialized reference 可以继续保留；不要为了“框架化”强行改成字符串路径。真正动态资产加载走 ResourceManager。
- GameObject 高频创建使用 PrefabPoolManager；不要在业务散落 `Resources.Load/Instantiate/Destroy`。
- Pool 归还必须由真正 owner 完成；查询/索引 System 不负责销毁别人拥有的对象。
- `LegacyRuntimeDebt/RecoveredSourceReference/CompatibilityRuntime` 只能是中间债务，不得留在最终运行 Assets。
- 音量、暂停、BGM/SFX 生命周期优先对齐 AudioManager/AudioHelper 的真实接口。
- 存档字段和值先保证兼容，再重构 API；Unity serialized field 改名必须保留兼容合同（原名/FormerlySerializedAs/显式迁移）。
- WebGL/小游戏/Android/iOS 的资源同步/异步约束以目标平台实际能力为准。
- Package/Assembly 依赖只能来自正式 Package/Plugin/框架原生裁剪方案；禁止 `MyFrameworkCompatibility`、同名 asmdef、空 namespace/class、placeholder 来绕过真实依赖。
- 最终 staged root 扫描所有 `Assets/**/*.asmdef` 与 embedded `Packages/**/*.asmdef` 的 `name`，重复 Assembly name 必须为 0。
- 如果 `Packages/com.xxx` 已 embedded 且 manifest 仍有同名 dependency，记录 embedded 优先生效；这本身允许存在，但禁止再制造第三份 fake implementation。
- MyFramework 1.1.12 完整包必须确认 `Assets/GameResources/KeyFrame/Keyframe.prefab` 已落盘；组装 FullInstall 时优先从同版本官方 `ProjectTemplate~`/已验证工程补齐 runtime-critical 模板资产。
- 所有运行期会由 SceneSystem/SceneManager 加载的 `.unity` 都必须在 `ProjectSettings/EditorBuildSettings.asset` 中启用；不能只保证 `start.unity` 第一位后让用户手工 Add Open Scenes。

存档字段、session、layout/world、UI 表现按状态寿命矩阵验收；检查 serializer 实际输出，而非只看 NonSerialized 标记。正常退出、Reset、初始化失败分别决定是否保存，取消/等待旧写入必须与实际源顺序一致。

### Phase 9：事件、异步、Tween、输入与物理桥

- EventSystem 的 listen 必须有明确 unlisten 生命周期；场景重开不能重复监听。
- Delay/Coroutine/Rx/UniTask 迁移时保持“是否立即回调、取消时机、FixedUpdate/Update 阶段、完成回调顺序”。
- Tween 不只比较时长，还要比较曲线、循环、Yoyo、跨帧余量、时缩放与 break 回调。
- Unity 物理消息必须由真实 MonoBehaviour 桥接时，可以保留**最薄的 Bridge**：只收 `OnCollision/OnTrigger/OnJointBreak` 并转发给普通框架对象；Bridge 不承载玩法状态。
- 不允许为了“MonoBehaviour=0”而伪造不存在的基类 override。

每个周期事件登记 clock/phase/initial/interval/catch-up/condition-order/interval-change/pause/reset/RNG；保持源节点各自计时状态。不机械复制其他项目 Every 的阈值。核查基类已有事件/命令清理，避免重复造管理器。

### Phase 10：去反射和迁移残留

业务运行时清零：

- `System.Reflection`
- `BindingFlags`
- `Activator`
- `GetField/GetProperty/GetMethod/GetMembers`
- `Assembly.Load/GetTypes`
- 通过字符串类名/字段名恢复 Actor/Prefab 字段

替代方案：

- 生成强类型 Registry。
- `switch` / 显式工厂。
- Excel stable ID → 强类型配置。
- Editor 导出器生成运行时静态代码。

删除旧兼容类、空壳代理、旧 Excel/ED、废弃 Scene/GameBase、无引用 wrapper，以及运行 Assets 中的 Legacy/Recovered 参考目录。不能只覆盖文件而让旧脚本、旧 prefab component、旧资源副本继续存在。

### Phase 11：静态审计

先运行 `scripts/audit_myframework_structure.py` 检查标准启动/目录/注册结构，再运行 `scripts/audit_myframework_migration.py` 扫描代码与迁移债务，运行 `scripts/audit_myframework_ui.py` 检查 Generator Prefab/LayoutScript/LayoutRegister/GBR/生成代码所有权/UI God System/字体引用合同，运行 `scripts/audit_myframework_display.py` 检查 Display Profile、FrameSettings/start UGUIRoot/Layout roots/orientation，运行 `scripts/audit_myframework_excel.py` 检查项目声明的 Excel 表、bytes、注册、硬编码残留与 fallback 标记，运行 `scripts/audit_myframework_resources.py` 检查 Resources 白名单、Legacy runtime path、Resources.Load、GUID 稳定性，并运行 `scripts/audit_myframework_dependencies.py` 检查 duplicate asmdef、伪兼容路径、embedded/manifest 来源重叠信息与 Direct-Run 必需资产；最后仍必须结合 Roslyn/Unity 编译确认。脚本结果不是语义编译器，不可把启发式 0 结果当最终证明。

七类审计加 `scripts/audit_myframework_runtime_contracts.py` 与适用的自动区比较，必须对**最终待交付 staged root** 再执行一次，不能只对中间工作目录执行。

对 MyFramework 1.1.12 标准项目，结构审计至少验证 `Assets/Resources/Scene/start.unity`、`GameEntry` 根节点、Game/GameHotFix/GBR/LaunchScene/SceneRegister、Build Settings 第一场景等。若目标版本不同，先按目标源码更新 Profile 再解释结构扫描。

推荐为每个项目复制 `templates/MIGRATION_AUDIT_CONFIG.json`，登记旧类型/旧 Prefab GUID/合法 MonoBehaviour Bridge。这样审计不仅查通用反射/BOM，也持续量化项目自己的迁移债务。

至少检查：

- 业务反射 / GetType。
- MonoBehaviour 直接/间接继承及允许的桥接白名单。
- ClassObject 直接 `new`。
- namespace/sealed/多 class/表达式体（若当前项目采用这些规范）。
- `Resources.Load/Instantiate/Destroy` 残留。
- UTF-8 BOM。
- 旧类/旧 API/旧 Excel 的引用计数。
- 项目 Manifest 中 legacy symbols / legacy prefab GUID 的剩余计数。
- HotFix UI 中运行时字符串节点 API、`Transform.Find`、运行时 Get/AddComponent 候选。
- UGUIGenerator root/Canvas、parent type、LayoutScript 生成标记/source、Generator-owned binding 是否越出自动区、LayoutRegister/GBR 集合、手工 fallback 注册、UI God FrameSystem 候选、已知错误 builtin font 引用。
- Display Profile 是否已配置；FrameSettings UISize、start UGUIRoot、Layout Prefab roots、orientation 是否一致；明显 Root 直系子节点越界候选。
- 项目声明的 Excel CSV/bytes/ED/Table/Register 是否闭环；稳定业务硬编码残留与 migration fallback 标记。
- `registeFrameSystem<T>()` callback 对 `null` 不安全的解引用。
- Static API owner/`using static` 可见性候选。
- `destroy()` 中依赖其他 System/Manager 的非空保护/释放阶段候选。
- UI → 具体 Scene 反向依赖。
- `UN_CLASS_LIST(HashSet)` 自注销风险。
- duplicate asmdef Assembly name。
- `MyFrameworkCompatibility/FakeRuntime/Placeholder*` 等伪兼容路径。
- embedded package + manifest 来源重叠信息（不默认判失败；确认实际生效来源）。
- 项目声明的 Direct-Run runtime-critical 资产是否真实存在。
- `FrameSettings.asset`、`KeyFrame/Keyframe.prefab` 与项目 `build_settings_required_scenes` 是否在最终 staged root/Build Settings 闭环。

新增运行合同静态审计需填写 `runtime_contracts` 五类合同，运行：

```bash
python scripts/audit_myframework_runtime_contracts.py <project-root> --config <project-root>/MIGRATION_AUDIT_CONFIG.json --json
python scripts/compare_myframework_generated_regions.py <previous-root> <current-root> --json
```

所有结果记录扫描数量和未覆盖项。自动区比较不得用相同目录、空目录、空 region 获得 PASS；有官方 Generator 变更时按 references/31 记录批准范围及真实执行日志，仍保留 changed 总数。

### Phase 12：Unity 真编译、运行和表现对照

顺序：

0. 从最终 staged root/ZIP 的干净解压副本验证依赖解析与 runtime-critical 资产已经存在；不得先执行自定义 Tools 菜单补资产。
1. CodeGenerator / UI Generator / CSVToBinary。
2. Unity Editor 真编译，解决所有错误和序列化断链。
3. 每种模式完整跑：进入 → 操作 → 受击/结算 → 重开 → 切模式 → 再进入。
4. 连续第二局/多次切场景，专查 ClassPool reset、事件重复注册、集合重入。
5. 目标平台真构建和启动。
6. 与原项目在同输入、同配置、同随机条件下对照 UI、物理、数值、动画、音效和时序；Display Profile 项目至少保留 Home/Menu、Gameplay、Result/Fail 三类目标分辨率截图，并检查 World Camera 无纯色 void/覆盖断层。
7. 对代表性流程检查性能/内存没有明显回退：GC、Instantiate/Destroy、Pool 第二局增长、重复 listener、重复加载等。见 `references/18-performance-regression.md`。

补充运行用例：不连续/重排 ID 与旧位置存档，实际 bytes 失败及存档写出字段，Procedure 再入/退出后回调，半初始化清理，Reset 与保存同帧，UI 二次显示、重叠输入层/奖励通道，周期边界和卡顿 trace。按项目范围选取，不把测试异常写进交付配置。

**没有执行的层级必须明确写“未验证”，不能用静态检查代替；未经穷尽核查不得宣称“只剩 Unity 验证”。**

## 完成判定

只有下面都满足才可称“完成”：

- 原项目定义范围内的玩法和表现无已知差异。
- MyFramework 目标架构已落地，不再依赖迁移兼容层维持运行；Manifest 中目标 legacy debt 已归零或有明确且必要的白名单理由。
- 业务反射清零；必要 `GetType()` 有明确理由。
- ClassObject 所有权、创建、销毁、reset 闭环。
- UI、Scene、Gameplay、System 职责边界清楚；每张目标业务 UI 满足 Per-Layout Gate，且自动生成状态没有伪报。
- 不存在承担多页面路由/业务的 UI God FrameSystem；LayoutRegister/GBR 与 Generator Prefab 集合一致；Font/TMP 等关键 UI 序列化引用无已知断链。
- FrameSystem 注册 callback 对销毁阶段 `null` 安全；跨 System 资源归还/解绑位于正确 `willDestroy/destroy` 阶段。
- 稳定业务数据硬编码盘点完成；范围内数据已正规化，并由目标版本官方 CodeGenerator + CSVToBinary 实际生成，旧→新数据等价性通过；若工具未执行必须保持 GENERATOR_UNVERIFIED。
- Display Profile 已闭环：orientation、FrameSettings UISize、start UGUIRoot、Layout roots、Safe Area 与 World Camera framing/coverage 有目标分辨率证据。
- 资源引用和 Prefab/Scene 无 Missing Script。
- `Assets/Resources` 非白名单资源为 0；运行 Assets 中无 Legacy/Recovered 兼容仓库。
- moved asset `.meta` GUID 保持稳定；旧 script/resource GUID 无非预期残留。
- duplicate Assembly name = 0；不存在为补依赖而制造的 fake asmdef/stub/placeholder。
- MyFramework/Unity Editor API 已按目标版本核实；没有通过兼容 wrapper 掩盖不存在的 API。
- 用户要求 Direct-Run 完整包时，运行关键资产已在最终 ZIP 中落盘，不依赖菜单/首次导入生成；1.1.12 的 Keyframe Prefab 与所有 required runtime Scene/Build Settings 也已闭环。
- Unity 真编译通过。
- 用户要求的运行模式和目标平台已实际验证。
- 最终报告明确列出“已验证 / 未验证 / 已知风险”，不夸大完成度。

## 交付物

用户要求完整工程或增量迁移制品时，按以下清单选择实际交付物；仅修复原工程时不默认生成这些 ZIP 和报告：

1. 完整可覆盖工程/目录包：解压后本身就是干净目标工程，不依赖“先删除上一版文件”，也不依赖用户执行 Tools 菜单或首次导入生成 runtime-critical 资产；正常 Unity import/compile 不属于额外初始化。
2. 增量 Patch（如果用户已有上一阶段）：涉及移动/删除时必须附版本化 DELETE 清单，并验证 patch 后文件集合与完整包等价。
3. `REFACTOR_REPORT.md`，使用 `templates/REFACTOR_REPORT.md`。
4. `DELETED_FILES.txt`，列出必须真正删除的旧文件。
5. 如有 Excel 结构重写，附迁移等价性报告。
6. `PROJECT_MIGRATION_MANIFEST.md`，保留项目级映射、Owner、Bridge/Binding、Serialized Contract、Resource Layout、UI Matrix 和 legacy debt。
7. `MIGRATION_AUDIT_CONFIG.json` 与审计结果（若项目有旧兼容层）。
8. 如有生成器/审计器，附运行入口与结果。
9. `RUNTIME_CONTRACTS.md` 与对应 JSON 声明、扫描覆盖数量、未验证项；新增工具不把用户提供日志自动认证为真实运行。

不要只提供一堆零散 `.cs`，也不要把“请用户自己再整理目录”当作完成。
