﻿# UI Generator / FrameSystem 销毁 / Direct-Run 运行闭环

本章来自 CrushYard R13→R14 实战。它解决一类 2.4.0 仍可能漏过的问题：**结构扫描看起来已经像 MyFramework，但真正进入 Unity 后才暴露 UI 自动生成链、静态 API 来源、FrameSystem 销毁顺序和完整安装包缺资产。**

这些问题现在属于迁移硬合同。

---

# 1. UI 迁移不是“有 LayoutScript 就完成”

以下结构不算 MyFramework UI 终态：

```text
XXXUISystem : FrameSystem
  -> 统一 LOAD/HIDE/UNLOAD 所有页面
  -> 统一处理每个页面按钮
  -> 持有 Popup 类型状态机
  -> 负责 UI refresh / toast / save timer / input / focus
```

即使页面已经有 Prefab 和 LayoutScript，这种 `UISystem` 仍然是在框架外重新造一层 UI Runtime。

默认目标应为：

```text
SceneProcedure / 业务流程
  -> LT.LOAD / LOAD_TOP / HIDE / UNLOAD

LayoutScript
  -> 当前页面成员绑定
  -> 当前页面交互
  -> 当前页面临时表现
  -> 调 Business System 命令

Business System
  -> 业务状态 / 存档 / Gameplay
  -> 事件通知 UI
```

独立 Settings / Shop / Goals / Pause / Daily 等页面必须各自有独立 LayoutScript。公共弹窗壳可以有项目级 `PopupLayout` 基类，但不能把所有页面业务塞回一个 FrameSystem。

允许存在真正的全局 UI 服务，例如跨页面统一 Toast/Loading/Guide 服务，但它必须职责单一，不能成为页面调度 God System；例外要进 Manifest 白名单。

---

# 2. 官方 UGUIGenerator 的四层输出必须同时闭环

对每个根 Layout，至少检查四层：

1. **Prefab 元数据**：Canvas 根上真实 `UGUIGenerator`，MemberData 正确；必要子块有 `UGUISubGenerator`。
2. **LayoutScript 自动区**：member / constructor / assignWindow / init 与 Generator 数据一致。
3. **LayoutRegisterHotFix 自动区**：页面已由正式注册区注册，不靠 MigrationBootstrap/fallback。
4. **GBR LayoutScript 自动区**：对应 `mUIXXX` 引用存在且集合与注册页面一致。

任何一层缺失都不能写“UGUI Generator 完成”。

尤其禁止：

```text
手工填 auto generate 区
自己写 regenerate_xxx_ui.py 后宣称官方 Generator 已执行
LayoutMigrationBootstrap.registerLayouts()
运行时 fallback registeLayout
GetLoadedLayout<T>() 作为长期页面查询层
```

离线脚本可以做**审计、差异预演、Prefab 元数据修复辅助**，但不能把自己生成的自动区冒充官方 Unity UGUIGenerator 产物。官方 Generator 没在 Unity 中真实执行时，状态必须保持：

```text
STRUCTURE_READY / GENERATOR_UNVERIFIED
```

---

# 3. Generator 源文件和 Prefab 必须可相互追溯

正式 LayoutScript 应能追溯到唯一 Prefab。MyFramework 1.1.12 生成代码通常包含：

```text
// generate from:Assets/GameResources/UI/UIPrefab/UIXXX.prefab
```

迁移时必须验证：

- source path 对应真实 Prefab。
- Prefab 名与 LayoutScript 类型一致，或有显式 Generator 自定义类型证据。
- 一个根 Layout Prefab 只有一个 root `UGUIGenerator`。
- root Generator 所在 GameObject 同时是 Canvas 根。
- LayoutRegister 和 GBR 中的 Layout 集合与 Generator Prefab 集合一致。
- 不存在“Prefab 已删，但注册/GBR 还在”的幽灵 Layout。

---

# 4. UI 序列化引用也属于运行合同

Prefab 结构正确不代表字体、Sprite、Material 引用正确。

CrushYard 实战中，137 个 `UnityEngine.UI.Text` 被写成：

```text
m_Font: {fileID: 12800000, guid: 0000000000000000f000000000000000, type: 0}
```

它指向 `unity_builtin_extra`，并不是默认 Arial 的正确引用，结果是：Panel/Image 正常、所有 Text 全部不显示。

MyFramework/Unity 2022.3 使用默认 Arial 时，常见正确内置引用为：

```text
m_Font: {fileID: 10102, guid: 0000000000000000e000000000000000, type: 0}
```

因此 UI Artifact Gate 必须额外检查：

- Font / TMP FontAsset 引用非 Missing/错误 builtin resource。
- Sprite/Material/Atlas GUID 真实存在。
- Prefab 无 Missing Script。
- 不能用“Text 字段有字符串”证明文字能渲染。

`audit_myframework_ui.py` 会检查当前已知错误 builtin font 引用；自定义字体仍需 Unity Import/Play 验证。

---

# 5. `registeFrameSystem<T>()` callback 必须支持 `null`

MyFramework 1.1.12 在系统注册/销毁过程中可能再次执行应用层注册 callback，并传入 `null` 来清空全局引用。

因此下面写法不安全：

```csharp
registeFrameSystem<FooSystem>(com =>
{
    mFooSystem = com;
    com.setInitOrder(10);
    com.setDestroyOrder(20);
});
```

销毁阶段会产生 NRE。

正确写法：

```csharp
registeFrameSystem<FooSystem>(com =>
{
    mFooSystem = com;
    if (com != null)
    {
        com.setInitOrder(10);
        com.setUpdateOrder(10);
        com.setDestroyOrder(20);
    }
});
```

或者使用目标版本源码明确支持的 null-safe 等价写法。

**硬规则：注册 callback 的第一职责是同步 GBR 引用；任何对 `com` 的解引用都必须在非空保护下。**

`audit_myframework_migration.py` 会报告 `frame_system_callback_null_unsafe_candidates`。

---

# 6. `willDestroy()` 是跨 FrameSystem 解绑阶段，`destroy()` 不能假设别的 System 还活着

MyFramework 1.1.12 的关键销毁语义：

```text
所有 FrameSystem.willDestroy()
    ↓
按照 destroyOrder 真正逐个 destroy()
```

因此：

- 需要 `CameraManager/ResourceManager/EventSystem/...` 等其他 System 仍存活才能完成的解绑/归还，优先放 `willDestroy()`。
- `destroy()` 主要释放**自身拥有**的普通对象/Unity Object，并进入 destroyed 状态。
- `destroy()` 中即便保留 fallback，也必须 null-safe、幂等。
- 不能仅凭自己设置的 `destroyOrder` 假设框架内置 System 一定比项目 System 晚销毁；必须读目标版本注册顺序/源码。

典型错误：

```csharp
public override void destroy()
{
    mCameraManager.destroyCamera(mCamera); // CameraManager 可能已经置 null
    base.destroy();
}
```

应改为：

```csharp
public override void willDestroy()
{
    releaseOwnedCameraWhileManagerAlive();
    base.willDestroy();
}

public override void destroy()
{
    releaseOwnedCameraFallbackNullSafe();
    base.destroy();
}
```

项目 Manifest 必须增加 FrameSystem Dependency/Destroy Matrix，写清跨 System 依赖的释放阶段。

---

# 7. Static API 的“存在”与“当前文件可见”是两回事

仅仅确认 API 在 MyFramework 源码里存在还不够，还要确认当前文件使用了正确 owner/静态导入。

MyFramework 1.1.12 当前实战：

```text
changeProcedure<T>() / changeProcedureDelay<T>() -> FrameUtility
mEventSystem / mGameFrameworkHotFix              -> FrameBaseHotFix
isEditor()                                       -> FrameBaseUtility
mGameSceneManager / mLayoutManager / mResourceManager
  -> AOT: FrameBase；HotFix: FrameBaseHotFix
```

这里不能把静态 owner 简化成“一符号一 owner”。例如 `Game.cs` / AOT `LaunchScene` 合法使用 `using static FrameBase;`，而 HotFix 同名成员来自 `FrameBaseHotFix`。审计应接受 source-confirmed owner 集合，再依据调用文件实际 import 判断。

例如：

```csharp
changeProcedureDelay<NextProcedure>();
```

若当前类型没有继承对应 owner，又没有：

```csharp
using static FrameUtility;
```

就会到 Unity 编译时才报 `CS0103`。

同理 LayoutScript 使用：

```csharp
mEventSystem
mGameFrameworkHotFix
```

必须有目标版本真实的 `FrameBaseHotFix` 可见方式。

因此 API Provenance Matrix 现在不仅记录“声明类”，还必须记录**当前调用文件的访问方式**：fully-qualified / inherited / `using static`。

`audit_myframework_migration.py` 增加 static API visibility 候选扫描。

---

# 8. FullInstall 不能只补 Unity Project 三目录，还要补 Framework Runtime Template 资产

“有 `Assets / Packages / ProjectSettings`”只是 Unity Project 外形，不代表 MyFramework Runtime Artifact 已闭环。

MyFramework 1.1.12 当前源码确认：

```text
FrameDefine.KEY_FRAME_FILE = "KeyFrame/Keyframe.prefab"
KeyFrameManager.init() -> ResourceManager.loadGameResourceAsync(KEY_FRAME_FILE)
```

因此目标包如果启用了标准 HotFix Framework，至少要确认：

```text
Assets/GameResources/KeyFrame/Keyframe.prefab
```

真实存在。官方 `ProjectTemplate~` 中已有的 runtime-critical 资产不能在“只拷工程骨架”时漏掉。

完整包组装优先级：

1. 目标项目已有完整工程根。
2. 同版本 MyFramework 官方 `ProjectTemplate~`。
3. 同版本已验证参考工程。
4. 禁止随意拼一套 `Packages/ProjectSettings` 后漏掉模板运行资产。

另外，官方包内 `ProjectTemplate~` 本身可能包含一套模板 asmdef。它是模板源，不是当前项目编译 Assembly；Dependency Audit 不能把其中 `Game/HotFix/AutoGenerated.asmdef` 与项目 Assets 下同名 asmdef 误判成 duplicate。

---

# 9. 所有运行时 Scene 必须已经进入 Build Settings

仅把 `start.unity` 放在第一位不够。

如果 `SceneSystem/SceneManager` 最终会加载：

```text
Assets/GameResources/XXX/Scene/XXX.unity
```

则 Direct-Run 包中该 Scene 必须：

- 真实存在。
- 保持正确 `.meta` GUID。
- 已加入 `ProjectSettings/EditorBuildSettings.asset` 并启用。

不能要求用户“自己 Add Open Scenes”。

项目配置应通过 `build_settings_required_scenes` 显式列出运行 Scene；`audit_myframework_structure.py` 会校验它们。

---

# 10. 完整包交付前新增五个闭环证据

除 2.4.0 的四类审计外，2.5.0 增加 UI Contract Audit：

```bash
python scripts/audit_myframework_ui.py <project-root> \
  --config <project-root>/MIGRATION_AUDIT_CONFIG.json
```

完整包报告至少写：

```text
UI generator prefabs            N
Layout scripts matched          N/N
LayoutRegister set matched      PASS/FAIL
GBR layout set matched          PASS/FAIL
Manual layout registration      0
UI God FrameSystem candidate    0/whitelist
Known bad builtin font refs     0
FrameSystem null-unsafe callback 0
Static API visibility candidates 0
Cross-System destroy candidates 0/whitelist
Required Build Settings scenes  N/N
Keyframe.prefab                 EXISTS
```

这些仍然不能替代 Unity 真编译、官方 Generator 真执行和 Play Mode；它们只是把此前必须等 Unity 才暴露的一批结构错误前移到交付前。

# 11. 2.6.0：Display / Generator Ownership / Excel 前置闭环

2.5.0 的“四层 Generator 集合一致”仍可能漏过两类错误：

1. LayoutScript 有 marker，但 `newObject/assignWindow/new(this)` 仍是手工写在自动区外。
2. UI 已经完整，但整个项目的 FrameSettings/Prefab Root 仍用了错误横竖屏基准。

因此 2.6.0 额外要求：

- `audit_myframework_ui.py` 检查 Generator-owned binding code 是否越出对应自动区。
- `audit_myframework_display.py` 检查 Display Profile、FrameSettings、start UGUIRoot、Layout roots 与 orientation 冲突。
- 稳定业务 Catalog/价格/奖励配置在 UI 最终 polish 前先走 `audit_myframework_excel.py` 与官方 Excel 工具链；不要一边精修 Shop UI，一边仍让 Catalog 数组硬编码在 Profile/System。


# 12. 3.1.0：LayoutScript resetProperty 与版本间生成区保护

- LayoutScript/UI 页面脚本不实现 `resetProperty()`；页面状态按 `onGameState/onHide/setData` 等真实 UI 生命周期管理。
- `ClassObject/WindowRecyclableUGUI/WindowStructPool item` 的 reset 合同不受影响。
- `audit_myframework_ui.py` 默认把 LayoutScript `resetProperty()` 作为失败项；特殊版本必须显式 `layout_reset_property_allowlist`。
- 若本轮没有运行官方 UGUIGenerator，应将上一版和当前版的 Layout/GBR/Register 自动区做版本间 diff，期望 0 drift。
- 若运行了官方 UGUIGenerator，则自动区变化必须与 Prefab MemberData 输入变化一致，并保留 Unity Generator 执行证据。
