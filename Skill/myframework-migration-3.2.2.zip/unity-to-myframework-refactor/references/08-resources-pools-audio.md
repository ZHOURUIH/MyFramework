﻿# 资源、对象池与音频

资源迁移不是“把东西从一个目录挪到另一个目录”。必须同时保证：**目录职责正确、GUID 不变、加载方式正确、旧副本被删除、最终制品没有兼容仓库。**

完整硬规则见 [Resources / GameResources / 最终制品完整性](20-resource-layout-artifact-integrity.md)。

## Resources 白名单

`Assets/Resources` 默认按白名单管理。MyFramework 1.1.12 已从源码确认的固定资源包括：

```text
Assets/Resources/Scene/start.unity
Assets/Resources/Settings/FrameSettings.asset
```

第三方固定 Resources 合同必须在项目 `MIGRATION_AUDIT_CONFIG.json` 的 `resources_allowlist` 中显式声明，并在 Manifest 记录依据。

禁止把旧业务 Prefab、ScriptableObject、Bot、世界 UI、字体材质整包塞进 Resources 作为过渡终态。

## GameResources

运行游戏资源主要整理进：

```text
Assets/GameResources/
```

按职责拆分 Prefab/UI/Font/Audio/Data/Excel 等。目录是职责提示，不强制所有项目完全相同。

**GameResources 不等于必须字符串路径加载。** 原本稳定的 Scene/Prefab serialized reference 可以继续保留；移动资源时保持 `.meta` GUID 即可。真正动态加载才接 ResourceManager。

## ResourceManager

HotFix 业务资源动态加载优先框架 ResourceManager。同步/异步策略根据目标平台能力选择；WebGL/小游戏尤其要验证同步加载限制。

不要在 HotFix 业务中散落：

```csharp
Resources.Load
AssetDatabase.LoadAssetAtPath   // Editor 除外
File.ReadAllBytes + 自己 Instantiate
```

## PrefabPoolManager

适合：

- 子弹。
- 特效。
- 高频单位。
- 重复 UI/世界对象。

owner 应明确负责 `createObject` 和 `destroyObject`。不要一边 ClassPool 管 wrapper，一边 GameObject 被另一个系统随意 Destroy，导致 wrapper 字典残留。

## 双层对象所有权

很多 Gameplay 对象有两层：

```text
Actor(ClassObject) <-> GameObject/Prefab instance
```

必须定义销毁顺序。例如：

```text
GameObject 准备销毁
-> ActorSystem 找到 wrapper
-> 注销 / UN_CLASS Actor
-> PrefabPoolManager.destroyObject 或必要 Unity Destroy
```

反过来时也要保证不会二次回收。

## GUID / `.meta` 完整性

资源移动必须连同 `.meta`。每轮至少检查：

- moved asset GUID unchanged。
- duplicate GUID = 0。
- 删除资源 GUID 无运行 YAML 残留。
- Prefab Missing Script。
- Sprite/Atlas/Material/Shader/TMP FontAsset/AudioClip/Scene Root 引用。
- Addressable/AssetBundle key（若项目使用）。

## Legacy 资源目录

`LegacyRuntimeDebt` / `RecoveredSourceReference` / 运行时 Compatibility 目录只能是有删除计划的中间态。最终运行 Assets 中不得保留“旧工程完整副本 + 新框架壳”。

## Audio

优先复用 AudioManager / AudioHelper / 项目 SoundRegister。

迁移时保持：

- BGM 是否跨场景。
- SFX 是否可叠加。
- 音量分类。
- Pause 对 Audio 的影响。
- 对象销毁时是否停止 loop。

不要仅把 `AudioSource.Play()` 包成一个新工具类就称完成。
