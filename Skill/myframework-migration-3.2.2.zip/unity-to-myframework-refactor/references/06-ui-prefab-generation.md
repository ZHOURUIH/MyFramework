# UI 与 Prefab 生成

## 基本结构

- 一个可独立显示/关闭的布局对应一个 LayoutScript。
- 子块复用使用 WindowObjectUGUI / WindowStructPoolBase 等框架机制。
- 业务 LayoutScript 不互相继承来共享 UI。

## 生成器优先

标准流程：

1. 改 Prefab 节点名和结构。
2. 检查同级重名、非法标识符、生成元数据。
3. 运行项目原 UGUI 生成器。
4. 保留生成的 member/constructor/assignWindow/init 段。
5. 只在非生成区写业务显示逻辑。

不要手写生成段让代码“看起来像生成器”。

## Prefab 必须是交付资产

如果用户要求“打开 Unity 直接 Play”：

- UI Prefab、复杂对象 Prefab 必须已存在于包内。
- 不接受运行时启动后才 BuildPrefab。
- 引用的 Sprite/Material/Font/Atlas 必须真实存在且不是白图占位。


## LayoutScript 不使用 resetProperty

MyFramework UI 页面脚本的状态生命周期与 ClassObject 池对象不同。项目 LayoutScript/UI 页面脚本默认**不得实现 `resetProperty()`**。

页面临时状态应在其真实语义位置收口：

- `onGameState()`：每次进入/显示时初始化本次页面状态。
- `onHide()`：隐藏时恢复动画、临时选择、pause 标记等。
- `setData()/setXXX()`：由调用方提供本次显示数据。
- `destroy()/willDestroy()`：只处理真实销毁合同。

这条规则不适用于 `ClassObject`、`WindowRecyclableUGUI`、`WindowStructPool` item 等真实需要 reset/回池合同的对象。不要为了“对象池更安全”给 LayoutScript 额外增加第二套 reset 生命周期。

`audit_myframework_ui.py` 会把 LayoutScript 中的 `resetProperty()` 作为候选失败项，特殊项目如确有目标版本源码证据，必须显式 allowlist。

## UI 与业务

UI 可以：

- 调 Business System 命令。
- 订阅业务事件。
- 显示 System 提供的数据。

UI 不应该：

- 直接切换具体 Scene 类型。
- 直接改 Gameplay 私有状态。
- 保存跨局核心状态。

## 输入

优先 `registeCollider()`、框架 Button/LegendButton、Drag/Scroll 组件。

迁移时保留：

- pointer down/up 同帧情况。
- drag threshold。
- pivot 对 collider 中心影响。
- mask/viewport 穿透规则。
- 世界 UI 与屏幕 UI 的 camera。

## 布局与适配

普通节点默认只用 ScaleAnchor（Game 层对应 ResScaleAnchor），保持宽高比，去除原生 UGUI anchors；PaddingAnchor 仅用于少量有明确父节点边界停靠合同的节点，禁止用它表达普通居中、文本列、scroll/viewport/content 或进度 fill。全屏覆盖/无可见图形的输入覆盖区域才可按实际用途不保持比例。排列使用 autoGrid/WindowStructPool。

所有节点、模板与启动/下载 UI 都遵循 [UI 适配规则](32-ui-scale-anchor-policy.md)。先保留设计分辨率下的矩形几何，再修改组件；每个例外按精确节点记录，不进行逐路径运行时补丁。

不要把大量 `scale(root, "A/B/C")`、`hide(path)` 作为长期架构。

## Text/TMP

迁移需要逐项保留：

- Font/TMP FontAsset。
- alignment。
- font size / auto size。
- overflow/wrap。
- rich text。
- outline/shadow。
- fallback font。
- 本地化刷新。

“文字能显示”不等于视觉一致。

## 2.5.0 补充：页面所有权与 Generator 四层闭环

- 独立页面的 owner 是其 LayoutScript，不再新增一个 `XXXUISystem : FrameSystem` 统一承担多页面加载、按钮路由、Popup 状态、页面刷新、存档计时与输入。
- SceneProcedure/业务流程决定 Layout 的 LOAD/HIDE/UNLOAD；LayoutScript 负责页面交互；Business System 负责业务状态。
- UGUIGenerator 完成必须同时闭环 Prefab MemberData、LayoutScript 自动区、LayoutRegisterHotFix、GBR LayoutScript 引用。
- 手工 `LayoutMigrationBootstrap`/fallback 注册只能是中间债务，最终必须删除。
- 离线脚本写出“像 Generator 的自动区”不能替代官方 Unity UGUIGenerator 真执行。
- UI Prefab 的 Font/TMP FontAsset/Sprite/Material serialized reference 也属于交付合同，必须单独审计。

## 2.6.0 补充：Display Profile 与生成代码所有权

- UI 开始迁移前必须先冻结项目 Display Profile；不能先按参考项目 1920x1080 搭 Prefab，再在后期发现原项目其实是竖屏。
- `FrameSettings.UISize*`、start Scene `UGUIRoot`、Layout Prefab Root 和全屏覆盖节点属于同一设计分辨率合同。
- 横竖屏切换不能只交换 Root 宽高；必须重新验证 Root 直系子节点边界、Safe Area、ScaleAnchor 的等比配置、少量明确边界停靠的 PaddingAnchor 和运行截图。
- auto-generate marker 只是边界标记，不代表代码归属正确。`newObject(...)`、成员 WindowObject 的 `.assignWindow(...)`、Generator-owned `new(this)` 等绑定代码不得长期维护在自动区外。
- Root `UGUIGenerator.mParentType` 必须与正式 Layout 基类一致；MyFramework 1.1.12 默认 Layout 为 `LayoutScript`。SubGenerator parent type 必须非空并与真实子窗基类一致。
- 如果点击回调需要 index/上下文参数，可关闭 MemberData 的自动 click，让 Generator 只生成强类型成员，再在业务区注册参数化回调；禁止两边同时注册。

## 3.2.0 运行合同补充

3.2.0 UI 验收增加 [输入层/业务刷新/多通道动画](30-cadence-ui-input-animation.md)；新增静态节点触及 Generator 时，不能以手工绑定一致代替正式工具。
