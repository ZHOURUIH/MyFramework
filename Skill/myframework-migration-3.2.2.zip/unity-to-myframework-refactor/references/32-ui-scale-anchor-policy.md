# UI 适配：ScaleAnchor 默认，PaddingAnchor 例外

适用于所有正式 UI Prefab，包括 HotFix 的 `GameResources/UI/UIPrefab`、Game 层启动/下载的 `Resources/UI/UIPrefab`，以及这些页面引用的行、卡片、按钮模板。不要只检查带 Generator 的页面根节点。

## 1. 先保留设计分辨率下的几何

先从项目 Display Profile、可运行基线和当前框架源码确认设计尺寸、节点中心、矩形尺寸、字体和输入区域。去除原生 UGUI anchors 或修改 pivot 时，在设计分辨率下保持节点的实际位置与边界；不能只把 anchor/pivot 数值设为 0.5 而让对象移动。

编辑/保存 Prefab 或重新计算 Padding 距离前，先停止 Play，并将 Unity Game 视图恢复该项目的标准设计分辨率。框架会对非标准分辨率提示；不能从运行比例、已经适配的实例或缩放后的矩形反写设计值。不同宽高比用于运行验证，验证完回到设计尺寸再编辑；具体设计尺寸按 Display Profile / FrameSettings 核实，不把 1920×1080 等某个项目数值固化为所有工程的默认。

普通节点的持久化配置为：

- `anchorMin = anchorMax = (0.5, 0.5)`；pivot 保留其真实几何/动态宽度用途，不能把 pivot 当作 UGUI anchors 一律改成中心。
- HotFix 使用 `ScaleAnchor`；Game/AOT 层按当前框架类型使用 `ResScaleAnchor`。
- `mKeepAspect = true`；使用框架默认缩放基准，除非项目真实显示合同要求其他基准。
- HotFix `ScaleAnchor` 的 `mRemoveUGUIAnchor = true`。当前 Game 层 `ResScaleAnchor` 只有 `mKeepAspect` / `mAspectBase` 等自身字段，不能给它填 HotFix 的 `mRemoveUGUIAnchor`；Game `UnityUtility.applyAnchor` 自身负责把原生 anchors 中心化。字段与执行入口均按目标版本真实源码核实。
- 默认不添加 `PaddingAnchor` / `ResPaddingAnchor`。

同时检查有效缩放基准：已核实版本默认 `ASPECT_BASE.AUTO`（序列化值 2）取宽高缩放中的较小值；`ASPECT_BASE.NONE`（值 4）保留两个独立轴，**即使 mKeepAspect=true 也不是等比**。不能仅看布尔值宣称保持比例。枚举数值按目标版本源码核实；非等比例外同时覆盖 false 或 NONE 的有效情况。

不要在业务脚本中写逐路径 setPosition/setScale/anchoredPosition 补丁，也不要使用 Unity LayoutGroup、ContentSizeFitter、CanvasScaler 或原生 anchors 代替框架布局。

在当前已核对实现中，ScaleAnchor 根据屏幕相对设计尺寸修改每个节点的 rect 尺寸、位置与字体，**不通过父节点 transform.localScale 传递缩放**。因此父子节点都添加 ScaleAnchor 不构成重复缩放；不能凭 Unity transform 缩放经验只给父节点添加而漏掉子节点。其他框架版本仍先核对其源码。

动态文本要额外保留宽度变化后的排列合同。`myUGUITextAuto` / `applyPreferredWidth` 可能只修改矩形宽度，不会自动把旁边的数值或兄弟文本移走；取消原生 anchors 后，要保留合法的左/右 pivot，或在内容刷新后通过框架对齐/排列方法定位兄弟节点。检查属性 Name/Value、Score/Season 等组合在不同文案与数字长度下是否重叠。禁止用 PaddingAnchor 给每列重新造对齐关系。

## 2. 非等比缩放只给明确的覆盖区域

绝大多数节点保持宽高比，包括按钮、文字、图标、窗口面板、列表行、viewport/content 和进度条。

`mKeepAspect = false` 只用于需要随两个轴覆盖可视区的具体节点，例如：

- 布局全屏 root、纯色全屏背景或遮罩。
- 没有可见图形的全屏/分屏输入命中区域，其宽和高必须分别覆盖目标区域。

这些例外必须逐个记录节点和用途。不能把“容器”“父节点”“scroll”“进度条 Fill”当作统一关闭保持比例的理由。可见 Sprite、按钮图形和中文文字不能因为其输入区域需要全屏而跟着拉伸。

## 3. PaddingAnchor 必须有真实边界停靠用途

仅极少数节点需要 PaddingAnchor：例如 HUD 固定距屏幕 root，或控件固定距真实目标父容器的左/右/上/下边界，并且该边距合同无法由等比缩放表达。父节点不必是屏幕，但必须是实际被停靠的区域，不能借此逐节点重建普通布局。普通节点先只用 ScaleAnchor，不能因需要居中、跟随父节点或对齐文本就添加 PaddingAnchor。

禁止把 PaddingAnchor 用于：

- 普通父子布局和面板内部居中。
- 排行榜的名次/姓名/分数列、设置文字与开关对齐。
- scroll/viewport/content、进度条 fill、普通按钮和模板内每个子节点。
- 逐节点复制原生 stretch anchors，或在大多数节点上叠加 ScaleAnchor 与 PaddingAnchor。

列表排列使用框架 autoGrid/autoGridVertical 和 WindowStructPoolBase 封装；滚动尺寸与顶部位置使用框架 scroll/pool 的已有方法；进度使用框架进度组件。方法名、参数与 owner 以目标版本源码为准，不凭拼写或印象猜签名。

滚动还必须保留渲染裁切合同。`myUGUIDragView` 等框架拖动/排列能力不等于自动裁切越界图形；按基线和目标框架实际实现保留必要的 `Mask` / `RectMask2D`，或使用已有框架裁切封装。这类必要渲染组件与被禁用的原生 `ScrollRect` 等控件区分，不能在移除原生控件时顺便删除裁切。验收需滚动到顶部与底部，确认行、图标与文字在 viewport 外不可见，不盖住 HUD、分数或其他界面；只确认拖动正常不能 PASS。

保留的每个 PaddingAnchor 必须写清：Prefab、完整节点路径、实际父节点区域、固定哪条边界、边距规则和测试宽高比。对其父节点是否真的代表屏幕边界、节点 pivot/旋转/localScale 与框架计算前提一并核实；例如当前实现要求中心 pivot，不支持旋转，并警告 localScale 非 1。

## 4. 原生 anchors 只有明确自动节点例外

业务 UI 的 authored 节点不使用 UGUI 自身 anchors。仅引擎/框架自动生成且由该机制管理的特定节点可以保留其所需原生 anchors；记录生成来源和完整节点路径。不能将普通 authored root、整个目录、TMP 主文本或某类控件全部加入例外。

TMP 自动子网格等情况要区分自动子节点与开发者配置的主文本。静态 Prefab 中有例外时精确记录；纯运行期生成节点按生成逻辑和实际层级确认，不虚构到资产中。

## 5. 修改、审计和运行验证

1. 枚举所有正式 UI Prefab 和被引用模板，保存设计分辨率下的基线几何。
2. 删除无真实停靠用途的 PaddingAnchor；用 ScaleAnchor 的等比缩放表达普通布局。
3. 去除 authored 节点原生 anchors，保持设计几何；逐个记录少量非等比/边界停靠/自动节点例外。
4. 若节点名、结构或 MemberData 改变，执行项目正式 UGUIGenerator；只改适配组件与矩形参数不需要手改生成代码。
5. 执行只读审计，再在设计分辨率和至少一个不同宽高比下验证页面、中文字体、列表滚动到顶部/底部后的渲染裁切、进度、点击命中和全屏覆盖。

```bash
python scripts/audit_myframework_ui_adaptation.py <project-root> --config <project-root>/MIGRATION_AUDIT_CONFIG.json --json
```

在 `ui_adaptation.prefab_roots` 写入项目实际目录（不存在的目录移除，有额外模板目录则添加）。脚本从当前源码 `.meta` 发现 ScaleAnchor/ResScaleAnchor/PaddingAnchor/ResPaddingAnchor GUID；离线制品没有框架源码时，在 `anchor_component_guids` 中填已核实的目标版本 GUID。

组件层级必须一致：Game 层 Resources 启动/下载 UI 使用 ResScaleAnchor/ResPaddingAnchor，HotFix GameResources UI 使用 ScaleAnchor/PaddingAnchor。脚本不会把名字都以 `ScaleAnchor` 结尾当成合法互换。若资产位于其他目录，或目标版本有不同合同，在 `scale_component_by_root` 用实际目录前缀声明 `ScaleAnchor` 或 `ResScaleAnchor`；未声明层级不能 PASS。

脚本从目标 `FrameBaseEnum.cs` 解析 ASPECT_BASE；离线制品可填写已核实的 `aspect_base_values`（包括 AUTO、NONE），不能套用另一版本数值。嵌套 `mAspectBase` override 也进入检查范围。

例外格式（每项均使用精确路径及实际用途，不允许通配符）：

```json
{
  "ui_adaptation": {
    "prefab_roots": ["Assets/GameResources/UI/UIPrefab", "Assets/Resources/UI/UIPrefab"],
    "scale_component_by_root": {"Assets/GameResources": "ScaleAnchor", "Assets/Resources": "ResScaleAnchor"},
    "padding_exceptions": [
      {"prefab": "Assets/GameResources/UI/UIPrefab/UIBattle.prefab", "node": "UIBattle/HUDLeft", "reason": "HUD root 固定距屏幕左边界，已核实其 parent 为全屏 root"}
    ],
    "nonuniform_scale_exceptions": [
      {"prefab": "Assets/GameResources/UI/UIPrefab/UIBattle.prefab", "node": "UIBattle", "reason": "布局 root 沿两轴覆盖整个屏幕"}
    ],
    "automatic_node_exceptions": []
  }
}
```

返回码：0 仅代表已声明资产的静态规则通过；1 表示发现规则问题；2 表示目录/组件身份/节点覆盖不足，未完成检查。嵌套 Prefab 源资产需纳入扫描范围；相关 anchor/组件 override 要在 Unity 核实有效结果，脚本会报告候选，不能假称已解析继承布局。例外理由仍需人工核实，静态 PASS 不能替代实际画面和输入验证。


3.2.2 审计补充：直接 Padding 节点检查序列化的 localRotation/localScale；相关嵌套 pivot/旋转/缩放/停靠参数 override 均需 Unity 核实。混入无法解析的 prefab 不再被其他已覆盖资产掩盖；GUID 冲突和无法区分 AUTO/NONE 的枚举配置不接受。框架会主动禁用 Anchor MonoBehaviour 并由 applyAnchor 显式调用，不能仅凭 enabled=false 判断适配失效。
