# RagdollArchers 实战沉淀

此文件记录可泛化经验，不把项目特定数量当其他项目目标。

## 反射绑定

原项目曾用大规模 ActorBinding 配置描述类型、字段和节点。最终做法是：

- Editor/迁移阶段读取旧绑定。
- 生成强类型 Registry。
- 每个资产分支和 Actor 类型显式创建、赋值。
- 对旧绑定逐条验证访问链等价。
- Runtime 反射清零。

结论：**动态绑定需求不等于运行时必须反射**。如果资源集合在构建时已知，生成代码通常更稳定。

## Excel 正规化

有效改造包括：

- 大表拆业务主表 + 一对多子表。
- 0/1 → bool。
- 魔法 StatID → enum。
- ModeMask → 明确模式字段。
- RGB 拆列 → 工具支持类型；Color 不支持时改 Hex string。
- 删除迁移残留 SourcePath。
- 外键/路径约束进入元数据。

关键不是列数越少越好，而是每列表达稳定业务概念。

## UI 与 Scene 解耦

一度 UI 通过 BattleSystem 获取具体 Scene 再执行 revive、切模式、领奖励等。最终改为：

```text
UI -> BattleSystem -> Mode -> Scene/Gameplay
```

UI 只通过 Binding 获得真正需要显示的世界引用。

## 生命周期

真实发现过：

- Scene 先清对象、后 detach Mode 导致 Mode.destroy 访问 null。
- Firework/Explosion、Pool binding、PlayerStats/Stat 等“外层 new、内层 CLASS”的半迁移。
- GameObject 真销毁但 Actor wrapper 未回收。
- ObjectSystem 越权 destroy PoolSystem/ActorSystem 对象。
- HashSet 遍历回收时对象自注销。
- update/destroy 共用 snapshot 产生重入风险。

结论：**MyFramework 对象池迁移的核心不是 CLASS 关键字，而是 owner + destroy 顺序 + resetProperty + 重入安全。**

## 配置行为基线

后期生命周期重构时对 Excel、UIPrefab、ActorRegistry 做版本哈希对比，确认 0 差异。这种“控制变量”方式比笼统宣称“没改玩法”更可信。

## 编译错误的处理方式

`UIArcherSettings` 引用已删除 `Settings` 时，没有恢复一个空 Settings，而是追到真实新职责 `ArcherSettingsController`。这是迁移期编译错误的通用处理原则：

**修复职责链，不修复名字。**
