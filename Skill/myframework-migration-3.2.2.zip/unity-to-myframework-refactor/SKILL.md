---
name: unity-to-myframework-refactor
description: 将现有 Unity 工程迁移或继续重构到 MyFramework，保留可运行基线的玩法、界面、数据和生命周期；处理官方 UI/表格生成、资源与平台构建回归。适用于完整迁移、已有迁移的局部修复及迁移后的 OPPO/vivo 快游戏构建调试；不用于网页抓取、首次 H5 到 Unity 复刻或无关 Unity 开发。
metadata:
  version: "3.2.2"
---

# Unity → MyFramework 重构

目标是改变架构与框架用法，同时保留任务指定基线的运行行为。编译、静态审计、生成器、运行和平台受理分别验证，不能互相替代。

## 先确定本轮范围

- **完整迁移**：读 [发现与基线](references/01-discovery-baseline.md)、[能力图](references/02-framework-capability-map.md)、[完整阶段清单](references/34-detailed-migration-workflow.md)，建立项目 Manifest，再按模块推进。
- **继续迁移或局部修复**：先读最新项目记录和实际调用链，仅加载下面涉及的模块合同；保护已有未提交修改，不重做已验证且本轮未影响的工作。
- **迁移后的 OPPO/vivo 构建、包体或启动问题**：读 [快游戏构建与调试](references/33-quickgame-build-debug-release.md)，直接完成原工程构建链的修复，不强行启动全项目结构重构。
- **只询问目录或文件是否必要**：检查实际调用者、构建入口和运行引用后回答。说明、日志、备份与构建依赖分开；询问“可以删吗”本身不表示要求执行删除。

用户要求和仓库规范决定范围、交付物与编码风格；API、生命周期和序列化事实以目标版本源码为准。[硬要求总表](references/19-hard-requirements.md) 是具体合同索引，按本轮涉及模块读取，不把案例版本数值直接套到其他项目。

## 开始时确认

1. 实际仓库、分支、未提交状态、AGENTS.md、Unity/MyFramework 版本与生效 Package 来源。
2. 可运行的行为基线。普通迁移以原 Unity 为默认；若用户明确指定不完整移植工程的合法上游，则以该上游为真值。参考框架项目只提供结构范式。
3. 本轮需改的生命周期、资源、数据或构建入口，以及实际验证条件。采用项目已有工具，先核对源码/API，再新增封装。

## 不可丢失的合同

- 生命周期一起迁移：创建、bind/init、更新/物理帧、回调、取消、willDestroy/destroy、回池、第二次进入。框架桥接组件不等于业务 MonoBehaviour；根据真实继承和 prefab/scene 挂载确认删除范围。
- 系统 callback 要接受销毁阶段的 null；跨系统解绑/归还放在依赖仍存活的阶段。基类有实现的 override 保留对应 base 合同；抽象方法不能伪造 base 调用。
- UI 使用实际 Prefab、LayoutScript、窗口池和官方 Generator；业务 UI 不互相继承，不用多页面 UI God System，也不把 resetProperty 套到 LayoutScript。
- 官方自动生成区只由真实生成流程修改。未运行生成器时，相关自动区应与独立基线 0 drift；手工同形代码、准备态 bytes 不算生成器已执行。
- 资源移动保留 .meta GUID；删除旧组件前迁移序列化字段、引用与物理绑定。Resources 白名单、GameResources 和实际加载链必须对应，不能用 Legacy 仓库或假 asmdef/stub 补编译。
- 数据保留 ID、排序、存档身份、默认值、精度和随机映射；表格需真实 consumer 与 bytes 加载后的 Ready Gate。
- 保留原周期时钟/相位/条件顺序、输入命中层、动画通道、暂停、重开和存档寿命。不要借架构迁移顺手改变玩法。
- 业务代码风格仅用于采用该规范的范围，保护框架、第三方和生成代码。语义重命名不能用全局字符串替换代替；正常 lambda 不是表达式体成员。
- 项目自有代码按 [代码规范](references/10-reflection-generated-code-style.md) 排版：复杂语句按语义换行，函数之间零空行、全文不出现连续空行，局部变量在合适的使用处内联声明；使用目标 Unity 支持的简洁语法并优先复用 MyFramework 封装。受影响程序集编译警告必须清零，按 [验证标准](references/11-verification.md) 检查。

## 按模块读取

| 本轮涉及 | 合同与方法 |
|---|---|
| 启动、系统、场景 | [目标架构](references/03-target-architecture.md)、[所有权](references/04-lifecycle-ownership.md)、[场景](references/05-scenes-gameplay.md)、[Scene/Reset](references/29-scene-restart-save-lifetimes.md) |
| UI 与适配 | 先读 [适配规则](references/32-ui-scale-anchor-policy.md)，再读 [UI/Prefab](references/06-ui-prefab-generation.md)、[Generator 合同](references/15-ui-generator-contract.md) |
| UI 销毁、生成区、直接运行 | [生成器与运行闭环](references/23-ui-generator-lifecycle-directrun-closure.md)、[覆盖证据](references/31-contract-audit-evidence-coverage.md) |
| 显示方向、相机与视觉 | [显示合同](references/24-display-orientation-visual-parity.md)、[最终有效行为](references/27-upstream-parity-effective-behavior.md) |
| Excel/CSV/bytes | [配置规范](references/07-excel-data.md)、[官方工具链](references/25-excel-hardcode-toolchain-closure.md)、[消费与身份](references/28-table-consumption-identity-readiness.md) |
| 资源、池、音频与绑定 | [资源/池](references/08-resources-pools-audio.md)、[制品完整性](references/20-resource-layout-artifact-integrity.md)、[序列化绑定](references/21-binding-bridge-serialization.md) |
| 事件、输入、物理、动画 | [异步与桥接](references/09-events-async-tween-input-physics.md)、[周期与通道](references/30-cadence-ui-input-animation.md) |
| API、依赖、编码规范 | [目标版本 Profile](references/14-current-version-profile.md)、[依赖与直接运行](references/22-dependency-api-directrun.md)、[代码规范](references/10-reflection-generated-code-style.md) |
| OPPO/vivo RPK | [构建、缩包、日志和发布](references/33-quickgame-build-debug-release.md) |
| 排错与性能 | [陷阱](references/12-pitfalls.md)、[性能回归](references/18-performance-regression.md) |

UI 默认 ScaleAnchor/ResScaleAnchor，绝大多数等比。PaddingAnchor 仅设置极少数节点相对父节点实际边界的停靠；记录父区域、方向、边距和用途，不能用来逐节点替代原生 anchors、文本列/scroll/进度 fill 排列。编辑前停止 Play、恢复项目设计分辨率；保留几何和合法 pivot，再检查不同宽高比。

## 验证与交付

读 [验证标准](references/11-verification.md)。选择能覆盖本轮风险的检查；完整迁移最终检查结构、UI、显示、数据、资源、依赖、运行合同和生成区，局部任务只重跑受影响检查并明确未覆盖范围。

- 工具返回 0 仅说明已声明静态范围通过；记录实际文件/节点/表/region 数量，空覆盖、未解析 nested override 不能 PASS。
- Unity 编译和运行验证必须使用待交付版本。验证玩法或生命周期时覆盖重开/第二局；UI 修改检查真实画面、中文和输入；平台修改检查正式产物冷启动及日志。
- 不把模拟器启动说成登录/实名/真机广告或平台上传已通过；不把分包合计说成磁盘 RPK 文件大小。
- 原工程修改优先接入现有正常构建入口，使用户按既有操作得到结果。日志脚本与审计工具是可选验证工具，不应成为额外手工发布步骤。
- 交付用户要求的工程修改或制品；完整 ZIP、Patch/删除清单只在交付形式需要时生成。git add/commit/push 按用户授权分别处理；私钥和账号数据不进入 Git/技能包。
- 简洁报告修改、实际测试、产物路径和未验证边界。发现技能缺口先记录并完成项目修复；只有用户明确要求维护技能时才写入技能，不自动改写已安装技能。

模板、审计工具和历史案例保留在本包；仅选择本轮需要的资源。历史案例路径、版本、阈值和“通过”结果使用前核实。
