# 工程接入与文件清单

## 先核对现有实现

用 `rg --files` 找 Game.cs、GameHotFix.cs、GBR/GameBaseHotFix.cs、PlatformInfo.cs、布局注册、asmdef、FrameSettings/MiniGameSettings、启动场景。先读当前框架 API：

| 已有框架能力 | 本包使用位置 |
| --- | --- |
| GameFramework / GameEntryBase / GameLayout | AOT 入口和下载界面 |
| GameScene / SceneProcedure / GameDownload / HybridCLRSystem | 启动过程、更新、加载程序集 |
| MiniGameSettings / PlatformSDK | 包名、AppID、广告 ID 和平台桥接 |
| MiniGamePlatform | 广告创建、加载、关闭、失败、超时、销毁 |
| QuickGameFileSystem / MiniGamePlayerPrefs / FileUtility / PrefsUtility | 包内和持久化文件、设置和存档 |
| LayoutScript / UGUIProgress / LegendButton / myUGUIDragView | HotFix 启动和隐私界面 |
| PlatformInternal_Oppo / PlatformInternal_Vivo | SDK 配置、WebGL 构建、正式签名、整包/分包封装；项目平台类只委托调用 |
| PlatformBase / MenuAssetBundle | AOT、热更 DLL、资源包、版本和 FileList |

源工程在基线框架已升级后删除了项目 PlatformBuildPipeline；本包不附带旧的重复流水线。新版远端动态策略的框架能力及升级补丁见 [build.md](build.md)。旧框架缺少这些 API 时，列出具体差异并升级到合适版本或在项目侧做兼容；不得改 Library/PackageCache，更不能同时保留两套同名实现。

## 可以复制的文件

`assets/copy/` 按 Unity 工程相对路径组织，包含代码与关联 `.meta`。

| 路径 | 内容及职责 |
| --- | --- |
| Assets/Scripts/Game/GameScene/LaunchScene/ | LaunchScene、Version、FileList、Download、Local、Exit 共六个类；下载对象复用框架 GameDownload.cancel，不另加相同子类 |
| Assets/Scripts/Game/Utility/LaunchNetworkUtility.cs | 网络状态探测；由版本流程处理超时 |
| Assets/Scripts/Game/UI/UIDownload.cs | AOT 下载状态和进度 |
| Assets/Scripts/Game/Settings/QuickGameProjectSettings.cs | 项目配置类型；不在框架内增加工程专属逻辑 |
| Assets/Scripts/HotFix/GameScene/QuickGameStartupScene/ | GameScene 只注册流程；Loading 负责 UI 加载、可见计时、隐私阻挡和进入主场景；Exit 卸载启动与隐私 UI |
| Assets/Scripts/HotFix/UI/UIQuickGameStartup.cs、UIQuickGamePrivacy.cs | 已由源 prefab 生成的布局代码和业务回调；导入后通过目标框架重新生成 |
| Assets/Scripts/HotFix/TimeSystem/QuickGameTimeSystem.cs | 框架时间倍率封装；已有等价系统时合并，不注册第二套 |
| Assets/Scripts/HotFix/PlatformSystem/QuickGamePlatformSystem.cs | 统一广告、可选后台间隔、广告暂停和恢复 |
| Assets/Scripts/Editor_Game/Game/ | 仅 OPPO/vivo 平台委托类；构建工具和插件 scope 复用 Editor_Frame |
| Assets/Scripts/Editor_Game/Menu/ | 平台选择与签名生成菜单 |
| Assets/Plugins/WebGL/QuickGamePath.jslib | 文件访问的项目侧桥接；配合框架已有文件系统 |
| Tools/Build/ | 导出 JS 兼容及 Node 测试、vivo CLI preload、两平台测试/日志 BAT 和 ADB 配置 |
| Assets/Resources/Settings/ | 两份 settings 和必须替换的 PrivacyAgreement.txt |
| Assets/Resources/UI/ | UIDownload.prefab、AOT 所需启动图片和字体 |
| Assets/GameResources/UI/、Assets/GameResources/Font/ | HotFix 启动、隐私 prefab、美术和字体依赖 |

不复制源工程 SDK、程序集定义、签名、云存储密钥、已构建 RPK、Library 或完整游戏业务。SDK 按官方安装；程序集在目标工程现有定义中增补引用。启动画面是现有游戏示例资源，不能把其 Logo/版权图当成其他游戏的正式美术。

## 必须合并的文件

`assets/merge/` 提供完整入口示例或代码片段，复制工具故意不覆盖这些文件。

1. **Game.cs**：保留已有初始化；在框架注册阶段注册 UIDownload，启动先进入 LaunchScene。已有 GameEntry 保持调用 `Game.startGame()`，避免增加第二个 MonoBehaviour 启动器。
2. **GameBase.cs**：增加 UIDownload 全局对象，复用已有 Game 对象。现有 GameBase 类不能重复定义。
3. **LayoutRegister.cs**：增加 AOT UIDownload 注册。此处使用 GameLayout 注册接口，与 HotFix LayoutScript 的注册接口不同。
4. **GameDefine.cs / GameUtility.cs**：合并 `CDN_URL` 和 `getRemotePathWithoutURL`。本包资源地址从 QuickGameProjectSettings 读取；编辑器和运行时调用同一个 getRemotePath，保留各平台独立目录。
5. **HotFixRegistration.cs.txt**：将四个对象合并到现有 GBR，注册两个系统，将启动场景类型返回改为 QuickGameStartupScene。UI 成员和布局注册交给生成器生成。保留游戏原有系统、表格和场景注册。
6. **PlatformInfo.cs**：若已有，合并 OPPO/vivo 的 create 分支、参数展示和远端路径，保留其他平台及对象存储。若缺少，可使用完整的双平台最小实现。`getBuildTimePlatformDefineInternal` 返回空字符串，不依赖本地回归夹具。内置资源的 backupAssets 恢复策略必须与目标框架当前实现核对。模板会映射备份路径并跳过 DynamicDownloadList，避免把已移出的 AB 再恢复进首包。采用动态下载时还需按 build.md 补齐目标项目远端完整清单和运行时按需加载入口。
7. **AdsAndPause.cs.txt**：只是业务接入片段，按用户指定入口调用；不是编译单元。不要新增每帧插屏检测或把游戏固定速度写进通用系统。

将 PlatformInfo.create/getBuildParameters 对接到现有 GameReleaseWindow，按 `assets/merge/BuildWindowOptions.cs.txt` 加分包选项。本版不复制独立打包窗口、PlatformBuildPipeline、OppoRuntimeBuildUtility 或同名框架工具。旧 skill 导入过这些文件时先查调用，确认职责由框架承担后删除；不要把无用代码迁移到别处。没有发布窗口的工程先对接框架标准发布入口，仅在确有缺口时补最小项目入口。

### 1.1.2 必需 API 与能力

读取目标框架真实源码，核对下表签名；旧框架不能靠复制模板补齐。`assets/manifest.json` 的 framework_api_snapshot 记录本轮读取的源文件哈希用于追溯，并非要求所有项目哈希相同。

| 类 | 模板调用 |
| --- | --- |
| PlatformInternal_Oppo | `mPortrait`、`mUseSubpackages`；`getBuildParameters(Dictionary<string,string>, string)`；`preBuild(string,bool,string,string,string)`；`buildInternal(out string)` |
| PlatformInternal_Vivo | `mPortrait`、`mUseSubpackages`；`SetPlayer(bool)`；平台宏内 `BuildWebGL(string,QGGameConfig,string,bool,string)` / `OnZipFile(string,Dictionary<string,string>)`；`preBuild(string,string,string,bool,string)`；vivo 宏内 `buildInternal(out string,IUnityCompatible)`，其他宏 `buildInternal(out string)` |
| PlatformBase / QuickGameBuildUtility | 当前 AOT→DLL bytes→内置清单→SDK 的顺序、整包/分包切换恢复原入口、真实产物检查 |
| FrameBaseUtility | OPPO/vivo 的 StreamingAssets 异步读取也走 QuickGameFileSystem，不能只封装 persistent 路径 |
| GameDownload | 提供 cancel，退出更新流程时清除回调并取消当前下载 |

图标使用当前框架 `QuickGameBuildUtility.ICON_PATH`：把目标游戏图标放到此路径；不留一个无人读取的项目 IconPath 字段。当前框架的包体阈值是内部常量，模板不会伪装成 settings 可调。预算变化先核对当前框架 gate，再通过 inspect_rpk 的精确字节参数补充发布检查；需要修改框架时在已获授权的真实源码仓库处理。

vivo `IUnityCompatible.BuildWebGL` 是 SDK 调用回调，不能因为项目没有显式调用就删除。模板会委托框架完成 BuildReport 验证，失败时停止转换。


## 两份配置

`Resources/Settings/MiniGameSettings.asset` 使用框架原生类型，填写各平台 PackageName、AppID、RewardedVideoID、InterstitialID。模板全部为空，不能沿用示例游戏的 ID。

`Resources/Settings/QuickGameProjectSettings.asset` 使用项目类型：

- GameName、GameFolder、Portrait：游戏名称、输出前缀和方向。图标使用框架 ICON_PATH，由目标游戏提供。
- CdnUrl、OppoResourceFolder、VivoResourceFolder：每个游戏各平台的远端资源根目录；CdnUrl 末尾有 `/`，目录示例 `MyGame_OPPO/` 与 `MyGame_VIVO/`。
- MainSceneTypeName：HotFix 程序集中实际 GameScene 类名。模板以 `typeof(GameHotFix).Assembly.GetType(...)` 查找，类型不在此程序集时改成真实 `typeof(场景类)` 或已有项目场景入口；启用混淆时保留类型名。
- SplashSeconds：默认 2 秒，从启动界面实际可见开始计时。
- ShowOppoPrivacyButton、ShowVivoPrivacyButton：按产品要求显示协议入口，默认两平台都显示。RagdollArchers 的 OPPO 首次同意和 vivo 隐藏是项目专属要求，接入步骤见 [startup-ui.md](startup-ui.md)；模板里的查看式隐私 UI 不能直接充当同意界面。
- AdConfigUrl、OppoInterstitialSwitchId、VivoInterstitialSwitchId：可选后台。无开关 ID 时按业务入口直接尝试插屏；有 ID 但未取得有效配置时跳过插屏。启用时 URL 与 ID 必须同时提供。
包体阈值和 CLI 兼容由当前框架构建器负责，不在此配置中保留无效字段。旧资产的这些字段可清理，先核对是否有目标项目自己的调用。

禁止将真实存储 AccessKey/SecretKey 放进这些运行时 Resources 配置。云上传使用目标工程现有编辑器配置或环境变量，和客户端 CDN 下载地址分开。

包体优化后仍超限时，第三份既有框架配置 `FrameSettings.asset` 的 `DynamicDownloadList` 用于非初期 AB 按需下载。复用目标工程资产，不新增同职责的下载清单；此字段只在编辑器排除包内资源并生成发布策略，不能作为启动更新忽略列表；客户端读取同版本远端 JSON，条目与发布/加载策略见 [build.md](build.md)；调整目录或拆包前先按 [dynamic-assets.md](dynamic-assets.md) 确定初期范围、实际依赖闭包和逐包依据，未知用途保留内置。

## asmdef 和 SDK 隔离

不要覆盖目标 asmdef；分别合并引用。

- Game/AOT：Frame_Base、Frame_Game、Unity.TextMeshPro；平台 SDK 引用按当前 SDK 实际程序集名添加。
- HotFix：Frame_Base、Frame_HotFix、Game、Obfuz.Runtime、Unity.TextMeshPro；本包广告配置解析还需要 Newtonsoft.Json。
- Editor_Game：仅 Editor；引用 Game、HotFix、Frame_Base、Frame_HotFix、Editor_Frame、HybridCLR.Editor、Obfuz.Editor、平台 SDK 编辑器程序集。
- 源工程 OPPO 程序集为 `OppoGameSDK` / `OppoGameSDK_Editor`；vivo 为 `VIVO-Game-SDK` / `vcore-editor`。按导入版本检查名称与 defineConstraints；两个 SDK 都声明 QGMiniGame，不能无条件同时编译。SDK 已隔离时复用其定义，不能只删除代码里的 using。
- Frame_Game 与 Frame_HotFix 有同名类型。Game 引用 Frame_Game；HotFix 和 Editor 引用 Frame_HotFix，不能把两个都直接引进同一个编译单元来“补齐引用”。

## 复制计划

```text
python scripts/copy_adapter.py E:/Games/MyGame
python scripts/copy_adapter.py E:/Games/MyGame --apply
```

默认只输出计划。存在路径内容冲突或 GUID 重复时，`--apply` 整次不写入。已有相同资源时在计划中识别并复用；不要为通过脚本而删掉目标工程资源。导入后根据目标项目命名规则移动代码/资源时，同时移动 `.meta` 并更新 prefab 与生成器路径。

## 平台隔离的实际检查点

三个小游戏平台都是 UNITY_WEBGL。业务代码的 BYTE_DANCE 条件不会禁用独立 SDK 程序集、插件 DLL 或 `.jslib`。对目标 SDK 全量查 asmdef、DLL PluginImporter 和 jslib meta，分别设置 BYTE_DANCE / OPPO_MINI_GAME / VIVO_MINI_GAME 条件。声明相同 QGMiniGame 类型的 SDK 必须互斥。框架构建 scope 的临时插件选择不能代替常驻隔离。

本次 StarkSDK 的必要修改仅是导入配置：ttsdk-editor、TTLitJson、ttsdk.ref、TTWebGL 四份 asmdef，以及 ttsdk.dll、ttsdk.base-editor.dll、ttsdk_tools.dll、TTSDK.jslib、TTUNBridge.jslib、bgdt.dll 的 meta 加 BYTE_DANCE 条件。不是修改 SDK 二进制或广告逻辑。路径随 SDK 版本变化，先读取真实导入条件，不照抄不存在文件；已有正确隔离就不改。给用户说明具体修改目的，不能仅说“SDK 必須修改”。
