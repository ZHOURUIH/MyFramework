# SDK、签名与 RPK 打包

## 基线和外部依赖

本包提供工程适配，不附带第三方 SDK。按目标平台官方 Unity 接入包安装；先核对 API，再复制平台类。

- [OPPO 官方 Unity 转换工程](https://github.com/oppominigame/unity-webgl-to-oppo-minigame)；[官方转换常见问题](https://github.com/oppominigame/unity-webgl-to-oppo-minigame/blob/main/doc/DevelopmentQA.md)；[OPPO 平台文档](https://ie-activity-cn.heytapimage.com/static/minigame/CN/docs/index.html#/)。
- [vivo Unity 接入文档](https://minigame.vivo.com.cn/documents/#/lesson/engine/unity/engine-unity-home)；[vivo 调试器下载](https://minigame.vivo.com.cn/documents/#/download/debugger)。

本轮代码核对日期 2026-10-08。文档可能是 SPA，搜索摘要中的旧包体规则不能作为当前审核依据；以目标后台上传提示/当前官方规则为准。默认 OPPO 分包 32 MiB、vivo 分包 40 MiB 是本次项目要求，检查脚本支持精确字节预算；当前框架内置 gate 的数值仍需单独核对，不能把旧项目阈值当作通用标准。

本版项目平台类委托 PlatformInternal_Oppo/Vivo，以下 SDK 调用由框架内部完成：OPPO 调用 `BuildConfigAsset.Fundamentals / AssetCache / OtherSettingsConfig / Save`、`QGGameTools.SetPlayer / BuildGame`、`ShellHelper.ExecuteCommand`。vivo 类调用 `QGWindowHepler.Instance`、`SetUnityCompatible`、`SetIsBuildRpk`、`DoBuildCMD`、`QGSettingsHelperInterface.helper.SetBuildSrc` 和 `IUnityCompatible`。SDK 升级后核对框架封装兼容性，不重新复制一套平台实现。模板按 integration.md 的现有 API 接入。

Windows 环境需 Unity WebGL Build Support、与 Unity/HybridCLR 匹配的工具链、Node、npm、官方 CLI、OpenSSL（仅签名生成）。确认 `node --version`、npm 包版本和 CLI 程序存在；Unity 内置 Emscripten Node 与系统 Node 是两个进程环境，不要将其错误混为一谈。

官方 CLI 安装来源分别为 `@oppo-minigame/cli` 和 `@vivo-minigame/cli`。根据实际 SDK 支持的版本固定依赖；不要默认一直安装 latest。模板运行 Node + 明确 CLI 入口路径，避免直接调用系统找不到的 mg-service/quickgame 批处理文件。环境 PATH 读取进程/用户/机器及 npm 全局目录。

## 参数全部由代码写入

平台 SDK 配置面板可用于查看结果，但不用每次手动填写。读取 MiniGameSettings 和 QuickGameProjectSettings 后，preBuild 写入：包名、游戏名称、图标、版本名/整数、方向、导出路径、正式签名、SDK 分包/首包加载选项；Unity Application.identifier 同时按当前平台包名设置。

vivo 先清空旧导出路径，再同步 SDK 配置，避免 SDK 从上次 manifest 覆盖新包名/版本。版本整数按三段版本号计算，后两段须小于 1000，结果在 int 范围内；不要所有平台固定同一包名。

OPPO 禁用 SDK 整体远端 StreamingAssets 与资源缓存选项，正式包使用固定签名。下述选择性 AB 按需下载通过框架实现，不等同于将整个 StreamingAssets 改为 SDK 远端加载。vivo 的 useSubPkgLoading 跟随发布窗口的 mUseSubpackages，关闭 useSelfLoading 和 wasm CDN URL；选择分包时保留官方 Unity 分包并补齐 StreamingAssets，整包时恢复原入口并移除分包声明。

## 框架升级：remote-dynamic-policy-v1

本版模板需要以下真实框架能力：`FrameBaseDefine.DYNAMIC_DOWNLOAD_LIST`、`DynamicDownloadConfig.tryParse`、Game 层 `AssetVersionSystem.setRemoteDynamicDownloadList/getRemoteDynamicDownloadList`；`GameDownload.start` 只复制远端策略；`PlatformBase.writeFileList(path, includeDynamicAssets)` 及发布全部 AB/策略的流程。框架配置解析使用现有 Newtonsoft.Json，缺字段/错误类型/版本不匹配不得当作合法空列表。

随附 `assets/framework/remote-dynamic-download.patch` 只包含上述框架源码改动，基于记录的框架基线；先在真实 MyFramework 源仓库运行 `git apply --check`，核对已有变更。用户明确授权升级框架时才在那里应用；不能在游戏 Assets 复制另一套框架类，也不能改 PackageCache。新版框架已有能力时不重复应用补丁。

当前游戏接入通过本地 UPM 包路径使用已修改的真实框架源；其他机器按其框架位置配置，团队发布时改用包含这些改动的框架版本。AOT 启动代码也有变化，旧底包只更新 HotFix.dll 无法补出该启动流程，必须先构建支持新协议的底包。发布前确认该版本目录已有策略文件，否则新版客户端会正确回退内置版本。

## 首次正式签名

1. 填好 MiniGameSettings 中当前平台包名。
2. Unity 菜单 **游戏平台 → 生成正式签名 → OPPO / vivo**。
3. 在 `BuildSigning/OPPO/` 或 `BuildSigning/VIVO/` 生成 `private.pem` 和 `certificate.pem`，RSA 2048、SHA256、自签名有效期 3650 天。
4. 私钥/证书配对备份；以后更新沿用。菜单遇到已存在或部分存在文件会保留，不覆盖、不偷偷重新生成。已有上线游戏先恢复原签名，不能创建替代签名。

证书由开发者本地创建，不是广告平台给的 AppID。包内不附带任何真实签名。将私钥路径加入项目忽略规则；模板不更改目标 .gitignore，接入时合并 `BuildSigning/**/private.pem` 等项目规则。SDK 默认 Debug 签名不能用于正式上传，仅文件名叫 signed.rpk 也不能证明证书正确。

## 构建顺序

**游戏平台 → 切换到 OPPO / vivo**，编译完成后使用目标工程已有发布窗口。填版本、测试/正式、是否重新打 AB、分包打包。窗口展示真实包名、AppID、广告 ID、签名路径、资源地址和分包选择。正式发布取消测试客户端并复用固定签名。

沿用框架现有宏切换及构建流程，宏稳定后才编译 DLL/AOT。不要另建 SessionState 队列、独立完整打包菜单或 ProjectDefineSymbols。保留项目其余必要宏，移除竞争平台宏。

流水线：

```text
平台宏稳定 →（资源变化时）MenuAssetBundle.packAssetBundle
→ 平台 preBuild：SDK 参数、纹理/裁剪/Unity 配置
→ 当前框架 PlatformBase：HybridCLR GenerateAll、DLL/AOT、混淆/加密
→ 写版本和 FileList、保留启动及初期资源、过滤动态下载 AB
→ 原平台 SDK Unity WebGL 构建 + 官方转换
→ 项目运行时/分包后处理（只改导出工程）
→ 官方 CLI build 或 release → 检查本次新 RPK、分包结构和限额
```

所有可能影响裁剪的设置必须在 GenerateAll 前确定。先从旧 PatchedAOTAssemblyList 拷贝补充 DLL 再生成新列表，会混入旧 AOT；正式完整包必须以本次平台生成的列表和裁剪 DLL 为准。既有框架不保证时在项目流水线补齐，不能绕过失败继续转换。任何 Unity BuildReport 失败都应停止 RPK；vivo SDK 的 bool 返回值不能单独作为成功依据。

发布使用同版本的完整 FileList 和 `DynamicDownloadList.json`；FrameSettings 只在编辑器控制首包排除及生成发布策略，运行时忽略目录来自远端。新版框架 `writeFileList(path)` 默认生成完整发布清单及策略；`writeFileList(path, false)` 生成只包含内置资源的清单，preBuild 使用后者，postBuild 还原源资源后恢复前者。`uploadResources` 上传全部 AB、FileList、动态列表，最后更新远端 Version。

沿用目标发布窗口的上传流程，先上传对应版本的全部资源及 FileList，再按既有发布策略更新远端版本号；不在 skill 中存放上传密钥。CDN 的编辑器上传路径和运行时下载路径必须完全一致。

## OPPO 与 vivo 分包

统一的是接口和验收，内部加载方式按 SDK 区分：

| 平台 | 模板分包与启动 |
| --- | --- |
| OPPO | 整体 `Build/`（包含 wasm/data/framework）和 `StreamingAssets/` 作为平台目录分包，manifest.subpackages；main.js 先 qg.setIsUnityGame(true)，加载两包成功后 require sdk-main.js |
| vivo | 保留官方 Unity 分包，同时将 StreamingAssets 加入 manifest；game.js 先加载额外资源分包，然后进入原 sdk-game.js，由官方脚本继续加载 Unity 分包 |

这里是平台**目录分包**，不是拆 wasm 函数的工具链方案。SDK 不支持 wasm 函数分包不等于没有 qg.loadSubpackage。是否允许 Build 中 wasm 在目录分包运行，要用实际目标 SDK/平台版本测试，不能仅通过改 manifest 声称成功。

模板保证每个 subpackage 有无副作用入口 `void 0;`；不能用 `module.exports={}`，某些平台执行分包没有 CommonJS module。所有必需分包成功一次后才进 Unity，任一失败停止；避免 success/complete 双回调重复启动。保留原 SDK 入口文件，不把旧版本入口当作本次构建产物。

上传 `dist/<package>.signed.rpk` **外层完整文件**。典型内部包含 main.rpk、各分包.rpk、兼容旧平台的原整包.rpk。外层可能比有效主包+分包合计大，不能删兼容包或把某个内部子 RPK 单独上传。

`inspect_rpk.py` 从 main.rpk 读取 manifest，检查列出的分包均存在并按内部 RPK 文件实际字节数统计，报告兼容整包与外层大小；签名及后台最终接受需要另验证。

```text
python scripts/inspect_rpk.py <package>.signed.rpk --platform oppo
python scripts/inspect_rpk.py <package>.signed.rpk --platform vivo
```

若规则是主包+分包总额，而不是仅分包合计，增加对应总额 gate；若按十进制 MB，用 `--main-bytes` / `--sub-bytes` 与 settings 对齐。源工程曾有 26 MB 保守上传预算，此工程专属预算已从通用默认中移除。超限即构建失败，不用日志显示“成功”然后让用户上传。

## 包体与迭代速度

- 先按实际包内条目排前十：wasm、data、HotFix/AOT bytes、字体、纹理、音频、重复平台插件；再有针对性优化。
- 目标要求允许时纹理 ASTC 6×6，背景等可 ASTC 8×8；确认当前 SDK 的 WebGL 导入路径和设备支持，不能只改 Android 纹理覆盖。文字、细线、透明边缘需看实际渲染；TMP 字库去掉无关字符但保留完整中文和数字，不能为了大小造成缺字。
- 裁剪、OptimizeSize、移除 profiling、WASM name 自定义调试段、关闭 Development 构建可减少代码包。stripWasmDebugNames 只移除合法 name 段，不改变执行段，不是通用压缩器。
- UnitTest 源码仅编辑器编译；如果它位于只读框架，使用已有正确框架版本或单独授权的上游修改，不能悄悄补丁 PackageCache。不要把测试 DLL 和所有平台 SDK 打进热更。
- 资源没改可跳过 AB；仅热更可编译 DLL 并使用已验证一致的 AOT 产物。更改框架、依赖、平台宏、裁剪、泛型/AOT 引用、混淆设置时要重建 AOT；不能用快速路径掩盖缺文件。正式完整包按当前框架生成或经过依赖一致性验证后复用 AOT；仅重新封装官方导出工程适合 JS/签名/manifest 已改且 Unity 产物完全相同的情形。

### 优化后仍超限：非初期 AB 按需下载

先完整执行 [dynamic-assets.md](dynamic-assets.md) 的初期范围、依赖闭包和清单检查，禁止把初期资源改为动态下载。完成所有适用的压缩、裁剪、去重和分包优化后，若仍超过目标平台限额，只从首包中移除已有实际依据证明初期不会使用的 AB；这里的“首包”包括首次交付的内置资源分包。OPPO/vivo 对外使用同一框架下载和加载接口，平台内部文件访问仍由宏和桥接区分。

1. 按真实启动和初期玩法列出必需资源及 AB 依赖闭包。晚期关卡、后期角色/皮肤、暂不开放功能等须证明没有初期使用、预览/预加载或存档启动依赖后才能延迟；初期会随机出现的道具仍属初期资源。保留 UIDownload、启动页、隐私、主界面、初期关卡、共用字体/材质/图集，以及 DLL、AOT、版本、动态密钥和 `StreamingAssets.bytes` 资源索引。一个 AB 混装早期和后期资源时先调整打包分组，不能直接移除共有包。
2. 将选中的 AB 相对路径加入框架 DownloadList。编辑器来源是 `FrameSettings.asset` 的 `DynamicDownloadList`；运行时只使用 `AssetVersionSystem.getRemoteDynamicDownloadList()`，不能再从 FrameSettings 复制。条目按 AB 输出根目录填写，小写、正斜杠，与实际打包路径一致；框架按前缀匹配，目录条目带结尾 `/`，优先使用精确 AB 文件名，不能写绝对路径或过宽的目录。目录前缀逐个展开核对实际匹配的 AB，不因目录名叫 late 就直接放行；未知用途默认内置。只服务后期资源的依赖也可移出；初期共享依赖留在包内。
3. 在打包流程使用框架 `isDynamicDownloadAsset` 过滤。随附 `PlatformInfo.backupAssets()` 会先映射回原 AB 路径再判断，动态 AB 留在临时备份中，不恢复进本次 StreamingAssets；构建结束仍由框架还原源工程。核对 SDK 导出、资源分包和其他复制逻辑均未重新带入这些 AB；不删除源 AB，也不在签名完成后删 RPK 条目。
4. 将这些 AB 连同依赖发布到与当前运行资源版本一致的远端目录，保留完整资源索引和校验信息。新版 `PlatformBase.writeFileList(path, false)` 只生成内置资源清单；默认 `writeFileList(path)` 生成包含动态 AB 的完整远端清单。策略文件独立上传，不作为 AB 下载任务，不参与 FileList 的资源差异。`GameDownload.start()` 每次清空旧忽略目录，再复制当前远端策略；不能与 FrameSettings 或旧版本目录合并，也不能为补齐远端清单而在启动时批量下载动态 AB。先发布资源，再按原发布流程更新版本。
5. 业务真正访问相应界面、关卡或资源时才调用框架异步资源加载接口；由 `AssetBundleLoader` 下载缺失的 AB 和依赖，下载成功后加载，写入框架持久缓存及文件记录。不能同步加载未下载的 AB，也不能在启动页预热全部动态 AB。确认资源管理器下载 URL、远端版本清单和读路径策略一致，不加载其他版本的缓存或远端资源。
6. 特别处理离线回退后再访问动态功能：随附 `LaunchSceneLocal` 会清空下载 URL 并设为 `STREAMING_ASSETS_ONLY`，这不能直接加载动态 AB，也不会命中持久缓存。接入该方案时，在实际访问动态资源的入口恢复当前运行版本的远端 URL/完整清单，并使用框架支持持久缓存与远端校验的读策略（基线为 `SAME_TO_REMOTE`）；离线时同样需要可用的当前版本完整清单或项目保存的对应校验信息。不能全局改成 `REMOTE_ASSETS_ONLY` 使已有资源也每次下载。尚未缓存且断网时显示该功能的加载失败/重试状态，初期玩法继续可用；只有下载成功、字节有效后才进入加载流程。

验收：正式 RPK 中没有选中的动态 AB；启动和初期玩法不请求它们；首次实际使用才下载并加载；第二次使用命中缓存；重启后断网能使用有效缓存；未缓存断网和依赖下载失败可重试且不进入空资源场景。移除资源后重新生成 AB/索引/清单、签名打包并按实际 RPK 复核限额。交付列出内置必需 AB、动态 AB、对应依赖、减少的字节数和需联网的功能。

## 有界 SDK 兼容处理

OPPO `PrepareOppoRuntime.cjs` 针对该基线 Unity/SDK：Unity 实例准备前队列回调，包内/persistent 文件 fetch 走 qg 文件系统，兼容只有 forEach 的 headers。SDK 原始入口可能是 `main.js` 或分包准备后改名的 `sdk-main.js`；按 `unityInstance` 初始化特征识别真实入口并处理对应文件及 `Build/webgl.framework.js`，不得固定读取 `sdk-main.js`。先检查 hook 唯一、JS 能解析、无 vivo 插件泄漏，幂等。分包 wrapper 与资源包空入口不能写 `module.exports`；快游戏脚本环境不保证存在 CommonJS 的 `module`，真机出现 `ReferenceError: module is not defined` 时先检查 `Build/main.js`、`StreamingAssets/main.js` 和实际加载的 JS 入口。新版导出结构不同就停止并针对新版核对，不做任意字符串替换。

`VivoCliPreload.cjs` 只适用于特定 CLI reporter 问题。仅拦截被审查的 telemetry reporter，不改签名、打包或上传结果。只支持 packager 1.27.45 且两个文件 SHA256 匹配；其他版本明确失败。当前读取的框架 PlatformInternal_Vivo 会传入此文件路径，接入前必须核对目标框架是否仍启用该路径、CLI 版本和哈希。项目 settings 不再提供不起作用的 EnableVivoReporterWorkaround 字段。其他 CLI 版本先审查当前框架正常调用能力，在已授权的真实框架源码调整；不能只删脚本让打包失败，也不能泛化成无条件抑制 reporter。

## 整包与分包切换

复用已有发布窗口，通过平台对象 `mOppo.mUseSubpackages` / `mVivo.mUseSubpackages` 设置选择。整包适合总文件已达标且减少兼容包重复的工程；分包仍需实际检查各预算和引擎支持，不能假定一定更小。示例默认 OPPO 整包、vivo 分包，不是所有项目固定规则。

切换模式后核对新的 SDK 配置、manifest、入口与 RPK：整包没有过期 subpackages/loadSubpackage 包装；再切回分包只包装当前 SDK 入口一次。不修改已签名的包，不复制旧 dist 当作新产物。目录分包能力存在，但不同 SDK/引擎下 Build/wasm 的运行效果需要实测。

## 最终 DLL 与 AOT 核对

完整包不能只看 Assets/StreamingAssets 中是否有文件。对照 FrameSettings 热更程序集、当前 HybridCLR 补充 AOT 列表、加载入口及最终 RPK 的 StreamingAssets，逐个确认 DLL bytes 非空、文件名与加载路径一致。加密/混淆后的 bytes 应与最终复制源比哈希，不能拿原始 DLL 比哈希。`inspect_rpk.py` 会列出有效主包/分包中的 dll_bytes 和 payload_top10；兼容整包另统计，不重复算成有效资源。

配置裁剪/平台宏 → GenerateAll → 读取新 AOT 列表与新裁剪 DLL → 混淆/加密 → 复制 HotFix/AOT bytes → 写同轮索引/清单 → SDK 导出复制 SA → 官方封装。任一阶段失败就停止；用户手动删了辅助文件不应靠创建新清单补救，沿用现有 FileList。

| 修改 | 可复用的产物与必须更新的部分 |
| --- | --- |
| 仅图片、字体、prefab、CSV bytes | 重新打相关 AB、索引、FileList；整包交付还需重新封装含新 SA 的 RPK |
| 仅 HotFix 业务代码 | 重编译对应 DLL、混淆/加密并拷贝 bytes、更新清单；新增 AOT/泛型调用需核对底包支持 |
| Game/Frame_Base、平台宏、程序集依赖、裁剪或 AOT 引用变化 | 重新生成当前平台 AOT 与完整 Unity WebGL，不能只复制旧 mscorlib.bytes |
| 仅导出 JS、manifest、正式签名 | 输入 Unity/DLL/SA 未变时可复用 Unity 输出，官方 CLI 重新生成签名包 |

默认 AB 使用 `BuildAssetBundleOptions.ChunkBasedCompression`（LZ4），不使用 LZMA。不要直接删除 mscorlib 的补充元数据来缩包；热更未来可调用的类型、泛型/AOT 范围必须与已安装底包匹配，超出时发布新底包。

## 包体数字的含义

分别报告：主包、分包合计、主包+分包、兼容整包、外层上传文件。MB=1,000,000 字节，MiB=1,048,576 字节；后台说 32M/40M 时核对其计数范围和精确字节规则。当前框架 OPPO 还有外层 30,000,000 字节的保守 gate，不能把它写成平台通用政策。脚本支持额外 `--upload-bytes` 和 `--total-bytes`，内部通过但外层超限仍失败。没有配置外层预算时报告“外层未判定”，不能说可上传。

```text
python scripts/inspect_rpk.py <rpk> --platform oppo --upload-bytes 32000000
python scripts/inspect_rpk.py <rpk> --platform vivo --main-bytes 7000000 --sub-bytes 40000000
```

示例预算只说明参数用法，以项目和实际后台要求填写。整包检查 outer_bytes，使用 `--whole-bytes` 指定完整包预算；不能把分包的主包预算用于 OPPO Unity 整包。
