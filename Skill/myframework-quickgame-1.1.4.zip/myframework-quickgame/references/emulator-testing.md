# 模拟器导入、运行与日志

## 配置 BAT

Tools/Build 下有 Test-OppoRpk.bat、Test-VivoRpk.bat 和两份 Capture-*RpkLogs.bat，共用 QuickGameAdbConfig.bat。BAT 使用 GBK/CRLF、chcp 936 和 DisableDelayedExpansion，避免 Windows 中文路径、空格、`!` 的解析问题。配置 QG_ADB 的实际 adb.exe 路径、QG_DEVICE 的 adb devices 序列号、QG_ADB_PORT 的 server 端口；不固定 Unity 安装路径或 MuMu 端口。单一在线设备可自动选择，多设备必须指定，不自动 kill-server。

```bat
set "QG_ADB=C:\Android\platform-tools\adb.exe"
set "QG_DEVICE=127.0.0.1:16384"
set "QG_ADB_PORT=5041"
Test-VivoRpk.bat "E:\Games\MyGame\GameOutput\game.signed.rpk"
Capture-VivoRpkLogs.bat
```

16384/5041 仅本次 MuMu 示例。真实端口由当前模拟器提供。不要把 RPK 当 APK 执行 adb install；adb install 用于引擎/调试器 APK，RPK 由对应调试器导入。

## vivo：使用官方外部引擎

在模拟器安装官方调试器和 [vivo 小游戏引擎外部包](https://minigame.vivo.com.cn/documents/#/download/engine_android)。该外部包支持 PC Android 模拟器；普通 vivo 手机版引擎依赖厂商系统服务，MuMu 曾报 `NoClassDefFoundError: com.vivo.services.daemon.VivoDmServiceProxy`。不要因此判断 vivo 无法在模拟器测试。官方外部包文档核对日期 2026-10-08。

本次实测组合：MuMu Android 12、外部引擎 1.20.6.103（12060103）、调试器 1.20.6.240。版本用于复现，其他工程按当前官方兼容版核对；skill 不分发 APK、不默认安装固定旧版本。

1. 拖完整 `.signed.rpk` 到 Test-VivoRpk.bat。它放到 `/sdcard/Download/vivo-随机值-原文件名` 并打开调试器。
2. 点 **本地安装 → Download/下载 → 本次文件**，选中后自动进入游戏。不要点“开始调试”再填服务器；那是另一条调试路径。
3. 对分包导入完整外层容器，由调试器处理子包；不能只导入 main.rpk。检查引擎控制台或启动日志的包名、versionName/versionCode，与 inspect_rpk 输出一致。
4. 运行 Capture-VivoRpkLogs.bat 后再启动/复现。游戏进程引擎包名 `com.vivo.hybrid`，调试器是 `com.vivo.hybrid.sdkdemo`；脚本精确匹配引擎 UID，不能把 sdkdemo 的 UID 当游戏。原生日志标签可出现 HybridGame-jswrapper，不能仅按 OPPO 的 jswrapper 字符串过滤。

## OPPO：整包和分包区别

安装匹配当前 SDK 的官方快游戏调试器/服务框架，本次引擎包名 com.nearme.instant.platform（10.9.3__b683041_dev）。整包 BAT 使用该版已实测的 app files/subPkg 目录；新版本目录可能变化，先查当前官方导入流程。打开小游戏列表，确认新文件对应的包名和版本再运行。

分包外层容器没有根 manifest，而内部 main.rpk 才有。旧扫描器按普通 `.rpk` 导入外层可能不刷新新条目；不能点击列表中同名旧 vivo/旧 OPPO 游戏后声称复现了目标包。当前 Test-OppoRpk.bat 对分包仅传输到 Download，要求按实际调试器的分包入口导入；自动分包安装尚未验证。

某些 OPPO 调试器包含 `.rpks` 导入处理，但简单重命名并不能保证当前扫描目录与缓存刷新正确。需要根据对应调试器官方说明/实际导入结果验证；不修改上传原包，不删除签名条目，不把这个实验写成通用已跑通方案。用户明确选择模拟器时先持续定位导入和日志问题，不随意换成必须真机。

## 先证明在测哪个包

每次记录完整路径、字节数、SHA256、整包/分包、包名、版本号、引擎/调试器版本。inspect_rpk 输出本地信息；设备显示或启动日志证明实际运行身份。随机文件名只能避免文件覆盖，不能阻止调试器按包名缓存/去重。若实际版本不符，先解决旧条目或导入缓存，不清整个模拟器或删除其他项目数据。

按 **平台解析/分包 → Unity → UIDownload → 版本/FileList/动态列表 → HotFix → 启动页 → 游戏场景** 标记最后成功阶段，保留首次异常及堆栈。Native 引擎自身也可能持续报错；没有关联游戏进程/启动阶段时，不能把后台噪声直接判为游戏根因。保留原始日志，再提取相关时间窗/进程；短时间无报错不是成功证据，日志为空先核对引擎 UID、启动时刻和 adb 连接。

## 最小运行用例

- 下载页/启动页顺序、2 秒可见计时、按配置显示隐私；查看模式可滚动和关闭。首次同意模式需验证自动弹出、未同意时不进入游戏、拒绝退出、同意后重启不重复弹出。
- 中文字库与换行、排行榜、设置、得分/关闭按钮被原生胶囊遮挡、输入位置。
- 一局射击/资源消耗/伤害/过关；死亡重开与菜单返回；暂停至少观察数秒，人物/物理停下且继续恢复。
- 存档重启、Editor 激励点击发奖一次；设备完整/提前关闭/失败广告分别观察。预览广告只代表预览通路，不代表正式广告或真实填充率通过。
- 初期资源无远端 AB 缓存断网运行、有效旧缓存复用、更新失败回退；动态后期资源访问时下载、失败可重试；旧底包热更将动态目录转普通资源。

关闭 WiFi 可能切断模拟器 ADB TCP，超时不等于游戏失败。先准备模拟器自己的控制通道（MuMu guest shell 等），记录网络状态；断网冷启动后观察游戏，再恢复原网络与显示配置。调整模拟器分辨率后冷启引擎，旧 viewport 会造成显示误判。已经测试的平台分包缓存不能代表从未交付的分包首次离线。

交付区分：BAT 传输/日志命令、实际模拟器运行、真实设备、生产广告、后台上传。任何未验证项目明确列出。测试 BAT 不自动购买云手机、不传后台、不清引擎数据。
