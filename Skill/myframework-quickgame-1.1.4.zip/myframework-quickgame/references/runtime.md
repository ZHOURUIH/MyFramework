# 统一广告、间隔、暂停和文件访问

## 统一接口

业务仅调用 GBR 中的 QuickGamePlatformSystem 或目标工程已有等价系统：

```csharp
GBR.mQuickGamePlatformSystem.showReward(onRewardGranted, onRewardFailed);
GBR.mQuickGamePlatformSystem.showInterstitial(onContinue, onContinue);
```

底层继承框架 MiniGamePlatform，由其创建当前 SDK 广告、监听加载/关闭/失败和超时。平台 ID 从 MiniGameSettings 读取，不把广告 ID 写到 UI 或 Build 类。Editor 调试时不创建平台广告，点击激励直接调用成功分支并发奖一次，即使未配置 ID；这仅验证业务。Player 未配置 ID、错误、超时、未完整观看不发激励奖励。所有回调需检查请求 generation 与销毁状态，重复回调只能结算一次。

扫描所有会触发激励视频的玩家可见按钮（解锁、复活、领取奖励等）：按钮上要有明显的广告或视频图标，并与普通直接领取/购买按钮区分；图标在实际 RPK 中应可见、尺寸清楚、不被文字或平台胶囊遮住。优先复用目标游戏已有图标资源，新增资源时一并更新图集/AB/字体或 UI 生成结果，不能只在 Editor 中出现。程序播放入口和奖励条件仍按上段统一接口处理，图标不代替真实广告结果判断。自动触发的插屏没有玩家点击按钮，不需要为其虚构按钮。

后台阈值只决定用户指定插屏入口是否允许播放。间隔未满足时直接继续业务；每关结算入口调用一次即可，不能用 update 每帧尝试。没有对应产品界面时按用户指示忽略，不生造皮肤/升级任务入口。

## 可选后台配置

项目 settings 的 AdConfigUrl 配合该已实现数据协议：

```json
{
  "switchIdList": ["<该游戏当前平台开关ID>"],
  "pkgName": "<当前平台真实包名>",
  "version": "<当前游戏版本>"
}
```

响应：

```json
{
  "meta": {"errCode": 0},
  "data": ["{\"firstDelay\":600,\"interval\":120}"]
}
```

单位秒，必须是有限非负数。firstDelay 从当前平台系统初始化算，interval 从上一次成功插屏结束算。刷新 60 秒，无有效初始配置则跳过插屏；本次会话已取得有效值后刷新失败保留原值。激励广告不受该阈值限制。

空 ID 表示该游戏不用远端阈值，按入口调用；设置 ID 时也必须设置 URL。不同后台只改请求和解析函数，保留调用方接口。频率配置应用于正常运行，发布说明和验证环境保持一致，不提供审查规避分支。

模板时间戳使用原实现 UTC 毫秒；设备系统时间改变会影响阈值。产品若要求严格会话时长，替换为单调、不受暂停影响的框架计时来源，并保持协议单位不变。

## 暂停与恢复

广告请求前保存当前倍率和 AudioListener.pause；设置倍率 0 并暂停音频。所有成功、失败、取消、销毁路径都恢复保存值，恢复在业务回调前完成。若从暂停界面开始看广告，结束后仍应保持原来的暂停。

QuickGameTimeSystem.setScale 使用完整命令：

```csharp
CmdTimeManagerScaleTime.execute(scale, scale, 0.0f, 0.0f, 0, false, null, null);
```

基线框架的简短 overload 不会按这个配置启动时间组件，曾造成暂停界面出现但游戏仍运动。不要只更新 mScale 字段或 Time.timeScale。目标游戏应统一控制框架物理、游戏更新、动画的时间来源，UI/网络/广告超时使用不受游戏暂停影响的计时。

如果已有 TimeSystem、音频系统，复用它们并将模板的引用换到对应对象，不同时注册两个时间系统。每个暂停弹窗自己保存之前倍率；继续、X 关闭、返回菜单、布局卸载等路径都恢复，不能用一个全局静态工具固定还原 0.75/1.0。

## 文件、持久化和其他平台能力

框架已有 QuickGameFileSystem/MiniGamePlayerPrefs。业务通过 FileUtility、ResourceUtility、PrefsUtility 读写；持久根目录由 qg.env.USER_DATA_PATH 的框架封装取得。只在框架/SDK边界做原生桥接，不在业务中使用 Application.persistentDataPath、System.IO 或抖音专属 TTFileSystem。

`QuickGamePath.jslib` 补充以下链接符号：GetQuickGamePersistentPath、QuickGamePackageAccess、QuickGamePackageIsDirectory、QuickGamePackageSize、QuickGamePackageDirectory、QuickGamePackageRead、QuickGamePackageFree。导入后对照当前框架 DllImport 搜索符号；已有同名桥接只保留一个。

桥接区分包内只读路径与用户目录，vivo 包内路径按 provider 处理前导 `/`；文件 stat 的数组/对象包装先归一；read 的 ArrayBuffer/TypedArray 必须保留 byteOffset/byteLength，不能把整个 underlying buffer 返回；返回缓冲区由调用者使用后释放。目录、空文件、不存在路径、中文路径、读写 binary、删除、缓存重新启动均要实测。

OPPO 原 SDK 中的本地 http://localhost/StreamingAssets fetch 不应误发网络请求；导出脚本后处理限定此地址和用户目录，真实 https URL 和请求参数仍走原网络 fetch。

分享、桌面快捷入口、侧边栏、启动参数、震动、录屏等优先用框架 PlatformSDK/MiniGamePlatform 已有方法；接口参数/能力因平台不同而异。没有能力时通过明确失败/default/out 参数返回，不留下仅 TT/WX 宏有 return 的函数，不编造成功。编译检查四类：Editor、OPPO Player、vivo Player、其他目标平台；平台函数使用对应条件引用，禁止 TT.JsonData 等类型泄漏到 OPPO/vivo。

## 包内异步读取与反射裁剪

文件系统封装要覆盖异步路径。只修 FileUtility 的同步读或 persistent 读，启动时 `openFileAsyncInternal` 仍可能把包内 `/WebGL/.../StreamingAssets` 当 URL 发到 localhost:8080，结果 DLL/动态密钥为空。检查真实 FrameBaseUtility：非 Editor WebGL 下 persistent 文件，以及 OPPO/vivo 的 F_STREAMING_ASSETS_PATH 文件，都应进 SDK 文件系统读取分支；真正 https URL 保持网络读取。已有实现则不再 patch，也不能在每个业务加载点添加补丁。

vivo `StatSync` 的 LitJson 反射可能在裁剪后报 QGStat 无默认构造函数。先读 SDK 的类型/反射调用并确认程序集名；按 `assets/merge/QuickGameLink.xml.txt` 仅保留 QGStat/QGStatInfo/QGStatResponse，放在 AOT 的现有 link.xml。SDK 改名则按真实名称调整。Game/link.xml 变化需重建 AOT 和底包，不靠 HotFix 更新解决；不能全量 preserve SDK 以隐藏问题。
