public class QuickGameTimeSystem : FrameSystem
{
	private float mScale = 1.0f;
	public float getScale()
	{
		return mScale;
	}
	public void setScale(float scale)
	{
		mScale = scale;
		CmdTimeManagerScaleTime.execute(scale, scale, 0.0f, 0.0f, 0, false, null, null);
	}
}
