public class QuickGameStartupScene : GameScene
{
	public override void assignStartExitProcedure()
	{
		mStartProcedure = typeof(QuickGameStartupSceneLoading);
		mExitProcedure = typeof(QuickGameStartupSceneExit);
	}
	public override void createSceneProcedure()
	{
		addProcedure(typeof(QuickGameStartupSceneLoading));
		addProcedure(typeof(QuickGameStartupSceneExit));
	}
}
