using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.Networking;
using static FrameBaseUtility;
using static FrameBaseHotFix;
using static GBR;
using static UnityUtility;
using static TimeUtility;
public class QuickGamePlatformSystem : MiniGamePlatform
{
	protected const long CONFIG_REFRESH_INTERVAL_MS = 60000;
	private bool mInitialized;
	private bool mAdRequestInProgress;
	private Action mCancelAd;
	private long mSessionStartTimeMS;
	private long mLastInterstitialTimeMS;
	private long mNextConfigRefreshTimeMS;
	private int mConfigRequestID;
	private bool mConfigRequestPending;
	private bool mInterstitialConfigLoaded;
	private bool mHasShownInterstitial;
	private double mInterstitialFirstDelay;
	private double mInterstitialInterval;
	public override void init()
	{
		base.init();
		mSessionStartTimeMS = getNowUTCTimeStampMS();
		mHasShownInterstitial = false;
		mInterstitialConfigLoaded = false;
		mConfigRequestPending = false;
		refreshAdConfig();
		if (!isWebGL() || isEditor())
		{
			mGameFrameworkHotFix.resetFrameRate();
		}
	}
	public bool isInitialized()
	{
		return mInitialized;
	}
	public new bool isAdRequestInProgress()
	{
		return mAdRequestInProgress;
	}
	public void init(Action callback)
	{
		mInitialized = true;
		callback?.Invoke();
	}
	public new void showInterstitial(Action adFinished, Action adError)
	{
		showGameAd(false, adFinished, adError);
	}
	public new void showReward(Action adFinished, Action adError)
	{
		showGameAd(true, adFinished, adError);
	}
	public void refreshAdConfig()
	{
		if (mDestroying || mConfigRequestPending || QuickGameProjectSettings.get().AdConfigUrl.isEmpty() || QuickGameProjectSettings.get().getInterstitialSwitchId().isEmpty())
		{
			return;
		}
		mConfigRequestPending = true;
		mNextConfigRefreshTimeMS = getNowUTCTimeStampMS() + CONFIG_REFRESH_INTERVAL_MS;
		int requestID = ++mConfigRequestID;
		try
		{
			JObject request = new();
			request["switchIdList"] = new JArray(QuickGameProjectSettings.get().getInterstitialSwitchId());
			request["pkgName"] = Application.identifier;
			request["version"] = Application.version;
			HttpUtility.httpPostAsyncWebGL(QuickGameProjectSettings.get().AdConfigUrl, request.ToString(Formatting.None),
				(result, status, code) => onAdConfigReceived(requestID, result, status, code));
		}
		catch (Exception e)
		{
			mConfigRequestPending = false;
			logWarning("获取插屏配置失败:" + e.Message);
		}
	}
	public override void update(float elapsedTime)
	{
		base.update(elapsedTime);
		if (!mDestroying && !QuickGameProjectSettings.get().AdConfigUrl.isEmpty() && !QuickGameProjectSettings.get().getInterstitialSwitchId().isEmpty() && getNowUTCTimeStampMS() >= mNextConfigRefreshTimeMS)
		{
			mConfigRequestPending = false;
			refreshAdConfig();
		}
	}
	public override void willDestroy()
	{
		++mConfigRequestID;
		mConfigRequestPending = false;
		base.willDestroy();
		mCancelAd?.Invoke();
	}
	public override void destroy()
	{
		++mConfigRequestID;
		mConfigRequestPending = false;
		base.destroy();
		mCancelAd?.Invoke();
		mCancelAd = null;
		mAdRequestInProgress = false;
		mInitialized = false;
	}
	//------------------------------------------------------------------------------------------------------------------------------
	private void showGameAd(bool rewarded, Action adFinished, Action adError)
	{
		if (mDestroying || mAdRequestInProgress || mPending)
		{
			adError?.Invoke();
			return;
		}
		if (!rewarded && !canShowInterstitial())
		{
			adFinished?.Invoke();
			return;
		}
		mAdRequestInProgress = true;
		float previousScale = GBR.mQuickGameTimeSystem.getScale();
		bool previousPause = AudioListener.pause;
		GBR.mQuickGameTimeSystem.setScale(0.0f);
		AudioListener.pause = true;
		bool settled = false;
		void finish(bool success)
		{
			if (settled)
			{
				return;
			}
			settled = true;
			mAdRequestInProgress = false;
			mCancelAd = null;
			mQuickGameTimeSystem.setScale(previousScale);
			AudioListener.pause = previousPause;
			if (success)
			{
				if (!rewarded)
				{
					mLastInterstitialTimeMS = getNowUTCTimeStampMS();
					mHasShownInterstitial = true;
				}
				adFinished?.Invoke();
			}
			else
			{
				adError?.Invoke();
			}
		}
		mCancelAd = () => finish(false);
		int requestID = mRequestID;
		try
		{
#if UNITY_EDITOR
			finish(true);
#elif BYTE_DANCE || OPPO_MINI_GAME || VIVO_MINI_GAME
			string adUnitID = rewarded ? MiniGameSettings.getRewardedVideoID() : MiniGameSettings.getInterstitialID();
			if (adUnitID.isEmpty())
			{
				logWarning("未配置当前平台的" + (rewarded ? "激励视频" : "插屏") + "广告位 ID");
				finish(false);
				return;
			}
#if UNITY_WEBGL && !UNITY_EDITOR
			mSuccess = () => finish(true);
			mFailure = () => finish(false);
			mPending = true;
			mShowing = false;
			mShowRequested = false;
			mLoadTime = 0.0f;
			requestID = ++mRequestID;
			createAd(requestID, rewarded, adUnitID);
#else
			logWarning("广告需要在对应平台的真机环境验证");
			finish(false);
#endif
#else
			finish(false);
#endif
		}
		catch (Exception e)
		{
			onAdError(requestID, e.Message);
			finish(false);
		}
	}
	private bool canShowInterstitial()
	{
		if (QuickGameProjectSettings.get().getInterstitialSwitchId().isEmpty())
		{
			return true;
		}
		long now = getNowUTCTimeStampMS();
		return mInterstitialConfigLoaded &&
			(now - mSessionStartTimeMS) / 1000.0 >= mInterstitialFirstDelay &&
			(!mHasShownInterstitial || (now - mLastInterstitialTimeMS) / 1000.0 >= mInterstitialInterval);
	}
	private void onAdConfigReceived(int requestID, string result, UnityWebRequest.Result status, long code)
	{
		if (mDestroying || !mConfigRequestPending || requestID != mConfigRequestID)
		{
			return;
		}
		mConfigRequestPending = false;
		if (status != UnityWebRequest.Result.Success || code < 200 || code >= 300 || !tryApplyAdConfig(result))
		{
			logWarning("插屏配置未取得有效值，保留本次启动已取得的配置；尚无配置时跳过插屏");
		}
	}
	private bool tryApplyAdConfig(string result)
	{
		try
		{
			JObject response = JObject.Parse(result);
			JObject meta = response["meta"] as JObject;
			JArray data = response["data"] as JArray;
			if (meta == null || meta["errCode"]?.Type != JTokenType.Integer || meta.Value<int>("errCode") != 0 ||
				data == null || data.Count != 1 || data[0]?.Type != JTokenType.String)
			{
				return false;
			}
			JObject config = JObject.Parse(data[0].Value<string>());
			if (!tryReadSeconds(config["firstDelay"], out double firstDelay) || !tryReadSeconds(config["interval"], out double interval))
			{
				return false;
			}
			mInterstitialFirstDelay = firstDelay;
			mInterstitialInterval = interval;
			mInterstitialConfigLoaded = true;
			return true;
		}
		catch (Exception)
		{
			return false;
		}
	}
	private static bool tryReadSeconds(JToken token, out double seconds)
	{
		seconds = 0.0;
		if (token == null || (token.Type != JTokenType.Integer && token.Type != JTokenType.Float))
		{
			return false;
		}
		seconds = token.Value<double>();
		return seconds >= 0.0 && !double.IsNaN(seconds) && !double.IsInfinity(seconds);
	}
}
