using static FrameBaseHotFix;
public class QuickGameStartupSceneExit : SceneProcedure
{
	protected override void onInit(SceneProcedure lastProcedure)
	{
		LT.UNLOAD<UIQuickGamePrivacy>();
		LT.UNLOAD<UIQuickGameStartup>();
	}
}
