using Obfuz;
using static FrameBaseUtility;
// auto generate member start
// generate from:Assets/GameResources/UI/UIPrefab/UIQuickGameStartup.prefab
// 启动页
[ObfuzIgnore(ObfuzScope.TypeName)]
public class UIQuickGameStartup : LayoutScript
{
	protected myUGUIObject mBackground;
	protected UGUIProgress mProgress;
	protected LegendButton mButtonPrivacy;
	// auto generate member end
	protected bool mPrivacyOpen;
	public UIQuickGameStartup()
	{
		// auto generate constructor start
		mProgress = new(this);
		mButtonPrivacy = new(this);
		// auto generate constructor end
	}
	public override void assignWindow()
	{
		// auto generate assignWindow start
		newObject(out mBackground, "Background");
		mProgress.assignWindow(mRoot, "Progress");
		mButtonPrivacy.assignWindow(mRoot, "ButtonPrivacy");
		// auto generate assignWindow end
	}
	public override void init()
	{
		base.init();
		// auto generate init start
		mBackground.registeCollider();
		mButtonPrivacy.registeCollider(onButtonPrivacyClick);
		// auto generate init end
	}
	public override void onGameState()
	{
		base.onGameState();
		mPrivacyOpen = false;
		QuickGameProjectSettings settings = QuickGameProjectSettings.get();
		mButtonPrivacy.setActive(isVivo() ? settings.ShowVivoPrivacyButton : settings.ShowOppoPrivacyButton);
		setProgress(0.0f);
	}
	public void setProgress(float percent)
	{
		mProgress.setValue(percent);
	}
	public bool isPrivacyOpen()
	{
		return mPrivacyOpen;
	}
	public void setPrivacyOpen(bool open)
	{
		mPrivacyOpen = open;
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------
	protected void onButtonPrivacyClick()
	{
		if (mPrivacyOpen)
		{
			return;
		}
		mPrivacyOpen = true;
		LT.LOAD_ASYNC_TOP<UIQuickGamePrivacy>(onPrivacyLoaded);
	}
	protected void onPrivacyLoaded()
	{
		if (GBR.mUIQuickGamePrivacy == null)
		{
			mPrivacyOpen = false;
		}
	}
}
