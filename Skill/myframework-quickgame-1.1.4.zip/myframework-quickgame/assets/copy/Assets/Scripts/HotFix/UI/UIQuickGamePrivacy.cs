using Obfuz;
using UnityEngine;
// auto generate member start
// generate from:Assets/GameResources/UI/UIPrefab/UIQuickGamePrivacy.prefab
// 隐私协议
[ObfuzIgnore(ObfuzScope.TypeName)]
public class UIQuickGamePrivacy : LayoutScript
{
	protected myUGUIObject mBackground;
	protected myUGUIObject mPanel;
	protected myUGUIObject mScrollView;
	protected myUGUIObject mViewport;
	protected myUGUIDragView mContent;
	protected myUGUITextTMP mTextAgreement;
	protected LegendButton mButtonClose;
	// auto generate member end
	public UIQuickGamePrivacy()
	{
		// auto generate constructor start
		mButtonClose = new(this);
		// auto generate constructor end
	}
	public override void assignWindow()
	{
		// auto generate assignWindow start
		newObject(out mBackground, "Background");
		newObject(out mPanel, "Panel");
		newObject(out mScrollView, mPanel, "ScrollView");
		newObject(out mViewport, mScrollView, "Viewport");
		newObject(out mContent, mViewport, "Content");
		newObject(out mTextAgreement, mContent, "TextAgreement");
		mButtonClose.assignWindow(mPanel, "ButtonClose");
		// auto generate assignWindow end
	}
	public override void init()
	{
		base.init();
		// auto generate init start
		mBackground.registeCollider();
		mPanel.registeCollider();
		mScrollView.registeCollider();
		mViewport.registeCollider();
		mButtonClose.registeCollider(onButtonCloseClick);
		// auto generate init end
	}
	public override void onGameState()
	{
		base.onGameState();
		TextAsset agreement = Resources.Load<TextAsset>("Settings/PrivacyAgreement");
		mTextAgreement.setText(agreement == null ? "隐私协议资源缺失" : agreement.text);
		mTextAgreement.applyPreferredHeight();
		mContent.setHeight(Mathf.Max(mTextAgreement.getSize().y, mViewport.getSize().y));
		mTextAgreement.setTopToParentTop();
		mContent.setTopToParentTop();
		mContent.stopMoving();
	}
	public override void onHide()
	{
		base.onHide();
		GBR.mUIQuickGameStartup?.setPrivacyOpen(false);
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------
	protected void onButtonCloseClick()
	{
		close();
	}
}
