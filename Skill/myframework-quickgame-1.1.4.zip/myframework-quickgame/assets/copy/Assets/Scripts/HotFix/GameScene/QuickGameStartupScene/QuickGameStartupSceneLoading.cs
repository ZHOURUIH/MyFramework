using UnityEngine;
using static FrameBaseHotFix;
using static GBR;
public class QuickGameStartupSceneLoading : SceneProcedure
{
	protected float mSplashSeconds;
	protected bool mActive;
	protected bool mStarted;
	protected float mElapsed;
	public override void resetProperty()
	{
		base.resetProperty();
		mSplashSeconds = default;
		mActive = default;
		mStarted = default;
		mElapsed = default;
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------
	protected override void onInit(SceneProcedure lastProcedure)
	{
		mSplashSeconds = Mathf.Max(0.01f, QuickGameProjectSettings.get().SplashSeconds);
		mActive = true;
		mStarted = false;
		mElapsed = 0.0f;
		LT.LOAD_ASYNC_TOP<UIQuickGameStartup>(onStartupLoaded);
	}
	protected override void onUpdate(float elapsedTime)
	{
		if (!mActive || mUIQuickGameStartup == null || !mUIQuickGameStartup.isVisible() || mUIQuickGameStartup.isPrivacyOpen())
		{
			return;
		}
		if (!mStarted)
		{
			mStarted = true;
			return;
		}
		mElapsed += Time.unscaledDeltaTime;
		mUIQuickGameStartup.setProgress(mElapsed / mSplashSeconds);
		if (mElapsed >= mSplashSeconds)
		{
			mActive = false;
			System.Type sceneType = typeof(GameHotFix).Assembly.GetType(QuickGameProjectSettings.get().MainSceneTypeName);
			if (sceneType == null || !typeof(GameScene).IsAssignableFrom(sceneType))
			{
				throw new System.InvalidOperationException("MainSceneTypeName 必须配置为真实 GameScene 类型，并在混淆时保留类型名");
			}
			mGameSceneManager.enterScene(sceneType, null);
		}
	}
	protected override void onExit(SceneProcedure nextProcedure)
	{
		mActive = false;
	}
	protected void onStartupLoaded()
	{
		if (!mActive)
		{
			LT.UNLOAD<UIQuickGameStartup>();
		}
	}
}
