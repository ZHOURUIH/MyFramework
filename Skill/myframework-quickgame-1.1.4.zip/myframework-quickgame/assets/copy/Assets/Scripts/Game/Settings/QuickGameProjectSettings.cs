using UnityEngine;
public class QuickGameProjectSettings : ScriptableObject
{
	protected static QuickGameProjectSettings mInstance;
	public string GameName = "";
	public string GameFolder = "Game";
	public string CdnUrl = "";
	public string OppoResourceFolder = "Game_OPPO/";
	public string VivoResourceFolder = "Game_VIVO/";
	public bool Portrait;
	public string MainSceneTypeName = "";
	public float SplashSeconds = 2.0f;
	public bool ShowOppoPrivacyButton = true;
	public bool ShowVivoPrivacyButton = true;
	public string AdConfigUrl = "";
	public string OppoInterstitialSwitchId = "";
	public string VivoInterstitialSwitchId = "";
	public static QuickGameProjectSettings get()
	{
		if (mInstance == null)
		{
			mInstance = Resources.Load<QuickGameProjectSettings>("Settings/QuickGameProjectSettings");
		}
		if (mInstance == null)
		{
			throw new System.InvalidOperationException("缺少 Resources/Settings/QuickGameProjectSettings.asset");
		}
		return mInstance;
	}
	public string getInterstitialSwitchId()
	{
#if OPPO_MINI_GAME
		return OppoInterstitialSwitchId;
#elif VIVO_MINI_GAME
		return VivoInterstitialSwitchId;
#else
		return "";
#endif
	}
	public string getRemotePath(bool testClient, string version)
	{
		string folder;
#if OPPO_MINI_GAME
		folder = OppoResourceFolder;
#elif VIVO_MINI_GAME
		folder = VivoResourceFolder;
#else
		throw new System.InvalidOperationException("需要选择 OPPO 或 vivo 平台");
#endif
		return folder.TrimEnd('/') + "/Assets_" + (testClient ? "Test_" : "") + "WebGL/" +
			(string.IsNullOrEmpty(version) ? "" : version + "/");
	}
}
