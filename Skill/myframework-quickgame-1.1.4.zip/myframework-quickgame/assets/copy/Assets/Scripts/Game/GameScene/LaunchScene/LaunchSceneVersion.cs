﻿using System;
using UnityEngine;
using static FrameBaseUtility;
using static FrameBaseDefine;
using static StringUtility;
using static ResourceUtility;
using static GameUtility;
using static FrameBase;
using static GameDefine;
using static GameBase;
public class LaunchSceneVersion : SceneProcedure
{
	protected const float NETWORK_CHECK_TIMEOUT = 2.0f;
	protected const float VERSION_TIMEOUT = 8.0f;
	protected bool mActive;
	protected bool mStreamingAndPersistDone;
	protected bool mRemoteDone;
	protected bool mCheckingNetwork;
	protected int mGeneration;
	protected float mElapsed;
	public override void init()
	{
		base.init();
		mActive = true;
		mStreamingAndPersistDone = false;
		mRemoteDone = false;
		mCheckingNetwork = false;
		mElapsed = 0.0f;
		int generation = ++mGeneration;
		CmdLayoutManagerLoad.execute<UIDownload>(0);
		mUIDownload.resetProgress();
		mUIDownload.setStatus("正在检查版本...");
		if (isEditor() || !isEnableHotFix())
		{
			mGameSceneManager.getCurScene().changeProcedure<LaunchSceneDownload>();
			return;
		}
		mAssetVersionSystem.loadStreamingAndPersistentVersion(() =>
		{
			if (!mActive || generation != mGeneration)
			{
				return;
			}
			mStreamingAndPersistDone = true;
			checkEnterNext();
		});
		mCheckingNetwork = true;
		LaunchNetworkUtility.checkNetwork(connected =>
		{
			if (!mActive || generation != mGeneration || !mCheckingNetwork)
			{
				return;
			}
			mCheckingNetwork = false;
			if (!connected)
			{
				startLocal("网络未连接，使用内置版本");
				return;
			}
			doGetRemoteVersion();
		});
	}
	public override void update(float elapsedTime)
	{
		base.update(elapsedTime);
		if (!mActive)
		{
			return;
		}
		mElapsed += Time.unscaledDeltaTime;
		if (mCheckingNetwork && mElapsed >= NETWORK_CHECK_TIMEOUT)
		{
			mCheckingNetwork = false;
			doGetRemoteVersion();
		}
		else if (!mCheckingNetwork && mElapsed >= VERSION_TIMEOUT)
		{
			startLocal("版本检查超时，使用内置版本");
		}
	}
	public override void exit()
	{
		mActive = false;
		++mGeneration;
		base.exit();
	}
	public override void willDestroy()
	{
		mActive = false;
		++mGeneration;
		base.willDestroy();
	}
	//---------
	protected void doGetRemoteVersion()
	{
		if (string.IsNullOrWhiteSpace(CDN_URL))
		{
			startLocal("未配置远端更新地址，使用内置版本");
			return;
		}
		mElapsed = 0.0f;
		int generation = mGeneration;
		try
		{
			loadAssetsFromUrl(CDN_URL + getRemotePathWithoutURL("") + VERSION, bytes =>
			{
				if (!mActive || generation != mGeneration)
				{
					return;
				}
				string version = bytes == null ? null : bytesToString(bytes).Trim();
				if (!checkValidVersion(ref version))
				{
					startLocal("版本检查失败，使用内置版本");
					return;
				}
				mAssetVersionSystem.setRemoteVersion(version);
				mResourceManager.setDownloadURL(CDN_URL + getRemotePathWithoutURL(version));
				mRemoteDone = true;
				checkEnterNext();
			});
		}
		catch (Exception e)
		{
			logWarningBase("获取版本失败:" + e.Message);
			startLocal("版本检查失败，使用内置版本");
		}
	}
	protected void checkEnterNext()
	{
		if (mActive && mRemoteDone && mStreamingAndPersistDone)
		{
			if (compareVersion3(mAssetVersionSystem.getRemoteVersion(), mAssetVersionSystem.getStreamingAssetsVersion(), out _, out _) ==
				VERSION_COMPARE.REMOTE_LOWER)
			{
				// 新完整包先于 CDN 发布时，避免请求旧资源并进入空文件列表的下载分支。
				startLocal("远端版本低于内置版本，使用内置版本");
				return;
			}
			mGameSceneManager.getCurScene().changeProcedure<LaunchSceneFileList>();
		}
	}
	protected void startLocal(string reason)
	{
		if (!mActive)
		{
			return;
		}
		mUIDownload.setStatus(reason);
		logBase(reason);
		mGameSceneManager.getCurScene().changeProcedure<LaunchSceneLocal>();
	}
}
