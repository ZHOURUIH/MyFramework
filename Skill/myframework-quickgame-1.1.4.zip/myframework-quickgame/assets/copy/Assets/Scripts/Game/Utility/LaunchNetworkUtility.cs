using System;
using UnityEngine;
#if (OPPO_MINI_GAME || VIVO_MINI_GAME) && UNITY_WEBGL && !UNITY_EDITOR
using QGMiniGame;
#endif
public class LaunchNetworkUtility
{
	public static void checkNetwork(Action<bool> callback)
	{
#if (OPPO_MINI_GAME || VIVO_MINI_GAME) && UNITY_WEBGL && !UNITY_EDITOR
		bool completed = false;
		void finish(bool connected)
		{
			if (!completed)
			{
				completed = true;
				callback?.Invoke(connected);
			}
		}
		try
		{
			QG.GetNetworkType(response =>
			{
				string type = response?.data?.networkType;
				finish(!string.Equals(type, "none", StringComparison.OrdinalIgnoreCase));
			}, error =>
			{
				finish(true);
			});
		}
		catch (Exception)
		{
			finish(true);
		}
#else
		callback?.Invoke(Application.internetReachability != NetworkReachability.NotReachable);
#endif
	}
}
