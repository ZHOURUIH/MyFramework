using System;
using UnityEngine;
using static FrameBase;
using static FrameBaseUtility;
using static GameBase;
public class LaunchSceneDownload : SceneProcedure
{
	protected const float DOWNLOAD_IDLE_TIMEOUT = 8.0f;
	protected GameDownload mInstance;
	protected bool mActive;
	protected bool mLaunching;
	protected PROGRESS_TYPE mLastProgressType;
	protected float mLastProgress;
	protected float mIdleElapsed;
	public override void init()
	{
		base.init();
		mActive = true;
		mLaunching = false;
		mLastProgress = -1.0f;
		mIdleElapsed = 0.0f;
		mInstance = new GameDownload();
		mInstance.setAutoRetryCount(0);
		mInstance.setProgressCallback(onDownloadProgress);
		mInstance.setErrorCallback(onDownloadError);
		try
		{
			mInstance.start();
		}
		catch (Exception e)
		{
			logWarningBase("资源更新失败:" + e.Message);
			startLocal("资源更新失败，使用内置版本");
		}
	}
	public override void update(float elapsedTime)
	{
		base.update(elapsedTime);
		if (!mActive || mLaunching)
		{
			return;
		}
		mIdleElapsed += Time.unscaledDeltaTime;
		if (mIdleElapsed >= DOWNLOAD_IDLE_TIMEOUT)
		{
			startLocal("资源更新超时，使用内置版本");
		}
	}
	public override void willDestroy()
	{
		mActive = false;
		mInstance?.cancel();
		mInstance = null;
		base.willDestroy();
	}
	public override void exit()
	{
		mActive = false;
		mInstance?.cancel();
		mInstance = null;
		base.exit();
	}
	//---------
	protected void onLaunchError()
	{
		if (mActive)
		{
			mUIDownload?.setStatus("启动失败，请重新启动游戏");
			logErrorBase("启动热更失败");
		}
	}
	protected void onDownloadError(DOWNLOAD_ERROR error)
	{
		if (mActive && error != DOWNLOAD_ERROR.NONE)
		{
			startLocal("资源更新失败，使用内置版本");
		}
	}
	protected void onDownloadProgress(float progress, PROGRESS_TYPE type, string info, int bytesPerSecond, int downloadRemainSeconds)
	{
		if (!mActive)
		{
			return;
		}
		if (mLastProgressType != type || progress > mLastProgress || bytesPerSecond > 0)
		{
			mIdleElapsed = 0.0f;
		}
		mLastProgressType = type;
		mLastProgress = progress;
		switch (type)
		{
			case PROGRESS_TYPE.CHECKING_UPDATE:
				mUIDownload.setProgress("正在检查更新...", progress);
				break;
			case PROGRESS_TYPE.DELETE_FILE:
				mUIDownload.setProgress("正在清理旧资源...", progress);
				break;
			case PROGRESS_TYPE.DOWNLOAD_RESOURCE:
				mUIDownload.setProgress("正在下载资源...", progress);
				break;
			case PROGRESS_TYPE.FINISH:
				mUIDownload.setProgress("正在启动游戏...", 1.0f);
				if (!mLaunching)
				{
					mLaunching = true;
					HybridCLRSystem.launchHotFix(onLaunchError);
				}
				break;
		}
	}
	protected void startLocal(string reason)
	{
		if (!mActive || mLaunching)
		{
			return;
		}
		mUIDownload.setStatus(reason);
		logBase(reason);
		mInstance?.cancel();
		mGameSceneManager.getCurScene().changeProcedure<LaunchSceneLocal>();
	}
}
