using TMPro;
using UnityEngine;
using UnityEngine.UI;
public class UIDownload : GameLayout
{
	protected TextMeshProUGUI mTipText;
	protected Image mProgressBar;
	public override void assignWindow()
	{
		base.assignWindow();
		getUIComponent(out mTipText, "TipText");
		getUIComponent(out mProgressBar, "ProgressBar");
	}
	public override void onGameState()
	{
		base.onGameState();
		resetProgress();
	}
	public void resetProgress()
	{
		mProgressBar.fillAmount = 0.0f;
		mTipText.text = "";
	}
	public void setProgress(string tip, float percent)
	{
		percent = Mathf.Clamp01(percent);
		mProgressBar.fillAmount = percent;
		mTipText.text = tip + " " + Mathf.RoundToInt(percent * 100) + "%";
	}
	public void setStatus(string tip)
	{
		mTipText.text = tip;
	}
}
