using System;
using System.Collections.Generic;
using UnityEngine;
using static FileUtility;
using static FrameBase;
using static FrameBaseDefine;
using static FrameBaseUtility;
using static GameBase;
public class LaunchSceneLocal : SceneProcedure
{
	protected const float LOCAL_LOAD_TIMEOUT = 20.0f;
	protected bool mActive;
	protected bool mLaunching;
	protected int mGeneration;
	protected float mElapsed;
	public override void init()
	{
		base.init();
		mActive = true;
		mLaunching = false;
		mElapsed = 0.0f;
		int generation = ++mGeneration;
		mAssetVersionSystem.setAssetReadPath(ASSET_READ_PATH.STREAMING_ASSETS_ONLY);
		mResourceManager.setDownloadURL("");
		mAssetVersionSystem.setRemoteDynamicDownloadList(null);
		mAssetVersionSystem.getRemoteAssetsFile().Clear();
		mUIDownload.setStatus("正在启动内置版本...");
		openTxtFileAsync(F_ASSET_BUNDLE_PATH + VERSION, false, version =>
		{
			if (!mActive || generation != mGeneration)
			{
				return;
			}
			version = version?.Trim();
			if (!checkValidVersion(ref version))
			{
				fail("内置版本信息缺失，请重新安装游戏");
				return;
			}
			mAssetVersionSystem.setStreamingAssetsVersion(version);
			loadLocalFileList(generation, version);
		});
	}
	public override void update(float elapsedTime)
	{
		base.update(elapsedTime);
		if (!mActive || mLaunching)
		{
			return;
		}
		mElapsed += Time.unscaledDeltaTime;
		if (mElapsed >= LOCAL_LOAD_TIMEOUT)
		{
			fail("内置资源读取超时，请重新启动游戏");
		}
	}
	public override void exit()
	{
		mActive = false;
		++mGeneration;
		base.exit();
	}
	public override void willDestroy()
	{
		mActive = false;
		++mGeneration;
		base.willDestroy();
	}
	//---------
	protected void loadLocalFileList(int generation, string version)
	{
		openTxtFileAsync(F_ASSET_BUNDLE_PATH + FILE_LIST, false, content =>
		{
			if (!mActive || generation != mGeneration)
			{
				return;
			}
			try
			{
				Dictionary<string, GameFileInfo> files = new();
				parseFileList(content, files);
				if (!files.ContainsKey(DYNAMIC_SECRET_FILE) || !files.ContainsKey("StreamingAssets.bytes"))
				{
					fail("内置资源不完整，请重新安装游戏");
					return;
				}
				foreach (string assemblyName in FrameSettings.getHotFixList())
				{
					if (!files.ContainsKey(assemblyName + ".dll.bytes"))
					{
						fail("内置程序集不完整，请重新安装游戏");
						return;
					}
				}
				Dictionary<string, GameFileInfo> streaming = mAssetVersionSystem.getStreamingAssetsFile();
				streaming.Clear();
				foreach (KeyValuePair<string, GameFileInfo> item in files)
				{
					streaming.Add(item.Key, item.Value);
				}
				loadLocalSecret(generation, version, files[DYNAMIC_SECRET_FILE]);
			}
			catch (Exception e)
			{
				logWarningBase("读取内置资源列表失败:" + e.Message);
				fail("内置资源列表无效，请重新安装游戏");
			}
		});
	}
	protected void loadLocalSecret(int generation, string version, GameFileInfo secretInfo)
	{
		openFileAsync(F_ASSET_BUNDLE_PATH + DYNAMIC_SECRET_FILE, false, bytes =>
		{
			if (!mActive || generation != mGeneration)
			{
				return;
			}
			if (bytes == null || bytes.LongLength != secretInfo.mFileSize ||
				!string.Equals(generateFileMD5(bytes), secretInfo.mMD5, StringComparison.OrdinalIgnoreCase))
			{
				fail("内置启动资源校验失败，请重新安装游戏");
				return;
			}
			openTxtFileAsync(F_PERSISTENT_ASSETS_PATH + FILE_LIST, false, content =>
			{
				if (!mActive || generation != mGeneration)
				{
					return;
				}
				prepareLocalLaunch(version, secretInfo, bytes, content);
			});
		});
	}
	protected void prepareLocalLaunch(string version, GameFileInfo secretInfo, byte[] secretBytes, string persistentList)
	{
		try
		{
			Dictionary<string, GameFileInfo> persisted = mAssetVersionSystem.getPersistentAssetsFile();
			if (!string.IsNullOrEmpty(persistentList))
			{
				try
				{
					Dictionary<string, GameFileInfo> files = new();
					parseFileList(persistentList, files);
					persisted.Clear();
					foreach (KeyValuePair<string, GameFileInfo> item in files)
					{
						persisted.Add(item.Key, item.Value);
					}
				}
				catch (Exception e)
				{
					logWarningBase("忽略无效缓存资源列表:" + e.Message);
				}
			}
			if (!writeFileSafe(F_PERSISTENT_ASSETS_PATH + DYNAMIC_SECRET_FILE, secretBytes, secretBytes.Length))
			{
				fail("启动资源写入失败，请重新启动游戏");
				return;
			}
			persisted[DYNAMIC_SECRET_FILE] = new GameFileInfo
			{
				mFileName = secretInfo.mFileName,
				mFileSize = secretInfo.mFileSize,
				mMD5 = secretInfo.mMD5,
			};
			if (!writeFileList(F_PERSISTENT_ASSETS_PATH, mAssetVersionSystem.generatePersistentAssetFileList()))
			{
				fail("启动资源记录写入失败，请重新启动游戏");
				return;
			}
			mAssetVersionSystem.setPersistentDataVersion(version);
			mAssetVersionSystem.setRemoteVersion(version);
			mAssetVersionSystem.setAssetReadPath(ASSET_READ_PATH.STREAMING_ASSETS_ONLY);
			mLaunching = true;
			mUIDownload.setProgress("正在启动游戏...", 1.0f);
			HybridCLRSystem.launchHotFix(onLaunchError);
		}
		catch (Exception e)
		{
			logWarningBase("启动内置版本失败:" + e.Message);
			fail("内置版本启动失败，请重新启动游戏");
		}
	}
	protected void onLaunchError()
	{
		if (mActive)
		{
			fail("内置版本启动失败，请重新启动游戏");
		}
	}
	protected void fail(string reason)
	{
		mActive = false;
		++mGeneration;
		mUIDownload?.setStatus(reason);
		logErrorBase(reason);
	}
}
