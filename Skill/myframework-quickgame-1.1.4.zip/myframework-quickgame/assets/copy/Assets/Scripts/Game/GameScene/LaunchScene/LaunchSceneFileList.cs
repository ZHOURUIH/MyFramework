using System;
using System.Collections.Generic;
using UnityEngine;
using static FileUtility;
using static StringUtility;
using static FrameBaseDefine;
using static FrameBaseUtility;
using static ResourceUtility;
using static FrameBase;
using static GameBase;
public class LaunchSceneFileList : SceneProcedure
{
	protected const float FILE_LIST_TIMEOUT = 8.0f;
	protected readonly List<string> mIgnoreFile = new() { VERSION, FILE_LIST };
	protected readonly List<string> mIgnorePath = new();
	protected string mRemoteFileList;
	protected bool mActive;
	protected int mGeneration;
	protected float mElapsed;
	public override void init()
	{
		base.init();
		mAssetVersionSystem.setRemoteDynamicDownloadList(null);
		mUIDownload.setStatus("正在校验文件列表...");
		mActive = true;
		mElapsed = 0.0f;
		++mGeneration;
		requestFileList();
	}
	public override void update(float elapsedTime)
	{
		base.update(elapsedTime);
		if (mActive)
		{
			mElapsed += Time.unscaledDeltaTime;
			if (mElapsed >= FILE_LIST_TIMEOUT)
			{
				onCheckFileListFailed();
			}
		}
	}
	public override void exit()
	{
		mActive = false;
		++mGeneration;
		base.exit();
	}
	public override void willDestroy()
	{
		mActive = false;
		++mGeneration;
		base.willDestroy();
	}
	//---------
	protected void onCheckFileListSuccess()
	{
		if (mActive)
		{
			mAssetVersionSystem.setAssetReadPath(ASSET_READ_PATH.SAME_TO_REMOTE);
			requestDynamicDownloadList();
		}
	}
	protected void onCheckFileListFailed()
	{
		if (!mActive)
		{
			return;
		}
		mUIDownload.setStatus("资源清单检查失败，使用内置版本");
		mGameSceneManager.getCurScene().changeProcedure<LaunchSceneLocal>();
	}
	protected void checkNeedRequestRemoteFileList(StringCallback callback)
	{
		if (mActive)
		{
			callback?.Invoke(mRemoteFileList);
		}
	}
	protected void requestDynamicDownloadList()
	{
		mElapsed = 0.0f;
		mUIDownload.setStatus("正在获取动态下载列表...");
		int generation = mGeneration;
		string version = mAssetVersionSystem.getRemoteVersion();
		try
		{
			loadAssetsFromUrl(mResourceManager.getDownloadURL() + DYNAMIC_DOWNLOAD_LIST, bytes =>
			{
				if (!mActive || generation != mGeneration)
				{
					return;
				}
				if (bytes == null || !DynamicDownloadConfig.tryParse(bytesToString(bytes), version, out DynamicDownloadConfig config))
				{
					onCheckFileListFailed();
					return;
				}
				mAssetVersionSystem.setRemoteDynamicDownloadList(config.Directories);
				mGameSceneManager.getCurScene().changeProcedure<LaunchSceneDownload>();
			});
		}
		catch (Exception e)
		{
			logWarningBase("获取动态下载列表失败:" + e.Message);
			onCheckFileListFailed();
		}
	}
	protected void requestFileList()
	{
		int generation = mGeneration;
		try
		{
			loadAssetsFromUrl(mResourceManager.getDownloadURL() + FILE_LIST, bytes =>
			{
				if (!mActive || generation != mGeneration)
				{
					return;
				}
				if (bytes == null || bytes.Length == 0)
				{
					onCheckFileListFailed();
					return;
				}
				mRemoteFileList = bytesToString(bytes);
				mAssetVersionSystem.startCheckFileList(generateFileMD5(bytes), mIgnorePath, mIgnoreFile,
					onCheckFileListSuccess, onCheckFileListFailed, checkNeedRequestRemoteFileList);
			});
		}
		catch (Exception e)
		{
			logWarningBase("获取文件列表失败:" + e.Message);
			onCheckFileListFailed();
		}
	}
}
