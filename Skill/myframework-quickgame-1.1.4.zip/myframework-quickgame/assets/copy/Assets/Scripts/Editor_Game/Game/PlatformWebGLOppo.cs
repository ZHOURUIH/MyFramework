using System.Collections.Generic;
using UBuilResult = UnityEditor.Build.Reporting.BuildResult;
public class PlatformWebGLOppo : PlatformInfo
{
	public PlatformInternal_Oppo mOppo = new();
	public override Dictionary<string, string> getBuildParameters(string version)
	{
		var parameters = base.getBuildParameters(version);
		mOppo.getBuildParameters(parameters, QuickGameProjectSettings.get().GameName);
		return parameters;
	}
	//---------
	protected override bool preBuild()
	{
		mOppo.mPortrait = QuickGameProjectSettings.get().Portrait;
		return mOppo.preBuild(mBuildVersion, mTestClient, QuickGameProjectSettings.get().GameName, mOutputPath, mFolderPreName) && base.preBuild();
	}
	protected override UBuilResult buildInternal(out string outputFullPath)
	{
		return mOppo.buildInternal(out outputFullPath);
	}
}
