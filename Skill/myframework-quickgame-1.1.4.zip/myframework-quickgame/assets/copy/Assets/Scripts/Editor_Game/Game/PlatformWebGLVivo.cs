using System.Collections.Generic;
#if VIVO_MINI_GAME
using QGMiniGameCore;
#endif
using UBuilResult = UnityEditor.Build.Reporting.BuildResult;
public class PlatformWebGLVivo : PlatformInfo
#if VIVO_MINI_GAME
	, IUnityCompatible
#endif
{
	public PlatformInternal_Vivo mVivo = new();
	public bool SetPlayer(bool useWebgl2)
	{
		return mVivo.SetPlayer(useWebgl2);
	}
#if VIVO_MINI_GAME
	public bool BuildWebGL(string srcPath, QGGameConfig config)
	{
		return mVivo.BuildWebGL(srcPath, config, mBuildVersion, mTestClient, QuickGameProjectSettings.get().GameName);
	}
	public void OnZipFile(string zipOutPath, Dictionary<string, string> fileMap)
	{
		mVivo.OnZipFile(zipOutPath, fileMap);
	}
#endif
	public override Dictionary<string, string> getBuildParameters(string version)
	{
		var parameters = base.getBuildParameters(version);
		mVivo.getBuildParameters(parameters, QuickGameProjectSettings.get().GameName);
		return parameters;
	}
	//---------
	protected override bool preBuild()
	{
		mVivo.mPortrait = QuickGameProjectSettings.get().Portrait;
		return mVivo.preBuild(mBuildVersion, mOutputPath, mFolderPreName, mTestClient, QuickGameProjectSettings.get().GameName) && base.preBuild();
	}
	protected override UBuilResult buildInternal(out string outputFullPath)
	{
#if VIVO_MINI_GAME
		return mVivo.buildInternal(out outputFullPath, this);
#else
		return mVivo.buildInternal(out outputFullPath);
#endif
	}
}
