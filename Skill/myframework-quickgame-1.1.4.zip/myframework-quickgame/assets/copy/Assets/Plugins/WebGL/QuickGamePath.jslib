mergeInto(LibraryManager.library, {
	$QuickGamePackagePath: function (path) {
		var value = UTF8ToString(path);
		return qg.getProvider && qg.getProvider() === 'vivo' && value.charAt(0) !== '/' ? '/' + value : value;
	},
	$QuickGamePackageStat__deps: ['$QuickGamePackagePath'],
	$QuickGamePackageStat: function (path) {
		var result = qg.getFileSystemManager().statSync(QuickGamePackagePath(path), false);
		if (Array.isArray(result)) { result = result[0]; }
		return result.stats || result;
	},
	GetQuickGamePersistentPath: function () {
		var path = qg.env.USER_DATA_PATH;
		var size = lengthBytesUTF8(path) + 1;
		var buffer = _malloc(size);
		stringToUTF8(path, buffer, size);
		return buffer;
	},
	QuickGamePackageAccess__deps: ['$QuickGamePackagePath'],
	QuickGamePackageAccess: function (path) {
		try { qg.getFileSystemManager().accessSync(QuickGamePackagePath(path)); return 1; }
		catch (e) { return 0; }
	},
	QuickGamePackageIsDirectory__deps: ['$QuickGamePackageStat'],
	QuickGamePackageIsDirectory: function (path) {
		try {
			var stat = QuickGamePackageStat(path);
			return (typeof stat.isDirectory === 'function' ? stat.isDirectory() : (stat.mode & 0xF000) === 0x4000) ? 1 : 0;
		} catch (e) { return 0; }
	},
	QuickGamePackageSize__deps: ['$QuickGamePackageStat'],
	QuickGamePackageSize: function (path) {
		try {
			return QuickGamePackageStat(path).size;
		} catch (e) { return -1; }
	},
	QuickGamePackageDirectory__deps: ['$QuickGamePackagePath'],
	QuickGamePackageDirectory: function (path) {
		var result = qg.getFileSystemManager().readdirSync(QuickGamePackagePath(path));
		var names = (result.files || result).join("\n");
		var buffer = _malloc(lengthBytesUTF8(names) + 1);
		stringToUTF8(names, buffer, lengthBytesUTF8(names) + 1);
		return buffer;
	},
	QuickGamePackageRead__deps: ['$QuickGamePackagePath'],
	QuickGamePackageRead: function (path, length) {
		try {
			var result = qg.getFileSystemManager().readFileSync(QuickGamePackagePath(path));
			var data = result.data !== undefined ? result.data : result;
			var bytes = ArrayBuffer.isView(data) ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength) : new Uint8Array(data);
			var pointer = _malloc(Math.max(1, bytes.length));
			HEAPU8.set(bytes, pointer);
			HEAP32[length >> 2] = bytes.length;
			return pointer;
		} catch (e) { HEAP32[length >> 2] = 0; return 0; }
	},
	QuickGamePackageFree: function (pointer) { _free(pointer); }
});
