using System.Collections.Generic;
using UnityEditor;
using static FileUtility;
using static PlatformUtility;
using static FrameBaseUtility;
public abstract class PlatformInfo : PlatformBase
{
	public static PlatformInfo create()
	{
#if OPPO_MINI_GAME
		return new PlatformWebGLOppo();
#elif VIVO_MINI_GAME
		return new PlatformWebGLVivo();
#else
		throw new System.InvalidOperationException("请先通过游戏平台菜单选择 OPPO 或 vivo");
#endif
	}
	public override void generateFolderPreName()
	{
		mFolderPreName = QuickGameProjectSettings.get().GameFolder + (mTestClient ? "_Test" : "");
	}
	public override string getRemotePathInEditor(string version)
	{
		return QuickGameProjectSettings.get().getRemotePath(mTestClient, version);
	}
	public override string getDefaultPlatformDefine()
	{
		var defines = new HashSet<string>(PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.WebGL).Split(';'));
		defines.Remove("");
		defines.Remove("TEST");
		defines.Remove("ENABLE_HOTFIX");
		return string.Join(";", defines);
	}
	public virtual Dictionary<string, string> getBuildParameters(string version)
	{
		return new()
		{
			{ "AppID", MiniGameSettings.getAppID() },
			{ "包名", MiniGameSettings.getPackageName() },
			{ "激励视频 ID", MiniGameSettings.getRewardedVideoID() },
			{ "插屏 ID", MiniGameSettings.getInterstitialID() },
		};
	}
	//---------
	protected override string getBuildTimePlatformDefineInternal()
	{
		return "";
	}
	protected override void backupAssets()
	{
		base.backupAssets();
		string backupPath = BUILD_TEMP_PATH + mName + "/";
		foreach (string file in findFilesNonAlloc(backupPath))
		{
			string assetPath = mAssetBundleFullPath + file.Substring(backupPath.Length);
			if (!isDynamicDownloadAsset(assetPath))
			{
				recoverFileFromBuildTemp(file);
			}
		}
	}
}
