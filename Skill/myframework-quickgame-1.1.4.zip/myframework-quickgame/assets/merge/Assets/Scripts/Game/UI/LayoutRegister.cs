using System;
using static FrameBase;
using static GameBase;
public class LayoutRegister
{
	public static void registeAllLayout()
	{
		registeLayout<UIDownload>((script) => { mUIDownload = script; });
	}
	//------------------------------------------------------------------------------------------------------------------------------
	protected static void registeLayout<T>(Action<T> callback) where T : GameLayout
	{
		mLayoutManager.registeLayout(typeof(T), typeof(T).ToString(), (script) => { callback?.Invoke(script as T); });
	}
}
