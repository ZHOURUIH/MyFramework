using static FrameBase;
public class Game : GameFramework
{
	public static void startGame()
	{
		Game framework = new();
		GameEntryBase.getInstance().setFrameworkAOT(framework);
		framework.init();
	}
	public override void init()
	{
		mOnRegisteStuff += LayoutRegister.registeAllLayout;
		base.init();
		mOnRegisteStuff -= LayoutRegister.registeAllLayout;
		mAssetVersionSystem.setAssetReadPath(ASSET_READ_PATH.STREAMING_ASSETS_ONLY);
		mGameSceneManager.enterScene<LaunchScene>();
	}
}
