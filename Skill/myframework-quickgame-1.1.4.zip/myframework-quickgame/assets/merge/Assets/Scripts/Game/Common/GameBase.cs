public class GameBase
{
	// FrameComponent
	public static Game mGame;
	public static UIDownload mUIDownload;
}
