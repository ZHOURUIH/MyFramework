public class GameDefine
{
	public static string CDN_URL = QuickGameProjectSettings.get().CdnUrl;
}
