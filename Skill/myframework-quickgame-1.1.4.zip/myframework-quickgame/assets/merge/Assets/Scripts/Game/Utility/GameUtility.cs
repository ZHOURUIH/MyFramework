using static FrameBaseUtility;
public class GameUtility
{
	public static string getRemotePathWithoutURL(string version)
	{
		return QuickGameProjectSettings.get().getRemotePath(isTestClient(), version);
	}
}
