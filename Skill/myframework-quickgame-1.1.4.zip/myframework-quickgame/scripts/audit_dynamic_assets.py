#!/usr/bin/env python3
"""Check initial AB dependency closure against the exact dynamic prefixes and package inventory."""
import argparse
import json
from pathlib import Path


def asset_path(value):
    if not isinstance(value, str) or not value:
        raise ValueError('AB paths must be nonempty strings')
    if value != value.lower() or '\\' in value or value.startswith('/') or ':' in value:
        raise ValueError('Use lowercase relative AB paths with forward slashes: ' + value)
    parts = value.rstrip('/').split('/')
    if any(part in ('', '.', '..') for part in parts):
        raise ValueError('Invalid relative AB path: ' + value)
    return value


def audit(data, require_package=True):
    errors = []
    try:
        raw = data['bundles']
        roots = data['initial_roots']
        prefixes = data['dynamic_prefixes']
        initial_evidence = data['initial_evidence']
        deferred_evidence = data['deferred_evidence']
        if not isinstance(raw, dict) or not raw:
            raise ValueError('bundles must be the nonempty current build dependency map')
        if not isinstance(roots, list) or not roots:
            raise ValueError('initial_roots must not be empty')
        if not isinstance(prefixes, list):
            raise ValueError('dynamic_prefixes must be a list')
        if not isinstance(initial_evidence, dict) or not isinstance(deferred_evidence, dict):
            raise ValueError('Evidence maps are required')
        graph = {}
        for name, dependencies in raw.items():
            asset_path(name)
            if name.endswith('/') or not isinstance(dependencies, list):
                raise ValueError('Each bundle must name a file with a dependency list: ' + name)
            graph[name] = [asset_path(dep) for dep in dependencies]
        roots = [asset_path(root) for root in roots]
        prefixes = [asset_path(prefix) for prefix in prefixes]
        for prefix in prefixes:
            if not prefix.endswith('/') and prefix not in graph:
                errors.append('Prefix must be an exact AB filename or a directory ending in /: ' + prefix)
        for root in roots:
            if root not in graph:
                errors.append('Unknown initial bundle: ' + root)
            evidence = initial_evidence.get(root)
            if not isinstance(evidence, str) or not evidence.strip():
                errors.append('Missing initial usage evidence: ' + root)
        for name, dependencies in graph.items():
            for dep in dependencies:
                if dep not in graph:
                    errors.append('Dependency missing from build inventory: ' + name + ' -> ' + dep)
        dynamic = {name for name in graph if any(name.startswith(prefix) for prefix in prefixes)}
        for prefix in prefixes:
            if not any(name.startswith(prefix) for name in graph):
                errors.append('Dynamic prefix matches no bundle: ' + prefix)
        protected = set()
        witnesses = {}
        queue = [(root, [root]) for root in roots]
        while queue:
            name, chain = queue.pop()
            if name in protected or name not in graph:
                continue
            protected.add(name)
            witnesses[name] = chain
            queue.extend((dep, chain + [dep]) for dep in graph[name])
        for name in sorted(protected & dynamic):
            errors.append('Initial resource marked dynamic: ' + ' -> '.join(witnesses[name]))
        for name in sorted(dynamic):
            evidence = deferred_evidence.get(name)
            if not isinstance(evidence, str) or not evidence.strip():
                errors.append('Missing proven deferred usage evidence: ' + name)
        packaged = data.get('packaged_bundles')
        if packaged is None and require_package:
            errors.append('packaged_bundles must come from the actual exported package; use --plan only before building')
        if packaged is not None:
            if not isinstance(packaged, list):
                raise ValueError('packaged_bundles must be a list')
            packaged = {asset_path(name) for name in packaged}
            for name in sorted(protected - packaged):
                errors.append('Initial bundle absent from package: ' + name)
            for name in sorted(graph.keys() - dynamic - protected - packaged):
                errors.append('Non-dynamic bundle absent from package: ' + name)
            for name in sorted(dynamic & packaged):
                errors.append('Dynamic bundle unexpectedly included in package: ' + name)
            for name in sorted(packaged - graph.keys()):
                errors.append('Packaged bundle not in current build inventory: ' + name)
        return {'mode': 'package' if require_package else 'plan',
                'protected_bundles': sorted(protected), 'dynamic_bundles': sorted(dynamic),
                'errors': errors,
                'limits': 'Checks supplied inventories only; initial coverage, source evidence and offline device behavior require separate verification.'}
    except (KeyError, ValueError, TypeError) as exc:
        return {'errors': ['Invalid audit input: ' + str(exc)]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('inventory', type=Path)
    parser.add_argument('--plan', action='store_true', help='Check before building; does not prove package contents')
    args = parser.parse_args()
    try:
        result = audit(json.loads(args.inventory.read_text(encoding='utf-8-sig')), not args.plan)
    except (OSError, ValueError) as exc:
        result = {'errors': [str(exc)]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if result['errors'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
