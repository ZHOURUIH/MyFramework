#!/usr/bin/env python3
"""Plan or copy project adapters. Never overwrite existing files or colliding GUIDs."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil

def run(project, apply=False):
    project = Path(project).resolve()
    bundle = Path(__file__).resolve().parents[1]
    source = bundle / 'assets/copy'
    if not (project / 'Assets').is_dir() or not (project / 'ProjectSettings').is_dir():
        raise ValueError('Target must be a Unity project with Assets and ProjectSettings.')
    existing_guids = {}
    for base in (project / 'Assets', project / 'Packages'):
        if base.is_dir():
            for path in base.rglob('*.meta'):
                match = re.search(r'^guid: ([0-9a-f]{32})$', path.read_text(encoding='utf-8-sig', errors='replace'), re.M)
                if match: existing_guids.setdefault(match[1], []).append(path)
    actions = []; conflicts = []
    for path in sorted(source.rglob('*')):
        if not path.is_file(): continue
        relative = path.relative_to(source)
        target = (project / relative).resolve()
        if not target.is_relative_to(project): raise ValueError('Invalid bundle path.')
        if target.exists():
            if target.is_file() and hashlib.sha256(target.read_bytes()).digest() == hashlib.sha256(path.read_bytes()).digest():
                actions.append(('same', relative.as_posix()))
            else: conflicts.append({'path':relative.as_posix(), 'reason':'existing content; merge or reuse it'})
            continue
        if path.suffix == '.meta':
            match = re.search(r'^guid: ([0-9a-f]{32})$', path.read_text(encoding='utf-8-sig'), re.M)
            if match and match[1] in existing_guids:
                conflicts.append({'path':relative.as_posix(), 'reason':'GUID already used', 'existing':[str(p) for p in existing_guids[match[1]] ]})
                continue
        actions.append(('copy', relative.as_posix()))
    report = {'project':str(project),'mode':'apply' if apply else 'plan','conflicts':conflicts,'actions':actions,
              'merge_required':[p.relative_to(bundle/'assets/merge').as_posix() for p in (bundle/'assets/merge').rglob('*') if p.is_file()]}
    if apply and not conflicts:
        for action, relative in actions:
            if action == 'copy':
                target = project / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source / relative, target)
    return report

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('project');parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    try:
        report=run(args.project,args.apply)
        print(json.dumps(report,ensure_ascii=False,indent=2))
        raise SystemExit(2 if report['conflicts'] else 0)
    except (OSError, ValueError) as error:
        parser.exit(1,str(error)+'\n')
