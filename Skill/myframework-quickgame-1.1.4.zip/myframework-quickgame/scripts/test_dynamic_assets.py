#!/usr/bin/env python3
"""Regression fixtures for initial-resource protection, not a game runtime test."""
import copy
import unittest
from audit_dynamic_assets import audit


def fixture():
    return {
        'bundles': {'ui/start.ab': ['shared/ui.ab'], 'shared/ui.ab': ['shared/font.ab'],
                    'shared/font.ab': [], 'late/level.ab': ['shared/font.ab']},
        'initial_roots': ['ui/start.ab'],
        'initial_evidence': {'ui/start.ab': 'Startup opens this prefab; source trace captured in project audit.'},
        'dynamic_prefixes': ['late/'],
        'deferred_evidence': {'late/level.ab': 'Only used after the later level unlock; verified loading entry.'},
        'packaged_bundles': ['ui/start.ab', 'shared/ui.ab', 'shared/font.ab'],
    }


class DynamicAssetTests(unittest.TestCase):
    def test_late_bundle_may_depend_on_bundled_shared_asset(self):
        self.assertEqual(audit(fixture())['errors'], [])

    def test_transitive_initial_dependency_cannot_be_dynamic(self):
        data = fixture()
        data['dynamic_prefixes'].append('shared/font.ab')
        self.assertTrue(any('Initial resource marked dynamic' in e and 'shared/font.ab' in e for e in audit(data)['errors']))

    def test_directory_cannot_sweep_initial_bundle(self):
        data = fixture()
        data['dynamic_prefixes'].append('ui/')
        self.assertTrue(any('Initial resource marked dynamic' in e for e in audit(data)['errors']))

    def test_missing_dependency_is_an_error(self):
        data = fixture()
        del data['bundles']['shared/font.ab']
        self.assertTrue(any('Dependency missing' in e for e in audit(data)['errors']))

    def test_new_bundle_in_dynamic_directory_needs_its_own_evidence(self):
        data = fixture()
        data['bundles']['late/unclassified.ab'] = []
        self.assertTrue(any('Missing proven deferred' in e and 'unclassified' in e for e in audit(data)['errors']))

    def test_missing_initial_bundle_in_package_fails(self):
        data = fixture()
        data['packaged_bundles'].remove('shared/font.ab')
        self.assertTrue(any('Initial bundle absent' in e for e in audit(data)['errors']))

    def test_dynamic_bundle_reintroduced_by_sdk_fails(self):
        data = fixture()
        data['packaged_bundles'].append('late/level.ab')
        self.assertTrue(any('unexpectedly included' in e for e in audit(data)['errors']))

    def test_partial_filename_prefix_is_rejected(self):
        data = fixture()
        data['dynamic_prefixes'] = ['late/lev']
        self.assertTrue(any('exact AB filename' in e for e in audit(data)['errors']))

    def test_package_mode_requires_actual_inventory(self):
        data = fixture()
        del data['packaged_bundles']
        self.assertTrue(audit(data)['errors'])
        self.assertEqual(audit(data, require_package=False)['errors'], [])

    def test_no_initial_roots_is_not_proof_of_safety(self):
        data = fixture()
        data['initial_roots'] = []
        self.assertTrue(audit(data)['errors'])

    def test_existing_save_start_must_be_promoted_to_initial(self):
        data = copy.deepcopy(fixture())
        data['initial_roots'].append('late/level.ab')
        data['initial_evidence']['late/level.ab'] = 'Existing save resumes directly into this level.'
        self.assertTrue(any('Initial resource marked dynamic' in e for e in audit(data)['errors']))

    def test_unclassified_bundle_must_stay_packaged(self):
        data = fixture()
        data['bundles']['unclassified/item.ab'] = []
        self.assertTrue(any('Non-dynamic bundle absent' in e for e in audit(data)['errors']))


if __name__ == '__main__':
    unittest.main()
