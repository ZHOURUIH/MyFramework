#!/usr/bin/env python3
"""Verify shipped hashes, GUID closure, shader includes and absence of private keys."""
import argparse
import hashlib
import json
from pathlib import Path
import re

def verify(root):
    root=Path(root).resolve()
    manifest=json.loads((root/'assets/manifest.json').read_text(encoding='utf-8'))
    errors=[]
    patch=manifest.get('framework_patch')
    if patch:
        file=root/patch['path']
        if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest()!=patch['sha256']:
            errors.append('framework source patch hash mismatch')
    for kind in ('copy','merge'):
        actual={p.relative_to(root/'assets'/kind).as_posix() for p in (root/'assets'/kind).rglob('*') if p.is_file()}
        declared={item['path'] for item in manifest[kind+'_files']}
        if actual!=declared:
            errors.append('manifest coverage mismatch: '+kind+' missing='+str(sorted(actual-declared))+' extra='+str(sorted(declared-actual)))
        for item in manifest[kind+'_files']:
            file=root/'assets'/kind/item['path']
            if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest()!=item['sha256']:
                errors.append('hash mismatch: '+kind+'/'+item['path'])
    guids={}
    payload=root/'assets/copy'
    for path in payload.rglob('*.meta'):
        match=re.search(r'^guid: ([0-9a-f]{32})$',path.read_text(encoding='utf-8-sig'),re.M)
        if match:
            if match[1] in guids: errors.append('duplicate GUID: '+match[1])
            guids[match[1]]=path
    for path in payload.rglob('*'):
        if not path.is_file(): continue
        if path.suffix=='.bat':
            raw=path.read_bytes()
            if any(byte<32 and byte not in (9,10,13) for byte in raw): errors.append('BAT contains control bytes: '+str(path))
            if b'\n' in raw.replace(b'\r\n',b''): errors.append('BAT must use CRLF: '+str(path))
            raw.decode('gbk')
        if path.suffix in ('.pem','.key','.p12','.pfx'): errors.append('signing material bundled: '+str(path))
        if path.suffix in ('.cs','.js','.cjs','.json','.asset','.prefab','.txt'):
            text=path.read_text(encoding='utf-8-sig',errors='replace')
            if re.search(r'-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----',text): errors.append('private key contents: '+str(path))
            if path.suffix in ('.asset','.prefab'):
                for guid in set(re.findall(r'guid: ([0-9a-f]{32})',text)):
                    if guid.startswith('0000000000000000'): continue
                    if guid not in guids and guid not in manifest['external_guids']: errors.append('unresolved GUID: '+guid+' in '+str(path))
        if path.suffix in ('.shader','.cginc'):
            text=path.read_text(encoding='utf-8-sig')
            for include in re.findall(r'#include\s+"([^"]+)"',text):
                if include.startswith(('Unity','Lighting','AutoLight','HLSL')): continue
                if not (path.parent/include).is_file(): errors.append('missing shader include: '+include)
    skill=(root/'SKILL.md').read_text(encoding='utf-8')
    for target in re.findall(r'\]\((references/[^)]+)\)',skill):
        if not (root/target).is_file(): errors.append('missing reference: '+target)
    return {'copy_files':len(manifest['copy_files']),'merge_files':len(manifest['merge_files']),'bundled_guids':len(guids),'external_guids':len(manifest['external_guids']),'errors':errors}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('skill',nargs='?',default=str(Path(__file__).resolve().parents[1]))
    args=parser.parse_args();result=verify(args.skill)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(1 if result['errors'] else 0)
