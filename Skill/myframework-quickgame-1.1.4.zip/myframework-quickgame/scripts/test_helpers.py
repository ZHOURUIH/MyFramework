#!/usr/bin/env python3
"""Observable tests for copying, collision handling and nested RPK inspection."""
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from copy_adapter import run
from inspect_rpk import inspect

def zipped(entries):
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
        for name,data in entries.items(): archive.writestr(name,data)
    return output.getvalue()

class HelpersTest(unittest.TestCase):
    def project(self, directory):
        root=Path(directory)
        (root/'Assets').mkdir();(root/'ProjectSettings').mkdir()
        return root
    def test_plan_is_readonly_and_apply_is_idempotent(self):
        with tempfile.TemporaryDirectory() as directory:
            root=self.project(directory)
            plan=run(root)
            self.assertFalse(list((root/'Assets').iterdir()))
            self.assertFalse(plan['conflicts'])
            result=run(root,True)
            self.assertFalse(result['conflicts'])
            again=run(root,True)
            self.assertTrue(all(action=='same' for action,_ in again['actions']))
            self.assertFalse((root/'Assets/Scripts/Game/Game/Game.cs').exists())
    def test_conflict_prevents_all_writes(self):
        with tempfile.TemporaryDirectory() as directory:
            root=self.project(directory)
            file=root/'Assets/Scripts/Game/UI/UIDownload.cs'
            file.parent.mkdir(parents=True);file.write_text('existing game content',encoding='utf-8')
            result=run(root,True)
            self.assertTrue(result['conflicts'])
            self.assertEqual(file.read_text(encoding='utf-8'),'existing game content')
            self.assertFalse((root/'Tools').exists())
    def test_guid_collision_prevents_all_writes(self):
        with tempfile.TemporaryDirectory() as directory:
            root=self.project(directory)
            bundle=Path(__file__).resolve().parents[1]
            source=next((bundle/'assets/copy').rglob('*.meta'))
            (root/'Assets/Existing.meta').write_bytes(source.read_bytes())
            result=run(root,True)
            self.assertTrue(any(item['reason']=='GUID already used' for item in result['conflicts']))
            self.assertFalse((root/'Tools').exists())
    def test_rpk_counts_inner_files_and_rejects_missing_package(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);file=root/'demo.signed.rpk'
            main=zipped({'manifest.json':json.dumps({'package':'demo','versionName':'1.0.0','subpackages':[{'name':'Build'}]}).encode()})
            sub=zipped({'payload':b'data'*1000})
            compat=zipped({'payload':b'compatibility'*1000})
            file.write_bytes(zipped({'main.rpk':main,'Build.rpk':sub,'demo.rpk':compat}))
            result=inspect(file,len(main),len(sub))
            self.assertTrue(result['within_configured_limits'])
            self.assertEqual(result['main_and_subpackages_bytes'],len(main)+len(sub))
            self.assertEqual(len(result['compatibility_packages']),1)
            self.assertFalse(inspect(file,len(main),len(sub)-1)['within_configured_limits'])
            file.write_bytes(zipped({'main.rpk':main,'demo.rpk':compat}))
            with self.assertRaisesRegex(ValueError,'do not match'): inspect(file,10000,10000)

    def test_whole_package_budget_and_dll_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            file=Path(directory)/'renamed.rpk'
            file.write_bytes(zipped({'manifest.json':b'{"package":"demo","versionName":"1.2.3"}',
                                     'StreamingAssets/HotFix.dll.bytes':b'final encrypted payload'}))
            size=file.stat().st_size
            result=inspect(file,1,1,whole_limit=size)
            self.assertEqual(result['mode'],'whole')
            self.assertTrue(result['within_configured_limits'])
            self.assertEqual(result['dll_bytes'][0]['bytes'],23)
            self.assertEqual(len(result['dll_bytes'][0]['sha256']),64)
            self.assertFalse(inspect(file,1,1,whole_limit=size-1)['within_configured_limits'])
            self.assertIsNone(inspect(file,1,1)['within_configured_limits'])
    def test_outer_and_total_budgets_and_renamed_container(self):
        with tempfile.TemporaryDirectory() as directory:
            file=Path(directory)/'renamed.rpk'
            main=zipped({'manifest.json':b'{"package":"demo","subpackages":[{"name":"Build"}]}'})
            sub=zipped({'HotFix.dll.bytes':b'new bytes'})
            compat=zipped({'HotFix.dll.bytes':b'old compatibility bytes'})
            file.write_bytes(zipped({'main.rpk':main,'Build.rpk':sub,'demo.signed.rpk':compat}))
            result=inspect(file,len(main),len(sub),upload_limit=file.stat().st_size-1)
            self.assertFalse(result['within_configured_limits'])
            self.assertEqual(len(result['dll_bytes']),1)
            self.assertEqual(result['dll_bytes'][0]['bytes'],9)
            result=inspect(file,len(main),len(sub),total_limit=len(main)+len(sub)-1)
            self.assertFalse(result['within_configured_limits'])
            self.assertFalse(inspect(file,len(main),len(sub))['upload_budget_checked'])
    def test_main_only_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            file=Path(directory)/'main.rpk'
            file.write_bytes(zipped({'manifest.json':b'{"package":"demo","subpackages":[{"name":"Build"}]}'}))
            with self.assertRaisesRegex(ValueError,'complete container'): inspect(file,10000,10000)

if __name__=='__main__': unittest.main()
