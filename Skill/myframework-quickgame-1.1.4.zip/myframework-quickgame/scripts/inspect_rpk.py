#!/usr/bin/env python3
"""Inspect whole/split RPKs, DLL payloads and independently configured byte budgets."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import zipfile

def read_manifest(archive):
    try:
        return json.loads(archive.read('manifest.json'))
    except KeyError as error:
        raise ValueError('Missing root manifest.json.') from error

def payload(archive, prefix):
    files = []
    dlls = []
    for entry in archive.infolist():
        if entry.is_dir():
            continue
        record = {'path': prefix + entry.filename, 'bytes': entry.file_size,
                  'compressed_bytes': entry.compress_size}
        files.append(record)
        if entry.filename.lower().endswith('.dll.bytes'):
            dlls.append(dict(record, sha256=hashlib.sha256(archive.read(entry)).hexdigest()))
    return files, dlls

def inspect(path, main_limit, sub_limit, upload_limit=None, total_limit=None, whole_limit=None):
    path = Path(path)
    outer = path.stat().st_size
    checks = {}
    files = []
    dlls = []
    with zipfile.ZipFile(path) as archive:
        if 'manifest.json' in archive.namelist():
            manifest = read_manifest(archive)
            if manifest.get('subpackages'):
                raise ValueError('Main-only RPK declares subpackages; provide the complete container.')
            mode = 'whole'
            main_bytes = outer
            sub_bytes = 0
            compatibles = []
            sub_records = []
            files, dlls = payload(archive, '')
            if whole_limit is not None:
                checks['whole'] = outer <= whole_limit
        else:
            mode = 'split'
            entries = [e for e in archive.infolist() if e.filename.lower().endswith('.rpk')]
            main = [e for e in entries if Path(e.filename).name == 'main.rpk']
            if len(main) != 1:
                raise ValueError('Expected exactly one main.rpk or a root manifest.json.')
            with zipfile.ZipFile(io.BytesIO(archive.read(main[0]))) as main_archive:
                manifest = read_manifest(main_archive)
                files, dlls = payload(main_archive, 'main.rpk/')
            expected = {p['name'] + '.rpk' for p in manifest.get('subpackages', [])}
            if not expected:
                raise ValueError('Split container has no declared subpackages.')
            package = manifest.get('package')
            compat_names = {package + '.rpk', package + '.signed.rpk'} if package else set()
            compat = [e for e in entries if e != main[0] and Path(e.filename).name in compat_names]
            sub = [e for e in entries if e != main[0] and e not in compat]
            actual = [Path(e.filename).name for e in sub]
            if expected != set(actual) or len(actual) != len(set(actual)):
                raise ValueError(f'Subpackages do not match manifest: expected={sorted(expected)} actual={sorted(actual)}')
            for entry in sub:
                with zipfile.ZipFile(io.BytesIO(archive.read(entry))) as part:
                    part_files, part_dlls = payload(part, entry.filename + '/')
                    files.extend(part_files)
                    dlls.extend(part_dlls)
            main_bytes = main[0].file_size
            sub_bytes = sum(e.file_size for e in sub)
            compatibles = [{'name': e.filename, 'bytes': e.file_size} for e in compat]
            sub_records = [{'name': e.filename, 'bytes': e.file_size} for e in sub]
            checks['main'] = main_bytes <= main_limit
            checks['subpackages'] = sub_bytes <= sub_limit
            if total_limit is not None:
                checks['main_and_subpackages'] = main_bytes + sub_bytes <= total_limit
    if upload_limit is not None:
        checks['upload'] = outer <= upload_limit
    return {'mode': mode, 'outer_bytes': outer,
            'outer_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'main_bytes': main_bytes, 'subpackages_bytes': sub_bytes,
            'main_and_subpackages_bytes': main_bytes + sub_bytes,
            'compatibility_packages': compatibles, 'subpackages': sub_records,
            'package_name': manifest.get('package'), 'version': manifest.get('versionName'),
            'version_code': manifest.get('versionCode'),
            'main_limit': main_limit, 'subpackages_limit': sub_limit,
            'upload_limit': upload_limit, 'total_limit': total_limit, 'whole_limit': whole_limit,
            'budget_checks': checks,
            'within_configured_limits': all(checks.values()) if checks else None,
            'upload_budget_checked': upload_limit is not None or (mode == 'whole' and whole_limit is not None),
            'payload_top10': sorted(files, key=lambda e: e['bytes'], reverse=True)[:10],
            'dll_bytes': sorted(dlls, key=lambda e: e['bytes'], reverse=True),
            'note': 'Internal package limits do not prove backend acceptance. Release certificate, exact backend byte rules and runtime require separate verification.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('rpk');parser.add_argument('--platform',choices=['oppo','vivo'],required=True)
    for option in ('main', 'sub', 'upload', 'total', 'whole'):
        parser.add_argument('--' + option + '-bytes', type=int)
    args=parser.parse_args()
    defaults=(6,32) if args.platform=='oppo' else (7,40)
    try:
        result=inspect(args.rpk,args.main_bytes if args.main_bytes is not None else defaults[0]*1024**2,args.sub_bytes if args.sub_bytes is not None else defaults[1]*1024**2,args.upload_bytes,args.total_bytes,args.whole_bytes)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        raise SystemExit(2 if result['within_configured_limits'] is False else 0)
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile) as error: parser.exit(1,str(error)+'\n')
