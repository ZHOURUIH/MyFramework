---
name: myframework-quickgame
description: 将使用 MyFramework 的 Unity 游戏适配到 OPPO/vivo 快游戏，提供可复制的项目代码、下载与热更启动流程、启动页、隐私界面、统一广告、文件访问桥接、签名和 RPK 分包打包。用于新接入或继续已有平台接入；完整游戏迁移另按迁移任务处理。
---

# MyFramework OPPO / vivo 快游戏接入

版本 1.1.4。先读目标工程，再使用随附模板；交付能编译、能打包、能运行的项目适配。默认保持框架只读，平台差异放在项目内通过宏区分；用户明确要求完善框架时修改真实框架源工程，不能补丁 PackageCache。

## 随附内容与阅读路线

- 接入新工程或整合已有接入：读 [integration.md](references/integration.md)。代码在 `assets/copy/`，入口合并模板在 `assets/merge/`。不要只给解释而不完成用户已授权的代码接入。
- 启动、断网、启动页和隐私：读 [startup-ui.md](references/startup-ui.md)。三个 prefab、字体及图片依赖已附带；美术是原工程示例，其他游戏必须换成自己的资源。
- 全部玩家可见文字汉化、字库与中文排版：读 [localization.md](references/localization.md)。覆盖 AOT/HotFix、prefab、代码、CSV/bytes 和图片内文字；不能只检查启动页或字体。
- SDK、平台打包、证书、分包与包体：读 [build.md](references/build.md)。动态 AB 划分或目录调整必须另读 [dynamic-assets.md](references/dynamic-assets.md)，先保护初期资源闭包，再检查清单与实际包。正式签名由菜单一次生成；包内没有私钥或上传密钥。
- 广告、后台间隔、暂停恢复和文件访问：读 [runtime.md](references/runtime.md)。后台数据协议可选，不是所有游戏都使用同一后台。
- 模拟器导入、测试 BAT 与日志定位：读 [emulator-testing.md](references/emulator-testing.md)。vivo 需要官方外部引擎；先核对实际运行的包名/版本，避免测试旧包。
- 验收或处理构建故障：读 [validation.md](references/validation.md)。区分源代码验证、实际 RPK 构建、设备验证三个层次。

`assets/manifest.json` 记录来源、文件哈希、GUID 和所需框架能力。1.1.2 的平台模板调用现有 `PlatformInternal_Oppo/Vivo`，要求分包切换、远端动态策略和快游戏异步包内文件读取能力；按 integration.md 核对 API，不能只按 commit 判断兼容。旧的 remote-dynamic 补丁仅针对原基线，不能替代新版平台构建能力。

复核此技能代码包时运行 `python scripts/verify_bundle.py`、`python scripts/test_helpers.py`、`python scripts/test_dynamic_assets.py`；OPPO JS 回归运行 `node --test assets/copy/Tools/Build/OppoRuntimeCompat.test.cjs`。这些不执行游戏打包或改动目标工程。

## 必须保留的约束

1. 启动顺序为平台分包加载 → Unity Game/AOT → UIDownload → 版本/完整文件列表/远端动态列表/资源检查 → HotFix → 启动页显示满 2 秒 → 游戏场景。当前 RagdollArchers 在 HotFix 启动页首次可见时，仅 OPPO 且本地未保存同意记录才自动弹出隐私协议；此时只显示“同意/不同意”，同意保存记录并继续，拒绝退出。玩家主动点击入口查看同一协议时只显示“关闭”，关闭不修改同意记录或退出；vivo 不需要首次弹窗。协议加载中或打开时不推进启动页计时。其他项目按产品要求决定是否启用首次同意；详见 [startup-ui.md](references/startup-ui.md)。启动 GameScene 只注册 Loading/Exit 流程，UI 加载、计时、隐私门槛和清理放进对应 SceneProcedure；不要把 2 秒放在下载开始之前。
2. 无网络或远端请求失败时回到内置版本，保留启动和初期玩法所需的完整资源。内置资源、热更 DLL、AOT 补充数据、版本、FileList、动态密钥必须来自同一构建。首次离线能否运行还取决于平台分包是否已交付/缓存；后期资源按第 10 条延迟下载，不把它们变成首次进入游戏前的必下载项。
3. 使用框架现有 `MiniGameSettings`、`MiniGamePlatform`、`QuickGameFileSystem`、`MiniGamePlayerPrefs`、`FileUtility`、`PrefsUtility`。不要把框架源码再复制到 Assets，也不修改 PackageCache。项目附带的 `.jslib` 补齐平台桥接符号。
4. 主包和分包都使用平台正式打包器签名。不能先签名再修改 RPK 或手动删掉兼容包；上传完整的外层 `.signed.rpk`。分别统计主包、分包、兼容整包与外层上传文件；内部预算通过不代表后台上传通过。分包或整包由已有发布窗口选择，AB 默认 LZ4，不能改成 LZMA。
5. 每个平台只启用一个平台宏；SDK C# 程序集、插件 DLL 和原生 JS 插件都要隔离。框架 `QuickGamePluginScope` 只负责构建期间的原生插件隔离，不替代常驻 asmdef/PluginImporter 条件。
6. UI 使用框架生成器生成成员、节点绑定、回调与注册；不要手写或改写 `auto generate` 区域。UI 类直接继承 `LayoutScript`，不继承业务 UI 类。按钮使用 `LegendButton`，滚动使用 `myUGUIDragView`。
7. 适配以 `ScaleAnchor` 等比缩放为主，只有铺满背景不保持宽高比。AOT 下载页使用 `ResScaleAnchor`。`PaddingAnchor` 仅用于明确固定屏幕边缘的少数节点，不作为布局工具；不用 UGUI stretch/锚点和 anchoredPosition3D 做适配。OPPO/vivo 实际设备上的下载、启动和游戏画面都必须覆盖可用显示区域，不能出现适配造成的黑边；内容保持比例，铺满背景可单独拉伸或裁剪，具体排查和验收见 [validation.md](references/validation.md)。
8. 业务层不增加 MonoBehaviour、自定义命名空间或另一套 pool。GBR 只放全局对象，不放状态。每类单独文件，不添加 sealed；函数用完整方法体；函数间和代码中没有无意义空行。非虚 protected/private 放在文件下部，用 `//---------` 与公开接口分隔。保留框架自动生成标记。
9. 插屏只在用户指定业务节点调用，不由远端配置制造额外入口。所有玩家主动点击后会播放激励广告的按钮，应有清晰可辨的广告/视频图标，不能只显示奖励数值或普通领取文案；按 [runtime.md](references/runtime.md) 验收。Editor 点击激励直接走成功回调方便业务测试；Player 激励必须完整观看且成功回调才发奖；广告结束/失败/销毁先恢复原暂停、音频状态，再继续业务。
10. 所有适用的包体优化完成后仍超过平台限制，剔除初期不会使用的 AB 及其非初期依赖，在打包配置 `FrameSettings.DynamicDownloadList` 中列出。发布流程自动生成同版本的远端 `DynamicDownloadList.json` 并上传全部 AB；客户端启动更新只使用远端列表，不能读安装包 FrameSettings 决定忽略目录。只在业务实际需要加载时远端下载并加载，成功后复用持久缓存。按 [build.md](references/build.md) 核对依赖、包内过滤、远端清单和离线回退；**初期资源及其全部传递依赖绝不能标为动态下载。** 无法证明只在后期使用的资源默认内置；混装 AB 先合理拆分并保持引用、路径、画面与玩法。初期范围、实际依赖和动态目录展开按 [dynamic-assets.md](references/dynamic-assets.md) 留证并通过检查及无远端缓存离线验收，不能仅缩小文件却破坏初期玩法。
11. 面向中文发行的接入默认将**所有游戏自身控制的玩家可见文字汉化**，包括下载/更新、启动、主界面、教程、设置/暂停、升级、武器/道具、结算、排行榜、广告引导与错误/重试提示。覆盖 prefab/场景序列化文本、代码动态文本、CSV 配置及其生成 bytes、图片内文字和可见的远端文案。按 [localization.md](references/localization.md) 检查漏译、字库、排版和实际 RPK；不靠隐藏文字或删除功能完成汉化。用户明确要求其他语言时遵从其语言范围；代码标识符、协议字段和玩家昵称不因汉化改名。

## 工作步骤

1. 确认已有入口、Game/HotFix/Editor 程序集、平台 SDK、设置资产、主场景和资源打包方式。整理已有代码与模板的重合处。
2. 运行 `python scripts/copy_adapter.py <工程路径>` 看复制计划。先解决冲突；`--apply` 仅复制无冲突文件，不覆盖已有文件，不自动合并入口。已有同 GUID 的字体/图片应复用并重绑定 prefab，不能强行导入第二份。
3. 确认框架已具备远端动态策略能力，再合并 `assets/merge/` 的入口、布局注册、全局对象和 PlatformInfo；保留目标游戏系统。填写两份 settings，替换启动图、图标和隐私全文；产品要求首次同意时先修改隐私 prefab，再执行框架 UI 生成器。按 localization.md 梳理并汉化完整玩家文案，重新生成相关表格 bytes、字库和资源包。
4. 平台构建复用框架实现，不新增重复打包窗口、队列和工具类。分别切换 OPPO/vivo 编译。完成下载启动、离线回退、广告回调、暂停恢复。复用已有发布窗口读取配置并按选择生成正式整包或分包 RPK；版本和补充元数据不能混用其他平台或旧轮构建。优化后仍超限时执行非初期 AB 按需下载方案，直至包体满足目标限额或明确指出无法移除的初期资源。
5. 采用动态 AB 时先运行 `scripts/audit_dynamic_assets.py` 检查本轮清单，实测无远端缓存的离线初期流程与按需下载；任何初期遗漏必须修复。用 `scripts/inspect_rpk.py` 检查结构与配置限额，在对应调试器/设备验证界面、文字、输入、存档、玩法和广告。用户只要求整理 skill 时，验证 skill 和模板即可，不主动重打其项目。

## 完成标准

实际接入任务结束时报告：改了哪些文件、哪项配置还需产品提供、包路径和各包大小、使用的签名、已验证环境及尚未验证项目。汉化交付说明覆盖的界面/文案来源、字库与排版验证、保留原文的合理例外和实际包验收结果；搜索未发现英文不等于汉化通过。采用动态 AB 时附初期范围/内置依赖闭包、动态前缀的逐包依据、拆分结果、实际包内核对及无远端缓存离线回归结果；未验证项不能写成已完成。只有模拟器或源代码编译通过时，不宣称真机、后台审核或真实广告已通过。

## 怎样使用

把整个 `myframework-quickgame` 文件夹安装到 Codex 的 skills 目录，在目标工程会话中明确工程路径和任务即可。可直接发送的示例：

- 新工程：`使用 $myframework-quickgame 将 E:/Games/MyGame 接入 OPPO/vivo。复用已有发布窗口，启动下载后进入热更启动页 2 秒，协议仅点击查看。先核对框架能力和首屏资源，再接入并测试。`
- 首次同意：`使用 $myframework-quickgame 为当前工程接入 OPPO 首次隐私同意：启动页自动弹出，同意后保存并继续，拒绝退出；vivo 隐藏入口。请用 UGUIGenerator 重新生成隐私 UI，并验证重启行为。`
- 已接入工程：`使用 $myframework-quickgame 补齐当前工程的分包选择、DLL bytes 拷贝和离线回退。先对照现有实现，只修改缺失部分，保留已有业务和签名。`
- 故障：`使用 $myframework-quickgame 检查这个 RPK 无法进入的问题。包路径是…，卡在…。先在模拟器确认包名/版本并采集日志，再定位并最小修复。`

skill 是工作指引和模板，不是一次点击就完成转换的工具。`copy_adapter.py --apply` 仅复制无冲突文件；入口、已有 UI/平台类仍需按工程合并，不能整包覆盖现有代码。用户只要求整理 skill 时，完成技能及资源验证，不启动游戏完整打包或上传。
